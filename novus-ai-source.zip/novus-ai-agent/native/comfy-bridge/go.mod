module github.com/1152379211-jpg/novus-ai/comfy-bridge

go 1.25.0
