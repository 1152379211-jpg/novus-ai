package main

import (
	"log"

	"github.com/1152379211-jpg/novus-ai/config"
	"github.com/1152379211-jpg/novus-ai/handler"
	"github.com/1152379211-jpg/novus-ai/router"
	"github.com/1152379211-jpg/novus-ai/service"
)

func main() {
	if err := config.Load(); err != nil {
		log.Fatal(err)
	}
	if err := service.EnsureDefaultAdmin(); err != nil {
		log.Fatal(err)
	}
	if err := service.EnsureDefaultAgentSkills(); err != nil {
		log.Fatal(err)
	}
	service.StartPromptSyncScheduler()
	service.StartCanvasProjectCleanupScheduler()
	handler.StartVideoTaskPoller()
	log.Fatal(router.New().Run(":" + config.Cfg.Port))
}
