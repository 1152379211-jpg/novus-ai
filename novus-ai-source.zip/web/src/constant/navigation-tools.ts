import { FileText, ImagePlus, Images, Maximize2, Music2, Video } from "lucide-react";

export const navigationTools = [
    {
        slug: "canvas",
        label: "我的画布",
        icon: Maximize2,
    },
    {
        slug: "image",
        label: "生图工作台",
        icon: ImagePlus,
    },
    {
        slug: "video",
        label: "视频创作台",
        icon: Video,
    },
    {
        slug: "music",
        label: "音乐创作台",
        icon: Music2,
    },
    {
        slug: "prompts",
        label: "提示词库",
        icon: FileText,
    },
    {
        slug: "assets",
        label: "我的素材",
        icon: Images,
    },
] as const;

export type NavigationToolSlug = (typeof navigationTools)[number]["slug"];

// 功能未上线，导航先置灰禁点（boss 2026-10-04：画布外的这些全部调黑，后续再添加）
export const disabledNavSlugs: ReadonlySet<string> = new Set(["image", "video", "prompts", "assets"]);
