"use client";

import { create } from "zustand";
import { persist, type PersistStorage, type StorageValue } from "zustand/middleware";

import { nanoid } from "nanoid";
import { localForageStorage } from "@/lib/localforage-storage";
import { cleanupUnusedImages, resolveImageUrl, uploadImage } from "@/services/image-storage";
import { cleanupUnusedMedia, resolveMediaUrl } from "@/services/file-storage";
import { fetchUserAssetData, syncUserAssetData } from "@/services/api/user-config";
import { useUserStore } from "@/stores/use-user-store";

export type AssetKind = "text" | "image" | "video" | "audio";
export type TextAsset = AssetBase<"text"> & { data: { content: string } };
export type ImageAsset = AssetBase<"image"> & { data: { dataUrl: string; storageKey?: string; width: number; height: number; bytes: number; mimeType: string } };
export type VideoAsset = AssetBase<"video"> & { data: { url: string; storageKey?: string; width: number; height: number; bytes: number; mimeType: string } };
export type AudioAsset = AssetBase<"audio"> & { data: { url: string; storageKey?: string; bytes?: number; mimeType: string; durationMs?: number } };
export type Asset = TextAsset | ImageAsset | VideoAsset | AudioAsset;

type AssetBase<T extends AssetKind> = {
    id: string;
    kind: T;
    title: string;
    coverUrl: string;
    tags: string[];
    category?: string;
    source?: string;
    createdAt: string;
    updatedAt: string;
    metadata?: Record<string, unknown>;
};

export type HostAssetImportResult = { ok: boolean; message?: string };

type AssetStore = {
    assets: Asset[];
    addAsset: (asset: Omit<Asset, "id" | "createdAt" | "updatedAt">) => string;
    addAssetAsync: (asset: Omit<Asset, "id" | "createdAt" | "updatedAt">) => Promise<HostAssetImportResult>;
    updateAsset: (id: string, patch: Partial<Omit<Asset, "id" | "createdAt">>) => void;
    removeAsset: (id: string) => void;
    hydrateAccountAssets: (token: string, syncEnabled?: boolean) => Promise<void>;
    syncAccountAssets: (token: string) => Promise<void>;
    stopAccountAssetSync: () => void;
    cleanupImages: (extra?: unknown, storageKeys?: ReadonlyMap<string, string>, ownerToken?: string) => void;
};

const ASSET_STORE_KEY = "novus-ai:asset_store";
let activeAssetSyncToken = "";
let accountAssetSyncEnabled = false;
let isHydratingAccountAssets = false;
let syncTimer: number | null = null;

type AssetSnapshot = { assets: Asset[] };

async function resolveStoredAsset(asset: Asset): Promise<Asset> {
    if (asset.kind === "video" && asset.data.storageKey) return { ...asset, data: { ...asset.data, url: await resolveMediaUrl(asset.data.storageKey, asset.data.url) } };
    if (asset.kind === "audio" && asset.data.storageKey) return { ...asset, data: { ...asset.data, url: await resolveMediaUrl(asset.data.storageKey, asset.data.url) } };
    if (asset.kind !== "image") return asset;
    if (asset.data.storageKey)
        return {
            ...asset,
            coverUrl: asset.coverUrl.startsWith("blob:") ? await resolveImageUrl(asset.data.storageKey, asset.coverUrl) : asset.coverUrl,
            data: { ...asset.data, dataUrl: await resolveImageUrl(asset.data.storageKey, asset.data.dataUrl) },
        };
    if (!asset.data.dataUrl.startsWith("data:image/")) return asset;
    const image = await uploadImage(asset.data.dataUrl);
    return { ...asset, coverUrl: asset.coverUrl.startsWith("data:image/") ? image.url : asset.coverUrl, data: { ...asset.data, dataUrl: image.url, storageKey: image.storageKey, bytes: image.bytes, mimeType: image.mimeType } };
}

const assetStorage: PersistStorage<AssetStore> = {
    getItem: async (name) => {
        const value = await localForageStorage.getItem(name);
        if (!value) return null;
        const parsed = JSON.parse(value) as StorageValue<AssetStore>;
        parsed.state.assets = await Promise.all(parsed.state.assets.map(resolveStoredAsset));
        return parsed;
    },
    setItem: (name, value) => localForageStorage.setItem(name, JSON.stringify(value)),
    removeItem: (name) => localForageStorage.removeItem(name),
};

export const useAssetStore = create<AssetStore>()(
    persist(
        (set, get) => ({
            assets: [],
            addAsset: (asset) => {
                // 023：嵌入宿主时，非文本素材统一入宿主「我的资产」池（本地不再单独存媒体，等宿主推送刷新）
                if (embeddedInAssetHost() && asset.kind !== "text") {
                    void forwardAssetImportToHost(asset as Asset);
                    return `host-pending-${nanoid()}`;
                }
                const now = new Date().toISOString();
                const id = nanoid();
                set((state) => ({ assets: [{ ...asset, id, createdAt: now, updatedAt: now } as Asset, ...state.assets] }));
                scheduleAssetSync(get);
                return id;
            },
            addAssetAsync: async (asset) => {
                if (embeddedInAssetHost() && asset.kind !== "text") {
                    return await forwardAssetImportToHost(asset as Asset, `asset-import-${nanoid()}`);
                }
                const now = new Date().toISOString();
                const id = nanoid();
                set((state) => ({ assets: [{ ...asset, id, createdAt: now, updatedAt: now } as Asset, ...state.assets] }));
                scheduleAssetSync(get);
                return { ok: true };
            },
            updateAsset: (id, patch) => {
                // 023：宿主镜像资产以「我的资产」页为编辑入口，画布侧不改
                if (id.startsWith(HOST_ASSET_PREFIX)) return;
                set((state) => {
                    const assets = state.assets.map((asset) => (asset.id === id ? ({ ...asset, ...patch, updatedAt: new Date().toISOString() } as Asset) : asset));
                    window.setTimeout(() => scheduleAssetSync(get), 0);
                    return { assets };
                });
            },
            removeAsset: (id) => {
                // 023：宿主镜像资产删除 → 转发宿主池，本地先行移除（宿主推送后以宿主为准）
                if (id.startsWith(HOST_ASSET_PREFIX)) {
                    if (embeddedInAssetHost()) {
                        window.parent.postMessage({ source: CANVAS_MESSAGE_SOURCE, type: "asset-delete", payload: { id: id.slice(HOST_ASSET_PREFIX.length) } }, "*");
                    }
                    set((state) => ({ assets: state.assets.filter((asset) => asset.id !== id) }));
                    return;
                }
                set((state) => {
                    const deletedAsset = state.assets.find((asset) => asset.id === id);
                    const assets = state.assets.filter((asset) => asset.id !== id);

                    if (deletedAsset && deletedAsset.kind !== "text" && deletedAsset.data.storageKey) {
                        const key = deletedAsset.data.storageKey;
                        window.setTimeout(async () => {
                            const { useCanvasStore } = await import("@/app/(user)/canvas/stores/use-canvas-store");
                            const usedKeys = new Set<string>();
                            // 收集其余资产的 storageKey
                            assets.forEach((a) => {
                                if (a.kind !== "text" && a.data.storageKey) usedKeys.add(a.data.storageKey);
                            });
                            // 收集画布中引用的 storageKey
                            const projects = useCanvasStore.getState().projects;
                            const { collectImageStorageKeys } = await import("@/services/image-storage");
                            const { collectMediaStorageKeys } = await import("@/services/file-storage");
                            collectImageStorageKeys(projects, usedKeys);
                            collectMediaStorageKeys(projects, usedKeys);

                            // 收集本地/云端生图历史与视频历史中的 storageKey，避免生成结果卡片失效
                            try {
                                const localforage = (await import("localforage")).default;
                                const imageLogStore = localforage.createInstance({ name: "novus-ai", storeName: "image_generation_logs" });
                                await imageLogStore.iterate((log: any) => {
                                    if (log) {
                                        if (Array.isArray(log.images)) {
                                            log.images.forEach((img: any) => {
                                                if (img && img.storageKey) usedKeys.add(img.storageKey);
                                            });
                                        }
                                        if (Array.isArray(log.references)) {
                                            log.references.forEach((ref: any) => {
                                                if (ref && ref.storageKey) usedKeys.add(ref.storageKey);
                                            });
                                        }
                                    }
                                });
                            } catch (e) {
                                console.error("Error iterating image_generation_logs", e);
                            }

                            try {
                                const localforage = (await import("localforage")).default;
                                const videoLogStore = localforage.createInstance({ name: "novus-ai", storeName: "video_generation_logs" });
                                await videoLogStore.iterate((log: any) => {
                                    if (log) {
                                        if (log.video && log.video.storageKey) {
                                            usedKeys.add(log.video.storageKey);
                                        }
                                        if (Array.isArray(log.references)) {
                                            log.references.forEach((ref: any) => {
                                                if (ref && ref.storageKey) usedKeys.add(ref.storageKey);
                                            });
                                        }
                                    }
                                });
                            } catch (e) {
                                console.error("Error iterating video_generation_logs", e);
                            }

                            // 若全站没有其他地方再引用此 storageKey，则执行真正的物理删除
                            if (!usedKeys.has(key)) {
                                if (key.startsWith("image:") || key.startsWith("server:")) {
                                    const { deleteStoredImages } = await import("@/services/image-storage");
                                    await deleteStoredImages([key]);
                                }
                                if (key.startsWith("file:") || key.startsWith("video:") || key.startsWith("server:")) {
                                    const { deleteStoredMedia } = await import("@/services/file-storage");
                                    await deleteStoredMedia([key]);
                                }
                            }
                        }, 0);
                    }

                    window.setTimeout(() => scheduleAssetSync(get), 0);
                    return { assets };
                });
            },
            hydrateAccountAssets: async (token, syncEnabled = false) => {
                if (!token) return;
                activeAssetSyncToken = token;
                accountAssetSyncEnabled = syncEnabled;
                isHydratingAccountAssets = true;
                try {
                    const remote = await fetchUserAssetData<AssetSnapshot>(token);
                    const remoteAssets = await Promise.all(
                        (Array.isArray(remote?.assets) ? remote.assets : []).map((asset) =>
                            asset.kind === "image" && asset.data.storageKey?.startsWith("image:") ? resolveStoredAsset(asset) : asset,
                        ),
                    );
                    if (syncEnabled) {
                        set({ assets: remoteAssets });
                    } else {
                        const localHasAssets = get().assets.length > 0;
                        if (!localHasAssets && remoteAssets.length) {
                            set({ assets: remoteAssets });
                        }
                    }
                } finally {
                    isHydratingAccountAssets = false;
                }
            },
            syncAccountAssets: async (token) => {
                if (!token || !accountAssetSyncEnabled) return;
                await syncUserAssetData(token, { assets: get().assets });
            },
            stopAccountAssetSync: () => {
                activeAssetSyncToken = "";
                if (syncTimer) window.clearTimeout(syncTimer);
                syncTimer = null;
            },
            cleanupImages: (extra, storageKeys, ownerToken) => {
                window.setTimeout(async () => {
                    const { useCanvasStore } = await import("@/app/(user)/canvas/stores/use-canvas-store");
                    const { loadLocalAgentSkills, useAgentSkillStore } = await import("@/stores/use-agent-skill-store");
                    const logKeys: string[] = [];
                    try {
                        const localforage = (await import("localforage")).default;
                        const imageLogStore = localforage.createInstance({ name: "novus-ai", storeName: "image_generation_logs" });
                        await imageLogStore.iterate((log: any) => {
                            if (log) {
                                if (Array.isArray(log.images)) {
                                    log.images.forEach((img: any) => {
                                        if (img && img.storageKey) logKeys.push(img.storageKey);
                                    });
                                }
                                if (Array.isArray(log.references)) {
                                    log.references.forEach((ref: any) => {
                                        if (ref && ref.storageKey) logKeys.push(ref.storageKey);
                                    });
                                }
                            }
                        });
                        const videoLogStore = localforage.createInstance({ name: "novus-ai", storeName: "video_generation_logs" });
                        await videoLogStore.iterate((log: any) => {
                            if (log) {
                                if (log.video && log.video.storageKey) {
                                    logKeys.push(log.video.storageKey);
                                }
                                if (Array.isArray(log.references)) {
                                    log.references.forEach((ref: any) => {
                                        if (ref && ref.storageKey) logKeys.push(ref.storageKey);
                                    });
                                }
                            }
                        });
                    } catch (e) {
                        console.error("Error gathering log keys in cleanupImages", e);
                    }

                    try {
                        await useAgentSkillStore.getState().loadSkills();
                        const skillStore = useAgentSkillStore.getState();
                        const localSkills = useUserStore.getState().token ? await loadLocalAgentSkills() : [];
                        await cleanupUnusedImages({ assets: get().assets, projects: useCanvasStore.getState().projects, skills: [...skillStore.systemSkills, ...skillStore.userSkills, ...localSkills], extra, logKeys }, storageKeys, ownerToken);
                    } catch (error) {
                        console.error("Error gathering Skill keys in cleanupImages", error);
                    }
                    await cleanupUnusedMedia({ assets: get().assets, projects: useCanvasStore.getState().projects, extra, logKeys });
                }, 0);
            },
        }),
        {
            name: ASSET_STORE_KEY,
            storage: assetStorage,
            partialize: (state) => ({ assets: state.assets }) as StorageValue<AssetStore>["state"],
        },
    ),
);

function scheduleAssetSync(get: () => AssetStore) {
    if (isHydratingAccountAssets || !activeAssetSyncToken || !accountAssetSyncEnabled || typeof window === "undefined") return;
    if (syncTimer) window.clearTimeout(syncTimer);
    syncTimer = window.setTimeout(() => {
        void get().syncAccountAssets(activeAssetSyncToken).catch(() => {});
    }, 600);
}

// ===== 023（boss 2026-10-04 21:26）：与宿主「我的资产」池合并 =====
// 嵌入Novus AI 宿主时，宿主资产池（外壳「我的资产」页 assets.json）是唯一数据源：
// 画布侧展示 = 宿主 asset-list 推送的镜像 + 本地文本素材；画布里新增/删除都会转发宿主落盘。
type HostAssetRecord = {
    id?: string;
    name?: string;
    aliases?: string[];
    kind?: string;
    mediaKind?: string;
    mimeType?: string;
    size?: number;
    canvasUrl?: string;
    filePath?: string;
    createdAt?: string;
    updatedAt?: string;
};

const HOST_ASSET_PREFIX = "host:";
const HOST_MESSAGE_SOURCE = "kinglevel-host";
const CANVAS_MESSAGE_SOURCE = "kinglevel-canvas";

function embeddedInAssetHost(): boolean {
    return typeof window !== "undefined" && !!window.parent && window.parent !== window;
}

function mapHostAssetToCanvasAsset(record: HostAssetRecord): Asset | null {
    const url = String(record.canvasUrl || "");
    const mediaKind = String(record.mediaKind || "");
    const hostId = String(record.id || "");
    if (!url || !hostId || !mediaKind) return null;
    const category = ["character", "scene", "clothing", "prop", "other"].includes(String(record.kind)) ? String(record.kind) : undefined;
    const updatedAt = String(record.updatedAt || record.createdAt || new Date().toISOString());
    const base = {
        id: `${HOST_ASSET_PREFIX}${hostId}`,
        title: String(record.name || "未命名资产"),
        coverUrl: mediaKind === "image" ? url : "",
        tags: [] as string[],
        category,
        source: "我的资产",
        createdAt: String(record.createdAt || updatedAt),
        updatedAt,
        metadata: { hostAssetId: hostId },
    };
    if (mediaKind === "image") {
        return { ...base, kind: "image", data: { dataUrl: url, width: 0, height: 0, bytes: Number(record.size) || 0, mimeType: String(record.mimeType || "image/*") } };
    }
    if (mediaKind === "video") {
        return { ...base, kind: "video", data: { url, width: 0, height: 0, bytes: Number(record.size) || 0, mimeType: String(record.mimeType || "video/mp4") } };
    }
    if (mediaKind === "audio") {
        return { ...base, kind: "audio", data: { url, bytes: Number(record.size) || 0, mimeType: String(record.mimeType || "audio/mpeg") } };
    }
    return null;
}

/**
 * 宿主「我的资产」推送 → 画布本地镜像。
 * 宿主在 canvas-ready 回复 asset-list，之后增/删/改也会主动推 asset-create / asset-update / asset-delete。
 * 画布侧保留本地文本素材，镜像资产以宿主数据为准（同一 id 覆盖）。
 */
function mirrorHostAssets(records: HostAssetRecord[]): void {
    const mapped = (Array.isArray(records) ? records : [])
        .filter((record) => record && !record.deletedAt)
        .map((record) => mapHostAssetToCanvasAsset(record))
        .filter((asset): asset is Asset => Boolean(asset));
    useAssetStore.setState((state) => {
        const hostIds = new Set(mapped.map((asset) => asset.id));
        const rest = state.assets.filter((asset) => !hostIds.has(asset.id) && !String(asset.id).startsWith(HOST_ASSET_PREFIX));
        return { assets: [...mapped, ...rest] };
    });
}

async function arrayBufferToBase64(buffer: ArrayBuffer): Promise<string> {
    const bytes = new Uint8Array(buffer);
    let binary = "";
    const chunkSize = 0x8000;
    for (let index = 0; index < bytes.length; index += chunkSize) {
        binary += String.fromCharCode(...bytes.subarray(index, index + chunkSize));
    }
    return btoa(binary);
}

// 039：storageKey 反解成宿主可取到文件的协议地址（local-image:<sha> → intl-canvas://image/<sha>）
function storageKeyToHostUrl(storageKey: string): string {
    const key = String(storageKey || "").trim();
    const matched = /^local-image:([a-f0-9]{40,64})$/i.exec(key);
    if (matched) return `intl-canvas://image/${matched[1]}`;
    return /^(intl-canvas|intl-media):/i.test(key) ? key : "";
}

// 039：保存素材时 dataUrl 常被 storageKey 顶掉（存成空串），这里按优先级兜底出可用的文件地址
function resolveHostAssetSource(asset: Asset): string {
    const data = (asset.data || {}) as { dataUrl?: string; url?: string; storageKey?: string };
    if (asset.kind === "image") {
        return String(data.dataUrl || "") || String(asset.coverUrl || "") || storageKeyToHostUrl(String(data.storageKey || ""));
    }
    if (asset.kind === "video" || asset.kind === "audio") {
        return String(data.url || "") || storageKeyToHostUrl(String(data.storageKey || ""));
    }
    return "";
}

// 039 修复：画布里新导入的图片/媒体本体存在画布自己的 localForage（local-image:* 等键），
// 宿主的 intl-canvas:// 协议只对「宿主落盘过」的文件有效（canvas-materials 目录），
// 所以取文件内容必须优先走画布本地存储，协议地址只作兜底。
async function resolveHostAssetBlob(asset: Asset): Promise<Blob | null> {
    const data = (asset.data || {}) as { dataUrl?: string; url?: string; storageKey?: string; mimeType?: string };
    const storageKey = String(data.storageKey || "").trim();
    if (storageKey && !/^https?:/i.test(storageKey)) {
        try {
            if (asset.kind === "image") {
                const { getImageBlob } = await import("@/services/image-storage");
                const blob = await getImageBlob(storageKey);
                if (blob && blob.size) return blob;
            } else if (asset.kind === "video" || asset.kind === "audio") {
                const { getMediaBlob } = await import("@/services/file-storage");
                const blob = await getMediaBlob(storageKey);
                if (blob && blob.size) return blob;
            }
        } catch {
            // 本地存储未命中则继续走地址兜底
        }
    }
    const source = resolveHostAssetSource(asset);
    if (!source) return null;
    if (source.startsWith("data:")) {
        return await (await fetch(source)).blob();
    }
    if (/^https?:/i.test(source) || /^(intl-canvas|intl-media):/i.test(source)) {
        return await fetch(source)
            .then((response) => (response.ok ? response.blob() : null))
            .catch(() => null);
    }
    return null;
}

const pendingHostImports = new Map<string, { resolve: (result: HostAssetImportResult) => void; timer: number }>();

function waitForHostImportReply(requestId: string, timeout = 30000): Promise<HostAssetImportResult> {
    return new Promise((resolve) => {
        const timer = window.setTimeout(() => {
            pendingHostImports.delete(requestId);
            resolve({ ok: false, message: "同步超时，素材没有写入我的资产" });
        }, timeout);
        pendingHostImports.set(requestId, {
            resolve: (result) => {
                window.clearTimeout(timer);
                resolve(result);
            },
            timer,
        });
    });
}

// 画布新增素材 → 交给宿主落盘入库（宿主导入 imports 目录并登记 assets.json，随后推送新列表）
async function forwardAssetImportToHost(asset: Asset, requestId: string): Promise<HostAssetImportResult> {
    try {
        if (!embeddedInAssetHost() || asset.kind === "text") return { ok: false, message: "当前环境无法同步到我的资产" };
        const blob = await resolveHostAssetBlob(asset);
        if (!blob || !blob.size) return { ok: false, message: "素材文件读取失败" };
        const base64 = await arrayBufferToBase64(await blob.arrayBuffer());
        window.parent.postMessage(
            {
                source: CANVAS_MESSAGE_SOURCE,
                type: "asset-import-data",
                payload: { requestId, name: asset.title, mimeType: blob.type || "", base64, kind: asset.category || "other" },
            },
            "*",
        );
        return await waitForHostImportReply(requestId);
    } catch (error) {
        return { ok: false, message: error instanceof Error ? error.message : "素材同步失败" };
    }
}

// 041（boss 2026-10-05）：画布「选择素材」弹窗的改名入口。
// 宿主镜像资产（host: 前缀）转发宿主 asset-update 改 name（宿主会把旧名并入 aliases，搜索不丢）；
// 本地资产直接 updateAsset。宿主改完会 notifyAssetsChanged 推送新列表，画布镜像自动刷新。
export async function renameAssetTitle(asset: Asset, title: string): Promise<boolean> {
    const nextTitle = title.trim();
    if (!nextTitle || nextTitle === asset.title) return true;
    if (asset.id.startsWith(HOST_ASSET_PREFIX)) {
        if (!embeddedInAssetHost()) return false;
        return await new Promise<boolean>((resolve) => {
            const cleanup = () => window.removeEventListener("message", handler);
            const handler = (event: MessageEvent) => {
                const message = event.data || {};
                if (message?.source !== HOST_MESSAGE_SOURCE) return;
                if (message?.type === "asset-updated") {
                    cleanup();
                    resolve(true);
                }
            };
            window.addEventListener("message", handler);
            window.parent.postMessage(
                { source: CANVAS_MESSAGE_SOURCE, type: "asset-update", payload: { id: asset.id.slice(HOST_ASSET_PREFIX.length), name: nextTitle } },
                "*",
            );
            window.setTimeout(() => {
                cleanup();
                resolve(false);
            }, 8000);
        });
    }
    useAssetStore.getState().updateAsset(asset.id, { title: nextTitle });
    return true;
}

// 023：宿主资产消息监听（模块加载即绑定一次，嵌入宿主环境才生效）
let hostAssetMirrorBound = false;
function bindHostAssetMirror(): void {
    if (hostAssetMirrorBound || typeof window === "undefined") return;
    hostAssetMirrorBound = true;
    window.addEventListener("message", (event) => {
        const message = event.data || {};
        if (message?.source !== HOST_MESSAGE_SOURCE) return;
        if (message?.type === "asset-imported" || message?.type === "asset-import-error") {
            const requestId = String(message?.payload?.requestId || "");
            const pending = requestId ? pendingHostImports.get(requestId) : undefined;
            if (!pending) return;
            pendingHostImports.delete(requestId);
            pending.resolve(
                message?.type === "asset-imported"
                    ? { ok: true }
                    : { ok: false, message: String(message?.payload?.message || "素材写入我的资产失败") },
            );
            return;
        }
        const records: HostAssetRecord[] = Array.isArray(message?.payload) ? message.payload : Array.isArray(message?.assets) ? message.assets : [];
        if (!records.length) return;
        if (message?.type === "asset-list" || message?.type === "asset-create" || message?.type === "asset-update") {
            mirrorHostAssets(records);
        }
    });
}
if (typeof window !== "undefined") bindHostAssetMirror();

export function mergeAssets(remoteAssets: Asset[], localAssets: Asset[]) {
    const records = new Map<string, Asset>();
    [...localAssets, ...remoteAssets].forEach((asset) => {
        const previous = records.get(asset.id);
        if (!previous || Date.parse(asset.updatedAt || "") >= Date.parse(previous.updatedAt || "")) {
            records.set(asset.id, asset);
        }
    });
    return Array.from(records.values()).sort((a, b) => Date.parse(b.updatedAt || "") - Date.parse(a.updatedAt || ""));
}
