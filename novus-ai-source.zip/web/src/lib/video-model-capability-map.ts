// 任务rFpe2z：视频「模型 → 支持参数」映射表（时长/分辨率/比例/个数）。
// 时长规则（boss 2026-10-06 定稿 + 官方核实）：
//   官方可查的按官方（ByteDance ModelArk：Seedance 2.5 = 4~30s 连续任意整秒；Seedance 2.0 系 = 4~15s；1.5 = 4~12s）；
//   MiniMax H3 官方满血 = 4~30s 任意（boss 提供并确认）；
//   **照顾不到/新接入的 API 一律 4~30s 全开**——生成不了平台会自己拒绝并回明确原因（099/101 链路兜底）。
// 分辨率规则（boss 样例）：Dola2.5/SD2.5 按官方 480P/720P/1080P；Dola2.0/SD2.0 全档；H3 720P/2K。
// 未命中模型 → durationRange=[4,30] 全开 + 分辨率全开（走默认行为）。

export type VideoModelCapability = {
    /** 支持的时长范围（闭区间，整秒连续可选） */
    durationRange: [number, number];
    /** 支持的分辨率（小写）；null = 全开 */
    resolutions: string[] | null;
    /** 支持的比例；null = 全部可用 */
    ratios?: string[] | null;
    /** 支持的生成个数；null = 1/2/4 */
    counts?: string[] | null;
    /** 面板底部说明文案 */
    note?: string;
};

const RULES: { match: (model: string) => boolean; capability: VideoModelCapability }[] = [
    {
        // Seedance 2.5 系（Dola 2.5 / Seedance 2.5 / 账号池变体）：官方 4~30s 连续
        match: (model) => /2[\._-]?5/.test(model) && /dola|seedance/i.test(model),
        capability: {
            durationRange: [4, 30],
            resolutions: ["480p", "720p", "1080p"],
            note: "官方支持 4~30 秒任意时长、480P/720P/1080P；Dola 账号池实际以 720P 为准",
        },
    },
    {
        // Seedance 2.0 系（Dola 2.0 / 2.0 Fast/Mini）：官方 4~15s 连续；480P~4K
        match: (model) => /2[\._-]?0/.test(model) && /dola|seedance/i.test(model),
        capability: {
            durationRange: [4, 15],
            resolutions: ["480p", "720p", "1080p", "4k"],
            note: "官方支持 4~15 秒任意时长、480P/720P/1080P/4K",
        },
    },
    {
        // Seedance 1.5 pro：官方 4~12s
        match: (model) => /1[\._-]?5/.test(model) && /seedance/i.test(model),
        capability: {
            durationRange: [4, 12],
            resolutions: ["480p", "720p", "1080p", "4k"],
            note: "官方支持 4~12 秒任意时长",
        },
    },
    {
        // MiniMax H3 系（官方满血）：4~30s 任意；720P/2K
        match: (model) => /minimax|h3/i.test(model),
        capability: {
            durationRange: [4, 30],
            resolutions: ["720p", "2k"],
            note: "官方满血版支持 4~30 秒任意时长、720P/2K",
        },
    },
];

/** 默认能力（未命中/新接入 API）：4~30s 全开、分辨率全开——平台不支持的会自行拒绝并回明确原因 */
export const DEFAULT_VIDEO_CAPABILITY: VideoModelCapability = {
    durationRange: [4, 30],
    resolutions: null,
};

/** 返回模型能力映射；未命中返回默认全开能力（永不为 null） */
export function videoModelCapability(modelName: string): VideoModelCapability {
    const model = String(modelName || "").trim();
    if (!model) return DEFAULT_VIDEO_CAPABILITY;
    for (const rule of RULES) {
        if (rule.match(model)) return rule.capability;
    }
    return DEFAULT_VIDEO_CAPABILITY;
}

/** 把时长钳制到模型支持范围内（整秒） */
export function normalizeDurationForModel(modelName: string, seconds: number): number {
    const [min, max] = videoModelCapability(modelName).durationRange;
    const value = Math.round(Number(seconds) || min);
    return Math.max(min, Math.min(max, value));
}

/** 把分辨率归一到模型支持集合（不支持则取第一个支持项；全开模型不拦截） */
export function normalizeResolutionForModel(modelName: string, resolution: string): string {
    const capability = videoModelCapability(modelName);
    if (!capability.resolutions) return resolution;
    const value = String(resolution || "").toLowerCase();
    return capability.resolutions.includes(value) ? value : capability.resolutions[0];
}
