// 066-T5：全站模型显示名——任何内部 ID / UUID 一律转成友好名（boss：什么模型就是什么模型）。
// 优先用宿主模型库的 displayName（模型中心/API 配置里的原名字），匹配不到再走内置映射与 saint-api 反解。

export type ModelDisplayHost = {
    id?: string;
    model?: string;
    displayName?: string;
};

const BUILTIN_FRIENDLY_NAMES: Record<string, string> = {
    "dola-expert-web": "Dola 文本",
    "dola-text": "Dola 文本",
    "dola-seedream-web": "Dola Seedream",
    "dola-seedance-web": "Dola 2.0",
    "dola-seedance-2.0-fast": "Dola 2.0",
    "dola-seedance-web-2.5": "Dola 2.5",
    "dola-seedance-2.5": "Dola 2.5",
    "chatgpt-image2": "ChatGPT 生图",
    "chatgpt-text": "ChatGPT 文本",
};

export function friendlyModelName(model: string, hostModels?: ModelDisplayHost[]): string {
    const value = String(model || "").trim();
    if (!value) return value;
    // 1) 宿主模型库的 displayName（模型中心 / API 配置原名字）
    if (hostModels?.length) {
        const host = hostModels.find((item) => item.model === value || item.id === value);
        if (host?.displayName) return host.displayName;
    }
    // 2) 内置映射
    const direct = BUILTIN_FRIENDLY_NAMES[value] || BUILTIN_FRIENDLY_NAMES[value.toLowerCase()];
    if (direct) return direct;
    // 3) saint-api/<渠道ID>/<模型名> → 显示模型名末段
    const saintApi = value.match(/^saint-api\/[^/]+\/(.+)$/i);
    if (saintApi) return saintApi[1];
    return value;
}
