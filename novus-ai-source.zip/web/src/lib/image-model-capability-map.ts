// 任务rUrQgS：生图「模型 → 支持参数」映射表。
// 原则（同 rFpe2z）：官方/已知按真实能力，照顾不到的默认全开。
// 已知：
//   Dola Seedream 5.0 Pro（web 账号池）→ 支持基础比例选择；不支持质量档、不支持自定义像素尺寸、
//   不支持指定张数（平台单次 1~4 张自动出图，063 实测）。
// 未命中（gpt-image-2 等第三方 API 模型）→ 全部参数开放（现状默认行为）。

export type ImageModelCapability = {
    /** 支持的比例选项（ASPECT_OPTIONS 的 value 集合）；null = 全开 */
    ratios: string[] | null;
    /** 是否支持质量档（自动/高/中/低） */
    supportsQuality: boolean;
    /** 是否支持自定义像素尺寸（W/H 数值输入） */
    supportsCustomSize: boolean;
    /** 是否支持指定生成张数 */
    supportsCount: boolean;
    /** 面板底部说明 */
    note?: string;
};

const BASE_RATIOS = ["auto", "1:1", "3:2", "2:3", "4:3", "3:4", "16:9", "9:16", "21:9"];

const RULES: { match: (model: string) => boolean; capability: ImageModelCapability }[] = [
    {
        // Dola Seedream 系（web 账号池）：仅比例；质量/尺寸/张数平台自管
        match: (model) => /dola|seedream/i.test(String(model || "")),
        capability: {
            ratios: BASE_RATIOS,
            supportsQuality: false,
            supportsCustomSize: false,
            supportsCount: false,
            note: "Dola 生图支持比例选择，单次自动出 1~4 张；质量与张数由平台决定",
        },
    },
];

/** 默认能力（未命中/第三方 API 模型）：全开 */
export const DEFAULT_IMAGE_CAPABILITY: ImageModelCapability = {
    ratios: null,
    supportsQuality: true,
    supportsCustomSize: true,
    supportsCount: true,
};

/** 返回生图模型能力；未命中返回默认全开（永不为 null） */
export function imageModelCapability(modelName: string): ImageModelCapability {
    const model = String(modelName || "").trim();
    if (!model) return DEFAULT_IMAGE_CAPABILITY;
    for (const rule of RULES) {
        if (rule.match(model)) return rule.capability;
    }
    return DEFAULT_IMAGE_CAPABILITY;
}
