"use client";

import { useEffect, useId, useMemo, useRef, useState } from "react";
import { Cpu } from "lucide-react";

import { Select, SelectContent, SelectItem, SelectTrigger } from "@/components/ui/select";
import { useAutoDLWorkflowNames } from "@/hooks/use-autodl-workflow";
import { isWorkflowProtocol } from "@/lib/model-channel";
import { cn } from "@/lib/utils";
import type { WorkflowRef } from "@/lib/workflow-channel";
import { filterModelsByCapability, normalizeLocalChannels, useConfigStore, type AiConfig, type ModelCapability } from "@/stores/use-config-store";
import { useUserStore } from "@/stores/use-user-store";

type ModelPickerProps = {
    config: AiConfig;
    value?: string;
    channelId?: string;
    capability?: ModelCapability;
    onChange: (model: string, channelId?: string) => void;
    workflowRef?: WorkflowRef;
    onWorkflowChange?: (ref?: WorkflowRef) => void;
    className?: string;
    /** 下拉菜单面板的额外类名（菜单走 portal 渲染，无法靠父级选择器命中） */
    menuClassName?: string;
    /** 触发器上显示的短名（点开下拉里仍是完整名） */
    shortLabel?: string;
    /** 触发器图标：true = 柱状图标（LibTV 风格），false = 按模型名解析 logo */
    useBarIcon?: boolean;
    fullWidth?: boolean;
    placeholder?: string;
    displayLabel?: string;
    onMissingConfig?: () => void;
};

type PickerBase = { key: string; channelId?: string; channelName: string; protocol?: string; baseUrl?: string };
type PickerOption = (PickerBase & { model: string }) | (PickerBase & { model: ""; workflowRef: WorkflowRef; label: string });

/**
 * r1xjVh：画布视频模型下拉隐藏 Dola 2.0 / Dola 2.5 两个假型号。
 * 仅在画布选择器做 UI 过滤 —— 模型管理列表里的两个内置条目必须保留：
 * model-library.js:36 靠 id.startsWith('dola-seedance-web') 推断 type=video，
 * novus-model-management.js:34 的 builtins 集合认原 id，删条目会导致掉出视频分类。
 */
const CANVAS_HIDDEN_VIDEO_MODELS = new Set(["dola-seedance-web", "dola-seedance-web-2.5"]);

/**
 * rT0dUD：画布生图模型下拉隐藏 gpt-image-2（ChatGPT 账号池生图，用户已确认无用）。
 * 同样只做 UI 过滤，模型管理内置条目保留（以后要恢复直接放开这里即可）。
 * chatgpt-image2 是宿主模型库的同一条目 id，一并隐藏。
 */
const CANVAS_HIDDEN_IMAGE_MODELS = new Set(["gpt-image-2", "chatgpt-image2"]);

export function ModelPicker({ config, value, channelId, capability, onChange, workflowRef, onWorkflowChange, className, menuClassName, shortLabel, useBarIcon = false, fullWidth = false, placeholder = "选择模型", displayLabel, onMissingConfig }: ModelPickerProps) {
    const pickerId = useId();
    const [open, setOpen] = useState(false);
    const token = useUserStore((state) => state.token);
    const userReady = useUserStore((state) => state.isReady);
    const publicSettings = useConfigStore((state) => state.publicSettings);
    const hostModels = useConfigStore((state) => state.hostModels);
    const workflowEnabled = Boolean(onWorkflowChange && capability && capability !== "text");
    const channelOptions = useMemo<PickerOption[]>(() => {
        const channels =
            config.channelMode === "remote"
                ? config.publicChannels.map((channel) => ({ id: channel.id, protocol: channel.protocol, name: channel.name || "云端渠道", baseUrl: channel.baseUrl, models: channel.models, workflows: channel.workflows || [] }))
                : normalizeLocalChannels(config).map((channel) => ({ id: channel.id, protocol: channel.protocol, name: channel.name || "本地渠道", baseUrl: channel.baseUrl, models: channel.models, workflows: channel.workflowSummaries || [] }));
        const models: Array<PickerBase & { model: string }> = channels.filter((channel) => !isWorkflowProtocol(channel.protocol || "")).flatMap((channel) => (channel.models ?? []).map((model) => ({ key: `${channel.id}::${model}`, channelId: channel.id, channelName: channel.name, protocol: channel.protocol, baseUrl: channel.baseUrl, model })));
        if (typeof window !== "undefined" && window.parent !== window && capability === "video" && !models.some((item) => item.channelId === "saint-dola-seedance-25-pool")) {
            models.push({ key: "saint-dola-seedance-25-pool::dola-seedance-2.5", channelId: "saint-dola-seedance-25-pool", channelName: "Seedance 2.5 账号池", protocol: "openai", baseUrl: "http://saint-host.invalid", model: "dola-seedance-2.5" });
        }
        // 050：嵌入宿主时注入外壳模型库（模型中心 + API 配置渠道），按宿主标注的类型匹配能力，绕过名字猜测过滤
        const embedded = typeof window !== "undefined" && window.parent !== window;
        const hostCapabilityType: Record<string, string[]> = { image: ["image"], video: ["video"], text: ["llm", "text"], audio: ["tts", "audio"] };
        const hostOptions = embedded
            ? hostModels
                .filter((item) => item.enabled && (!capability || (hostCapabilityType[capability] || []).includes(item.type)))
                .filter((item) => !models.some((existing) => existing.model === item.model))
                .map((item) => ({ key: `saint-host-models::${item.model}`, channelId: "saint-host-models", channelName: item.displayName || "Novus 模型库", protocol: "openai", baseUrl: "http://saint-host.invalid", model: item.model }))
            : [];
        const filtered = capability ? models.filter((item) => filterModelsByCapability([item.model], capability, item.protocol || "").length > 0) : models;
        // r1xjVh / rT0dUD：按能力剔除隐藏名单里的型号（账号池本体不在名单内，保留可见）
        const hiddenForCapability = capability === "video" ? CANVAS_HIDDEN_VIDEO_MODELS : capability === "image" ? CANVAS_HIDDEN_IMAGE_MODELS : null;
        const scoped = hiddenForCapability
            ? [...hostOptions, ...filtered].filter((item) => !hiddenForCapability.has("model" in item ? String(item.model || "") : ""))
            : [...hostOptions, ...filtered];
        if (!workflowEnabled || !token) return scoped;
        const scope = config.channelMode === "remote" ? "system" : "personal";
        return [...scoped, ...channels.flatMap((channel) => isWorkflowProtocol(channel.protocol || "") ? channel.workflows.filter((entry) => entry.enabled && entry.capability === capability && entry.provider === channel.protocol).map((entry) => {
            const ref: WorkflowRef = { scope, channelId: channel.id || "", kind: entry.kind, workflowId: entry.workflowId };
            return { key: `workflow:${JSON.stringify([ref.scope, ref.channelId, ref.kind, ref.workflowId])}`, channelId: channel.id, channelName: channel.name, protocol: channel.protocol, baseUrl: channel.baseUrl, model: "", workflowRef: ref, label: entry.title || entry.workflowId };
        }) : [])];
    }, [capability, config, token, workflowEnabled, hostModels]);
    const modelLabel = useAutoDLWorkflowNames(channelOptions);
    const currentOption = useMemo(() => {
        if (workflowRef && workflowEnabled) return channelOptions.find((item) => "workflowRef" in item && item.key === `workflow:${JSON.stringify([workflowRef.scope, workflowRef.channelId, workflowRef.kind, workflowRef.workflowId])}`);
        if (!value) return undefined;
        return channelOptions.find((item) => item.model === value && item.channelId === channelId) || channelOptions.find((item) => item.model === value);
    }, [channelId, channelOptions, value, workflowEnabled, workflowRef]);
    const options = channelOptions;
    const current: string = workflowRef && workflowEnabled
        ? (currentOption && "label" in currentOption ? String(currentOption.label) : "")
        : (currentOption && !("workflowRef" in currentOption) ? String(currentOption.model) : config.channelMode !== "remote" ? value || "" : "");
    const currentValue = current && currentOption ? currentOption.key : "";

    // rT0dUD：当前值命中隐藏名单（gpt-image-2 / chatgpt-image2 等）→ 自动切到第一个可用模型，不残留无效选中
    const autoSwitchedRef = useRef<string>("");
    useEffect(() => {
        if (!value) return;
        const hidden = capability === "video" ? CANVAS_HIDDEN_VIDEO_MODELS : capability === "image" ? CANVAS_HIDDEN_IMAGE_MODELS : null;
        if (!hidden || !hidden.has(value)) return;
        const key = `${capability}:${value}`;
        if (autoSwitchedRef.current === key) return;
        autoSwitchedRef.current = key;
        const fallback = options.find((item) => "model" in item && item.model && !hidden.has(item.model));
        if (fallback && "model" in fallback) onChange(fallback.model, fallback.channelId);
    }, [capability, value, options, onChange]);

    const displayModelName = useMemo(() => {
        const id = String(current || value || "");
        if (!id) return "";
        const lower = id.toLowerCase();
        if (lower.includes("dola-seedance-2.5")) return "Seedance 2.5";
        if (lower.includes("dola-seedance-2.0")) return "Seedance 2.0 Fast";
        return modelLabel(id, currentOption as { protocol?: string; baseUrl?: string }) || id;
    }, [current, value, currentOption, modelLabel]);

    // 触发器短名：优先用外部传入，否则从模型 id 压成最短可辨识形式（dola-seedance-2.5 → dola-2.5）
    const triggerLabel = useMemo(() => {
        if (shortLabel) return shortLabel;
        // 051：宿主模型（Novus 模型库）触发器显示友好名（displayName），不显示 saint-api/UUID 长串
        if (currentOption && !("workflowRef" in currentOption) && currentOption.channelId === "saint-host-models") {
            return currentOption.channelName || shortenModelId(String(current));
        }
        const id = String(current || value || "");
        return shortenModelId(id);
    }, [shortLabel, currentOption, current, value]);

	useEffect(() => {
		if (workflowRef && workflowEnabled) {
			const workflowOptionsReady = workflowRef.scope === "system"
				? publicSettings !== null
				: config.workflowSyncTouched === true;
			if (token && userReady && workflowOptionsReady && !currentOption && channelOptions.some((item) => !("workflowRef" in item))) {
				onWorkflowChange?.(undefined);
            }
            return;
        }
        if (value && currentOption?.channelId && !("workflowRef" in currentOption) && channelId !== currentOption.channelId) onChange(value, currentOption.channelId);
	}, [channelId, channelOptions, config.workflowSyncTouched, currentOption, onChange, onWorkflowChange, publicSettings, token, userReady, value, workflowEnabled, workflowRef]);

    useEffect(() => {
        const closeOtherPicker = (event: Event) => {
            if ((event as CustomEvent<string>).detail !== pickerId) setOpen(false);
        };
        window.addEventListener("model-picker-open", closeOtherPicker);
        return () => window.removeEventListener("model-picker-open", closeOtherPicker);
    }, [pickerId]);

    return (
        <Select
            open={open}
            value={current ? currentValue : ""}
            onOpenChange={(nextOpen) => {
                if (nextOpen && !options.length && config.channelMode === "local") {
                    onMissingConfig?.();
                    return;
                }
                if (nextOpen) window.dispatchEvent(new CustomEvent("model-picker-open", { detail: pickerId }));
                setOpen(nextOpen);
            }}
            onValueChange={(nextValue) => {
                const option = options.find((item) => item.key === nextValue);
                if (!option) return;
                if ("workflowRef" in option) onWorkflowChange?.(option.workflowRef);
                else { onChange(option.model, option.channelId); if (workflowRef) onWorkflowChange?.(undefined); }
            }}
        >
            <SelectTrigger
                className={cn(
                    "canvas-composer-model-picker h-8 w-fit max-w-full gap-2 rounded-full border border-input bg-transparent px-3 text-sm font-normal shadow-sm transition-colors",
                    fullWidth ? "w-full min-w-0 justify-start" : "min-w-[9rem] justify-start",
                    "data-[state=open]:border-ring data-[state=open]:ring-2 data-[state=open]:ring-ring/20",
                    className,
                )}
                onMouseDown={(event) => event.stopPropagation()}
                onPointerDown={(event) => event.stopPropagation()}
                title={workflowRef && workflowEnabled && !currentOption ? "工作流已停用、未公开或删除，请重新选择" : current || placeholder}
            >
                <ModelIcon model={current} bar={useBarIcon} />
                <span className="canvas-model-picker-text min-w-0 flex-1 truncate text-left">{triggerLabel || placeholder}</span>
                {/* 真值（报告 B6）：末尾是 lucideChevronDown "text-fg-muted size-3.5 shrink-0 transition-transform"（展开 rotate-180）。
                    Radix SelectTrigger 自带一个 chevron（.canvas-select-chevron size-4），就是真值里那个的位置，
                    只是尺寸/颜色不符 —— 由 canvas-prompt-bar.css 压制成 size-3.5 + #919191，不再另加一个。 */}
            </SelectTrigger>
            <SelectContent
                data-canvas-no-zoom
                className={`z-[1200] w-80 max-w-[calc(100vw-24px)] rounded-xl border border-border/70 bg-popover p-1 shadow-xl ${menuClassName || ""}`}
                position="popper"
                align="start"
                side="bottom"
                sideOffset={6}
                onPointerDown={(event) => event.stopPropagation()}
                onMouseDown={(event) => event.stopPropagation()}
            >
                {options.length ? (
                    options.map((option) => (
                        <SelectItem key={option.key} value={option.key} textValue={`${"workflowRef" in option ? option.label : option.channelId === "saint-host-models" ? option.channelName : modelLabel(option.model, option)} ${option.model} ${option.channelName}`}>
                            <ModelLabel model={"workflowRef" in option ? option.workflowRef.workflowId : option.model} label={"workflowRef" in option ? `工作流 · ${option.label}` : option.channelId === "saint-dola-seedance-25-pool" ? "Seedance 2.5 账号池" : option.channelId === "saint-host-models" ? option.channelName : modelLabel(option.model, option)} channelName={option.channelId === "saint-host-models" ? (option.channelName.includes(" · ") ? option.channelName.split(" · ").slice(1).join(" · ") : "") : option.channelName} />
                        </SelectItem>
                    ))
                ) : (
                    <SelectItem value="__empty__" disabled>
                        {config.channelMode === "remote" ? "暂无可用模型" : "请先到配置里拉取模型列表"}
                    </SelectItem>
                )}
            </SelectContent>
        </Select>
    );
}

function ModelLabel({ model, label, channelName }: { model: string; label?: string; channelName?: string }) {
    return (
        <span className="flex min-w-0 items-center gap-2">
            <ModelIcon model={model} />
            <span className="truncate" title={model}>{label || model}</span>
            {channelName ? <span className="ml-auto max-w-24 shrink-0 truncate text-xs opacity-50">{channelName}</span> : null}
        </span>
    );
}

function ModelIcon({ model, bar = false }: { model: string; bar?: boolean }) {
    // bar：LibTV 风格的三根柱状图标（画布底栏模型区用这个）
    if (bar) {
        // boss 2026-10-03：柱状图标改紫色（覆盖真值 text-fg-muted #919191），用画布 spark 紫 #b39dff
        return (
            <svg className="size-4 shrink-0" style={{ color: "#b39dff" }} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                <rect x="4" y="11" width="3" height="9" rx="1" />
                <rect x="10.5" y="6" width="3" height="14" rx="1" />
                <rect x="17" y="3" width="3" height="17" rx="1" />
            </svg>
        );
    }
    const icon = resolveModelIcon(model);
    return icon ? <img src={icon} alt="" className="size-4 shrink-0 dark:invert" /> : <Cpu className="size-4 shrink-0 opacity-70" />;
}

/** 模型 id → 触发器短名：dola-seedance-2.5 → seedance-2.5（后两段），点开下拉里仍是完整名 */
function shortenModelId(id: string) {
    const parts = String(id || "").split("-").filter(Boolean);
    if (parts.length <= 2) return parts.join("-");
    return parts.slice(-2).join("-");
}

function resolveModelIcon(model: string) {
    const name = model.toLowerCase();
    if (name.includes("claude") || name.includes("anthropic")) return "/icons/claude.svg";
    if (name.includes("gemini") || name.includes("google")) return "/icons/gemini.svg";
    if (name.includes("gpt") || name.includes("openai")) return "/icons/openai.svg";
    if (name.includes("grok") || name.includes("grok")) return "/icons/grok.svg";
    if (name.includes("deepseek") || name.includes("deepseek")) return "/icons/deepseek.svg";
    if (name.includes("glm") || name.includes("glm")) return "/icons/glm.svg";
    return "";
}
