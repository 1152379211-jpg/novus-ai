"use client";

import { Bell, Moon, PanelLeft, Search, Sun } from "lucide-react";

import { useThemeStore } from "@/stores/use-theme-store";

export function AppDashboardHeader() {
    const theme = useThemeStore((state) => state.theme);
    const setTheme = useThemeStore((state) => state.setTheme);

    return (
        <header className="flex h-14 shrink-0 items-center justify-between border-b border-stone-200 bg-white px-4 dark:border-stone-800 dark:bg-[#1f1d1a]">
            <div className="flex min-w-0 items-center gap-3">
                <button type="button" className="rounded-md p-2 !text-stone-500 transition hover:!bg-stone-100 hover:!text-stone-950 dark:!text-stone-400 dark:hover:!bg-stone-800 dark:hover:!text-white" aria-label="侧栏" title="侧栏">
                    <PanelLeft className="size-4" />
                </button>
                <div className="hidden h-5 w-px bg-stone-200 sm:block dark:bg-stone-800" />
                <label className="hidden h-9 w-[280px] items-center gap-2 rounded-md border border-stone-200 bg-stone-50 px-3 !text-stone-500 sm:flex dark:border-stone-800 dark:bg-stone-900 dark:!text-stone-400" aria-label="搜索">
                    <Search className="size-4" />
                    <input className="min-w-0 flex-1 bg-transparent text-sm !text-stone-950 outline-none placeholder:!text-stone-400 dark:!text-stone-100 dark:placeholder:!text-stone-500" placeholder="搜索..." />
                    <kbd className="rounded border border-stone-200 bg-white px-1.5 py-0.5 text-[10px] !text-stone-400 dark:border-stone-700 dark:bg-stone-800 dark:!text-stone-500">⌘ K</kbd>
                </label>
            </div>
            <div className="flex items-center gap-1">
                <button
                    type="button"
                    className="rounded-md p-2 !text-stone-500 transition hover:!bg-stone-100 hover:!text-stone-950 dark:!text-stone-400 dark:hover:!bg-stone-800 dark:hover:!text-white"
                    aria-label={theme === "dark" ? "切换到浅色主题" : "切换到深色主题"}
                    title={theme === "dark" ? "切换到浅色主题" : "切换到深色主题"}
                    onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                >
                    <Sun className="size-4 dark:hidden" />
                    <Moon className="hidden size-4 dark:block" />
                </button>
                <button type="button" className="relative rounded-md p-2 !text-stone-500 transition hover:!bg-stone-100 hover:!text-stone-950 dark:!text-stone-400 dark:hover:!bg-stone-800 dark:hover:!text-white" aria-label="通知" title="通知">
                    <Bell className="size-4" />
                    <span className="absolute right-1.5 top-1.5 size-1.5 rounded-full bg-red-500" />
                </button>
            </div>
        </header>
    );
}
