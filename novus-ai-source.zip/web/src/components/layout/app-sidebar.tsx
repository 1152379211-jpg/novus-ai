"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import {
    ChevronDown,
    FileText,
    FolderOpen,
    ImagePlus,
    Maximize2,
    Plus,
    Settings2,
    SlidersHorizontal,
    Sparkles,
    Users,
    Video,
} from "lucide-react";

import { AppConfigModal } from "@/components/layout/app-config-modal";
import { cn } from "@/lib/utils";
import { useConfigStore } from "@/stores/use-config-store";

type Icon = typeof Video;

function SidebarItem({
    label,
    icon: IconComponent,
    href,
    active = false,
    indent = false,
    onClick,
}: {
    label: string;
    icon: Icon;
    href?: string;
    active?: boolean;
    indent?: boolean;
    onClick?: () => void;
}) {
    const className = cn(
        "group flex h-10 w-full items-center gap-3 rounded-md px-3 text-left text-sm transition-[background-color,color,box-shadow] duration-150",
        indent && "pl-10",
        active
            ? "!bg-[#171717] font-medium !text-white shadow-[inset_0_0_0_1px_rgba(255,255,255,.06)] dark:!bg-[#2d2d2d]"
            : "!text-stone-600 hover:!bg-stone-100 hover:!text-stone-950 dark:!text-white/60 dark:hover:!bg-white/[0.06] dark:hover:!text-white",
    );
    const content = (
        <>
            <IconComponent className="size-4 shrink-0" strokeWidth={1.8} />
            <span className="truncate">{label}</span>
        </>
    );

    if (href) {
        return <Link href={href} className={className}>{content}</Link>;
    }
    return <button type="button" className={className} onClick={onClick}>{content}</button>;
}

export function AppSidebar() {
    const pathname = usePathname();
    const setConfigDialogOpen = useConfigStore((state) => state.setConfigDialogOpen);
    const [creationOpen, setCreationOpen] = useState(true);
    const [modelOpen, setModelOpen] = useState(true);

    const isActive = (href: string) => href === "/" ? pathname === "/" : pathname === href || pathname.startsWith(`${href}/`);
    const openConfig = () => setConfigDialogOpen(true);
    const creationActive = pathname === "/" || pathname.startsWith("/video") || pathname.startsWith("/image");

    return (
        <aside className="flex h-full w-[248px] shrink-0 flex-col border-r border-stone-200 bg-white px-3.5 py-4 !text-stone-950 dark:border-white/10 dark:bg-[#1f1d1a] dark:!text-white">
            <div className="flex items-center justify-between px-2 pb-5">
                <Link href="/" className="flex min-w-0 items-center gap-2.5 text-sm font-semibold tracking-tight !text-stone-950 dark:!text-white">
                    <span className="flex size-7 items-center justify-center rounded-md bg-stone-900 text-xs font-semibold text-white ring-1 ring-stone-900/10 dark:bg-[#2d2d2d] dark:ring-white/10">D</span>
                    <span className="truncate">Dola Workspace</span>
                </Link>
                <button type="button" className="rounded-md p-1.5 !text-stone-500 transition hover:!bg-stone-100 hover:!text-stone-950 dark:!text-white/45 dark:hover:!bg-white/[0.06] dark:hover:!text-white" aria-label="收起侧栏" title="收起侧栏">
                    <ChevronDown className="size-4 -rotate-90" />
                </button>
            </div>

            <nav className="space-y-1.5" aria-label="主要导航">
                <button
                    type="button"
                    className={cn(
                        "group flex h-10 w-full items-center gap-3 rounded-md px-3 text-left text-sm transition-[background-color,color,box-shadow] duration-150",
                        creationActive
                            ? "!bg-[#171717] font-medium !text-white shadow-[inset_0_0_0_1px_rgba(255,255,255,.06)] dark:!bg-[#2d2d2d]"
                            : "!text-stone-600 hover:!bg-stone-100 hover:!text-stone-950 dark:!text-white/60 dark:hover:!bg-white/[0.06] dark:hover:!text-white",
                    )}
                    aria-expanded={creationOpen}
                    onClick={() => setCreationOpen((value) => !value)}
                >
                    <Plus className="size-4 shrink-0" strokeWidth={1.8} />
                    <span className="flex-1 truncate">创作中心</span>
                    <ChevronDown className={cn("size-4 shrink-0 transition-transform", !creationOpen && "-rotate-90")} />
                </button>
                {creationOpen ? (
                    <div className="space-y-1">
                        <SidebarItem label="新视频" icon={Video} href="/video" indent />
                        <SidebarItem label="批量生产" icon={FileText} href="/video" indent />
                        <SidebarItem label="AI 超分去水印" icon={ImagePlus} indent />
                    </div>
                ) : null}

                <SidebarItem label="账号池" icon={Users} />

                <button
                    type="button"
                    className="group flex h-10 w-full items-center gap-3 rounded-md px-3 text-left text-sm !text-stone-600 transition hover:!bg-stone-100 hover:!text-stone-950 dark:!text-white/60 dark:hover:!bg-white/[0.06] dark:hover:!text-white"
                    aria-expanded={modelOpen}
                    onClick={() => setModelOpen((value) => !value)}
                >
                    <Settings2 className="size-4 shrink-0" strokeWidth={1.8} />
                    <span className="flex-1 truncate">模型与 API</span>
                    <ChevronDown className={cn("size-4 shrink-0 transition-transform", !modelOpen && "-rotate-90")} />
                </button>
                {modelOpen ? (
                    <div className="space-y-1">
                        <SidebarItem label="模型中心" icon={Sparkles} indent onClick={openConfig} />
                        <SidebarItem label="API 配置" icon={SlidersHorizontal} indent onClick={openConfig} />
                    </div>
                ) : null}

                <SidebarItem label="Novus AI" icon={Maximize2} href="/canvas" active={pathname.startsWith("/canvas")} />
                <SidebarItem label="作品库" icon={FolderOpen} href="/asset-library" active={pathname.startsWith("/asset-library")} />
            </nav>

            <div className="mt-auto">
                <AppConfigModal />
            </div>
        </aside>
    );
}
