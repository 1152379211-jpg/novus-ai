"use client";

import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState, Fragment } from "react";
import type { ChangeEvent as ReactChangeEvent, DragEvent as ReactDragEvent, MouseEvent as ReactMouseEvent, PointerEvent as ReactPointerEvent } from "react";
import dynamic from "next/dynamic";
import { useParams, useRouter } from "next/navigation";
import { Boxes, ChevronLeft, ChevronRight, Copy, Download, Globe2, Home, ImageIcon, Images, Layers3, List, Maximize, Menu, Bot, Music2, PanelLeftClose, PanelLeftOpen, Pause, Play, Plus, Redo2, Settings2, Star, Trash2, Undo2, Upload, Video, Volume2, VolumeX, X } from "lucide-react";
import { saveAs } from "file-saver";

import { deleteCanvasProjects, deleteCanvasTasks } from "@/services/api/canvas-tasks";
import { createCanvasImageTask, pollCanvasImageTaskStatus, requestImageQuestion, type CanvasImageTask } from "@/services/api/image";
import { createCanvasAudioTask, pollCanvasAudioTaskStatus, type CanvasAudioTask } from "@/services/api/audio";
import { createVideoGenerationTask, pollVideoGenerationTaskStatus, VIDEO_POLL_INTERVAL_MS, type VideoResponse } from "@/services/api/video";
import { comfyOutputStorageKey, getWorkflowTask, submitWorkflowTask, workflowMediaSource, type WorkflowGenerationTask } from "@/services/api/workflow-generation";
import type { WorkflowRef } from "@/lib/workflow-channel";
import { channelProtocolForConfig, defaultConfig, resolveModelForCapability, type AiConfig, useConfigStore, useEffectiveConfig } from "@/stores/use-config-store";
import { collectImageStorageKeys, deleteStoredImages, getImageBlob, resolveImageUrl, uploadImage, uploadRemoteImageToServer, type UploadedImage } from "@/services/image-storage";
import { downloadRemoteMedia, getMediaBlob, resolveMediaUrl, uploadMediaFile, uploadRemoteMediaToServer, type UploadedFile } from "@/services/file-storage";
import { nanoid } from "nanoid";
import { getDataUrlByteSize, readImageMeta } from "@/lib/image-utils";
import { canvasThemes, type CanvasBackgroundMode } from "@/lib/canvas-theme";
import { isKIEKlingV3Config, kieKlingOmniVariant } from "@/components/video-settings-panel";
import { useAssetStore } from "@/stores/use-asset-store";
import { useUserStore } from "@/stores/use-user-store";
import { useThemeStore } from "@/stores/use-theme-store";
import { cropDataUrl, splitDataUrl, upscaleDataUrl } from "../utils/canvas-image-data";
import { fitNodeSize, nodeSizeFromRatio, normalizeNodeSize } from "../utils/canvas-node-size";
import { captureVideoFrame, type VideoFramePosition } from "../utils/canvas-video-frame";
import { PANORAMA_IMAGE_SIZE, PANORAMA_NODE_SIZE, buildPanoramaPrompt, isCanvasImageNodeType, isPanoramaNodeType } from "../utils/canvas-panorama";
import { applyCameraPrompt } from "../utils/canvas-camera";
import { GROUP_PADDING, findContainingGroupId, findGroupDropTarget, getNodeBounds, snapNodesIntoGroup } from "../utils/canvas-group";
import { snapCanvasDragDelta } from "../utils/canvas-grid";
import { computeAlignmentSnap, type AlignBox } from "../utils/canvas-alignment";
import { App, Button, Dropdown, Modal, Slider } from "antd";
import { isCogVideoX3Model, modelKey, supportsVideoAudioGeneration, supportsVideoFrameReferences } from "@/lib/video-model-capabilities";
import { isMimoVoiceCloneModel } from "@/lib/mimo-tts";
import { isAutoDLConfig } from "@/lib/autodl";
import { isGlmTtsModel } from "@/lib/audio-generation";
import { isGrok2APITtsConfig } from "@/lib/grok-tts";
import { isGeminiConfig, isGeminiTtsModel } from "@/lib/gemini";
import { isKIESeedreamLayerDecompositionModel } from "@/lib/kie-models";
import { NODE_DEFAULT_SIZE, getNodeSpec } from "../constants";
import { ActiveConnectionPath, ConnectionPath, buildConnectionPath, connectionCurvePoints } from "../components/canvas-connections";
import { CanvasConfigComposer } from "../components/canvas-config-composer";
import { CanvasConfigNodePanel } from "../components/canvas-config-node-panel";
import { CanvasDirector } from "../components/canvas-director";
import { CanvasDirectorNodePanel } from "../components/canvas-director-node-panel";
import { CanvasAssistantPanel } from "../components/canvas-assistant-panel";
import { CanvasNodeContextMenu, CanvasSelectionContextMenu } from "../components/canvas-context-menu";
import { CanvasNodeAngleDialog, type CanvasImageAngleParams } from "../components/canvas-node-angle-dialog";
import { CanvasNodeTransformBar, transformToCss, type NodeTransformState } from "../components/canvas-node-transform-bar";
import { CanvasNodeCropDialog, type CanvasImageCropRect } from "../components/canvas-node-crop-dialog";
import { CanvasNodeMaskEditDialog, type CanvasImageMaskEditPayload } from "../components/canvas-node-mask-edit-dialog";
import { CanvasNodeSplitDialog, type CanvasImageSplitParams } from "../components/canvas-node-split-dialog";
import { CanvasNodeUpscaleDialog, type CanvasImageUpscaleParams } from "../components/canvas-node-upscale-dialog";
import { buildNodeChatMessages, buildNodeGenerationContext, buildNodeGenerationInputs, hydrateNodeGenerationContext, type NodeGenerationContext, type NodeGenerationInput } from "../components/canvas-node-generation";
import { CanvasNodeHoverToolbar, CanvasNodeInfoModal } from "../components/canvas-node-hover-toolbar";
import { NovusAI } from "../components/novus-ai";
import { Minimap } from "../components/canvas-mini-map";
import { CanvasNode } from "../components/canvas-node";
import { CanvasNodePromptPanel, type CanvasNodeGenerationMode, type CanvasVideoFrameOption } from "../components/canvas-node-prompt-panel";
import type { CanvasVideoResourceOption } from "../components/canvas-video-settings-popover";
import { CanvasToolbar } from "../components/canvas-toolbar";
import { OriginalBottomNav } from "../components/original-bottom-nav";
import { OriginalMultiSelectionToolbar } from "../components/original-multi-selection-toolbar";
import { OriginalGroupToolbar } from "../components/original-group-toolbar";
import { OriginalNodeMenu } from "../components/original-node-menu";
import { OriginalImageToolbar } from "../components/original-image-toolbar";
import { DoodleStrokesOverlay, ImageDoodleEditor, type DoodleStroke } from "../components/image-doodle";
import { OriginalPaneContextMenu } from "../components/original-pane-context-menu";
import { CanvasNodeSearchPanel } from "../components/canvas-node-search";
import { OriginalShortcutsPanel } from "../components/original-shortcuts-panel";
// 024：统一批量下载（≤5 逐个、>5 打包 zip）
import { downloadBatchItems, type BatchDownloadItem } from "../utils/canvas-batch-download";
import { AssetPickerModal, CategoryPickDialog, type AssetPickerTab } from "../components/asset-picker-modal";
import { CanvasGenerationHistoryModal } from "../components/canvas-generation-history-modal";
import { CanvasEmptyState } from "../components/canvas-empty-state";
import { CanvasZoomControls } from "../components/canvas-zoom-controls";
import { CANVAS_ASSET_DRAG_TYPE, CanvasSidePanel } from "../components/canvas-side-panel";
import { DEFAULT_CANVAS_AGENT_PANEL, DEFAULT_CANVAS_SIDE_PANEL, useCanvasStore } from "../stores/use-canvas-store";
import { assistantReferenceContentFromNode, buildNodeMentionReferences, isCanvasReferenceNode } from "../utils/canvas-resource-references";
import { buildCanvasAgentContext } from "../agent/canvas-agent-context";
import type { CanvasAgentAction, CanvasAgentToolResult } from "../agent/canvas-agent-tools";
import {
    CanvasNodeType,
    type CanvasAgentConfig,
    type CanvasAgentState,
    type CanvasAssistantImage,
    type CanvasAssistantReference,
    type CanvasAssistantSession,
    type CanvasConnection,
    type CanvasDirectorCapture,
    type CanvasDirectorPanorama,
    type CanvasDirectorVideo,
    type CanvasImageGenerationType,
    type CanvasNodeData,
    type CanvasNodeMetadata,
    type CanvasPendingAgentRequest,
    type ConnectionHandle,
    type ContextMenuState,
    type InsertAssetPayload,
    type Position,
    type SelectionBox,
    type ViewportTransform,
} from "../types";
import type { ReferenceImage } from "@/types/image";
import type { ReferenceAudio, ReferenceVideo } from "@/types/media";

const CanvasPanoramaViewer = dynamic(() => import("../components/canvas-panorama-viewer"), { ssr: false, loading: () => null });

type CanvasClipboard = {
    nodes: CanvasNodeData[];
    connections: CanvasConnection[];
};

type PendingConnectionCreate = {
    connection: ConnectionHandle;
    position: Position;
    /** All selected nodes when a selection proxy is used as the source. */
    sourceNodeIds?: string[];
    selection?: boolean;
};

type ConnectionDropTarget = {
    nodeId: string | null;
    isNearNode: boolean;
};

type PendingPanoramaImport = {
    image: UploadedImage;
    title: string;
    position: Position;
};

type CanvasHistoryEntry = Pick<CanvasClipboard, "nodes" | "connections"> & {
    backgroundMode: CanvasBackgroundMode;
    showImageInfo: boolean;
};

// 093：展开态网格真值（LibTV 02-ImageNode.jsx `o_` 回调）：主图本身就是田字格 (0,0)，
// >2 张时四图占满 2×2：{0,0},{0,-(h+8)},{w+8,-(h+8)},{w+8,0}；≤2 张横排；间距恒为 8，行内底对齐。
// 我们架构是根+子节点：根固定不动占 (0,0)，子图按阅读顺序填 (0,1)(1,0)(1,1)(2,0)…；
// 列 1 的 x = 列 0 最宽 + 8；每排高 = 该排最高者，排内底对齐（等价原版负 top）。
function layoutBatchExpandedChildren(
    root: { x: number; y: number; width: number; height: number },
    childSizes: { width: number; height: number }[],
): { x: number; y: number }[] {
    const GAP = 8;
    const slotOf = (index: number) => index + 1; // 子图 index 的格子序号（根占 slot 0）；行 = floor(slot/2)，列 = slot%2
    const col0W = Math.max(root.width, ...childSizes.filter((_, i) => slotOf(i) % 2 === 0).map((s) => s.width));
    const col1X = root.x + col0W + GAP;
    const out: { x: number; y: number }[] = new Array(childSizes.length);
    // 行 0：底边锚定主图底边（主图不动；子图与主图底对齐）
    const first = childSizes[0];
    const row0Bottom = root.y + Math.max(root.height, first ? first.height : 0);
    if (first) out[0] = { x: col1X, y: row0Bottom - first.height };
    // 行 ≥1：每排高 = 该排最高者，排内底对齐，排距 GAP
    const rows = new Map<number, number[]>();
    childSizes.forEach((_, i) => {
        if (i === 0) return;
        const row = Math.floor(slotOf(i) / 2);
        const list = rows.get(row) || [];
        list.push(i);
        rows.set(row, list);
    });
    let top = row0Bottom + GAP;
    for (const row of [...rows.keys()].sort((a, b) => a - b)) {
        const idxs = rows.get(row) || [];
        const rowH = Math.max(...idxs.map((i) => childSizes[i].height));
        idxs.forEach((i) => {
            out[i] = { x: slotOf(i) % 2 === 0 ? root.x : col1X, y: top + rowH - childSizes[i].height };
        });
        top += rowH + GAP;
    }
    return out;
}

const VIDEO_NODE_MAX_WIDTH = 420;
const VIDEO_NODE_MAX_HEIGHT = 420;
// The Saint host exposes the Dola account pool as a virtual canvas channel.
// Keeping this identifier stable lets saved node metadata continue to route to
// the host even when the account pool changes internally.
const SAINT_DOLA_POOL_MODEL = "dola-seedance-2.5";
const CONNECTION_HANDLE_HIT_RADIUS = 40;
const CONNECTION_NODE_HIT_PADDING = 32;
const NODE_STATUS_LOADING = "loading" as const;
const NODE_STATUS_SUCCESS = "success" as const;
const NODE_STATUS_ERROR = "error" as const;
const NODE_STATUS_IDLE = "idle" as const;
const AGENT_PRIMARY_SCRIPT_NODE_SIZE = { width: 550, height: 600 };
const VIDEO_PREVIEW_CONTROL_CLASS = "flex size-9 items-center justify-center rounded-lg text-white transition-colors hover:bg-white/10";
const IMAGE_PROMPT_REVERSE_PRESET = `请根据参考图片反推一段适合用于 AI 生图的提示词。

要求：
1. 只输出提示词正文，不要解释。
2. 覆盖主体、构图、风格、光线、色彩、材质、镜头和氛围。
3. 尽量写成可直接用于生图模型的完整提示词。`;

type SaintHostTaskMessage = {
    id?: string;
    task_id?: string;
    taskId?: string;
    source?: string;
    source_id?: string;
    sourceId?: string;
    node_id?: string;
    nodeId?: string;
    canvasNodeId?: string;
    status?: string;
    progress?: number;
    model?: string;
    resultUrl?: string;
    videoUrl?: string;
    video_url?: string;
    url?: string;
    storageKey?: string;
    size?: string;
    seconds?: string | number;
    createdAt?: string | number;
    created_at?: string | number;
    startedAt?: string | number;
    started_at?: string | number;
    error?: { message?: string };
    message?: string;
    deliveryId?: string;
    accountName?: string;
    accountId?: string;
    account?: string;
    channelName?: string;
    taskNumber?: string;
    stage?: string;
    stageLabel?: string;
    generationMessage?: string;
    failureReason?: string;
};

function isEmbeddedSaintCanvas() {
    return typeof window !== "undefined" && window.parent !== window;
}

function isSaintDolaPoolModel(model: string | undefined) {
    const value = String(model || "").trim().toLowerCase();
    // 050：dola-seedance-web（2.0 Fast）来自宿主模型库，一并走宿主账号池通道
    return value === SAINT_DOLA_POOL_MODEL || value === "dola-seedance-web-2.5" || value === "dola-seedance-web" || (value.includes("seedance") && value.includes("2.5") && value.includes("dola"));
}

// 054：画布模型 ID → 宿主（main.js）认得的模型值。main 的分派按显示名匹配：
// Dola 生图要求 'Dola Seedream 5.0 Pro'、ChatGPT 生图要求 'ChatGPT image2'，saint-api/ 前缀走 API 渠道。
const CANVAS_TO_HOST_MODEL: Record<string, string> = {
    "dola-seedream-web": "Dola Seedream 5.0 Pro",
    "chatgpt-image2": "ChatGPT image2",
    "dola-expert-web": "Dola text",
    "chatgpt-text": "ChatGPT text",
};

function hostModelPayload(model: string | undefined) {
    const value = String(model || "").trim();
    return CANVAS_TO_HOST_MODEL[value] || value;
}

function isHostDispatchedModel(model: string | undefined) {
    const value = String(model || "").trim();
    if (!value) return false;
    return value.startsWith("saint-api/") || Boolean(CANVAS_TO_HOST_MODEL[value]);
}

function normalizeSaintPoolSeconds(model: string | undefined, value: string | undefined) {
    const seconds = String(value || "").trim();
    if (!isSaintDolaPoolModel(model)) return seconds;
    return seconds === "5" || seconds === "30" ? seconds : "30";
}

function ratioFromCanvasSize(size: string | undefined) {
    const value = String(size || "").trim();
    if (/^(1:1|3:4|4:3|9:16|16:9|21:9)$/.test(value)) return value;
    const match = value.match(/^(\d+)x(\d+)$/i);
    if (!match) return "16:9";
    const width = Number(match[1]);
    const height = Number(match[2]);
    if (!width || !height) return "16:9";
    const ratio = width / height;
    if (Math.abs(ratio - 1) < 0.08) return "1:1";
    if (Math.abs(ratio - 3 / 4) < 0.08) return "3:4";
    if (Math.abs(ratio - 4 / 3) < 0.08) return "4:3";
    if (Math.abs(ratio - 9 / 16) < 0.08) return "9:16";
    if (Math.abs(ratio - 21 / 9) < 0.08) return "21:9";
    return "16:9";
}

function saintHostTaskToVideoResponse(task: SaintHostTaskMessage): VideoResponse {
    const resultUrl = String(task.video_url || task.videoUrl || task.resultUrl || task.url || "").trim();
    return {
        ...(task as VideoResponse),
        id: String(task.id || task.task_id || task.taskId || ""),
        task_id: task.task_id || task.taskId || task.id,
        video_url: resultUrl || undefined,
        url: resultUrl || undefined,
        // Keep the stable virtual model id on the node. The host may report a
        // display model such as “Seedance 2.5”, but replacing the id would
        // make a later retry fall back to a direct API channel.
        model: SAINT_DOLA_POOL_MODEL,
        seconds: task.seconds === undefined ? undefined : String(task.seconds),
        error: task.error || task.message ? { message: task.error?.message || task.message } : undefined,
    };
}

function formatPreviewTime(value: number) {
    if (!Number.isFinite(value)) return "0:00";
    const seconds = Math.floor(value);
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const rest = String(seconds % 60).padStart(2, "0");
    return hours ? `${hours}:${String(minutes).padStart(2, "0")}:${rest}` : `${minutes}:${rest}`;
}

function createCanvasNode(type: CanvasNodeType, position: Position, metadata?: CanvasNodeMetadata, nodeId?: string): CanvasNodeData {
    const spec = getNodeSpec(type);
    const id = nodeId || `${type}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;

    return {
        id,
        type,
        title: spec.title,
        position: {
            x: position.x - spec.width / 2,
            y: position.y - spec.height / 2,
        },
        width: spec.width,
        height: spec.height,
        metadata: { ...spec.metadata, ...metadata },
    };
}

export default function CanvasPage() {
    const params = useParams<{ id: string }>();
    const [mounted, setMounted] = useState(false);

    useEffect(() => {
        setMounted(true);
    }, []);

    if (!mounted) return <CanvasRefreshShell />;

    return <NovusAIPage key={params.id} projectId={params.id} />;
}

function CanvasRefreshShell() {
    return (
        <main className="relative h-full min-h-0 overflow-hidden bg-background text-foreground">
            <div
                className="absolute inset-0 opacity-60"
                style={{
                    backgroundImage: "radial-gradient(circle, var(--border) 1px, transparent 1px)",
                    backgroundSize: "28px 28px",
                }}
            />

            <div className="absolute bottom-5 left-1/2 z-50 flex h-14 -translate-x-1/2 items-center gap-1 rounded-xl border px-2 shadow-lg backdrop-blur" style={{ background: "var(--background)", borderColor: "var(--border)" }} aria-hidden="true">
                {Array.from({ length: 7 }).map((_, index) => (
                    <div key={index} className="size-8 rounded-md bg-current opacity-10" />
                ))}
            </div>

            <div className="absolute bottom-24 left-6 z-50 h-40 w-[240px] rounded-lg border shadow-2xl backdrop-blur-sm" style={{ background: "var(--background)", borderColor: "var(--border)" }} aria-hidden="true">
                <div className="absolute left-7 top-7 h-5 w-12 rounded-sm bg-current opacity-10" />
                <div className="absolute left-28 top-16 h-6 w-16 rounded-sm bg-current opacity-10" />
                <div className="absolute bottom-7 left-16 h-8 w-20 rounded-sm bg-current opacity-10" />
                <div className="absolute inset-5 rounded border border-current opacity-15" />
            </div>

            <div className="absolute bottom-5 left-5 z-50 flex h-14 w-[260px] items-center gap-2 rounded-xl border px-2 shadow-lg backdrop-blur" style={{ background: "var(--background)", borderColor: "var(--border)" }} aria-hidden="true">
                <div className="size-8 rounded-md bg-current opacity-10" />
                <div className="size-8 rounded-md bg-current opacity-10" />
                <div className="h-1 flex-1 rounded-full bg-current opacity-10" />
                <div className="h-4 w-10 rounded bg-current opacity-10" />
                <div className="size-8 rounded-md bg-current opacity-10" />
            </div>
        </main>
    );
}

function ConnectionCreateMenu({ pending, nodes, onCreate }: { pending: PendingConnectionCreate; nodes: CanvasNodeData[]; onCreate: (type: CanvasNodeType) => void }) {
    const theme = canvasThemes[useThemeStore((state) => state.theme)];

    // 引用节点类型统计（boss 2026-10-04 生成规则）：图片/全景计为图片参考，视频、音频各自计数
    const refNodeIds = pending.sourceNodeIds?.length ? pending.sourceNodeIds : [pending.connection.nodeId];
    const refNodes = refNodeIds
        .map((id) => nodes.find((node) => node.id === id))
        .filter((node): node is CanvasNodeData => Boolean(node));
    const imageRefCount = refNodes.filter((node) => node.type === CanvasNodeType.Image || node.type === CanvasNodeType.Panorama).length;
    const videoRefCount = refNodes.filter((node) => node.type === CanvasNodeType.Video).length;
    const audioRefCount = refNodes.filter((node) => node.type === CanvasNodeType.Audio).length;

    // 禁用规则（boss 2026-10-04 口述）：
    // - 图片生成不支持视频参考、音频参考 → 引用里有视频或音频就置灰
    // - 只有视频节点（无图片）→ 只可以视频生成，文本生成置灰
    // - 有视频节点又有音频节点 → 不允许音频生成
    // - 视频生成：图片/视频/音频任意组合都可用
    const options: { type: CanvasNodeType; icon: React.ReactNode; title: string; disabled?: boolean }[] = [
        { type: CanvasNodeType.Text, icon: <List className="size-[18px]" />, title: "文本生成", disabled: imageRefCount === 0 && videoRefCount > 0 },
        { type: CanvasNodeType.Image, icon: <ImageIcon className="size-[18px]" />, title: "图片生成", disabled: videoRefCount > 0 || audioRefCount > 0 },
        { type: CanvasNodeType.Video, icon: <Video className="size-[18px]" />, title: "视频生成" },
        { type: CanvasNodeType.Audio, icon: <Music2 className="size-[18px]" />, title: "音频参考", disabled: videoRefCount > 0 && audioRefCount > 0 },
        { type: CanvasNodeType.Panorama, icon: <Globe2 className="size-[18px]" />, title: "全景图" },
        { type: CanvasNodeType.Director, icon: <Layers3 className="size-[18px]" />, title: "3D 导演台" },
        { type: CanvasNodeType.Config, icon: <Settings2 className="size-[18px]" />, title: "配置节点" },
    ];

    return (
        <div
            className="thin-scrollbar absolute z-[120] max-h-[520px] w-[220px] overflow-y-auto rounded-2xl border p-1.5 shadow-2xl backdrop-blur"
            data-connection-create-menu
            data-canvas-no-zoom
            style={{ left: pending.position.x, top: pending.position.y, transform: "translateY(calc(-50% * var(--canvas-inverse-scale, 1))) scale(var(--canvas-inverse-scale, 1))", transformOrigin: "top left", background: "#262626", borderColor: theme.node.stroke, color: theme.node.text }}
            onMouseDown={(event) => event.stopPropagation()}
            onPointerDown={(event) => event.stopPropagation()}
        >
            <div className="px-2 pb-1.5 pt-1 text-xs leading-4" style={{ color: theme.node.muted }}>
                {pending.selection ? `引用选中的 ${refNodes.length} 个${audioRefCount > 0 ? "" : "图片/视频"}节点` : "引用该节点生成"}
            </div>
            <div className="grid gap-0.5">
                {options.map((option) => (
                    <ConnectionCreateOption key={option.type} theme={theme} icon={option.icon} title={option.title} disabled={option.disabled} onClick={() => onCreate(option.type)} />
                ))}
            </div>
        </div>
    );
}

// 018-1（boss 2026-10-04）：原 hover 用 theme.node.fill(#262626)，与菜单背景同色导致看不见；改为外壳侧边栏同款 #30303e + 阴影
function ConnectionCreateOption({ theme, icon, title, disabled, onClick }: { theme: (typeof canvasThemes)[keyof typeof canvasThemes]; icon: React.ReactNode; title: string; disabled?: boolean; onClick?: () => void }) {
    return (
        <button
            type="button"
            disabled={disabled}
            className={`flex h-9 w-full items-center gap-2.5 rounded-[10px] px-2 text-left ${disabled ? "cursor-not-allowed" : "cursor-pointer"}`}
            style={{ color: disabled ? theme.node.faint : theme.node.text }}
            onClick={disabled ? undefined : onClick}
            onMouseEnter={disabled ? undefined : (event) => { event.currentTarget.style.background = "#30303e"; event.currentTarget.style.boxShadow = "0 2px 10px rgba(0,0,0,.35)"; }}
            onMouseLeave={disabled ? undefined : (event) => { event.currentTarget.style.background = "transparent"; event.currentTarget.style.boxShadow = "none"; }}
        >
            <span className="shrink-0">{icon}</span>
            <span className="min-w-0 flex-1 truncate text-[13px] leading-4">{title}</span>
        </button>
    );
}

function FloatingConnectPlus({
    bounds,
    theme,
    screenToCanvas,
    onConnectStart,
    sourceNodeIds,
    dragging,
    dragWorld,
}: {
    bounds: { left: number; top: number; right: number; bottom: number };
    theme: (typeof canvasThemes)[keyof typeof canvasThemes];
    screenToCanvas: (x: number, y: number) => Position;
    onConnectStart: (event: ReactMouseEvent<HTMLButtonElement>, sourceNodeIds: string[]) => void;
    sourceNodeIds: string[];
    dragging: boolean;
    dragWorld: Position | null;
}) {
    const [offset, setOffset] = useState<{ x: number; y: number } | null>(null);
    const centerX = bounds.right + 44;
    const centerY = (bounds.top + bounds.bottom) / 2;
    const maxDist = 48;

    const track = (clientX: number, clientY: number) => {
        const world = screenToCanvas(clientX, clientY);
        let ox = world.x - centerX;
        let oy = world.y - centerY;
        const dist = Math.hypot(ox, oy);
        if (dist > maxDist) {
            ox = (ox / dist) * maxDist;
            oy = (oy / dist) * maxDist;
        }
        setOffset({ x: ox, y: oy });
    };

    // 松手（拖拽结束）后：清除残留偏移，加号回到圆心待命
    useEffect(() => {
        if (!dragging) setOffset(null);
    }, [dragging]);
    const buttonLeft = dragging && dragWorld ? dragWorld.x - 11 : centerX - 11;
    const buttonTop = dragging && dragWorld ? dragWorld.y - 11 : centerY - 11;

    return (
        <>
            <div
                aria-hidden="true"
                className="absolute z-[70] rounded-full"
                style={{ left: centerX - 64, top: centerY - 64, width: 128, height: 128, cursor: "crosshair" }}
                onMouseMove={(event) => track(event.clientX, event.clientY)}
                onMouseLeave={() => setOffset(null)}
            />
            <button
                type="button"
                aria-label="从选中节点创建连接"
                data-canvas-no-zoom
                className="absolute z-[80] grid size-[22px] place-items-center rounded-full border shadow-md opacity-85 hover:opacity-100 will-change-transform"
                style={{ left: buttonLeft, top: buttonTop, transition: dragging ? "none" : "transform 100ms ease-out", transform: `translate(${offset && !(dragging && dragWorld) ? `${offset.x}px, ${offset.y}px` : "0, 0"}) scale(var(--canvas-inverse-scale, 1))`, transformOrigin: "center", background: theme.node.panel, borderColor: theme.canvas.selectionStroke, color: theme.node.text }}
                onMouseDown={(event) => onConnectStart(event, sourceNodeIds)}
                onMouseMove={(event) => track(event.clientX, event.clientY)}
            >
                <Plus className="size-3" strokeWidth={2.2} />
            </button>
        </>
    );
}

const EMPTY_ALIGN_GUIDES: { vLines: number[]; hLines: number[] } = { vLines: [], hLines: [] };

function NovusAIPage({ projectId }: { projectId: string }) {
    const { message } = App.useApp();
    const router = useRouter();
    const containerRef = useRef<HTMLDivElement>(null);
    const imageInputRef = useRef<HTMLInputElement>(null);
    const assetInsertPositionRef = useRef<Position | null>(null);
    const draggedAssetPayloadRef = useRef<InsertAssetPayload | null>(null);
    const uploadTargetRef = useRef<{ nodeId?: string; position?: Position } | null>(null);
    const clipboardRef = useRef<CanvasClipboard | null>(null);
    const historyRef = useRef<{ past: CanvasHistoryEntry[]; future: CanvasHistoryEntry[] }>({ past: [], future: [] });
    const lastHistoryRef = useRef<CanvasHistoryEntry | null>(null);
    const historyCommitTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
    const historyCleanupTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
    const historyCleanupKeysRef = useRef(new Map<string, string>());
    const viewportSaveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
    const sidePanelSaveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
    const focusAnimationRef = useRef<number | null>(null);
    const applyingHistoryRef = useRef(false);
    const historyPausedRef = useRef(false);
    const didInitialCenterRef = useRef(false);
    const rafRef = useRef<number | null>(null);
    const uploadingMediaNodeIdsRef = useRef(new Set<string>());
    const uploadingImageNodeIdsRef = useRef(new Set<string>());
    const nodeDraggingRef = useRef(false);
    const dragRef = useRef<{
        isDraggingNode: boolean;
        hasMoved: boolean;
        startX: number;
        startY: number;
        initialSelectedNodes: { id: string; x: number; y: number; width: number; height: number }[];
        clickedGroupId: string | null;
        // 本次拖拽是否涉及组（组节点本身或组内子节点）：组拖拽不做网格吸附，只保留对齐
        dragIncludesGroup: boolean;
    }>({
        isDraggingNode: false,
        hasMoved: false,
        clickedGroupId: null,
        dragIncludesGroup: false,
        startX: 0,
        startY: 0,
        initialSelectedNodes: [],
    });

    const [alignGuides, setAlignGuides] = useState<{ vLines: number[]; hLines: number[] }>({ vLines: [], hLines: [] });

    // Grid snap + node-edge alignment snap for node drags. Shared by live preview and commit.
    const resolveDragDelta = useCallback((initialPositions: { id: string; x: number; y: number; width: number; height: number }[], rawDx: number, rawDy: number, enabled: boolean) => {
        const snapped = snapCanvasDragDelta(initialPositions, rawDx, rawDy, enabled);
        const draggedIds = new Set(initialPositions.map((item) => item.id));
        const draggedBoxes: AlignBox[] = initialPositions.map((item) => ({ id: item.id, x: item.x, y: item.y, width: item.width, height: item.height }));
        const others: AlignBox[] = nodesRef.current
            .filter((node) => !draggedIds.has(node.id))
            .map((node) => ({ id: node.id, x: node.position.x, y: node.position.y, width: node.width, height: node.height }));
        const threshold = 6 / Math.max(viewportRef.current.k, 0.05);
        const alignment = computeAlignmentSnap(draggedBoxes, snapped.x, snapped.y, others, threshold);
        return { dx: alignment.dx, dy: alignment.dy, vLines: alignment.vLines, hLines: alignment.hLines };
    }, []);

    const config = useConfigStore((state) => state.config);
    const effectiveConfig = useEffectiveConfig();
    const isAiConfigReady = useConfigStore((state) => state.isAiConfigReady);
    const openConfigDialog = useConfigStore((state) => state.openConfigDialog);
    const addAssetAsync = useAssetStore((state) => state.addAssetAsync);
    const cleanupAssetImages = useAssetStore((state) => state.cleanupImages);
    const hydrated = useCanvasStore((state) => state.hydrated);
    const createProject = useCanvasStore((state) => state.createProject);
    const openProject = useCanvasStore((state) => state.openProject);
    const updateProject = useCanvasStore((state) => state.updateProject);
    const renameProject = useCanvasStore((state) => state.renameProject);
    const deleteProjects = useCanvasStore((state) => state.deleteProjects);
    const currentProject = useCanvasStore((state) => state.projects.find((project) => project.id === projectId));
    const colorTheme = useThemeStore((state) => state.theme);
    const theme = canvasThemes[colorTheme];
    const [nodes, setNodes] = useState<CanvasNodeData[]>([]);
    const [connections, setConnections] = useState<CanvasConnection[]>([]);
    const [chatSessions, setChatSessions] = useState<CanvasAssistantSession[]>([]);
    const [activeChatId, setActiveChatId] = useState<string | null>(null);
    const [agentConfig, setAgentConfig] = useState<CanvasAgentConfig | null>(null);
    const [initialAgentRequest, setInitialAgentRequest] = useState<{ prompt: CanvasPendingAgentRequest["prompt"]; references: CanvasAssistantReference[]; skills: CanvasPendingAgentRequest["skills"] } | null>(null);
    const [viewport, setViewport] = useState<ViewportTransform>({ x: 0, y: 0, k: 1 });
    const [canvasTool, setCanvasTool] = useState<"select" | "pan">("select");
    const [size, setSize] = useState({ width: 1200, height: 720 });
    const [selectedNodeIds, setSelectedNodeIds] = useState<Set<string>>(new Set());
    const [agentReferenceNodeClick, setAgentReferenceNodeClick] = useState<{ nodeId: string | null; version: number }>({ nodeId: null, version: 0 });
    const [selectedConnectionId, setSelectedConnectionId] = useState<string | null>(null);
    // 框选（marquee）命中的连线：支持多选后按 Delete 批量删除
    const [selectedConnectionIds, setSelectedConnectionIds] = useState<Set<string>>(new Set());
    const [hoveredNodeId, setHoveredNodeId] = useState<string | null>(null);
    // 画布平移中：暂停 hover 等高开销更新，避免框内抓手拖动卡顿
    const [canvasPanning, setCanvasPanning] = useState(false);
    const canvasPanningRef = useRef(false);
    const [connectingParams, setConnectingParams] = useState<ConnectionHandle | null>(null);
    const [connectionTargetNodeId, setConnectionTargetNodeId] = useState<string | null>(null);
    const [pendingConnectionCreate, setPendingConnectionCreate] = useState<PendingConnectionCreate | null>(null);
    const [selectionConnectionDrag, setSelectionConnectionDrag] = useState<{ sourceNodeIds: string[] } | null>(null);
    const [mouseWorld, setMouseWorld] = useState<Position>({ x: 0, y: 0 });
    const [selectionBox, setSelectionBox] = useState<SelectionBox | null>(null);
    const [contextMenu, setContextMenu] = useState<ContextMenuState | null>(null);
    const [nodeCreatePosition, setNodeCreatePosition] = useState<Position | null>(null);
    /** 任务06：原版导航＋按钮的菜单锚点（屏幕固定坐标，left=导航中心、bottom=导航顶+8） */
    const [nodeCreateAnchor, setNodeCreateAnchor] = useState<{ left: number; bottom: number } | null>(null);
    const [runningNodeId, setRunningNodeId] = useState<string | null>(null);
    const [isMiniMapOpen, setIsMiniMapOpen] = useState(false);
    const [hideConnections, setHideConnections] = useState(false);
    const [backgroundMode, setBackgroundMode] = useState<CanvasBackgroundMode>("lines");
    const [snapToGrid, setSnapToGrid] = useState(true);
    const [showImageInfo, setShowImageInfo] = useState(false);
    const [sidePanel, setSidePanel] = useState(() => DEFAULT_CANVAS_SIDE_PANEL);
    // rf8HzD：左侧面板停靠推开——画布区跟随面板宽度右移。拖宽期间禁用 left 过渡（即时跟随），松手后恢复
    const [sidePanelResizing, setSidePanelResizing] = useState(false);
    const sidePanelResizeTimerRef = useRef<number | null>(null);
    const handleSidePanelWidthChange = useCallback((width: number) => {
        setSidePanel((current) => ({ ...current, width }));
        setSidePanelResizing(true);
        if (sidePanelResizeTimerRef.current) window.clearTimeout(sidePanelResizeTimerRef.current);
        // 160ms 内无新拖动事件才算拖宽结束，恢复开关动画；与 CanvasSidePanel 拖宽（duration 0）节奏一致
        sidePanelResizeTimerRef.current = window.setTimeout(() => setSidePanelResizing(false), 160);
    }, []);
    const [clearConfirmOpen, setClearConfirmOpen] = useState(false);
    const [assetPickerOpen, setAssetPickerOpen] = useState(false);
    const [assetPickerTab, setAssetPickerTab] = useState<AssetPickerTab>("my-assets");
    // 030：分类库（角色/场景/服装/道具/其他库）→ 记录“从哪个节点点开的、要哪个分类”
    const [categoryLibrary, setCategoryLibrary] = useState<{ nodeId: string; category: string } | null>(null);
    const [pendingPanoramaImport, setPendingPanoramaImport] = useState<PendingPanoramaImport | null>(null);
    const [projectLoaded, setProjectLoaded] = useState(false);
    const [toolbarNodeId, setToolbarNodeId] = useState<string | null>(null);
    const [nodeImageSettingsOpen, setNodeImageSettingsOpen] = useState(false);
    const [dialogNodeId, setDialogNodeId] = useState<string | null>(null);
    const [openDirectorNodeId, setOpenDirectorNodeId] = useState<string | null>(null);
    const [infoNodeId, setInfoNodeId] = useState<string | null>(null);
    const [cropNodeId, setCropNodeId] = useState<string | null>(null);
    const [audioTrimNodeId, setAudioTrimNodeId] = useState<string | null>(null);
    const [audioTrimStart, setAudioTrimStart] = useState(0);
    const [audioTrimEnd, setAudioTrimEnd] = useState(0);
    const [audioTrimDuration, setAudioTrimDuration] = useState(0);
    const [audioTrimPlaying, setAudioTrimPlaying] = useState(false);
    const [trimmingAudio, setTrimmingAudio] = useState(false);
    const audioTrimRef = useRef<HTMLAudioElement | null>(null);
    const [maskEditNodeId, setMaskEditNodeId] = useState<string | null>(null);
    const [maskEditModel, setMaskEditModel] = useState("");
    const [maskEditChannelId, setMaskEditChannelId] = useState("");
    const [splitNodeId, setSplitNodeId] = useState<string | null>(null);
    const [upscaleNodeId, setUpscaleNodeId] = useState<string | null>(null);
    const [superResolveNodeId, setSuperResolveNodeId] = useState<string | null>(null);
    const [angleNodeId, setAngleNodeId] = useState<string | null>(null);
    // 任务rDjmof：「旋转与镜像」——变换目标节点（独立新节点）与实时变换参数
    const [transformNodeId, setTransformNodeId] = useState<string | null>(null);
    const [transformState, setTransformState] = useState<NodeTransformState>({ angle: 0, flipH: false, flipV: false });
    const [previewNodeId, setPreviewNodeId] = useState<string | null>(null);
    const [generationHistoryOpen, setGenerationHistoryOpen] = useState(false);
    const canvasProjects = useCanvasStore((state) => state.projects);
    const [agentPanel, setAgentPanel] = useState(DEFAULT_CANVAS_AGENT_PANEL);
    // 底部工具栏“生成历史”：每次触发 +1，Agent 面板监听该信号切到历史记录视图
    const [assistantHistorySignal, setAssistantHistorySignal] = useState(0);
    const [toolbarShortcutsOpen, setToolbarShortcutsOpen] = useState(false);
    // 任务05：原版快捷键面板（底栏 keyboard 按钮 toggle 触发，与现有快捷键 Modal 两套并存）
    const [originalShortcutsOpen, setOriginalShortcutsOpen] = useState(false);
    /** 画布节点搜索浮层（Ctrl+F，boss 2026-10-04 补齐功能） */
    const [nodeSearchOpen, setNodeSearchOpen] = useState(false);
    const [assistantMounted, setAssistantMounted] = useState(false);
    const [titleEditing, setTitleEditing] = useState(false);
    const [titleDraft, setTitleDraft] = useState("");
    const [historyState, setHistoryState] = useState({ canUndo: false, canRedo: false });
    const [collapsingBatchIds, setCollapsingBatchIds] = useState<Set<string>>(new Set());
    const [openingBatchIds, setOpeningBatchIds] = useState<Set<string>>(new Set());
    const [isNodeDragging, setIsNodeDragging] = useState(false);
    const [dropTargetGroupId, setDropTargetGroupId] = useState<string | null>(null);
    const [referencePickerNodeId, setReferencePickerNodeId] = useState<string | null>(null);
    const [canvasNow, setCanvasNow] = useState(Date.now());
    const resolvedAgentConfig = useMemo<CanvasAgentConfig>(
        () => {
            const defaults = { textApiMode: "chat" as const, autoGenerateMedia: false };
            return agentConfig ? { ...defaults, ...agentConfig } : {
                textApiMode: "chat",
                autoGenerateMedia: false,
                imageQuality: effectiveConfig.quality,
                imageSize: effectiveConfig.size,
                videoQuality: effectiveConfig.vquality,
                videoSize: effectiveConfig.videoSize,
            };
        },
        [agentConfig, effectiveConfig.quality, effectiveConfig.size, effectiveConfig.videoSize, effectiveConfig.vquality],
    );
    const agentEffectiveConfig = useMemo(
        () => ({ ...effectiveConfig, quality: resolvedAgentConfig.imageQuality, size: resolvedAgentConfig.imageSize, vquality: resolvedAgentConfig.videoQuality, videoSize: resolvedAgentConfig.videoSize, count: "1", canvasImageCount: "1" }),
        [effectiveConfig, resolvedAgentConfig],
    );

    const nodesRef = useRef(nodes);
    const consumedAgentRequestProjectRef = useRef<string | null>(null);
    const connectionsRef = useRef(connections);
    const selectedNodeIdsRef = useRef(selectedNodeIds);
    const selectedConnectionIdsRef = useRef(selectedConnectionIds);
    const viewportRef = useRef(viewport);
    const connectingParamsRef = useRef(connectingParams);
    const connectionPressStartPosRef = useRef<{ x: number; y: number } | null>(null);
    const connectionTargetNodeIdRef = useRef(connectionTargetNodeId);
    const selectionBoxRef = useRef(selectionBox);
    const pendingConnectionCreateRef = useRef(pendingConnectionCreate);
    const selectionConnectionDragRef = useRef<{ sourceNodeIds: string[] } | null>(null);
    const pollingVideoNodeIdsRef = useRef(new Set<string>());
    const saintHostVideoRequestsRef = useRef(new Map<string, { resolve: (task: VideoResponse) => void; reject: (error: Error) => void }>());
    const saintHostVideoStatusRequestsRef = useRef(new Map<string, { resolve: (task: VideoResponse) => void; reject: (error: Error) => void }>());
    const saintHostVideoPollFailuresRef = useRef(new Map<string, number>());
    const pollingImageNodeIdsRef = useRef(new Set<string>());
    const pollingAudioNodeIdsRef = useRef(new Set<string>());
    const hasLoadingTimedNodes = nodes.some((node) => node.metadata?.status === NODE_STATUS_LOADING && !node.metadata.content && (node.type === CanvasNodeType.Video || isCanvasImageNodeType(node.type) || node.type === CanvasNodeType.Audio));

    const requestSaintHostVideoTask = useCallback((payload: Record<string, unknown>) => {
        return new Promise<VideoResponse>((resolve, reject) => {
            if (!isEmbeddedSaintCanvas()) {
                reject(new Error("当前画布没有连接Novus AI 宿主"));
                return;
            }
            const requestId = String(payload.requestId || `saint-canvas-${nanoid()}`);
            saintHostVideoRequestsRef.current.set(requestId, { resolve, reject });
            // 054：宿主桥异常（如 IPC 抛错未回包）时 60s 兜底，避免节点永久转圈
            window.setTimeout(() => {
                if (saintHostVideoRequestsRef.current.has(requestId)) {
                    saintHostVideoRequestsRef.current.delete(requestId);
                    reject(new Error("宿主视频任务创建超时，请重试"));
                }
            }, 60_000);
            window.parent.postMessage({ source: "kinglevel-canvas", type: "video-generation-request", payload: { ...payload, requestId, model: SAINT_DOLA_POOL_MODEL } }, "*");
        });
    }, []);

    // 054：图片任务走宿主（Dola 账号池生图 / ChatGPT image2 / saint-api 渠道），协议同视频桥
    const saintHostImageRequestsRef = useRef(new Map<string, { resolve: (task: Record<string, unknown>) => void; reject: (error: Error) => void }>());
    const requestSaintHostImageTask = useCallback((payload: Record<string, unknown>) => {
        return new Promise<Record<string, unknown>>((resolve, reject) => {
            if (!isEmbeddedSaintCanvas()) {
                reject(new Error("当前画布没有连接Novus AI 宿主"));
                return;
            }
            const requestId = String(payload.requestId || `saint-image-${nanoid()}`);
            saintHostImageRequestsRef.current.set(requestId, { resolve, reject });
            window.setTimeout(() => {
                if (saintHostImageRequestsRef.current.has(requestId)) {
                    saintHostImageRequestsRef.current.delete(requestId);
                    reject(new Error("宿主图片任务创建超时，请重试"));
                }
            }, 60_000);
            window.parent.postMessage({ source: "kinglevel-canvas", type: "image-generation-request", payload: { ...payload, requestId, model: hostModelPayload(String(payload.model || "")) } }, "*");
        });
    }, []);

    // 056：文本任务走宿主（Dola text / ChatGPT text 账号池），创建后等宿主推送完成（结果在 task.answer）
    const saintHostTextRequestsRef = useRef(new Map<string, { resolve: (task: Record<string, unknown>) => void; reject: (error: Error) => void }>());
    const saintHostTextWaitersRef = useRef(new Map<string, { resolve: (answer: string) => void; reject: (error: Error) => void }>());
    const requestSaintHostTextTask = useCallback((payload: Record<string, unknown>) => {
        return new Promise<Record<string, unknown>>((resolve, reject) => {
            if (!isEmbeddedSaintCanvas()) {
                reject(new Error("当前画布没有连接Novus AI 宿主"));
                return;
            }
            const requestId = String(payload.requestId || `saint-text-${nanoid()}`);
            saintHostTextRequestsRef.current.set(requestId, { resolve, reject });
            window.setTimeout(() => {
                if (saintHostTextRequestsRef.current.has(requestId)) {
                    saintHostTextRequestsRef.current.delete(requestId);
                    reject(new Error("宿主文本任务创建超时，请重试"));
                }
            }, 30_000);
            window.parent.postMessage({ source: "kinglevel-canvas", type: "text-generation-request", payload: { ...payload, requestId, model: hostModelPayload(String(payload.model || "")) } }, "*");
        });
    }, []);
    const waitSaintHostTextTask = useCallback((taskId: string) => {
        return new Promise<string>((resolve, reject) => {
            saintHostTextWaitersRef.current.set(taskId, { resolve, reject });
            window.setTimeout(() => {
                if (saintHostTextWaitersRef.current.has(taskId)) {
                    saintHostTextWaitersRef.current.delete(taskId);
                    reject(new Error("宿主文本生成超时"));
                }
            }, 600_000);
        });
    }, []);

    // The Electron host normally pushes status changes, but an iframe can be
    // recreated while a task is running and miss one of those messages. Keep
    // the same bridge requestable so the canvas can recover the latest task
    // state without falling back to the public provider polling path.
    const requestSaintHostVideoStatus = useCallback((taskId: string, nodeId: string) => {
        return new Promise<VideoResponse>((resolve, reject) => {
            if (!isEmbeddedSaintCanvas()) {
                reject(new Error("当前画布没有连接Novus AI 宿主"));
                return;
            }
            const requestId = `saint-canvas-status-${nanoid()}`;
            saintHostVideoStatusRequestsRef.current.set(requestId, { resolve, reject });
            const timeout = window.setTimeout(() => {
                if (!saintHostVideoStatusRequestsRef.current.has(requestId)) return;
                saintHostVideoStatusRequestsRef.current.delete(requestId);
                reject(new Error(`账号池任务 ${taskId} 状态请求超时`));
            }, 20_000);
            window.parent.postMessage({
                source: "kinglevel-canvas",
                type: "video-generation-status-request",
                payload: { requestId, taskId, nodeId },
            }, "*");
            void Promise.resolve().then(() => {
                if (!saintHostVideoStatusRequestsRef.current.has(requestId)) window.clearTimeout(timeout);
            });
        });
    }, []);

    // Receive task lifecycle events from the Electron renderer and apply them
    // to the actual video node that initiated the request.
    useEffect(() => {
        if (!isEmbeddedSaintCanvas()) return;
        const parent = window.parent;
        const onMessage = (event: MessageEvent) => {
            if (event.source !== parent || event.data?.source !== "kinglevel-host") return;
            const message = event.data as { type?: string; payload?: { requestId?: string; task?: SaintHostTaskMessage; message?: string } };
            const payload = message.payload || {};
            if (message.type === "video-generation-created") {
                const requestId = String(payload.requestId || "");
                const pending = requestId ? saintHostVideoRequestsRef.current.get(requestId) : undefined;
                if (!pending) return;
                saintHostVideoRequestsRef.current.delete(requestId);
                pending.resolve(saintHostTaskToVideoResponse(payload.task || {}));
                return;
            }
            // 065：图片任务创建应答（054 漏了此处理——宿主毫秒级回包没人听，干等到 60s 创建超时）
            if (message.type === "image-generation-created") {
                const requestId = String(payload.requestId || "");
                const pending = requestId ? saintHostImageRequestsRef.current.get(requestId) : undefined;
                if (!pending) return;
                saintHostImageRequestsRef.current.delete(requestId);
                pending.resolve((payload.task || {}) as Record<string, unknown>);
                return;
            }
            if (message.type === "host-error") {
                const requestId = String(payload.requestId || "");
                const pending = requestId ? saintHostVideoRequestsRef.current.get(requestId) : undefined;
                if (pending) {
                    saintHostVideoRequestsRef.current.delete(requestId);
                    pending.reject(new Error(String(payload.message || "Novus AI 宿主生成失败")));
                }
                // 054：图片宿主任务创建失败（Dola 无可用账号 / 渠道密钥错误等）→ 立刻落到对应节点
                const imagePending = requestId ? saintHostImageRequestsRef.current.get(requestId) : undefined;
                if (imagePending) {
                    saintHostImageRequestsRef.current.delete(requestId);
                    imagePending.reject(new Error(String(payload.message || "Novus AI 宿主生成失败")));
                }
                // 056：文本宿主任务创建失败
                const textPending = requestId ? saintHostTextRequestsRef.current.get(requestId) : undefined;
                if (textPending) {
                    saintHostTextRequestsRef.current.delete(requestId);
                    textPending.reject(new Error(String(payload.message || "Novus AI 宿主生成失败")));
                }
                return;
            }
            // 056：文本任务创建应答 + 完成推送（结果在 task.answer；失败走 waiter reject）
            if (message.type === "text-generation-created") {
                const requestId = String(payload.requestId || "");
                const pending = requestId ? saintHostTextRequestsRef.current.get(requestId) : undefined;
                if (pending) {
                    saintHostTextRequestsRef.current.delete(requestId);
                    pending.resolve((payload.task || {}) as Record<string, unknown>);
                }
                return;
            }
            if (message.type === "text-generation-status") {
                const task = ((payload as Record<string, unknown>).task || payload) as Record<string, unknown>;
                const taskId = String(task.id || "");
                const waiter = taskId ? saintHostTextWaitersRef.current.get(taskId) : undefined;
                if (!waiter) return;
                const status = String(task.status || "");
                if (status === "success" || status === "completed") {
                    saintHostTextWaitersRef.current.delete(taskId);
                    waiter.resolve(String(task.answer || ""));
                } else if (status === "failed" || status === "error") {
                    saintHostTextWaitersRef.current.delete(taskId);
                    waiter.reject(new Error(String((task.error as { message?: string })?.message || task.message || "宿主文本生成失败")));
                }
                return;
            }
            // 054：宿主图片任务状态（主动推送 payload=task；请求应答 payload={requestId,task}，两种形态都接）
            if (message.type === "image-generation-status" || message.type === "image-generation-error") {
                const task = ((payload as Record<string, unknown>).task || payload) as Record<string, unknown>;
                const status = String(task.status || "");
                if (message.type === "image-generation-error" || status === "failed") {
                    const errorDetail = String((task.error as { message?: string })?.message || task.message || task.error || "宿主图片生成失败");
                    setNodes((prev) => {
                        // 065：created 丢失时节点 imageTaskId 可能仍是发起前状态——补 node_id 兜底（LOADING 也要能命中）
                        const target = prev.find((node) => node.metadata?.hostImageTask && node.metadata?.imageTaskId === String(task.id || ""))
                            || prev.find((node) => node.metadata?.hostImageTask && node.id === String(task.node_id || "") && node.metadata?.status === NODE_STATUS_LOADING);
                        if (!target) return prev;
                        return prev.map((node) => (node.id === target.id ? { ...node, metadata: { ...node.metadata, status: NODE_STATUS_ERROR, errorDetails: errorDetail } } : node));
                    });
                    return;
                }
                if (status !== "success" && status !== "completed") return;
                const output = String(task.url || task.image_url || task.resultUrl || (task.outputs as string[] | undefined)?.[0] || "");
                if (!output) return;
                // 063：宿主多张图（Dola 单次 1~4 张不定）——全部 URL，首张进主节点，其余平铺新节点
                const hostImageUrls = Array.isArray(task.image_urls) ? (task.image_urls as unknown[]).map((url) => String(url || "").trim()).filter(Boolean) : [];
                const allUrls = [...new Set([output, ...hostImageUrls])];
                setNodes((prev) => {
                    // 057：优先按 taskId 匹配；创建应答超时未回包时（imageTaskId 还是 clientTaskId），按 node_id 兜底匹配，防止任务白跑
                    const target = prev.find((node) => node.metadata?.hostImageTask && node.metadata?.imageTaskId === String(task.id || ""))
                        || prev.find((node) => node.metadata?.hostImageTask && node.id === String(task.node_id || "") && node.metadata?.status === NODE_STATUS_ERROR);
                    if (!target) return prev;
                    const normalized: Record<string, unknown> = { ...task, url: allUrls[0], image_url: allUrls[0], image_urls: allUrls, status: "success" };
                    let next = applyCanvasImageTaskUpdate(prev, target.id, normalized as never, target.metadata?.startedAt || Date.now(), { width: target.width, height: target.height });
                    const extraUrls = allUrls.slice(1);
                    if (!extraUrls.length) return next;
                    // 073：多张改用画布原生 batch 结构（isBatchRoot/batchChildIds）——折叠堆叠、九宫格展开、双击切换全用原生能力
                    const rootNode = next.find((node) => node.id === target.id);
                    if (!rootNode) return next;
                    // 096：重拉/补图去重——重拉会再次推送全量 image_urls，content 已存在的子图不重复建节点，只补新图
                    const existingChildren = next.filter((node) => node.metadata?.batchRootId === target.id && node.id !== target.id);
                    const existingByContent = new Map(existingChildren.map((child) => [String(child.metadata?.content || ""), child]));
                    const newUrls = extraUrls.filter((url) => !existingByContent.has(url));
                    // 093：主图占田字格 (0,0)，子图按阅读顺序填其余格（LibTV 真值，gap 8、行底对齐）
                    const childBoxes = layoutBatchExpandedChildren({ x: rootNode.position.x, y: rootNode.position.y, width: rootNode.width, height: rootNode.height }, extraUrls.map(() => ({ width: rootNode.width, height: rootNode.height })));
                    const urlSlot = new Map(extraUrls.map((url, index) => [url, index]));
                    const newIds = newUrls.map(() => `${target.id}-host-${nanoid()}`);
                    const newIdByUrl = new Map(newUrls.map((url, index) => [url, newIds[index]]));
                    const childNodes = newUrls.map((url, i): CanvasNodeData => ({
                        id: newIds[i],
                        type: CanvasNodeType.Image,
                        title: rootNode.title,
                        position: childBoxes[urlSlot.get(url) ?? i],
                        width: rootNode.width,
                        height: rootNode.height,
                        metadata: {
                            content: url,
                            status: NODE_STATUS_SUCCESS,
                            prompt: rootNode.metadata?.prompt,
                            startedAt: rootNode.metadata?.startedAt,
                            naturalWidth: rootNode.metadata?.naturalWidth,
                            naturalHeight: rootNode.metadata?.naturalHeight,
                            mimeType: rootNode.metadata?.mimeType || "image/png",
                            progress: 100,
                            imageTaskId: String(task.id || ""),
                            hostImageTask: true,
                            batchRootId: target.id,
                        },
                    }));
                    // 子图顺序按 extraUrls 排：已有子图沿用原 id，新图用新 id
                    const childIds = extraUrls.map((url) => existingByContent.get(url)?.id || newIdByUrl.get(url) || `${target.id}-host-${nanoid()}`);
                    next = [...next, ...childNodes].map((node) => (node.id === target.id ? {
                        ...node,
                        metadata: {
                            ...node.metadata,
                            isBatchRoot: true,
                            batchChildIds: childIds,
                            primaryImageId: target.id,
                            imageBatchExpanded: true,
                        },
                    } : node));
                    return next;
                });
                return;
            }
            if (message.type !== "video-generation-status") return;
            // Push notifications carry the task directly as payload, while
            // request/response polling wraps it as { requestId, task }.
            // Accept both shapes so a successful or failed Dola task cannot
            // be dropped just because it arrived via the push path.
            const rawTask = (payload.task || payload) as SaintHostTaskMessage;
            const task = saintHostTaskToVideoResponse(rawTask);
            const requestId = String(payload.requestId || "");
            const pendingStatus = requestId ? saintHostVideoStatusRequestsRef.current.get(requestId) : undefined;
            if (pendingStatus) {
                saintHostVideoStatusRequestsRef.current.delete(requestId);
                if (task.id || task.task_id || rawTask.status) pendingStatus.resolve(task);
                else pendingStatus.reject(new Error("Novus AI 未返回画布视频任务状态"));
            }
            const nodeId = String(rawTask.canvasNodeId || rawTask.nodeId || rawTask.node_id || "");
            const target = nodesRef.current.find((node) => node.id === nodeId || node.metadata?.videoTaskId === task.id);
            if (!target) return;
            const nodeConfig = buildGenerationConfig(effectiveConfig, target, "video");
            setNodes((prev) => applyCanvasVideoTaskUpdate(prev, target.id, task, nodeConfig, target.metadata?.startedAt || Date.now(), { width: target.width, height: target.height }));
            if (canvasVideoTaskCompleted(task) || canvasVideoTaskFailed(task)) {
                parent.postMessage({ source: "kinglevel-canvas", type: "video-generation-ack", payload: { taskId: task.id, deliveryId: rawTask.deliveryId || "", nodeId: target.id } }, "*");
            }
        };
        window.addEventListener("message", onMessage);
        parent.postMessage({ source: "kinglevel-canvas", type: "canvas-ready", payload: { route: window.location.pathname } }, "*");
        return () => {
            window.removeEventListener("message", onMessage);
            saintHostVideoRequestsRef.current.forEach(({ reject }) => reject(new Error("画布已关闭")));
            saintHostVideoRequestsRef.current.clear();
            saintHostVideoStatusRequestsRef.current.forEach(({ reject }) => reject(new Error("画布已关闭")));
            saintHostVideoStatusRequestsRef.current.clear();
        };
    }, [effectiveConfig]);

    const createHistoryEntry = useCallback(
        (): CanvasHistoryEntry => ({
            nodes: nodesRef.current,
            connections: connectionsRef.current,
            backgroundMode,
            showImageInfo,
        }),
        [backgroundMode, showImageInfo],
    );

    const cleanupCanvasFiles = useCallback(
        (extra?: unknown, storageKeys?: ReadonlyMap<string, string>) => {
            cleanupAssetImages({ extra, history: historyRef.current, lastHistory: lastHistoryRef.current }, storageKeys);
        },
        [cleanupAssetImages],
    );

    const getBatchGroupNodes = useCallback((activeNode: CanvasNodeData | null) => {
        if (!activeNode) return [];
        const rootId = activeNode.metadata?.batchRootId || (activeNode.metadata?.isBatchRoot ? activeNode.id : null);
        if (!rootId) return [activeNode];
        return nodes.filter(
            (n) =>
                n.metadata?.batchRootId === rootId &&
                isCanvasImageNodeType(n.type) &&
                n.metadata?.content
        );
    }, [nodes]);

    useEffect(() => {
        if (!previewNodeId) return;
        const handlePreviewKeyDown = (event: KeyboardEvent) => {
            const pn = previewNodeId ? nodesRef.current.find((n) => n.id === previewNodeId) : null;
            if (!pn) return;
            const group = getBatchGroupNodes(pn);
            if (group.length <= 1) {
                if (event.key === "Escape") { event.preventDefault(); setPreviewNodeId(null); }
                return;
            }
            const idx = group.findIndex((n) => n.id === previewNodeId);
            if (event.key === "ArrowLeft") { event.preventDefault(); if (idx > 0) setPreviewNodeId(group[idx - 1].id); }
            else if (event.key === "ArrowRight") { event.preventDefault(); if (idx < group.length - 1) setPreviewNodeId(group[idx + 1].id); }
            else if (event.key === "Escape") { event.preventDefault(); setPreviewNodeId(null); }
        };
        window.addEventListener("keydown", handlePreviewKeyDown);
        return () => window.removeEventListener("keydown", handlePreviewKeyDown);
    }, [previewNodeId, getBatchGroupNodes]);

    useEffect(() => () => {
        const storageKeys = historyCleanupKeysRef.current;
        collectImageStorageKeys([historyRef.current, lastHistoryRef.current], new Set(), undefined, storageKeys).forEach((key) => storageKeys.set(key, key));
        historyCleanupKeysRef.current = new Map<string, string>();
        if (historyCleanupTimerRef.current) {
            clearTimeout(historyCleanupTimerRef.current);
            historyCleanupTimerRef.current = null;
        }
        const usedKeys = collectImageStorageKeys(nodesRef.current, new Set(), storageKeys);
        if (Array.from(storageKeys.values()).some((key) => !usedKeys.has(key))) cleanupAssetImages({ nodes: nodesRef.current }, storageKeys, useUserStore.getState().token);
    }, [cleanupAssetImages, projectId]);

    useEffect(() => {
        if (!hydrated) return;
        setProjectLoaded(false);
        setInitialAgentRequest(null);
        setReferencePickerNodeId(null);
        consumedAgentRequestProjectRef.current = null;
        const project = openProject(projectId);
        if (!project) {
            router.replace("/canvas");
            return;
        }

        const restore = async () => {
            const restoredBase = await hydrateCanvasImages(resetInterruptedGeneration(project.nodes));
            // 092：展开态子图按 LibTV 网格真值重排（gap 8）。老项目子图位置是创建时写死的旧间距，
            // 仅改创建代码不会挪动已有节点——进画布即归一化，保证改完代码马上看得到。
            const batchLayout = new Map<string, { x: number; y: number }>();
            const nodeByIdForBatch = new Map(restoredBase.map((node) => [node.id, node]));
            restoredBase.forEach((root) => {
                const childIds: string[] = root.metadata?.batchChildIds || [];
                if (!root.metadata?.imageBatchExpanded || !childIds.length) return;
                const children = childIds.map((id) => nodeByIdForBatch.get(id)).filter((node): node is CanvasNodeData => Boolean(node));
                if (!children.length) return;
                // 093：主图占田字格 (0,0) 的 LibTV 真值布局（用子图真实宽高，不再拿主图尺寸当格子）
                layoutBatchExpandedChildren({ x: root.position.x, y: root.position.y, width: root.width, height: root.height }, children.map((child) => ({ width: child.width, height: child.height }))).forEach((pos, index) => {
                    batchLayout.set(children[index].id, pos);
                });
            });
            const restoredNodes = batchLayout.size ? restoredBase.map((node) => { const next = batchLayout.get(node.id); return next ? { ...node, position: next } : node; }) : restoredBase;
            const restoredSessions = syncAssistantReferences(project.chatSessions || [], restoredNodes, true);
            setNodes(restoredNodes);
            // 081：节点名回填作品库——节点标题是显示名权威，进画布即把关联任务的标题同步给宿主
            restoredNodes.forEach((item) => {
                const linkedTaskId = item.metadata?.imageTaskId || item.metadata?.videoTaskId || item.metadata?.audioTaskId;
                const nodeTitle = String(item.title || '').trim();
                if (linkedTaskId && nodeTitle) {
                    try { window.parent.postMessage({ source: "kinglevel-canvas", type: "media-rename", payload: { taskId: String(linkedTaskId), title: nodeTitle } }, "*"); } catch (_) {}
                }
            });
            setConnections(project.connections);
            setChatSessions(restoredSessions);
            setActiveChatId(project.activeChatId || null);
            setAgentConfig(project.agentConfig || null);
            setBackgroundMode(project.backgroundMode);
            setSnapToGrid(project.snapToGrid ?? true);
            setShowImageInfo(project.showImageInfo || false);
            setViewport(project.viewport);
            // 资产面板（原左侧“画布资产提示词库”）默认不打开，由左下角“资产管理”按钮控制
            setSidePanel({ ...(project.sidePanel || DEFAULT_CANVAS_SIDE_PANEL), open: false });
            const restoredAgentPanel = project.agentPanel || DEFAULT_CANVAS_AGENT_PANEL;
            setAgentPanel(restoredAgentPanel);
            setAssistantMounted(restoredAgentPanel.open);
            historyRef.current = { past: [], future: [] };
            if (historyCommitTimerRef.current) {
                clearTimeout(historyCommitTimerRef.current);
                historyCommitTimerRef.current = null;
            }
            lastHistoryRef.current = {
                nodes: restoredNodes,
                connections: project.connections,
                backgroundMode: project.backgroundMode,
                showImageInfo: project.showImageInfo || false,
            };
            setHistoryState({ canUndo: false, canRedo: false });
            setProjectLoaded(true);
        };
        void restore();
    }, [hydrated, openProject, projectId, router]);

    useEffect(() => {
        if (!projectLoaded) return;
        const openFromLink = () => {
            const params = new URLSearchParams(window.location.hash.slice(1));
            if (!params.has("agentUrl") && !params.has("agentToken")) return;
            setAssistantMounted(true);
            setAgentPanel((current) => ({ ...current, open: true }));
        };
        openFromLink();
        window.addEventListener("hashchange", openFromLink);
        return () => window.removeEventListener("hashchange", openFromLink);
    }, [projectLoaded, projectId]);

    useEffect(() => {
        if (!projectLoaded || applyingHistoryRef.current || historyPausedRef.current) return;
        const next = createHistoryEntry();
        const previous = lastHistoryRef.current;
        if (previous?.nodes === next.nodes && previous.connections === next.connections && previous.backgroundMode === next.backgroundMode && previous.showImageInfo === next.showImageInfo) return;

        if (historyCommitTimerRef.current) clearTimeout(historyCommitTimerRef.current);
        historyCommitTimerRef.current = setTimeout(() => {
            const current = createHistoryEntry();
            const last = lastHistoryRef.current;
            if (!last) return;
            const historyDropped = historyRef.current.past.length >= 10 || historyRef.current.future.length > 0;
            if (historyDropped) collectImageStorageKeys([historyRef.current.past.slice(0, -9), historyRef.current.future], new Set(), undefined, historyCleanupKeysRef.current).forEach((key) => historyCleanupKeysRef.current.set(key, key));
            historyRef.current.past = [...historyRef.current.past.slice(-9), last];
            historyRef.current.future = [];
            setHistoryState({ canUndo: true, canRedo: false });
            lastHistoryRef.current = current;
            historyCommitTimerRef.current = null;
            if (historyDropped) {
                if (historyCleanupTimerRef.current) clearTimeout(historyCleanupTimerRef.current);
                historyCleanupTimerRef.current = setTimeout(() => {
                    historyCleanupTimerRef.current = null;
                    const storageKeys = historyCleanupKeysRef.current;
                    historyCleanupKeysRef.current = new Map<string, string>();
                    cleanupCanvasFiles(undefined, storageKeys);
                }, 2000);
            }
        }, 180);

        return () => {
            if (historyCommitTimerRef.current) {
                clearTimeout(historyCommitTimerRef.current);
                historyCommitTimerRef.current = null;
            }
        };
    }, [backgroundMode, cleanupCanvasFiles, connections, createHistoryEntry, nodes, projectLoaded, showImageInfo]);

    useEffect(() => {
        if (!projectLoaded || historyPausedRef.current) return;
        updateProject(projectId, { nodes, connections, chatSessions, activeChatId, agentConfig, backgroundMode, snapToGrid, showImageInfo });
    }, [activeChatId, agentConfig, backgroundMode, chatSessions, connections, nodes, projectId, projectLoaded, showImageInfo, snapToGrid, updateProject]);

    useEffect(() => {
        if (!projectLoaded) return;
        const pollCanvasTasks = () => {
            const videoTargets = nodesRef.current.filter((node) => node.type === CanvasNodeType.Video && node.metadata?.status === NODE_STATUS_LOADING && !node.metadata.content && canvasVideoTaskId(node.metadata));
            videoTargets.forEach((node) => {
                if (pollingVideoNodeIdsRef.current.has(node.id)) return;
                const taskId = canvasVideoTaskId(node.metadata);
                const workflowToken = node.metadata?.workflowRef ? useUserStore.getState().token : "";
                const generationConfig = buildGenerationConfig(effectiveConfig, node, "video");
                const usesSaintDolaPool = isEmbeddedSaintCanvas() && !node.metadata?.workflowRef && isSaintDolaPoolModel(generationConfig.model);
                if (!taskId || (!node.metadata?.workflowRef && !usesSaintDolaPool && !isAiConfigReady(generationConfig, generationConfig.model))) return;
                pollingVideoNodeIdsRef.current.add(node.id);
                void (node.metadata?.workflowRef
                    ? getWorkflowTask(workflowToken, taskId).then((task) => workflowVideoTask(task, workflowToken))
                    : usesSaintDolaPool
                        ? requestSaintHostVideoStatus(taskId, node.id)
                    : pollVideoGenerationTaskStatus(generationConfig, canvasVideoTaskFromMetadata(node.metadata)))
                    .then((task) => {
                        saintHostVideoPollFailuresRef.current.delete(node.id);
                        setNodes((prev) => applyCanvasVideoTaskUpdate(prev, node.id, task, generationConfig, node.metadata?.startedAt || Date.now(), { width: node.width, height: node.height }));
                    })
                    .catch((error) => {
                        const failures = (saintHostVideoPollFailuresRef.current.get(node.id) || 0) + 1;
                        saintHostVideoPollFailuresRef.current.set(node.id, failures);
                        if (failures < 3) return;
                        const taskId = canvasVideoTaskId(node.metadata) || "未知任务";
                        const detail = error instanceof Error ? error.message : "账号池未返回任务状态";
                        setNodes((prev) => prev.map((item) => item.id === node.id ? { ...item, metadata: { ...item.metadata, status: NODE_STATUS_ERROR, errorDetails: `任务 ${taskId} 状态失联：${detail}`, statusMessage: "账号或任务状态失联", stageLabel: "状态获取失败" } } : item));
                    })
                    .finally(() => {
                        pollingVideoNodeIdsRef.current.delete(node.id);
                    });
            });
            const imageTargets = nodesRef.current.filter((node) => isCanvasImageNodeType(node.type) && node.metadata?.status === NODE_STATUS_LOADING && !node.metadata.content && node.metadata.imageTaskId && !node.metadata.hostImageTask);
            // 059：宿主图片任务（hostImageTask）主动轮询兜底——推送丢失/创建应答超时的场景也能取回结果；
            // 失败节点保留 10 分钟的查询窗口（创建应答超时后才完成的任务也能落图）
            const hostImageTargets = nodesRef.current.filter((node) => {
                if (!node.metadata?.hostImageTask || !node.metadata?.imageTaskId) return false;
                if (node.metadata?.status === NODE_STATUS_LOADING) return true;
                if (node.metadata?.status === NODE_STATUS_ERROR) return Date.now() - Number(node.metadata?.startedAt || 0) < 10 * 60_000;
                return false;
            });
            hostImageTargets.forEach((node) => {
                if (pollingImageNodeIdsRef.current.has(`host-${node.id}`)) return;
                pollingImageNodeIdsRef.current.add(`host-${node.id}`);
                const requestId = `host-img-status-${nanoid()}`;
                window.parent.postMessage({ source: "kinglevel-canvas", type: "image-generation-status-request", payload: { requestId, taskId: node.metadata.imageTaskId } }, "*");
                window.setTimeout(() => pollingImageNodeIdsRef.current.delete(`host-${node.id}`), 4_000);
            });
            imageTargets.forEach((node) => {
                if (pollingImageNodeIdsRef.current.has(node.id) || !node.metadata?.imageTaskId) return;
                const workflowToken = node.metadata.workflowRef ? useUserStore.getState().token : "";
                pollingImageNodeIdsRef.current.add(node.id);
                void (node.metadata.workflowRef
                    ? getWorkflowTask(workflowToken, node.metadata.imageTaskId).then((task) => workflowImageTask(task, workflowToken))
                    : pollCanvasImageTaskStatus(node.metadata.imageTaskId))
                    .then((task) => {
                        setNodes((prev) => applyCanvasImageTaskUpdate(prev, node.id, task, node.metadata?.startedAt || Date.now(), { width: node.width, height: node.height }));
                        setConnections((prev) => applyCanvasImageTaskConnections(prev, node.id, task, node.metadata?.batchRootId));
                    })
                    .catch(() => undefined)
                    .finally(() => {
                        pollingImageNodeIdsRef.current.delete(node.id);
                    });
            });
            const audioTargets = nodesRef.current.filter((node) => node.type === CanvasNodeType.Audio && node.metadata?.status === NODE_STATUS_LOADING && !node.metadata.content && node.metadata.audioTaskId);
            audioTargets.forEach((node) => {
                if (pollingAudioNodeIdsRef.current.has(node.id) || !node.metadata?.audioTaskId) return;
                const workflowToken = node.metadata.workflowRef ? useUserStore.getState().token : "";
                pollingAudioNodeIdsRef.current.add(node.id);
                void (node.metadata.workflowRef
                    ? getWorkflowTask(workflowToken, node.metadata.audioTaskId).then((task) => workflowAudioTask(task, workflowToken))
                    : pollCanvasAudioTaskStatus(node.metadata.audioTaskId))
                    .then((task) => {
                        setNodes((prev) => applyCanvasAudioTaskUpdate(prev, node.id, task, node.metadata?.startedAt || Date.now()));
                    })
                    .catch(() => undefined)
                    .finally(() => {
                        pollingAudioNodeIdsRef.current.delete(node.id);
                    });
            });
        };
        pollCanvasTasks();
        const timer = window.setInterval(pollCanvasTasks, VIDEO_POLL_INTERVAL_MS);
        return () => window.clearInterval(timer);
    }, [effectiveConfig, isAiConfigReady, projectLoaded, requestSaintHostVideoStatus]);

    useEffect(() => {
        if (!hasLoadingTimedNodes) return;
        setCanvasNow(Date.now());
        const timer = window.setInterval(() => setCanvasNow(Date.now()), 1000);
        return () => window.clearInterval(timer);
    }, [hasLoadingTimedNodes]);

    useEffect(() => {
        if (!dialogNodeId) setNodeImageSettingsOpen(false);
    }, [dialogNodeId]);

    useEffect(() => {
        if (!projectLoaded) return;
        if (viewportSaveTimerRef.current) clearTimeout(viewportSaveTimerRef.current);
        viewportSaveTimerRef.current = setTimeout(() => {
            updateProject(projectId, { viewport: viewportRef.current });
            viewportSaveTimerRef.current = null;
        }, 500);
        return () => {
            if (viewportSaveTimerRef.current) clearTimeout(viewportSaveTimerRef.current);
        };
    }, [projectId, projectLoaded, updateProject, viewport]);

    useEffect(() => {
        if (!projectLoaded) return;
        if (sidePanelSaveTimerRef.current) clearTimeout(sidePanelSaveTimerRef.current);
        sidePanelSaveTimerRef.current = setTimeout(() => {
            updateProject(projectId, { sidePanel, agentPanel });
            sidePanelSaveTimerRef.current = null;
        }, 500);
        return () => {
            if (sidePanelSaveTimerRef.current) clearTimeout(sidePanelSaveTimerRef.current);
        };
    }, [projectId, projectLoaded, sidePanel, agentPanel, updateProject]);

    useLayoutEffect(() => {
        nodesRef.current = nodes;
        connectionsRef.current = connections;
        selectedNodeIdsRef.current = selectedNodeIds;
        selectedConnectionIdsRef.current = selectedConnectionIds;
        viewportRef.current = viewport;
        connectingParamsRef.current = connectingParams;
        connectionTargetNodeIdRef.current = connectionTargetNodeId;
        pendingConnectionCreateRef.current = pendingConnectionCreate;
    }, [nodes, connections, selectedNodeIds, selectedConnectionIds, viewport, connectingParams, connectionTargetNodeId, pendingConnectionCreate]);

    useLayoutEffect(() => {
        selectionBoxRef.current = selectionBox;
    }, [selectionBox]);

    useEffect(() => {
        const el = containerRef.current;
        if (!el) return;

        const updateSize = () => {
            const rect = el.getBoundingClientRect();
            setSize({ width: rect.width, height: rect.height });
            if (!didInitialCenterRef.current) {
                didInitialCenterRef.current = true;
                setViewport({ x: rect.width / 2, y: rect.height / 2, k: 1 });
            }
        };

        updateSize();
        const resizeObserver = new ResizeObserver(updateSize);
        resizeObserver.observe(el);
        return () => resizeObserver.disconnect();
    }, []);

    const screenToCanvas = useCallback((clientX: number, clientY: number) => {
        const rect = containerRef.current?.getBoundingClientRect();
        const currentViewport = viewportRef.current;
        const localX = clientX - (rect?.left || 0);
        const localY = clientY - (rect?.top || 0);

        return {
            x: (localX - currentViewport.x) / currentViewport.k,
            y: (localY - currentViewport.y) / currentViewport.k,
        };
    }, []);

    const getCanvasCenter = useCallback(() => {
        const rect = containerRef.current?.getBoundingClientRect();
        return screenToCanvas((rect?.left || 0) + (rect?.width || size.width) / 2 + Math.random() * 360 - 180, (rect?.top || 0) + (rect?.height || size.height) / 2 + Math.random() * 240 - 120);
    }, [screenToCanvas, size.height, size.width]);

    /** 任务06：原版导航＋按钮 —— 菜单固定在按钮正上方（去随机抖动）；双击菜单与其互斥 */
    const toggleNodeCreateMenuAtNav = useCallback(() => {
        setNodeCreateAnchor((current) => {
            if (current) return null;
            const rect = containerRef.current?.getBoundingClientRect();
            const left = (rect?.left || 0) + (rect?.width || size.width) / 2;
            const bottom = window.innerHeight - (rect?.bottom || window.innerHeight) + 70;
            return { left, bottom };
        });
        setNodeCreatePosition(null);
    }, [size.width]);

    const setConnecting = useCallback((next: ConnectionHandle | null) => {
        connectingParamsRef.current = next;
        setConnectingParams(next);
        if (!next) {
            connectionTargetNodeIdRef.current = null;
            setConnectionTargetNodeId(null);
        }
    }, []);

    const keepNodeToolbar = useCallback(
        (nodeId: string) => {
            if (nodeDraggingRef.current || nodeImageSettingsOpen || !selectedNodeIdsRef.current.has(nodeId)) return;
            setToolbarNodeId(nodeId);
        },
        [nodeImageSettingsOpen],
    );

    const hideNodeToolbar = useCallback(() => { }, []);

    const connectNodes = useCallback(
        (current: ConnectionHandle, targetNodeId: string) => {
            if (current.nodeId === targetNodeId) return;

            const connection = normalizeConnection(current.nodeId, targetNodeId, nodesRef.current, current.handleType);
            if (!connection) {
                message.warning("配置节点之间不能连接");
                return;
            }
            const { fromNodeId, toNodeId } = connection;
            const exists = connectionsRef.current.some((conn) => conn.fromNodeId === fromNodeId && conn.toNodeId === toNodeId);
            if (!exists) {
                setConnections((prev) => [...prev, { id: `conn-${Date.now()}`, fromNodeId, toNodeId }]);
            }
            setContextMenu(null);
        },
        [message],
    );

    // 框选批量连线：把所有选中节点连到同一个已有目标节点（从选区 ⊕ 拖到目标节点上松手）
    const connectSelectionNodes = useCallback(
        (sourceNodeIds: string[], targetNodeId: string) => {
            const sources = [...new Set(sourceNodeIds)].filter((id) => id !== targetNodeId);
            const created = sources
                .map((sourceNodeId) => normalizeConnection(sourceNodeId, targetNodeId, nodesRef.current, "source"))
                .filter((connection): connection is { fromNodeId: string; toNodeId: string } => Boolean(connection));
            if (!created.length) {
                message.warning("配置节点之间不能连接");
                return;
            }
            setConnections((prev) => [
                ...prev,
                ...created
                    .filter((connection) => !prev.some((item) => item.fromNodeId === connection.fromNodeId && item.toNodeId === connection.toNodeId))
                    .map((connection) => ({ id: `conn-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, ...connection })),
            ]);
            setContextMenu(null);
        },
        [message],
    );

    const createConnectedNode = useCallback(
        (type: CanvasNodeType, pending: PendingConnectionCreate) => {
            const workflowRef = isCanvasImageNodeType(type) ? effectiveConfig.imageWorkflowRef : type === CanvasNodeType.Video ? effectiveConfig.videoWorkflowRef : type === CanvasNodeType.Audio ? effectiveConfig.audioWorkflowRef : undefined;
            const metadata = type === CanvasNodeType.Config
                ? { model: effectiveConfig.imageModel || effectiveConfig.model, size: effectiveConfig.size, count: getGenerationCount(effectiveConfig.canvasImageCount || effectiveConfig.count), workflowRef: effectiveConfig.imageWorkflowRef }
                : workflowRef ? { workflowRef } : undefined;
            const newNode = createCanvasNode(type, pending.position, metadata);
            const sourceNodeIds = pending.sourceNodeIds?.length ? [...new Set(pending.sourceNodeIds)] : [pending.connection.nodeId];
            const allNodes = [...nodesRef.current, newNode];
            const createdConnections = sourceNodeIds
                .map((sourceNodeId) => normalizeConnection(sourceNodeId, newNode.id, allNodes, pending.connection.handleType))
                .filter((connection): connection is { fromNodeId: string; toNodeId: string } => Boolean(connection));
            if (!createdConnections.length) {
                message.warning("配置节点之间不能连接");
                return;
            }
            setNodes((prev) => [...prev, newNode]);
            setConnections((prev) => [
                ...prev,
                ...createdConnections
                    .filter((connection) => !prev.some((item) => item.fromNodeId === connection.fromNodeId && item.toNodeId === connection.toNodeId))
                    .map((connection) => ({ id: nanoid(), ...connection })),
            ]);
            setSelectedNodeIds(new Set([newNode.id]));
            setSelectedConnectionId(null);
            if (type !== CanvasNodeType.Text && type !== CanvasNodeType.Audio && type !== CanvasNodeType.Director) setDialogNodeId(newNode.id);
            setPendingConnectionCreate(null);
            setConnecting(null);
        },
        [effectiveConfig.audioWorkflowRef, effectiveConfig.canvasImageCount, effectiveConfig.count, effectiveConfig.imageModel, effectiveConfig.imageWorkflowRef, effectiveConfig.model, effectiveConfig.size, effectiveConfig.videoWorkflowRef, message, setConnecting],
    );

    const cancelPendingConnectionCreate = useCallback(() => {
        setPendingConnectionCreate(null);
        setConnecting(null);
        selectionConnectionDragRef.current = null;
        setSelectionConnectionDrag(null);
    }, [setConnecting]);

    const getConnectionDropTarget = useCallback(
        (clientX: number, clientY: number, current: ConnectionHandle): ConnectionDropTarget => {
            const world = screenToCanvas(clientX, clientY);
            const scale = Math.max(viewportRef.current.k, 0.05);
            const padding = CONNECTION_NODE_HIT_PADDING / scale;
            const handleRadius = CONNECTION_HANDLE_HIT_RADIUS / scale;
            let isNearNode = false;
            let bestNodeId: string | null = null;
            let bestPriority = Number.POSITIVE_INFINITY;

            [...nodesRef.current]
                .filter((node) => !isHiddenBatchChild(node, nodesRef.current))
                .reverse()
                .forEach((node) => {
                    const anchor = getConnectionTargetAnchor(node, current);
                    const dx = world.x - anchor.x;
                    const dy = world.y - anchor.y;
                    const hitsHandle = dx * dx + dy * dy <= handleRadius * handleRadius;
                    const hitsInside = world.x >= node.position.x && world.x <= node.position.x + node.width && world.y >= node.position.y && world.y <= node.position.y + node.height;
                    const hitsExpanded = world.x >= node.position.x - padding && world.x <= node.position.x + node.width + padding && world.y >= node.position.y - padding && world.y <= node.position.y + node.height + padding;

                    if (!hitsHandle && !hitsInside && !hitsExpanded) return;
                    isNearNode = true;
                    if (node.id === current.nodeId || !normalizeConnection(current.nodeId, node.id, nodesRef.current, current.handleType)) return;

                    const priority = hitsInside ? 0 : hitsHandle ? 1 : 2;
                    if (priority < bestPriority) {
                        bestNodeId = node.id;
                        bestPriority = priority;
                    }
                });

            return { nodeId: bestNodeId, isNearNode };
        },
        [screenToCanvas],
    );

    const visibleNodes = useMemo(() => {
        const padding = 280;
        const rect = containerRef.current?.getBoundingClientRect();
        const width = rect?.width || size.width;
        const height = rect?.height || size.height;
        const viewLeft = -viewport.x / viewport.k - padding;
        const viewTop = -viewport.y / viewport.k - padding;
        const viewRight = viewLeft + width / viewport.k + padding * 2;
        const viewBottom = viewTop + height / viewport.k + padding * 2;

        return nodes.filter((node) => !isHiddenBatchChild(node, nodes, collapsingBatchIds) && node.position.x + node.width > viewLeft && node.position.x < viewRight && node.position.y + node.height > viewTop && node.position.y < viewBottom);
    }, [collapsingBatchIds, nodes, size.height, size.width, viewport.k, viewport.x, viewport.y]);

    const nodeById = useMemo(() => new Map(nodes.map((node) => [node.id, node])), [nodes]);
    // 性能：连线也做视口剔除（此前只剔除了节点，445 条连线全部渲染，平移缩放时全量重绘）
    const visibleConnections = useMemo(() => {
        const padding = 280;
        const rect = containerRef.current?.getBoundingClientRect();
        const width = rect?.width || size.width;
        const height = rect?.height || size.height;
        const viewLeft = -viewport.x / viewport.k - padding;
        const viewTop = -viewport.y / viewport.k - padding;
        const viewRight = viewLeft + width / viewport.k + padding * 2;
        const viewBottom = viewTop + height / viewport.k + padding * 2;

        return connections.filter((connection) => {
            const from = nodeById.get(connection.fromNodeId);
            const to = nodeById.get(connection.toNodeId);
            if (!from || !to) return false;
            if (isHiddenBatchConnectionEndpoint(from, nodes) || isHiddenBatchConnectionEndpoint(to, nodes)) return false;
            const x1 = from.position.x + from.width;
            const y1 = from.position.y + from.height / 2;
            const x2 = to.position.x;
            const y2 = to.position.y + to.height / 2;
            const left = Math.min(x1, x2);
            const right = Math.max(x1, x2);
            const top = Math.min(y1, y2);
            const bottom = Math.max(y1, y2);
            return right > viewLeft && left < viewRight && bottom > viewTop && top < viewBottom;
        });
    }, [connections, nodeById, nodes, size.height, size.width, viewport.k, viewport.x, viewport.y]);
    // A selection proxy is rendered in world coordinates so the bounding box
    // follows the selected nodes while its controls stay screen-sized through
    // data-canvas-no-zoom. Groups expose their child nodes as sources.
    const selectionVisualNodes = useMemo(() => {
        const selected = nodes.filter((node) => selectedNodeIds.has(node.id));
        const expanded = selected.flatMap((node) => node.type === CanvasNodeType.Group ? nodes.filter((child) => child.metadata?.groupId === node.id) : [node]);
        return [...new Map(expanded.filter((node) => node.type !== CanvasNodeType.Group && !isHiddenBatchChild(node, nodes, collapsingBatchIds)).map((node) => [node.id, node])).values()];
    }, [collapsingBatchIds, nodes, selectedNodeIds]);
    const selectionProxyNodes = selectionVisualNodes.length > 1 ? selectionVisualNodes : [];
    const selectionProxyBounds = useMemo(() => selectionProxyNodes.length ? getNodeBounds(selectionProxyNodes) : null, [selectionProxyNodes]);
    // 选中项里包含组时，直接用组框自身作为选中框（组已自带蓝边和四角手柄），不再叠加代理虚线框
    const selectionGroups = useMemo(() => nodes.filter((node) => node.type === CanvasNodeType.Group && selectedNodeIds.has(node.id)), [nodes, selectedNodeIds]);
    // 选中框比节点外沿再扩出去一圈，视觉上“包住”节点而不是贴着边。
    const selectionProxyFrame = useMemo(() => {
        if (selectionGroups.length) {
            const bounds = getNodeBounds(selectionGroups);
            return { left: bounds.left, top: bounds.top, right: bounds.right, bottom: bounds.bottom, isGroupFrame: true };
        }
        if (!selectionProxyBounds) return null;
        const pad = 24;
        return { left: selectionProxyBounds.left - pad, top: selectionProxyBounds.top - pad, right: selectionProxyBounds.right + pad, bottom: selectionProxyBounds.bottom + pad, isGroupFrame: false };
    }, [selectionProxyBounds, selectionGroups]);
    // 仅选中「单个 Group」时挂载组工具栏（与多选工具栏互斥）：selectionGroups 恰好 1 个且总选中节点数恰好 1
    const singleSelectedGroup = selectionGroups.length === 1 && selectedNodeIds.size === 1 ? selectionGroups[0] : null;
    const singleSelectionNode = selectionVisualNodes.length === 1 ? selectionVisualNodes[0] : null;
    const toolbarNode = toolbarNodeId ? nodeById.get(toolbarNodeId) || null : null;
    const infoNode = infoNodeId ? nodeById.get(infoNodeId) || null : null;
    const cropNode = cropNodeId ? nodeById.get(cropNodeId) || null : null;
    const audioTrimNode = audioTrimNodeId ? nodeById.get(audioTrimNodeId) || null : null;
    const audioTrimTooShort = Math.round((audioTrimEnd - audioTrimStart) * 100) < 50;

    useEffect(() => {
        setAudioTrimPlaying(false);
        const src = audioTrimNode?.metadata?.content;
        if (!src) return;

        const audio = new Audio(src);
        audioTrimRef.current = audio;
        audio.preload = "metadata";
        setAudioTrimStart(0);
        setAudioTrimEnd(0);
        setAudioTrimDuration(0);

        audio.onloadedmetadata = () => {
            const duration = Number.isFinite(audio.duration)
                ? Math.floor(audio.duration * 100) / 100
                : 0;
            setAudioTrimDuration(duration);
            setAudioTrimEnd(duration);
        };
        audio.onplay = () => setAudioTrimPlaying(true);
        audio.onpause = () => setAudioTrimPlaying(false);
        audio.onended = () => setAudioTrimPlaying(false);
        audio.onerror = () => message.error("音频加载失败");

        return () => {
            audio.pause();
            audio.removeAttribute("src");
            audio.load();
            audioTrimRef.current = null;
        };
    }, [audioTrimNode?.id, audioTrimNode?.metadata?.content, message]);

    useEffect(() => {
        if (!audioTrimPlaying) return;

        let frame = 0;
        const checkEnd = () => {
            const audio = audioTrimRef.current;
            if (!audio || audio.paused) return;

            if (audio.currentTime >= audioTrimEnd) {
                audio.pause();
            } else {
                frame = requestAnimationFrame(checkEnd);
            }
        };

        frame = requestAnimationFrame(checkEnd);
        return () => cancelAnimationFrame(frame);
    }, [audioTrimPlaying, audioTrimEnd]);

    const maskEditNode = maskEditNodeId ? nodeById.get(maskEditNodeId) || null : null;
    const maskEditConfig = maskEditNode ? buildGenerationConfig(effectiveConfig, maskEditNode, "image") : null;
    const currentMaskEditModel = maskEditModel || maskEditConfig?.model || "";
    const currentMaskEditChannelId = maskEditChannelId || maskEditConfig?.imageChannelId || "";
    const splitNode = splitNodeId ? nodeById.get(splitNodeId) || null : null;
    const upscaleNode = upscaleNodeId ? nodeById.get(upscaleNodeId) || null : null;
    const superResolveNode = superResolveNodeId ? nodeById.get(superResolveNodeId) || null : null;
    const angleNode = angleNodeId ? nodeById.get(angleNodeId) || null : null;
    // 任务rDjmof：变换目标节点
    const transformNode = transformNodeId ? nodeById.get(transformNodeId) || null : null;
    const contextMenuNode = contextMenu?.type === "node" ? nodeById.get(contextMenu.nodeId) || null : null;
    const previewNode = previewNodeId ? nodeById.get(previewNodeId) || null : null;
    const openDirectorNode = openDirectorNodeId ? nodeById.get(openDirectorNodeId) || null : null;
    const hasMultipleSelectedNodes = selectedNodeIds.size > 1;
    const activeNodeId = hasMultipleSelectedNodes ? null : hoveredNodeId || (selectedNodeIds.size === 1 ? Array.from(selectedNodeIds)[0] : null);
    const batchChildCountById = useMemo(() => {
        const map = new Map<string, number>();
        nodes.forEach((node) => {
            if (node.metadata?.isBatchRoot) map.set(node.id, node.metadata.batchChildIds?.length || 0);
        });
        return map;
    }, [nodes]);
    const groupChildCountById = useMemo(() => {
        const map = new Map<string, number>();
        nodes.forEach((node) => {
            const groupId = node.metadata?.groupId;
            if (groupId) map.set(groupId, (map.get(groupId) || 0) + 1);
        });
        return map;
    }, [nodes]);
    const batchMotionById = useMemo(() => {
        const map = new Map<string, { x: number; y: number; index: number }>();
        nodes.forEach((node) => {
            const rootId = node.metadata?.batchRootId;
            if (!rootId) return;
            const root = nodeById.get(rootId);
            const index = root?.metadata?.batchChildIds?.indexOf(node.id) ?? 0;
            // 092：LibTV 原版折叠层偏移 left 12*t / top 4*t（主图 t=0，子层 t = index+1）
            const stackX = root ? root.position.x + 12 * (index + 1) : node.position.x;
            const stackY = root ? root.position.y + 4 * (index + 1) : node.position.y;
            map.set(node.id, { x: stackX - node.position.x, y: stackY - node.position.y, index: Math.max(index, 0) });
        });
        return map;
    }, [nodeById, nodes]);
    // 悬停不做关联高亮；**选中节点**时高亮与其直接相连的连线（静态样式，无动画无滤镜，不产生额外重绘）
    const relatedHighlight = useMemo(() => {
        const nodeIds = new Set<string>();
        const connectionIds = new Set<string>();
        if (selectedNodeIds.size > 0) {
            connections.forEach((connection) => {
                if (selectedNodeIds.has(connection.fromNodeId) || selectedNodeIds.has(connection.toNodeId)) {
                    connectionIds.add(connection.id);
                }
            });
        }
        return { nodeIds, connectionIds };
    }, [connections, selectedNodeIds]);

    // 计算单个节点的屏幕对齐描边（世界坐标）：让边框四条边精确落在整设备像素上，
    // 任何缩放下都恒定 1 物理像素、四边浓度一致。返回相对节点原点的偏移与尺寸。
    // 描边作为节点自身的子元素渲染（canvas-node.tsx），从而保持节点间遮挡层级——
    // 不能用独立覆盖层拍平在最上面，否则被挡住的节点边框会穿透叠在前面节点/面板之上。
    const nodeScreenBorder = (node: CanvasNodeData, relatedIds: Set<string>): { left: number; top: number; width: number; height: number; color: string } | null => {
        const k = viewport.k;
        if (!(k > 0)) return null;
        const isActive = selectedNodeIds.has(node.id) || connectionTargetNodeId === node.id;
        const isRelated = relatedIds.has(node.id);
        const isGroup = node.type === CanvasNodeType.Group;
        const isImage = isCanvasImageNodeType(node.type);
        const hasImageContent = isImage && Boolean(node.metadata?.content);
        // 选中态描边灰，与 canvas-node.tsx 的 selectionHighlight 保持一致；组节点启用自定义颜色（原版组工具栏颜色选择器），
        // 已设组色时描边用组色 33 半透明（原版真值：边框 `${e}33`、组体 `${e}1A` 同族），与组体底色同步（boss 2026-10-04：实色太红，两处不是一个颜色）
        const color = isGroup
            ? dropTargetGroupId === node.id ? "#a8a29e" : (node.metadata?.groupColor ? `${node.metadata.groupColor}33` : (isActive ? "#a8a29e" : theme.node.stroke))
            : isActive ? null : hasImageContent ? (isRelated && !node.metadata?.batchRootId ? theme.node.muted : null) : isRelated ? theme.node.muted : theme.node.stroke;
        if (!color) return null;
        const x = node.position.x;
        const y = node.position.y;
        return {
            left: (Math.round(x * k + viewport.x) - viewport.x) / k - x,
            top: (Math.round(y * k + viewport.y) - viewport.y) / k - y,
            width: Math.max(2, Math.round(node.width * k)) / k,
            height: Math.max(2, Math.round(node.height * k)) / k,
            color,
        };
    };

    const configInputsById = useMemo(() => {
        const map = new Map<string, NodeGenerationInput[]>();
        nodes.forEach((node) => {
            if (node.type !== CanvasNodeType.Config) return;
            map.set(node.id, buildNodeGenerationInputs(node.id, nodes, connections));
        });
        return map;
    }, [connections, nodes]);
    const directorPanoramasByNodeId = useMemo(() => {
        const map = new Map<string, CanvasDirectorPanorama[]>();
        nodes.forEach((node) => {
            if (node.type === CanvasNodeType.Director) map.set(node.id, []);
        });
        connections.forEach((connection) => {
            const target = nodeById.get(connection.toNodeId);
            const source = nodeById.get(connection.fromNodeId);
            if (target?.type !== CanvasNodeType.Director || !isCanvasImageNodeType(source?.type) || !source?.metadata?.content) return;
            map.get(target.id)?.push({
                edgeId: connection.id,
                sourceNodeId: source.id,
                imageUrl: source.metadata.content,
                fileName: source.title || "画布图片.png",
                projectionMode: source.metadata.panoramaProjection === "equirectangular" ? "equirectangular" : "backdrop",
            });
        });
        return map;
    }, [connections, nodeById, nodes]);
    const mentionReferencesByNodeId = useMemo(() => {
        const map = new Map<string, ReturnType<typeof buildNodeMentionReferences>>();
        nodes.forEach((node) => map.set(node.id, buildNodeMentionReferences(node, nodes, connections)));
        return map;
    }, [connections, nodes]);
    const connectedNodesByNodeId = useMemo(() => {
        const map = new Map<string, CanvasNodeData[]>();
        connections.forEach((connection) => {
            const source = nodeById.get(connection.fromNodeId);
            if (!source || !isCanvasReferenceNode(source)) return;
            const connected = map.get(connection.toNodeId);
            if (connected) connected.push(source);
            else map.set(connection.toNodeId, [source]);
        });
        return map;
    }, [connections, nodeById]);
    const referenceConnectedNodeIds = useMemo(() => new Set([referencePickerNodeId, ...(referencePickerNodeId ? connectedNodesByNodeId.get(referencePickerNodeId)?.map((node) => node.id) || [] : [])].filter((id): id is string => Boolean(id))), [connectedNodesByNodeId, referencePickerNodeId]);
    const videoFrameOptionsByNodeId = useMemo(() => {
        const map = new Map<string, CanvasVideoFrameOption[]>();
        nodes.forEach((node) => {
            if (node.type !== CanvasNodeType.Video && node.type !== CanvasNodeType.Config) return;
            const options = connections.flatMap((connection) => {
                if (connection.toNodeId !== node.id) return [];
                const imageNode = nodeById.get(connection.fromNodeId);
                return isCanvasImageNodeType(imageNode?.type) && imageNode?.metadata?.content ? [{ nodeId: imageNode.id, label: imageNode.title || "图片节点", previewUrl: imageNode.metadata.content }] : [];
            });
            map.set(node.id, options);
        });
        return map;
    }, [connections, nodeById, nodes]);
    const videoResourceOptionsByNodeId = useMemo(() => {
        const map = new Map<string, CanvasVideoResourceOption[]>();
        nodes.forEach((node) => {
            if (node.type !== CanvasNodeType.Video && node.type !== CanvasNodeType.Config && node.type !== CanvasNodeType.Audio) return;
            const options: CanvasVideoResourceOption[] = connections.flatMap<CanvasVideoResourceOption>((connection) => {
                if (connection.toNodeId !== node.id) return [];
                const source = nodeById.get(connection.fromNodeId);
                if (!source) return [];
                const label = source.title || source.id;
                if (source.type === CanvasNodeType.Text) {
                    const text = source.metadata?.content || source.metadata?.prompt || "";
                    return text.trim() ? [{ nodeId: source.id, kind: "text" as const, label, text }] : [];
                }
                if (isCanvasImageNodeType(source.type) && source.metadata?.content) return [{ nodeId: source.id, kind: "image" as const, label, previewUrl: source.metadata.content }];
                if (source.type === CanvasNodeType.Video && source.metadata?.content) return [{ nodeId: source.id, kind: "video" as const, label, previewUrl: source.metadata.content }];
                if (source.type === CanvasNodeType.Audio && source.metadata?.content) return [{ nodeId: source.id, kind: "audio" as const, label }];
                return [];
            });
            map.set(node.id, options);
        });
        return map;
    }, [connections, nodeById, nodes]);
    const createNode = useCallback(
        (type: CanvasNodeType, position?: Position, textContent?: string, nodeId?: string) => {
            const targetPosition = position || getCanvasCenter();
            const workflowRef = isCanvasImageNodeType(type) ? effectiveConfig.imageWorkflowRef : type === CanvasNodeType.Video ? effectiveConfig.videoWorkflowRef : type === CanvasNodeType.Audio ? effectiveConfig.audioWorkflowRef : undefined;
            const configMetadata =
                type === CanvasNodeType.Config
                    ? {
                        model: effectiveConfig.imageModel || effectiveConfig.model,
                        size: effectiveConfig.size,
                        count: getGenerationCount(effectiveConfig.canvasImageCount || effectiveConfig.count),
                        workflowRef: effectiveConfig.imageWorkflowRef,
                    }
                    : workflowRef ? { workflowRef } : undefined;
            const newNode = createCanvasNode(
                type,
                targetPosition,
                type === CanvasNodeType.Text && textContent !== undefined
                    ? { content: textContent, status: NODE_STATUS_SUCCESS }
                    : configMetadata,
                nodeId,
            );
            if (type === CanvasNodeType.Text && textContent !== undefined) newNode.title = textContent.slice(0, 32) || "Assistant Text";
            setNodes((prev) => [...prev, newNode]);
            setSelectedNodeIds(new Set([newNode.id]));
            setSelectedConnectionId(null);
            if (type !== CanvasNodeType.Text && type !== CanvasNodeType.Audio && type !== CanvasNodeType.Director) setDialogNodeId(newNode.id);
        },
        [effectiveConfig.audioWorkflowRef, effectiveConfig.canvasImageCount, effectiveConfig.count, effectiveConfig.imageModel, effectiveConfig.imageWorkflowRef, effectiveConfig.model, effectiveConfig.size, effectiveConfig.videoWorkflowRef, getCanvasCenter],
    );

    const generateVideoFromSelection = useCallback(() => {
        const selected = nodesRef.current.filter((node) => selectedNodeIdsRef.current.has(node.id));
        const sourceNodes = Array.from(new Map(
            selected.flatMap((node) => node.type === CanvasNodeType.Group ? nodesRef.current.filter((child) => child.metadata?.groupId === node.id) : [node])
                .filter((node) => isCanvasReferenceNode(node))
                .map((node) => [node.id, node]),
        ).values());
        if (!sourceNodes.length) {
            message.warning("请先框选至少一个图片、视频、音频或文本节点");
            return;
        }
        const generationConfig = buildGenerationConfig(effectiveConfig, undefined, "video");
        const spec = nodeSizeFromRatio(generationConfig.size, NODE_DEFAULT_SIZE[CanvasNodeType.Video].width, NODE_DEFAULT_SIZE[CanvasNodeType.Video].height) || NODE_DEFAULT_SIZE[CanvasNodeType.Video];
        const bounds = getNodeBounds(sourceNodes);
        const videoNode = createCanvasNode(CanvasNodeType.Video, { x: bounds.right + 96 + spec.width / 2, y: (bounds.top + bounds.bottom) / 2 }, {
            status: NODE_STATUS_IDLE,
            model: generationConfig.model,
            channelId: generationConfig.videoChannelId || generationConfig.activeChannelId,
            size: generationConfig.size,
            seconds: generationConfig.videoSeconds,
            vquality: generationConfig.vquality,
            mode: generationConfig.videoMode,
            generateAudio: generationConfig.videoGenerateAudio,
        });
        videoNode.width = spec.width;
        videoNode.height = spec.height;
        videoNode.title = "视频任务（待生成）";
        const nextConnections = sourceNodes.map((source) => ({ id: nanoid(), fromNodeId: source.id, toNodeId: videoNode.id }));
        setNodes((prev) => [...prev, videoNode]);
        setConnections((prev) => [...prev, ...nextConnections]);
        setSelectedNodeIds(new Set([videoNode.id]));
        setSelectedConnectionId(null);
        setDialogNodeId(videoNode.id);
        message.success(`已将 ${sourceNodes.length} 个选中节点连接到视频生成`);
    }, [effectiveConfig, message]);

    const deleteCanvasTaskRecords = useCallback(
        (nodeIds?: string[]) => {
            void deleteCanvasTasks(projectId, nodeIds).catch(() => undefined);
        },
        [projectId],
    );

    const deleteNodes = useCallback(
        (ids: Set<string>) => {
            if (!ids.size) return;
            const allIds = new Set(ids);
            nodesRef.current.forEach((node) => {
                if (ids.has(node.id)) node.metadata?.batchChildIds?.forEach((childId) => allIds.add(childId));
            });
            nodesRef.current.forEach((node) => {
                if (node.metadata?.isBatchRoot && node.metadata?.batchChildIds) {
                    const allChildrenDeleted = node.metadata.batchChildIds.every((childId) => allIds.has(childId));
                    if (allChildrenDeleted) allIds.add(node.id);
                }
            });
            deleteCanvasTaskRecords([...allIds]);
            const removedNodes = nodesRef.current.filter((node) => allIds.has(node.id));
            const remainingNodes = nodesRef.current.filter((node) => !allIds.has(node.id));
            const removedKeys = collectImageStorageKeys(removedNodes);
            const usedKeys = collectImageStorageKeys({ nodes: remainingNodes, assets: useAssetStore.getState().assets, history: historyRef.current, lastHistory: lastHistoryRef.current });
            const disposableKeys = [...removedKeys].filter((key) => !usedKeys.has(key));
            setChatSessions((sessions) => sessions.map((session) => ({
                ...session,
                messages: session.messages.map((message) => ({
                    ...message,
                    references: message.references?.map((reference) => allIds.has(reference.id) ? {
                        ...reference,
                        dataUrl: undefined,
                        url: undefined,
                        storageKey: undefined,
                    } : reference),
                })),
            })));
            if (disposableKeys.length) void deleteStoredImages(disposableKeys).catch((error) => message.error(error instanceof Error ? error.message : "图片文件删除失败"));
            const nextNodes = remainingNodes.map((node) => {
                const nextNode = node.metadata?.groupId && allIds.has(node.metadata.groupId) ? { ...node, metadata: { ...node.metadata, groupId: undefined } } : node;
                const childIds = nextNode.metadata?.batchChildIds?.filter((childId) => !allIds.has(childId));
                if (!nextNode.metadata?.isBatchRoot || childIds?.length === nextNode.metadata.batchChildIds?.length) return nextNode;
                const primaryImageId = childIds?.includes(nextNode.metadata.primaryImageId || "") ? nextNode.metadata.primaryImageId : childIds?.[0];
                const primaryNode = remainingNodes.find((item) => item.id === primaryImageId);
                return {
                    ...nextNode,
                    metadata: {
                        ...nextNode.metadata,
                        batchChildIds: childIds,
                        primaryImageId,
                        content: primaryNode?.metadata?.content || nextNode.metadata.content,
                        storageKey: primaryNode?.metadata?.content ? primaryNode.metadata.storageKey : nextNode.metadata.storageKey,
                        bytes: primaryNode?.metadata?.content ? primaryNode.metadata.bytes : nextNode.metadata.bytes,
                        mimeType: primaryNode?.metadata?.content ? primaryNode.metadata.mimeType : nextNode.metadata.mimeType,
                        naturalWidth: primaryNode?.metadata?.naturalWidth || nextNode.metadata.naturalWidth,
                        naturalHeight: primaryNode?.metadata?.naturalHeight || nextNode.metadata.naturalHeight,
                        panoramaProjection: primaryNode?.metadata?.panoramaProjection || nextNode.metadata.panoramaProjection,
                    },
                };
            });
            const nextConnections = connectionsRef.current.filter((connection) => !allIds.has(connection.fromNodeId) && !allIds.has(connection.toNodeId));
            nodesRef.current = nextNodes;
            connectionsRef.current = nextConnections;
            selectedNodeIdsRef.current = new Set();
            setNodes(nextNodes);
            setConnections(nextConnections);
            setSelectedNodeIds(new Set());
            setSelectedConnectionId(null);
            setHoveredNodeId((current) => (current && allIds.has(current) ? null : current));
            setToolbarNodeId((current) => (current && allIds.has(current) ? null : current));
            setDialogNodeId((current) => (current && allIds.has(current) ? null : current));
            setInfoNodeId((current) => (current && allIds.has(current) ? null : current));
            setCropNodeId((current) => (current && allIds.has(current) ? null : current));
            setMaskEditNodeId((current) => (current && allIds.has(current) ? null : current));
            setAngleNodeId((current) => (current && allIds.has(current) ? null : current));
            setPreviewNodeId((current) => (current && allIds.has(current) ? null : current));
            setRunningNodeId((current) => (current && allIds.has(current) ? null : current));
            setReferencePickerNodeId((current) => (current && allIds.has(current) ? null : current));
            setContextMenu((current) => (current?.type === "node" && allIds.has(current.nodeId) ? null : current));
            cleanupCanvasFiles({ projectId, nodes: nextNodes, chatSessions });
        },
        [chatSessions, cleanupCanvasFiles, deleteCanvasTaskRecords, projectId],
    );

    const deleteConnection = useCallback((connectionId: string) => {
        const nextConnections = connectionsRef.current.filter((connection) => connection.id !== connectionId);
        connectionsRef.current = nextConnections;
        setConnections(nextConnections);
        setSelectedConnectionId((current) => (current === connectionId ? null : current));
        setContextMenu((current) => (current?.type === "connection" && current.connectionId === connectionId ? null : current));
    }, []);

    const deleteConnections = useCallback((connectionIds: Set<string>) => {
        if (!connectionIds.size) return;
        const nextConnections = connectionsRef.current.filter((connection) => !connectionIds.has(connection.id));
        connectionsRef.current = nextConnections;
        setConnections(nextConnections);
        setSelectedConnectionId((current) => (current && connectionIds.has(current) ? null : current));
        setSelectedConnectionIds(new Set());
        setContextMenu((current) => (current?.type === "connection" && current.connectionId && connectionIds.has(current.connectionId) ? null : current));
    }, []);

    const deselectCanvas = useCallback(() => {
        cancelPendingConnectionCreate();
        setSelectedNodeIds(new Set());
        setSelectedConnectionId(null);
        setSelectedConnectionIds(new Set());
        setContextMenu(null);
        setSelectionBox(null);
        setHoveredNodeId(null);
        setToolbarNodeId(null);
        setDialogNodeId(null);
    }, [cancelPendingConnectionCreate]);

    const clearCanvas = useCallback(() => {
        deleteCanvasTaskRecords();
        setNodes([]);
        setConnections([]);
        setInfoNodeId(null);
        setCropNodeId(null);
        setMaskEditNodeId(null);
        setAngleNodeId(null);
        setPreviewNodeId(null);
        setRunningNodeId(null);
        setReferencePickerNodeId(null);
        deselectCanvas();
        setClearConfirmOpen(false);
        cleanupCanvasFiles({ projectId, nodes: [], chatSessions: [] });
    }, [cleanupCanvasFiles, deleteCanvasTaskRecords, deselectCanvas, projectId]);

    const duplicateNode = useCallback((nodeId: string) => {
        const source = nodesRef.current.find((node) => node.id === nodeId);
        if (!source) return;

        const id = `${source.type}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
        // 任务r7Jphn：生成中的节点，副本还原为「生成前输入态」草稿——
        // 清产物/任务绑定/进度（保留任务绑定会让原件的任务推送按 taskId 同步覆盖副本），
        // 保留提示词/参数/工作流配置；参考素材经连线复制保留，可修改后独立重新生成。
        const isGenerating = source.metadata?.status === NODE_STATUS_LOADING;
        const next: CanvasNodeData = { ...source, id, title: `${source.title} 副本`, position: { x: source.position.x + 36, y: source.position.y + 36 } };
        if (isGenerating) {
            next.metadata = {
                ...source.metadata,
                status: NODE_STATUS_IDLE,
                progress: undefined,
                startedAt: undefined,
                errorDetails: undefined,
                durationMs: undefined,
                imageTaskId: undefined,
                videoTaskId: undefined,
                audioTaskId: undefined,
                imageTaskResultId: undefined,
                hostImageTask: undefined,
                content: undefined,
                storageKey: undefined,
                bytes: undefined,
                previewTransform: undefined,
                doodleStrokes: undefined,
            };
        }
        const copiedConnections = connectionsRef.current
            .filter((connection) => connection.fromNodeId === source.id || connection.toNodeId === source.id)
            .map((connection) => ({
                ...connection,
                id: nanoid(),
                fromNodeId: connection.fromNodeId === source.id ? id : connection.fromNodeId,
                toNodeId: connection.toNodeId === source.id ? id : connection.toNodeId,
            }));
        const nextConnections = [...connectionsRef.current, ...copiedConnections];

        setNodes((prev) => [...prev, next]);
        connectionsRef.current = nextConnections;
        setConnections(nextConnections);
        setSelectedNodeIds(new Set([id]));
        setSelectedConnectionId(null);
        setDialogNodeId(id);
    }, []);

    const createGroupFromSelection = useCallback((nodeIds?: string[]) => {
        const selectedIds = new Set(nodeIds || Array.from(selectedNodeIdsRef.current));
        const selectedNodes = nodesRef.current.filter((node) => selectedIds.has(node.id));
        if (selectedNodes.length < 2 || selectedNodes.some((node) => node.type === CanvasNodeType.Group || node.metadata?.groupId)) return null;

        const bounds = getNodeBounds(selectedNodes);
        const width = bounds.right - bounds.left + GROUP_PADDING * 2;
        const height = bounds.bottom - bounds.top + GROUP_PADDING * 2;
        const group = createCanvasNode(CanvasNodeType.Group, {
            x: bounds.left - GROUP_PADDING + width / 2,
            y: bounds.top - GROUP_PADDING + height / 2,
        });
        group.width = width;
        group.height = height;
        group.position = { x: bounds.left - GROUP_PADDING, y: bounds.top - GROUP_PADDING };

        const nextNodes = [
            ...nodesRef.current.map((node) => (selectedIds.has(node.id) ? { ...node, metadata: { ...node.metadata, groupId: group.id } } : node)),
            group,
        ];
        nodesRef.current = nextNodes;
        selectedNodeIdsRef.current = new Set([group.id]);
        setNodes(nextNodes);
        setSelectedNodeIds(new Set([group.id]));
        setSelectedConnectionId(null);
        setDialogNodeId(null);
        return group.id;
    }, []);

    // 解组（boss 2026-10-04：打组之后解组，快捷键 Ctrl/Alt+Shift+G）：删 Group 壳 + 子节点 groupId 清除，组内子节点继承选中
    const ungroupSelection = useCallback(() => {
        const selectedIds = selectedNodeIdsRef.current;
        const groupIds = new Set<string>();
        nodesRef.current.forEach((node) => {
            if (node.type === CanvasNodeType.Group && selectedIds.has(node.id)) groupIds.add(node.id);
            else if (node.metadata?.groupId && selectedIds.has(node.id)) groupIds.add(node.metadata.groupId);
        });
        if (!groupIds.size) return;

        const releasedChildIds = new Set<string>();
        const nextNodes = nodesRef.current
            .filter((node) => !(node.type === CanvasNodeType.Group && groupIds.has(node.id)))
            .map((node) => {
                if (node.metadata?.groupId && groupIds.has(node.metadata.groupId)) {
                    releasedChildIds.add(node.id);
                    return { ...node, metadata: { ...node.metadata, groupId: undefined } };
                }
                return node;
            });
        nodesRef.current = nextNodes;
        setNodes(nextNodes);
        if (releasedChildIds.size) {
            selectedNodeIdsRef.current = releasedChildIds;
            setSelectedNodeIds(releasedChildIds);
        }
        setSelectedConnectionId(null);
    }, []);

    // 组颜色（原版 GroupNodeToolbar 颜色选择器 → metadata.groupColor，落组边框色）
    const handleGroupColorChange = useCallback((groupId: string, color: string | null) => {
        const nextNodes = nodesRef.current.map((node) =>
            node.id === groupId ? { ...node, metadata: { ...node.metadata, groupColor: color ?? undefined } } : node,
        );
        nodesRef.current = nextNodes;
        setNodes(nextNodes);
    }, []);

    // 组排版（原版 GroupNodeToolbar 排版菜单 → 012 chunk 算法 + 常量 36/36/66，grid 列数 min(5,max(1,ceil(sqrt(n))))）
    const layoutGroupChildren = useCallback((groupId: string, mode: "grid" | "horizontal" | "vertical") => {
        const group = nodesRef.current.find((node) => node.id === groupId && node.type === CanvasNodeType.Group);
        if (!group) return;
        const children = nodesRef.current.filter((node) => node.metadata?.groupId === groupId && node.type !== CanvasNodeType.Group);
        if (!children.length) return;
        const PADDING = 36;
        const GAP = 36;
        const TOP_PADDING = 66;
        const maxW = Math.max(...children.map((c) => c.width));
        const maxH = Math.max(...children.map((c) => c.height));
        const positions = new Map<string, { x: number; y: number }>();
        let groupWidth = 0;
        let groupHeight = 0;
        if (mode === "horizontal") {
            let x = PADDING;
            children.forEach((c) => {
                positions.set(c.id, { x, y: TOP_PADDING });
                x += c.width + GAP;
            });
            groupWidth = x - GAP + PADDING;
            groupHeight = TOP_PADDING + maxH + PADDING;
        } else if (mode === "vertical") {
            let y = TOP_PADDING;
            children.forEach((c) => {
                positions.set(c.id, { x: PADDING, y });
                y += c.height + GAP;
            });
            groupWidth = 2 * PADDING + maxW;
            groupHeight = y - GAP + PADDING;
        } else {
            const n = children.length;
            const cols = Math.min(5, Math.max(1, Math.ceil(Math.sqrt(n))));
            const rows = Math.ceil(n / cols);
            children.forEach((c, i) => {
                const col = i % cols;
                const row = Math.floor(i / cols);
                positions.set(c.id, { x: PADDING + col * (maxW + GAP), y: TOP_PADDING + row * (maxH + GAP) });
            });
            groupWidth = 2 * PADDING + cols * maxW + (cols - 1) * GAP;
            groupHeight = TOP_PADDING + PADDING + rows * maxH + (rows - 1) * GAP;
        }
        const originX = group.position.x;
        const originY = group.position.y;
        const nextNodes = nodesRef.current.map((node) => {
            if (node.id === groupId) return { ...node, width: groupWidth, height: groupHeight };
            const p = positions.get(node.id);
            if (p) return { ...node, position: { x: originX + p.x, y: originY + p.y } };
            return node;
        });
        nodesRef.current = nextNodes;
        setNodes(nextNodes);
    }, []);

    // 整理画布（boss 2026-10-04：快捷键 Alt+Shift+F 保留，整理后可 Ctrl+Z 撤回）：
    // 复用 agent arrange_nodes 的网格算法（每行 4 个、间距 72，组节点子元素跟随），走 commitNodes 进历史栈
    const arrangeCanvasNodes = useCallback(() => {
        const targetNodes = nodesRef.current.filter((node) => !node.metadata?.groupId && !node.metadata?.batchRootId);
        if (!targetNodes.length) return;
        const startX = Math.min(...targetNodes.map((node) => node.position.x));
        const startY = Math.min(...targetNodes.map((node) => node.position.y));
        const positions = new Map<string, Position>();
        let x = startX;
        let y = startY;
        let rowHeight = 0;
        targetNodes.forEach((node, index) => {
            if (index > 0 && index % 4 === 0) {
                x = startX;
                y += rowHeight + 72;
                rowHeight = 0;
            }
            positions.set(node.id, { x, y });
            x += node.width + 72;
            rowHeight = Math.max(rowHeight, node.height);
        });
        targetNodes
            .filter((node) => node.type === CanvasNodeType.Group)
            .forEach((group) => {
                const groupPosition = positions.get(group.id);
                if (!groupPosition) return;
                const offsetX = groupPosition.x - group.position.x;
                const offsetY = groupPosition.y - group.position.y;
                nodesRef.current
                    .filter((node) => node.metadata?.groupId === group.id && !positions.has(node.id))
                    .forEach((node) => positions.set(node.id, { x: node.position.x + offsetX, y: node.position.y + offsetY }));
            });
        const nextNodes = nodesRef.current.map((node) => (positions.has(node.id) ? { ...node, position: positions.get(node.id)! } : node));
        nodesRef.current = nextNodes;
        setNodes(nextNodes);
    }, []);

    const copySelectedNodes = useCallback(() => {
        const selectedIds = selectedNodeIdsRef.current;
        if (!selectedIds.size) return;

        const copiedIds = new Set(selectedIds);
        nodesRef.current.forEach((node) => {
            if (node.type !== CanvasNodeType.Group || !selectedIds.has(node.id)) return;
            nodesRef.current.forEach((child) => {
                if (child.metadata?.groupId === node.id) copiedIds.add(child.id);
            });
        });

        const copiedNodes = nodesRef.current
            .filter((node) => copiedIds.has(node.id))
            .map((node) => ({
                ...node,
                position: { ...node.position },
                metadata: node.metadata ? { ...node.metadata } : undefined,
            }));

        if (!copiedNodes.length) return;

        clipboardRef.current = {
            nodes: copiedNodes,
            connections: connectionsRef.current.filter((connection) => copiedIds.has(connection.fromNodeId) && copiedIds.has(connection.toNodeId)).map((connection) => ({ ...connection })),
        };
    }, []);

    const pasteCopiedNodes = useCallback(() => {
        const clipboard = clipboardRef.current;
        if (!clipboard?.nodes.length) return false;

        const center = getCanvasCenter();
        const bounds = clipboard.nodes.reduce(
            (acc, node) => ({
                left: Math.min(acc.left, node.position.x),
                top: Math.min(acc.top, node.position.y),
                right: Math.max(acc.right, node.position.x + node.width),
                bottom: Math.max(acc.bottom, node.position.y + node.height),
            }),
            { left: Infinity, top: Infinity, right: -Infinity, bottom: -Infinity },
        );
        const dx = center.x - (bounds.left + bounds.right) / 2;
        const dy = center.y - (bounds.top + bounds.bottom) / 2;
        const idMap = new Map<string, string>();
        const nextNodes = clipboard.nodes.map((node, index) => {
            const id = `${node.type}-${Date.now()}-${index}-${Math.random().toString(36).slice(2, 7)}`;
            idMap.set(node.id, id);
            return {
                ...node,
                id,
                title: node.title.endsWith(" Copy") ? node.title : `${node.title} Copy`,
                position: {
                    x: node.position.x + dx,
                    y: node.position.y + dy,
                },
                metadata: node.metadata ? { ...node.metadata } : undefined,
            };
        });

        const pastedNodes = nextNodes.map((node) => {
            const groupId = node.metadata?.groupId;
            const nextGroupId = groupId ? idMap.get(groupId) : undefined;
            if (!groupId || nextGroupId) return nextGroupId ? { ...node, metadata: { ...node.metadata, groupId: nextGroupId } } : node;
            return { ...node, metadata: { ...node.metadata, groupId: undefined } };
        });

        const nextConnections = clipboard.connections.flatMap((connection, index) => {
            const fromNodeId = idMap.get(connection.fromNodeId);
            const toNodeId = idMap.get(connection.toNodeId);
            if (!fromNodeId || !toNodeId) return [];
            return [
                {
                    ...connection,
                    id: `conn-${Date.now()}-${index}-${Math.random().toString(36).slice(2, 7)}`,
                    fromNodeId,
                    toNodeId,
                },
            ];
        });

        setNodes((prev) => [...prev, ...pastedNodes]);
        setConnections((prev) => [...prev, ...nextConnections]);
        setSelectedNodeIds(new Set(pastedNodes.map((node) => node.id)));
        setSelectedConnectionId(null);
        setContextMenu(null);
        setDialogNodeId(pastedNodes[0]?.type === CanvasNodeType.Group ? null : pastedNodes[0]?.id || null);
        return true;
    }, [getCanvasCenter]);

    const resetViewport = useCallback(() => {
        setViewport({ x: size.width / 2, y: size.height / 2, k: 1 });
        setContextMenu(null);
    }, [size.height, size.width]);

    const setZoomScale = useCallback(
        (scale: number) => {
            const nextScale = Math.min(Math.max(scale, 0.05), 5);
            setViewport((prev) => ({
                x: size.width / 2 - ((size.width / 2 - prev.x) / prev.k) * nextScale,
                y: size.height / 2 - ((size.height / 2 - prev.y) / prev.k) * nextScale,
                k: nextScale,
            }));
            setContextMenu(null);
        },
        [size.height, size.width],
    );

    const applyHistory = useCallback((entry: CanvasHistoryEntry) => {
        if (historyCommitTimerRef.current) {
            clearTimeout(historyCommitTimerRef.current);
            historyCommitTimerRef.current = null;
        }
        applyingHistoryRef.current = true;
        setNodes(entry.nodes);
        setConnections(entry.connections);
        setBackgroundMode(entry.backgroundMode);
        setShowImageInfo(entry.showImageInfo);
        setSelectedNodeIds(new Set());
        setSelectedConnectionId(null);
        setContextMenu(null);
        setReferencePickerNodeId(null);
        setTimeout(() => {
            lastHistoryRef.current = entry;
            applyingHistoryRef.current = false;
            setHistoryState({ canUndo: historyRef.current.past.length > 0, canRedo: historyRef.current.future.length > 0 });
        });
    }, []);

    const undoCanvas = useCallback(() => {
        const previous = historyRef.current.past.pop();
        const current = lastHistoryRef.current;
        if (!previous || !current) return;
        historyRef.current.future.push(current);
        applyHistory(previous);
    }, [applyHistory]);

    const redoCanvas = useCallback(() => {
        const next = historyRef.current.future.pop();
        const current = lastHistoryRef.current;
        if (!next || !current) return;
        historyRef.current.past.push(current);
        applyHistory(next);
    }, [applyHistory]);

    const createAndOpenProject = useCallback(() => {
        const id = createProject(`Novus AI ${useCanvasStore.getState().projects.length + 1}`);
        router.push(`/canvas/${id}`);
    }, [createProject, router]);

    const deleteCurrentProject = useCallback(() => {
        void deleteCanvasProjects([projectId]).catch(() => undefined);
        deleteCanvasTaskRecords();
        deleteProjects([projectId]);
        cleanupAssetImages();
        router.push("/canvas");
    }, [cleanupAssetImages, deleteCanvasTaskRecords, deleteProjects, projectId, router]);

    const handleCanvasMouseDown = useCallback(
        (event: ReactPointerEvent<HTMLDivElement>) => {
            setContextMenu(null);
            setNodeCreatePosition(null);
            setHoveredNodeId(null);
            setToolbarNodeId(null);
            setDialogNodeId(null);
            if (pendingConnectionCreateRef.current) cancelPendingConnectionCreate();
            // 连线跟随模式下点击空白：连接到悬停目标，否则弹出添加节点菜单
            if (connectingParamsRef.current) {
                const pending = connectingParamsRef.current;
                const dropTarget = getConnectionDropTarget(event.clientX, event.clientY, pending);
                setConnecting(null);
                if (dropTarget.nodeId && dropTarget.nodeId !== pending.nodeId) {
                    connectNodes(pending, dropTarget.nodeId);
                } else if (!dropTarget.isNearNode) {
                    const position = screenToCanvas(event.clientX, event.clientY);
                    setMouseWorld(position);
                    setPendingConnectionCreate({ connection: pending, position });
                }
                return;
            }
            if (event.button !== 0) return;
            setAgentReferenceNodeClick((current) => ({ ...current, nodeId: null }));

            const world = screenToCanvas(event.clientX, event.clientY);
            const nextSelectionBox = {
                startWorldX: world.x,
                startWorldY: world.y,
                currentWorldX: world.x,
                currentWorldY: world.y,
                additive: event.shiftKey,
                initialSelectedNodeIds: event.shiftKey ? Array.from(selectedNodeIdsRef.current) : [],
                initialSelectedConnectionIds: event.shiftKey ? Array.from(selectedConnectionIdsRef.current) : [],
            };
            selectionBoxRef.current = nextSelectionBox;
            setSelectionBox(nextSelectionBox);
            if (!event.shiftKey) {
                setSelectedNodeIds(new Set());
                setSelectedConnectionIds(new Set());
            }

            setSelectedConnectionId(null);
            setSelectedConnectionIds(new Set());
        },
        [cancelPendingConnectionCreate, connectNodes, getConnectionDropTarget, screenToCanvas, setConnecting],
    );

    const handleSelectionConnectStart = useCallback(
        (event: ReactMouseEvent<HTMLButtonElement>, sourceNodeIds: string[]) => {
            if (!sourceNodeIds.length) return;
            event.preventDefault();
            event.stopPropagation();
            const world = screenToCanvas(event.clientX, event.clientY);
            selectionConnectionDragRef.current = { sourceNodeIds };
            setSelectionConnectionDrag({ sourceNodeIds });
            setMouseWorld(world);
            setPendingConnectionCreate(null);
            setConnecting(null);
        },
        [screenToCanvas, setConnecting],
    );

    // 画布整理：按连线的上下游层级把节点排成整齐的列（同列纵向等间距），不改动节点尺寸与连线。
    // 按连线深度分层排列给定节点（连线只统计两端都在 targets 内的）；工具栏「整理」传全部节点，右键菜单「整理」传选中节点
    const layoutNodesByDepth = useCallback((targets: CanvasNodeData[]) => {
        if (!targets.length) return;
        const currentConnections = connectionsRef.current;
        const targetIds = new Set(targets.map((node) => node.id));

        const incoming = new Map<string, string[]>();
        currentConnections.forEach((connection) => {
            if (!targetIds.has(connection.fromNodeId) || !targetIds.has(connection.toNodeId)) return;
            const list = incoming.get(connection.toNodeId) || [];
            list.push(connection.fromNodeId);
            incoming.set(connection.toNodeId, list);
        });

        const depthMap = new Map<string, number>();
        const visiting = new Set<string>();
        const depthOf = (id: string): number => {
            const cached = depthMap.get(id);
            if (cached !== undefined) return cached;
            if (visiting.has(id)) return 0;
            visiting.add(id);
            const parents = incoming.get(id) || [];
            const depth = parents.length ? Math.max(...parents.map(depthOf)) + 1 : 0;
            visiting.delete(id);
            depthMap.set(id, depth);
            return depth;
        };
        targets.forEach((node) => depthOf(node.id));

        const columns = new Map<number, CanvasNodeData[]>();
        [...targets]
            .sort((a, b) => a.position.y - b.position.y || a.position.x - b.position.x)
            .forEach((node) => {
                const depth = depthMap.get(node.id) ?? 0;
                const list = columns.get(depth) || [];
                list.push(node);
                columns.set(depth, list);
            });

        const gapX = 140;
        const gapY = 56;
        const startX = Math.min(...targets.map((node) => node.position.x));
        const startY = Math.min(...targets.map((node) => node.position.y));
        const nextPositions = new Map<string, Position>();
        let x = startX;
        [...columns.keys()].sort((a, b) => a - b).forEach((depth) => {
            const column = columns.get(depth) || [];
            let y = startY;
            column.forEach((node) => {
                nextPositions.set(node.id, { x, y });
                y += node.height + gapY;
            });
            x += Math.max(...column.map((node) => node.width)) + gapX;
        });

        createHistoryEntry();
        setNodes((previous) => previous.map((node) => (nextPositions.has(node.id) ? { ...node, position: nextPositions.get(node.id)! } : node)));
    }, [createHistoryEntry]);

    const organizeNodes = useCallback(() => layoutNodesByDepth(nodesRef.current), [layoutNodesByDepth]);

    // 多选节点的快捷排序：宫格 / 垂直单列 / 水平单行（右键菜单）
    const arrangeSelectedNodes = useCallback((mode: "grid" | "column" | "row") => {
        const all = nodesRef.current;
        const selected = all.filter((node) => selectedNodeIdsRef.current.has(node.id) && !isHiddenBatchChild(node, all));
        if (selected.length < 2) return;
        const ordered = [...selected].sort((a, b) => a.position.y - b.position.y || a.position.x - b.position.x);
        const startX = Math.min(...selected.map((node) => node.position.x));
        const startY = Math.min(...selected.map((node) => node.position.y));
        const gapX = 140;
        const gapY = 56;
        const maxW = Math.max(...selected.map((node) => node.width));
        const maxH = Math.max(...selected.map((node) => node.height));
        const cols = mode === "column" ? 1 : mode === "row" ? selected.length : Math.ceil(Math.sqrt(selected.length));
        const nextPositions = new Map<string, Position>();
        // boss 2026-10-04 修复：行/列排序原来用 index*(自身宽高+间距)，节点尺寸不一时会产生大空隙和重叠
        //（例：第 5 个节点 y = start + 5*(自身高+56)，与第 4 个节点的实际底边无关）。改成游标累加前面节点的实际尺寸。
        let cursorX = startX;
        let cursorY = startY;
        ordered.forEach((node, index) => {
            const col = index % cols;
            const row = Math.floor(index / cols);
            if (mode === "row") {
                nextPositions.set(node.id, { x: cursorX, y: startY });
                cursorX += node.width + gapX;
            } else if (mode === "column") {
                nextPositions.set(node.id, { x: startX, y: cursorY });
                cursorY += node.height + gapY;
            } else {
                nextPositions.set(node.id, { x: startX + col * (maxW + gapX), y: startY + row * (maxH + gapY) });
            }
        });

        createHistoryEntry();
        setNodes((previous) => previous.map((node) => (nextPositions.has(node.id) ? { ...node, position: nextPositions.get(node.id)! } : node)));
    }, [createHistoryEntry]);

    const handleNodeMouseDown = useCallback((event: ReactMouseEvent, nodeId: string) => {
        event.stopPropagation();
        // 连线跟随模式下点击节点：完成连接（点回起点则取消），不启动节点拖动
        if (connectingParamsRef.current) {
            const pending = connectingParamsRef.current;
            const dropTarget = getConnectionDropTarget(event.clientX, event.clientY, pending);
            setConnecting(null);
            if (dropTarget.nodeId && dropTarget.nodeId !== pending.nodeId) connectNodes(pending, dropTarget.nodeId);
            return;
        }
        if (event.button === 0) setAgentReferenceNodeClick((current) => ({ nodeId, version: current.version + 1 }));
        setContextMenu(null);
        setHoveredNodeId(null);
        setToolbarNodeId(null);
        setSelectedConnectionId(null);
        setSelectedConnectionIds(new Set());
        if (nodesRef.current.find((node) => node.id === nodeId)?.type === CanvasNodeType.Group) setDialogNodeId(null);

        const currentSelected = selectedNodeIdsRef.current;
        const currentNodes = nodesRef.current;
        const nextSelected = new Set(currentSelected);

        if (event.shiftKey || event.metaKey || event.ctrlKey) {
            if (nextSelected.has(nodeId)) {
                nextSelected.delete(nodeId);
            } else {
                nextSelected.add(nodeId);
            }
        } else if (!nextSelected.has(nodeId)) {
            nextSelected.clear();
            nextSelected.add(nodeId);
        }

        setSelectedNodeIds(nextSelected);
        // Node actions are available from the right-click menu. Keeping the
        // selection here avoids showing the old floating action bar on every
        // single click.
        setToolbarNodeId(null);
        const dragIds = new Set(nextSelected);
        currentNodes.forEach((node) => {
            if (!nextSelected.has(node.id)) return;
            node.metadata?.batchChildIds?.forEach((childId) => dragIds.add(childId));
            if (node.type === CanvasNodeType.Group) {
                currentNodes.forEach((child) => {
                    if (child.metadata?.groupId === node.id) dragIds.add(child.id);
                });
            }
        });
        // 拖拽涉及组（组节点或组内子节点）时不做网格吸附，只保留对齐吸附
        const dragIncludesGroup = [...dragIds].some((id) => {
            const node = currentNodes.find((item) => item.id === id);
            return Boolean(node && (node.type === CanvasNodeType.Group || node.metadata?.groupId));
        });
        dragRef.current = {
            isDraggingNode: true,
            hasMoved: false,
            clickedGroupId: currentNodes.find((node) => node.id === nodeId)?.type === CanvasNodeType.Group ? nodeId : null,
            dragIncludesGroup,
            startX: event.clientX,
            startY: event.clientY,
            initialSelectedNodes: currentNodes.filter((node) => dragIds.has(node.id)).map((node) => ({ id: node.id, x: node.position.x, y: node.position.y, width: node.width, height: node.height })),
        };
        historyPausedRef.current = true;
        nodeDraggingRef.current = true;
        setIsNodeDragging(true);
    }, []);

    // 018-8（boss 2026-10-04）：框选后，点选区框内「空白处」拖动 = 只移动被框选的节点，不平移画布。
    // 复用 handleNodeMouseDown 的同一套拖拽初始化（dragRef / nodeDraggingRef / 历史暂停），保证吸附、对齐、分组逻辑一致。
    const startSelectionAreaDrag = useCallback((clientX: number, clientY: number) => {
        const currentSelected = selectedNodeIdsRef.current;
        if (!currentSelected || currentSelected.size === 0) return false;
        const currentNodes = nodesRef.current;
        const dragIds = new Set(currentSelected);
        currentNodes.forEach((node) => {
            if (!currentSelected.has(node.id)) return;
            node.metadata?.batchChildIds?.forEach((childId) => dragIds.add(childId));
            if (node.type === CanvasNodeType.Group) {
                currentNodes.forEach((child) => {
                    if (child.metadata?.groupId === node.id) dragIds.add(child.id);
                });
            }
        });
        const dragIncludesGroup = [...dragIds].some((id) => {
            const node = currentNodes.find((item) => item.id === id);
            return Boolean(node && (node.type === CanvasNodeType.Group || node.metadata?.groupId));
        });
        dragRef.current = {
            isDraggingNode: true,
            hasMoved: false,
            clickedGroupId: null,
            dragIncludesGroup,
            startX: clientX,
            startY: clientY,
            initialSelectedNodes: currentNodes.filter((node) => dragIds.has(node.id)).map((node) => ({ id: node.id, x: node.position.x, y: node.position.y, width: node.width, height: node.height })),
        };
        historyPausedRef.current = true;
        nodeDraggingRef.current = true;
        setIsNodeDragging(true);
        return true;
    }, []);

    const finishNodeDrag = useCallback((clientX?: number, clientY?: number, freeMove = false) => {
        if (rafRef.current) {
            cancelAnimationFrame(rafRef.current);
            rafRef.current = null;
        }
        if (!dragRef.current.isDraggingNode) {
            setDropTargetGroupId(null);
            return;
        }

        const wasClick = !dragRef.current.hasMoved && dragRef.current.initialSelectedNodes.length === 1;
        const clickedNodeId = dragRef.current.clickedGroupId || dragRef.current.initialSelectedNodes[0]?.id;
        const currentViewport = viewportRef.current;
        const rawDx = clientX == null ? 0 : (clientX - dragRef.current.startX) / currentViewport.k;
        const rawDy = clientY == null ? 0 : (clientY - dragRef.current.startY) / currentViewport.k;
        const initialPositions = dragRef.current.initialSelectedNodes;
        const resolved = resolveDragDelta(initialPositions, rawDx, rawDy, snapToGrid && !freeMove && !dragRef.current.dragIncludesGroup);
        const dx = resolved.dx;
        const dy = resolved.dy;

        historyPausedRef.current = false;
        nodeDraggingRef.current = false;
        setIsNodeDragging(false);
        if (dragRef.current.hasMoved && clientX != null && clientY != null) {
            const movedIds = new Set(initialPositions.map((item) => item.id));
            setNodes((prev) => {
                const moved = prev.map((node) => {
                    const initial = initialPositions.find((item) => item.id === node.id);
                    return initial ? { ...node, position: { x: initial.x + dx, y: initial.y + dy } } : node;
                });
                const targetGroup = findGroupDropTarget(movedIds, moved);
                if (targetGroup) return snapNodesIntoGroup(movedIds, moved, targetGroup);
                return moved.map((node) => {
                    if (!movedIds.has(node.id) || node.type === CanvasNodeType.Group) return node;
                    const groupId = findContainingGroupId(node, moved);
                    return node.metadata?.groupId === groupId ? node : { ...node, metadata: { ...node.metadata, groupId } };
                });
            });
        }

        dragRef.current.isDraggingNode = false;
        dragRef.current.hasMoved = false;
        dragRef.current.clickedGroupId = null;
        dragRef.current.initialSelectedNodes = [];
        setAlignGuides({ vLines: [], hLines: [] });
        setDropTargetGroupId(null);
        if (wasClick && clickedNodeId) {
            // boss 2026-10-07：旋转与镜像编辑页面中，点击节点不再弹提示词栏（点旋转已属于编辑态）
            if (transformNodeId) return;
            const clickedNode = nodesRef.current.find((node) => node.id === clickedNodeId);
            if (clickedNode?.type === CanvasNodeType.Group) {
                setDialogNodeId(null);
            } else if (clickedNode?.type === CanvasNodeType.Text) {
                setDialogNodeId((current) => (current === clickedNodeId ? current : null));
            } else {
                setDialogNodeId(clickedNodeId);
            }
        }
    }, [resolveDragDelta, snapToGrid, transformNodeId]);

    const handleGlobalMouseMove = useCallback(
        (event: MouseEvent) => {
            const currentViewport = viewportRef.current;

            if (selectionConnectionDragRef.current) {
                setMouseWorld(screenToCanvas(event.clientX, event.clientY));
                return;
            }

            if (dragRef.current.isDraggingNode) {
                const rawDx = (event.clientX - dragRef.current.startX) / currentViewport.k;
                const rawDy = (event.clientY - dragRef.current.startY) / currentViewport.k;
                const initialPositions = dragRef.current.initialSelectedNodes;
                const resolved = resolveDragDelta(initialPositions, rawDx, rawDy, snapToGrid && !event.altKey && !dragRef.current.dragIncludesGroup);
                const dx = resolved.dx;
                const dy = resolved.dy;
                setAlignGuides(resolved.vLines.length || resolved.hLines.length ? { vLines: resolved.vLines, hLines: resolved.hLines } : EMPTY_ALIGN_GUIDES);
                if (Math.abs(event.clientX - dragRef.current.startX) > 3 || Math.abs(event.clientY - dragRef.current.startY) > 3) {
                    dragRef.current.hasMoved = true;
                }

                const movedIds = new Set(initialPositions.map((item) => item.id));
                const previewNodes = nodesRef.current.map((node) => {
                    const initial = initialPositions.find((item) => item.id === node.id);
                    return initial ? { ...node, position: { x: initial.x + dx, y: initial.y + dy } } : node;
                });
                setDropTargetGroupId(findGroupDropTarget(movedIds, previewNodes)?.id || null);

                if (rafRef.current) cancelAnimationFrame(rafRef.current);
                rafRef.current = requestAnimationFrame(() => {
                    setNodes((prev) =>
                        prev.map((node) => {
                            const initial = initialPositions.find((item) => item.id === node.id);
                            return initial ? { ...node, position: { x: initial.x + dx, y: initial.y + dy } } : node;
                        }),
                    );
                    rafRef.current = null;
                });
                return;
            }

            if (connectingParamsRef.current && !pendingConnectionCreateRef.current) {
                const dropTarget = getConnectionDropTarget(event.clientX, event.clientY, connectingParamsRef.current);
                connectionTargetNodeIdRef.current = dropTarget.nodeId;
                setConnectionTargetNodeId(dropTarget.nodeId);
                setMouseWorld(screenToCanvas(event.clientX, event.clientY));
            }
        },
        [finishNodeDrag, getConnectionDropTarget, resolveDragDelta, screenToCanvas, snapToGrid],
    );

    const handleGlobalPointerMove = useCallback(
        (event: PointerEvent) => {
            const currentSelection = selectionBoxRef.current;
            if (!currentSelection) return;

            if (event.buttons === 0) {
                selectionBoxRef.current = null;
                setSelectionBox(null);
                return;
            }

            const world = screenToCanvas(event.clientX, event.clientY);
            const rectX = Math.min(currentSelection.startWorldX, world.x);
            const rectY = Math.min(currentSelection.startWorldY, world.y);
            const rectW = Math.abs(world.x - currentSelection.startWorldX);
            const rectH = Math.abs(world.y - currentSelection.startWorldY);
            const nextSelected = new Set<string>(currentSelection.additive ? currentSelection.initialSelectedNodeIds : []);

            nodesRef.current
                .filter((node) => !isHiddenBatchChild(node, nodesRef.current))
                .forEach((node) => {
                    const intersects = rectX < node.position.x + node.width && rectX + rectW > node.position.x && rectY < node.position.y + node.height && rectY + rectH > node.position.y;

                    if (intersects) nextSelected.add(node.id);
                });

            // 连线也能被框选：沿连线真实曲线采样，要求选框确实“框住”了这条线的一段
            // （老做法用两端点包围盒 + 曲率外扩，汇入同一节点的多条线包围盒互相重叠，会误选）
            const nextSelectedConnections = new Set<string>(currentSelection.additive ? currentSelection.initialSelectedConnectionIds : []);
            const marqueeNodeById = new Map(nodesRef.current.map((node) => [node.id, node]));
            connectionsRef.current.forEach((connection) => {
                const from = marqueeNodeById.get(connection.fromNodeId);
                const to = marqueeNodeById.get(connection.toNodeId);
                if (!from || !to) return;
                const startX = from.position.x + from.width;
                const startY = from.position.y + from.height / 2;
                const endX = to.position.x;
                const endY = to.position.y + to.height / 2;
                const dist = Math.hypot(endX - startX, endY - startY);
                const steps = Math.min(64, Math.max(14, Math.round(dist / 16)));
                const points = connectionCurvePoints(startX, startY, endX, endY, steps);
                let inside = 0;
                let firstInside = -1;
                let lastInside = -1;
                points.forEach((point, index) => {
                    if (point.x >= rectX && point.x <= rectX + rectW && point.y >= rectY && point.y <= rectY + rectH) {
                        inside += 1;
                        if (firstInside < 0) firstInside = index;
                        lastInside = index;
                    }
                });
                if (inside < 2) return;
                // 两种命中：①选框框住线长的 1/4 以上；②线“穿过”选框（一侧进另一侧出）——细选框横竖扫过连线也能选中；
                // 仅在端点处蹭进选框（线终止于框内，如汇入同一节点的收敛段）不算，避免误选。
                const coverage = inside / (steps + 1);
                const crossing = firstInside > 0 && lastInside < steps;
                if (coverage >= 0.25 || crossing) nextSelectedConnections.add(connection.id);
            });

            const nextSelectionBox = { ...currentSelection, currentWorldX: world.x, currentWorldY: world.y };
            selectionBoxRef.current = nextSelectionBox;
            setSelectionBox(nextSelectionBox);
            setSelectedNodeIds(nextSelected);
            setSelectedConnectionIds(nextSelectedConnections);
        },
        [screenToCanvas],
    );

    const handleGlobalMouseUp = useCallback(
        (event: MouseEvent) => {
            finishNodeDrag(event.clientX, event.clientY, event.altKey);

            selectionBoxRef.current = null;
            setSelectionBox(null);

            const selectionDrag = selectionConnectionDragRef.current;
            if (selectionDrag) {
                selectionConnectionDragRef.current = null;
                setSelectionConnectionDrag(null);
                const position = screenToCanvas(event.clientX, event.clientY);
                setMouseWorld(position);
                // 松手落在已有节点上 → 整批选中节点连到该节点；落在空白才弹「引用选中节点生成」菜单
                const dropTarget = getConnectionDropTarget(event.clientX, event.clientY, { nodeId: selectionDrag.sourceNodeIds[0], handleType: "source" });
                if (dropTarget.nodeId) {
                    connectSelectionNodes(selectionDrag.sourceNodeIds, dropTarget.nodeId);
                    return;
                }
                setPendingConnectionCreate({
                    connection: { nodeId: selectionDrag.sourceNodeIds[0], handleType: "source" },
                    sourceNodeIds: selectionDrag.sourceNodeIds,
                    selection: true,
                    position,
                });
                return;
            }

            if (pendingConnectionCreateRef.current) return;

            const currentConnection = connectingParamsRef.current;
            if (currentConnection) {
                const dropTarget = getConnectionDropTarget(event.clientX, event.clientY, currentConnection);
                // 快速点击（松手时鼠标基本没挪动，<6px）：进入「连线跟随」模式——线持续跟着鼠标走，
                // 点目标节点完成连接、点空白弹出添加节点菜单、Esc 取消；只有明确拖拽后松手才走原逻辑。
                // 用位移而非按住时长判定：正常点击往往超过 350ms，按时长会误判成拖拽。
                const pressPos = connectionPressStartPosRef.current;
                const movedDist = pressPos ? Math.hypot(event.clientX - pressPos.x, event.clientY - pressPos.y) : Number.POSITIVE_INFINITY;
                const quickClick = movedDist < 6;
                connectionPressStartPosRef.current = null;
                if (dropTarget.nodeId) {
                    connectNodes(currentConnection, dropTarget.nodeId);
                    setConnecting(null);
                } else if (dropTarget.isNearNode) {
                    if (!quickClick) setConnecting(null);
                } else if (quickClick) {
                    setMouseWorld(screenToCanvas(event.clientX, event.clientY));
                } else {
                    const position = screenToCanvas(event.clientX, event.clientY);
                    setMouseWorld(position);
                    setPendingConnectionCreate({ connection: currentConnection, position });
                }
            }
        },
        [connectNodes, finishNodeDrag, getConnectionDropTarget, screenToCanvas, setConnecting],
    );

    useEffect(() => {
        const handlePointerUp = (event: PointerEvent) => {
            finishNodeDrag(event.clientX, event.clientY, event.altKey);
            selectionBoxRef.current = null;
            setSelectionBox(null);
            const selectionDrag = selectionConnectionDragRef.current;
            if (!selectionDrag) return;
            selectionConnectionDragRef.current = null;
            setSelectionConnectionDrag(null);
            const position = screenToCanvas(event.clientX, event.clientY);
            setMouseWorld(position);
            // 松手落在已有节点上 → 整批选中节点连到该节点；落在空白才弹「引用选中节点生成」菜单
            const dropTarget = getConnectionDropTarget(event.clientX, event.clientY, { nodeId: selectionDrag.sourceNodeIds[0], handleType: "source" });
            if (dropTarget.nodeId) {
                connectSelectionNodes(selectionDrag.sourceNodeIds, dropTarget.nodeId);
                return;
            }
            setPendingConnectionCreate({
                connection: { nodeId: selectionDrag.sourceNodeIds[0], handleType: "source" },
                sourceNodeIds: selectionDrag.sourceNodeIds,
                selection: true,
                position,
            });
        };
        const cancelNodeDrag = () => finishNodeDrag();
        window.addEventListener("mousemove", handleGlobalMouseMove);
        window.addEventListener("mouseup", handleGlobalMouseUp);
        window.addEventListener("pointerup", handlePointerUp);
        window.addEventListener("pointercancel", cancelNodeDrag);
        window.addEventListener("blur", cancelNodeDrag);
        window.addEventListener("pointermove", handleGlobalPointerMove);
        return () => {
            window.removeEventListener("mousemove", handleGlobalMouseMove);
            window.removeEventListener("mouseup", handleGlobalMouseUp);
            window.removeEventListener("pointerup", handlePointerUp);
            window.removeEventListener("pointercancel", cancelNodeDrag);
            window.removeEventListener("blur", cancelNodeDrag);
            window.removeEventListener("pointermove", handleGlobalPointerMove);
        };
    }, [connectSelectionNodes, finishNodeDrag, getConnectionDropTarget, handleGlobalMouseMove, handleGlobalMouseUp, handleGlobalPointerMove, screenToCanvas]);

    const appendImportedImageNode = useCallback((image: UploadedImage, title: string, position: Position, type: CanvasNodeType.Image | CanvasNodeType.Panorama) => {
        const isPanorama = type === CanvasNodeType.Panorama;
        const size = isPanorama ? PANORAMA_NODE_SIZE : normalizeNodeSize(image.width, image.height);
        const id = type + "-" + Date.now() + "-" + Math.random().toString(36).slice(2, 7);
        const newNode: CanvasNodeData = {
            id,
            type,
            title,
            position: { x: position.x - size.width / 2, y: position.y - size.height / 2 },
            width: size.width,
            height: size.height,
            metadata: isPanorama ? { ...imageMetadata(image), size: PANORAMA_IMAGE_SIZE, panoramaProjection: "equirectangular" } : imageMetadata(image),
        };
        setNodes((prev) => [...prev, newNode]);
        setSelectedNodeIds(new Set([id]));
        setSelectedConnectionId(null);
        setDialogNodeId(id);
    }, []);

    const createImageFileNode = useCallback(async (file: File, position: Position, choosePanoramaImport = false) => {
        const hideLoading = message.loading("正在上传图片...", 0);
        try {
            const image = await uploadImage(file);
            if (choosePanoramaImport && image.width === image.height * 2) {
                setPendingPanoramaImport({ image, title: file.name, position });
                return;
            }
            appendImportedImageNode(image, file.name, position, CanvasNodeType.Image);
        } catch (error) {
            console.error("Upload image node failed:", error);
            message.error("图片上传失败");
        } finally {
            hideLoading();
        }
    }, [appendImportedImageNode, message]);

    const finishPanoramaImport = useCallback((type: CanvasNodeType.Image | CanvasNodeType.Panorama) => {
        if (!pendingPanoramaImport) return;
        setPendingPanoramaImport(null);
        appendImportedImageNode(pendingPanoramaImport.image, pendingPanoramaImport.title, pendingPanoramaImport.position, type);
    }, [appendImportedImageNode, pendingPanoramaImport]);
    const createVideoFileNode = useCallback(async (file: File, position: Position) => {
        const hideLoading = message.loading("正在上传视频...", 0);
        try {
            const video = await uploadMediaFile(file, "video");
            const node = buildImportedVideoNode(video, file.name, position);
            setNodes((prev) => [...prev, node]);
            setSelectedNodeIds(new Set([node.id]));
            setSelectedConnectionId(null);
            setDialogNodeId(node.id);
        } catch (error) {
            console.error("Upload video node failed:", error);
            message.error("视频上传失败");
        } finally {
            hideLoading();
        }
    }, [message]);

    const createAudioFileNode = useCallback(async (file: File, position: Position) => {
        const hideLoading = message.loading("正在上传音频...", 0);
        try {
            const audio = await uploadMediaFile(file, "audio");
            const spec = NODE_DEFAULT_SIZE[CanvasNodeType.Audio];
            const id = `audio-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
            setNodes((prev) => [
                ...prev,
                {
                    id,
                    type: CanvasNodeType.Audio,
                    title: file.name,
                    position: { x: position.x - spec.width / 2, y: position.y - spec.height / 2 },
                    width: spec.width,
                    height: spec.height,
                    metadata: audioMetadata(audio),
                },
            ]);
            setSelectedNodeIds(new Set([id]));
            setSelectedConnectionId(null);
            return id;
        } catch (error) {
            console.error("Upload audio node failed:", error);
            message.error("音频上传失败");
        } finally {
            hideLoading();
        }
    }, [message]);

    // 批量导入：一次拖入/选择多个素材文件 → 逐个上传 → 按 4 列自动排布 → 一次性写入（单步可撤销）
    const importFilesAt = useCallback(
        async (files: File[], position: Position) => {
            const supported = files.filter((file) => file.type.startsWith("image/") || file.type.startsWith("video/") || isAudioFile(file));
            if (!supported.length) return;
            if (supported.length === 1) {
                const file = supported[0];
                void (isAudioFile(file) ? createAudioFileNode(file, position) : file.type.startsWith("video/") ? createVideoFileNode(file, position) : createImageFileNode(file, position, true));
                return;
            }
            const hideLoading = message.loading(`正在批量导入 ${supported.length} 个文件...`, 0);
            try {
                const results = await Promise.all(
                    supported.map(async (file) => {
                        try {
                            if (isAudioFile(file)) return { kind: "audio" as const, name: file.name, audio: await uploadMediaFile(file, "audio") };
                            if (file.type.startsWith("video/")) return { kind: "video" as const, name: file.name, video: await uploadMediaFile(file, "video") };
                            return { kind: "image" as const, name: file.name, image: await uploadImage(file) };
                        } catch {
                            return null;
                        }
                    }),
                );
                const items = results.filter((item): item is NonNullable<typeof results[number]> => Boolean(item));
                if (!items.length) {
                    message.error("没有可用的图片/视频/音频文件");
                    return;
                }
                const perRow = 4;
                const gap = 48;
                const newNodes: CanvasNodeData[] = [];
                let cursorX = position.x;
                let cursorY = position.y;
                let rowHeight = 0;
                let column = 0;
                items.forEach((item, index) => {
                    let node: CanvasNodeData;
                    if (item.kind === "audio") {
                        const spec = NODE_DEFAULT_SIZE[CanvasNodeType.Audio];
                        node = {
                            id: `audio-${Date.now()}-${index}-${Math.random().toString(36).slice(2, 7)}`,
                            type: CanvasNodeType.Audio,
                            title: item.name,
                            position: { x: cursorX - spec.width / 2, y: cursorY - spec.height / 2 },
                            width: spec.width,
                            height: spec.height,
                            metadata: audioMetadata(item.audio),
                        };
                    } else if (item.kind === "video") {
                        node = buildImportedVideoNode(item.video, item.name, { x: cursorX, y: cursorY });
                    } else {
                        const size = normalizeNodeSize(item.image.width, item.image.height);
                        node = {
                            id: `image-${Date.now()}-${index}-${Math.random().toString(36).slice(2, 7)}`,
                            type: CanvasNodeType.Image,
                            title: item.name,
                            position: { x: cursorX - size.width / 2, y: cursorY - size.height / 2 },
                            width: size.width,
                            height: size.height,
                            metadata: imageMetadata(item.image),
                        };
                    }
                    newNodes.push(node);
                    rowHeight = Math.max(rowHeight, node.height);
                    cursorX += node.width + gap;
                    column += 1;
                    if (column >= perRow) {
                        column = 0;
                        cursorX = position.x;
                        cursorY += rowHeight + gap;
                        rowHeight = 0;
                    }
                });
                setNodes((prev) => [...prev, ...newNodes]);
                setSelectedNodeIds(new Set(newNodes.map((node) => node.id)));
                setSelectedConnectionId(null);
                // 批量导入不弹单个节点的提示词面板（会只覆盖其中一个），提示后由用户自己选目标
                message.success(`已导入 ${newNodes.length} 个素材，已全部选中`);
            } catch (error) {
                console.error("Batch import failed:", error);
                message.error("批量导入失败");
            } finally {
                hideLoading();
            }
        },
        [createAudioFileNode, createImageFileNode, createVideoFileNode, message],
    );

    const extractingAudioRef = useRef(new Set<string>());

    const extractAudio = useCallback(async (node: CanvasNodeData, trim?: { start: number; end: number }) => {
        if ((node.type !== CanvasNodeType.Video && node.type !== CanvasNodeType.Audio) || !node.metadata?.content || extractingAudioRef.current.has(node.id)) return;
        extractingAudioRef.current.add(node.id);
        if (trim) setTrimmingAudio(true);
        const hideLoading = message.loading(trim ? "正在截取音频..." : "正在分离音频...", 0);
        let input: import("mediabunny").Input | undefined;
        let conversion: import("mediabunny").Conversion | undefined;

        try {
            if (trim && (!Number.isFinite(trim.start) || !Number.isFinite(trim.end) || trim.start < 0 || Math.round((trim.end - trim.start) * 100) < 50)) {
                throw new Error("请填写有效的起止时间，至少保留 0.5 秒");
            }
            const [{ Input, ALL_FORMATS, BlobSource, Output, WavOutputFormat, BufferTarget, Conversion }, blob] = await Promise.all([
                import("mediabunny"),
                resolveMediaUrl(node.metadata.storageKey, node.metadata.content).then(downloadRemoteMedia),
            ]);
            input = new Input({ source: new BlobSource(blob), formats: ALL_FORMATS });
            const audioTrack = await input.getPrimaryAudioTrack();
            if (!audioTrack) throw new Error("该文件没有音轨");
            if (trim && trim.end > await audioTrack.computeDuration()) throw new Error("结束时间不能超过音频时长");

            const target = new BufferTarget();
            const output = new Output({ format: new WavOutputFormat(), target });
            conversion = await Conversion.init({
                input, output, tracks: "primary", trim,
                audio: { process: (sample) => { if (sample.timestamp < 0 && sample.timestamp > -1e-9) sample.setTimestamp(0); return sample; } },
            });
            if (!conversion.isValid) throw new Error("当前浏览器无法解码该文件的音频");
            await conversion.execute();

            const file = new File([target.buffer!], `${node.title || (trim ? "音频" : "视频")} ${trim ? "截取" : "音频"}.wav`, {
                type: "audio/wav",
            });
            const width = NODE_DEFAULT_SIZE[CanvasNodeType.Audio].width;
            hideLoading();
            const audioNodeId = await createAudioFileNode(file, {
                x: node.position.x + node.width + 96 + width / 2,
                y: node.position.y + node.height / 2,
            });

            if (audioNodeId) {
                setConnections((prev) => [
                    ...prev,
                    { id: nanoid(), fromNodeId: node.id, toNodeId: audioNodeId },
                ]);
            }
            return audioNodeId;
        } catch (error) {
            message.error(error instanceof Error ? error.message : "音频处理失败");
        } finally {
            await conversion?.cancel().catch(console.error);
            input?.dispose();
            extractingAudioRef.current.delete(node.id);
            hideLoading();
            if (trim) setTrimmingAudio(false);
        }
    }, [createAudioFileNode, message]);

    const createTextNodeFromClipboard = useCallback(
        (text: string) => {
            const trimmed = text.trim();
            if (!trimmed) return false;

            const node = {
                ...createCanvasNode(CanvasNodeType.Text, getCanvasCenter(), { content: trimmed, status: NODE_STATUS_SUCCESS }),
                title: trimmed.slice(0, 32) || "剪切板文本",
            };

            setNodes((prev) => [...prev, node]);
            setSelectedNodeIds(new Set([node.id]));
            setSelectedConnectionId(null);
            setContextMenu(null);
            setDialogNodeId(node.id);
            return true;
        },
        [getCanvasCenter],
    );

    const pasteSystemClipboard = useCallback(async () => {
        if (!navigator.clipboard) return;

        const items = await navigator.clipboard.read();
        const imageItem = items.find((item) => item.types.some((type) => type.startsWith("image/")));
        if (imageItem) {
            const imageType = imageItem.types.find((type) => type.startsWith("image/"));
            if (!imageType) return;
            const blob = await imageItem.getType(imageType);
            const file = new File([blob], "clipboard-image.png", { type: imageType });
            void createImageFileNode(file, getCanvasCenter());
            message.success("已从剪切板添加图片");
            return;
        }

        const text = await navigator.clipboard.readText();
        if (createTextNodeFromClipboard(text)) message.success("已从剪切板添加文本");
    }, [createImageFileNode, createTextNodeFromClipboard, getCanvasCenter, message]);

    useEffect(() => {
        const handleKeyDown = (event: KeyboardEvent) => {
            const target = event.target instanceof Element ? event.target : null;
            const targetNodeId = target?.closest<HTMLElement>("[data-node-id]")?.dataset.nodeId;
            const isSelectedVideo = event.target instanceof HTMLVideoElement && Boolean(targetNodeId && selectedNodeIdsRef.current.has(targetNodeId));
            if (event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement || event.target instanceof HTMLSelectElement || target?.closest("[contenteditable='true']") || (target?.closest("[data-canvas-no-zoom]") && !isSelectedVideo)) return;

            const key = event.key.toLowerCase();
            const isModifierShortcut = event.metaKey || event.ctrlKey;

            // boss 2026-10-04：工具快捷键 —— V 移动工具 / H 抓手工具（裸键，不带修饰）
            if (!isModifierShortcut && !event.shiftKey && !event.altKey && key === "v") {
                event.preventDefault();
                setCanvasTool("select");
                return;
            }

            if (!isModifierShortcut && !event.shiftKey && !event.altKey && key === "h") {
                event.preventDefault();
                setCanvasTool("pan");
                return;
            }

            // boss 2026-10-04：解组 Ctrl/Alt+Shift+G（此前无此功能，新建）
            if (event.shiftKey && event.altKey && key === "g") {
                event.preventDefault();
                ungroupSelection();
                return;
            }

            // boss 2026-10-04：整理画布 Alt+Shift+F（走 setNodes，进历史栈，可 Ctrl+Z 撤回）
            if (event.shiftKey && event.altKey && key === "f") {
                event.preventDefault();
                arrangeCanvasNodes();
                return;
            }

            // boss 2026-10-04：画布节点搜索 Ctrl/Cmd+F（拦截浏览器默认页内查找）
            if (isModifierShortcut && !event.shiftKey && !event.altKey && key === "f") {
                event.preventDefault();
                setNodeSearchOpen(true);
                return;
            }

            if (isModifierShortcut && !event.altKey && key === "z") {
                event.preventDefault();
                if (event.shiftKey) redoCanvas();
                else undoCanvas();
                return;
            }

            if (isModifierShortcut && !event.altKey && key === "y") {
                event.preventDefault();
                redoCanvas();
                return;
            }

            if (isModifierShortcut && !event.altKey && key === "a") {
                event.preventDefault();
                setSelectedNodeIds(new Set(nodesRef.current.map((node) => node.id)));
                setSelectedConnectionId(null);
                setContextMenu(null);
                setSelectionBox(null);
                return;
            }

            if (isModifierShortcut && !event.altKey && key === "g") {
                event.preventDefault();
                createGroupFromSelection();
                return;
            }

            if (isModifierShortcut && !event.altKey && key === "c") {
                const selection = window.getSelection();
                if (selection && !selection.isCollapsed && selection.toString()) return;

                event.preventDefault();
                copySelectedNodes();
                return;
            }

            if (isModifierShortcut && !event.altKey && key === "v") {
                event.preventDefault();
                if (!pasteCopiedNodes()) void pasteSystemClipboard();
                return;
            }

            if (event.key === "Delete" || event.key === "Backspace") {
                if (selectedNodeIdsRef.current.size) {
                    deleteNodes(new Set(selectedNodeIdsRef.current));
                    setSelectedConnectionIds(new Set());
                } else if (selectedConnectionId) {
                    deleteConnection(selectedConnectionId);
                    setSelectedConnectionIds(new Set());
                } else if (selectedConnectionIdsRef.current.size) {
                    deleteConnections(new Set(selectedConnectionIdsRef.current));
                }
            }

            if (event.key === "Escape") {
                setSelectedNodeIds(new Set());
                setSelectedConnectionId(null);
                setSelectedConnectionIds(new Set());
                setContextMenu(null);
                setNodeCreatePosition(null);
                setSelectionBox(null);
                setConnecting(null);
                setHoveredNodeId(null);
                setToolbarNodeId(null);
                setDialogNodeId(null);
                setInfoNodeId(null);
                setCropNodeId(null);
                setMaskEditNodeId(null);
                setPendingConnectionCreate(null);
                setNodeSearchOpen(false);
                selectionConnectionDragRef.current = null;
                setSelectionConnectionDrag(null);
            }
        };

        window.addEventListener("keydown", handleKeyDown);
        return () => window.removeEventListener("keydown", handleKeyDown);
    }, [arrangeCanvasNodes, copySelectedNodes, createGroupFromSelection, deleteConnection, deleteConnections, deleteNodes, pasteCopiedNodes, pasteSystemClipboard, redoCanvas, selectedConnectionId, setConnecting, undoCanvas, ungroupSelection]);

    const handleConnectStart = useCallback(
        (event: ReactMouseEvent, nodeId: string, handleType: "source" | "target") => {
            event.stopPropagation();
            connectionPressStartPosRef.current = { x: event.clientX, y: event.clientY };
            setMouseWorld(screenToCanvas(event.clientX, event.clientY));
            setConnecting({ nodeId, handleType });
            connectionTargetNodeIdRef.current = null;
            setConnectionTargetNodeId(null);
            setSelectedConnectionId(null);
        },
        [screenToCanvas, setConnecting],
    );

    const handleNodeResize = useCallback((nodeId: string, width: number, height: number, position?: Position) => {
        setNodes((prev) => prev.map((node) => (node.id === nodeId ? { ...node, width, height, position: position || node.position } : node)));
    }, []);

    const toggleNodeFreeResize = useCallback((nodeId: string) => {
        setNodes((prev) =>
            prev.map((node) => {
                if (node.id !== nodeId) return node;
                const freeResize = !node.metadata?.freeResize;
                if (freeResize || !isCanvasImageNodeType(node.type)) return { ...node, metadata: { ...node.metadata, freeResize } };
                const ratio = (node.metadata?.naturalWidth || node.width) / (node.metadata?.naturalHeight || node.height || 1);
                const height = node.width / ratio;
                return { ...node, height, position: { x: node.position.x, y: node.position.y + node.height / 2 - height / 2 }, metadata: { ...node.metadata, freeResize } };
            }),
        );
    }, []);

    const handleNodeContentChange = useCallback((nodeId: string, content: string) => {
        setNodes((prev) => prev.map((node) => (node.id === nodeId ? { ...node, metadata: { ...node.metadata, content, ...(content ? { generatedAt: Date.now() } : {}) } } : node)));
    }, []);

    // 给有产出的媒体节点补生成时间戳（生成历史按时间分组用）：覆盖上传/生成等所有写入路径，
    // 旧节点首次被观察到时补记一次
    useEffect(() => {
        const needsStamp = nodes.filter((node) => node.metadata?.content && !node.metadata.generatedAt && (isCanvasImageNodeType(node.type) || node.type === CanvasNodeType.Video || node.type === CanvasNodeType.Audio));
        if (!needsStamp.length) return;
        const now = Date.now();
        const ids = new Set(needsStamp.map((node) => node.id));
        setNodes((prev) => prev.map((node) => (ids.has(node.id) ? { ...node, metadata: { ...node.metadata, generatedAt: now } } : node)));
    }, [nodes]);

    const handleNodeTitleChange = useCallback((nodeId: string, title: string) => {
        setNodes((prev) => prev.map((node) => (node.id === nodeId ? { ...node, title } : node)));
        // 081：节点改名实时同步作品库（节点关联生成任务时，走宿主 media-rename 通道）
        const node = nodesRef.current.find((item) => item.id === nodeId);
        const linkedTaskId = node?.metadata?.imageTaskId || node?.metadata?.videoTaskId || node?.metadata?.audioTaskId;
        if (linkedTaskId && title.trim()) {
            try {
                window.parent.postMessage({ source: "kinglevel-canvas", type: "media-rename", payload: { taskId: String(linkedTaskId), title: title.trim() } }, "*");
            } catch (_) {}
        }
    }, []);

    const toggleBatchExpanded = useCallback((nodeId: string) => {
        const isExpanded = Boolean(nodesRef.current.find((node) => node.id === nodeId)?.metadata?.imageBatchExpanded);
        if (isExpanded) {
            setCollapsingBatchIds((prev) => new Set(prev).add(nodeId));
            window.setTimeout(() => {
                setCollapsingBatchIds((prev) => {
                    const next = new Set(prev);
                    next.delete(nodeId);
                    return next;
                });
            }, 320);
        } else {
            setOpeningBatchIds((prev) => new Set(prev).add(nodeId));
            window.setTimeout(() => {
                setOpeningBatchIds((prev) => {
                    const next = new Set(prev);
                    next.delete(nodeId);
                    return next;
                });
            }, 260);
        }
        setNodes((prev) => {
            const root = prev.find((node) => node.id === nodeId);
            // 092：展开时按 LibTV 网格真值重排子图（gap 8）。老项目子图位置是创建时写死存的，
            // 只改创建代码不会挪动已有节点，必须在展开这一刻按当前公式重算，否则看起来"没改"。
            const childIds = root?.metadata?.batchChildIds || [];
            const layout = new Map<string, { x: number; y: number }>();
            if (root && !isExpanded && childIds.length) {
                const nodeById = new Map(prev.map((node) => [node.id, node]));
                const children = childIds.map((id) => nodeById.get(id)).filter((node): node is CanvasNodeData => Boolean(node));
                if (children.length) {
                    // 093：主图占田字格 (0,0) 的 LibTV 真值布局（用子图真实宽高，不再拿主图尺寸当格子）
                    layoutBatchExpandedChildren({ x: root.position.x, y: root.position.y, width: root.width, height: root.height }, children.map((child) => ({ width: child.width, height: child.height }))).forEach((pos, index) => {
                        layout.set(children[index].id, pos);
                    });
                }
            }
            return prev.map((node) => {
                if (node.id === nodeId) return { ...node, metadata: { ...node.metadata, imageBatchExpanded: !node.metadata?.imageBatchExpanded } };
                const next = layout.get(node.id);
                return next ? { ...node, position: next } : node;
            });
        });
    }, []);

    // 097：右键「展开节点」——把堆叠批次（主图+子图）拆成各自独立的普通图片节点；
    // 内容各自保留（主图对调后内容在对应节点里），位置按 093 田字格布局平铺，批次内部连线拆除。
    const expandBatchToNodes = useCallback((rootId: string) => {
        const root = nodesRef.current.find((node) => node.id === rootId);
        const childIds: string[] = (root?.metadata?.batchChildIds as string[] | undefined) || [];
        if (!root?.metadata?.isBatchRoot || !childIds.length) return;
        const children = childIds
            .map((id) => nodesRef.current.find((node) => node.id === id))
            .filter((node): node is CanvasNodeData => Boolean(node));
        // 097b：主图留在原位（田字格 (0,0)），layoutBatchExpandedChildren 只算子图位置——
        // 此前把主图也当子图传入导致整体错位一格，主图原位空出。
        const boxes = layoutBatchExpandedChildren(
            { x: root.position.x, y: root.position.y, width: root.width, height: root.height },
            children.map((member) => ({ width: member.width, height: member.height })),
        );
        const stripBatchMeta = (node: CanvasNodeData, position?: { x: number; y: number }): CanvasNodeData => ({
            ...node,
            ...(position ? { position } : {}),
            metadata: {
                ...node.metadata,
                isBatchRoot: undefined,
                batchChildIds: undefined,
                batchRootId: undefined,
                primaryImageId: undefined,
                imageBatchExpanded: undefined,
            },
        });
        const next = nodesRef.current.map((node) => {
            if (node.id === rootId) return stripBatchMeta(node);
            const memberIndex = childIds.indexOf(node.id);
            return memberIndex >= 0 ? stripBatchMeta(node, boxes[memberIndex]) : node;
        });
        // 只拆批次内部（根→子图）连线；外部指向主图的连线保留
        const nextConnections = connectionsRef.current.filter((connection) => !(connection.fromNodeId === rootId && childIds.includes(connection.toNodeId)));
        setNodes(next);
        connectionsRef.current = nextConnections;
        setConnections(nextConnections);
        setSelectedNodeIds(new Set([rootId, ...children.map((child) => child.id)]));
        setSelectedConnectionId(null);
    }, []);

    const setBatchPrimary = useCallback((child: CanvasNodeData) => {
        const rootId = child.metadata?.batchRootId;
        if (!rootId || !child.metadata?.content) return;
        // 077：主图与子图【对调】而不是覆盖——旧主图内容退到被点子图的位置，
        // 否则原主图会被新图顶掉丢失（boss 实测 4 张变 3 张）。
        setNodes((prev) => {
            const root = prev.find((node) => node.id === rootId);
            if (!root) return prev;
            const rootMedia = {
                content: root.metadata?.content,
                storageKey: root.metadata?.storageKey,
                bytes: root.metadata?.bytes,
                mimeType: root.metadata?.mimeType,
                naturalWidth: root.metadata?.naturalWidth,
                naturalHeight: root.metadata?.naturalHeight,
                freeResize: root.metadata?.freeResize,
                panoramaProjection: root.metadata?.panoramaProjection,
            };
            const childMedia = {
                content: child.metadata?.content,
                storageKey: child.metadata?.storageKey,
                bytes: child.metadata?.bytes,
                mimeType: child.metadata?.mimeType,
                naturalWidth: child.metadata?.naturalWidth,
                naturalHeight: child.metadata?.naturalHeight,
                freeResize: child.metadata?.freeResize,
                panoramaProjection: child.metadata?.panoramaProjection,
            };
            return prev.map((node) => {
                if (node.id === rootId) {
                    return {
                        ...node,
                        width: child.width,
                        height: child.height,
                        metadata: {
                            ...node.metadata,
                            ...childMedia,
                            primaryImageId: child.id,
                        },
                    };
                }
                if (node.id === child.id) {
                    return {
                        ...node,
                        width: root.width,
                        height: root.height,
                        metadata: {
                            ...node.metadata,
                            ...rootMedia,
                        },
                    };
                }
                return node;
            });
        });
    }, []);

    const handleNodePromptChange = useCallback((nodeId: string, prompt: string) => {
        setNodes((prev) => prev.map((node) => (node.id === nodeId ? { ...node, metadata: node.type === CanvasNodeType.Panorama ? { ...node.metadata, prompt, panoramaSourcePrompt: prompt } : { ...node.metadata, prompt } } : node)));
    }, []);

    const handleConfigNodeChange = useCallback((nodeId: string, patch: Partial<CanvasNodeData["metadata"]>) => {
        setNodes((prev) => prev.map((node) => (node.id === nodeId ? applyNodeConfigPatch(node, patch) : node)));
    }, []);

    // rvgR9q（2026-10-07 定案重做）：图片涂鸦——笔迹跟着图走。
    // 编辑期间笔迹只存会话状态（annotateStrokes），绝不写原节点 metadata；
    // 「完成」→ 原图+笔迹合成新图，右侧生成全新独立节点（原图一丝不动）；
    // 「取消」/Esc → 直接丢弃。旧版写 metadata 的路径已废弃，打开时清掉遗留数据。
    const [annotateNodeId, setAnnotateNodeId] = useState<string | null>(null);
    const [annotateStrokes, setAnnotateStrokes] = useState<DoodleStroke[]>([]);
    const openDoodleEditor = useCallback((node: CanvasNodeData) => {
        setAnnotateNodeId(node.id);
        setAnnotateStrokes([]);
        if (node.metadata?.doodleStrokes?.length) handleConfigNodeChange(node.id, { doodleStrokes: undefined });
    }, [handleConfigNodeChange]);
    const closeDoodleEditor = useCallback(() => {
        setAnnotateNodeId(null);
        setAnnotateStrokes([]);
    }, []);
    const finishDoodleEditor = useCallback(() => {
        const sourceNode = annotateNodeId ? nodesRef.current.find((item) => item.id === annotateNodeId) : null;
        const strokes = annotateStrokes;
        setAnnotateNodeId(null);
        setAnnotateStrokes([]);
        if (!sourceNode?.metadata?.content || !strokes.length) return;
        void (async () => {
            try {
                const image = new Image();
                await new Promise<void>((resolve, reject) => {
                    image.onload = () => resolve();
                    image.onerror = () => reject(new Error("图片加载失败"));
                    image.src = String(sourceNode.metadata.content);
                });
                const imgW = image.naturalWidth || sourceNode.width;
                const imgH = image.naturalHeight || sourceNode.height;
                const canvas = document.createElement("canvas");
                canvas.width = imgW;
                canvas.height = imgH;
                const ctx = canvas.getContext("2d");
                if (!ctx) throw new Error("无法创建画布");
                ctx.drawImage(image, 0, 0, imgW, imgH);
                // 笔迹 0..1 归一化坐标（相对节点盒）→ 原图像素：按 object-contain 显示区映射
                const containScale = Math.min(sourceNode.width / imgW, sourceNode.height / imgH);
                const dispW = imgW * containScale;
                const dispH = imgH * containScale;
                const offX = (sourceNode.width - dispW) / 2;
                const offY = (sourceNode.height - dispH) / 2;
                const widthScale = imgW / Math.max(1, sourceNode.width);
                ctx.lineCap = "round";
                ctx.lineJoin = "round";
                for (const stroke of strokes) {
                    const pts = stroke.points;
                    if (!pts || pts.length < 4) continue;
                    ctx.strokeStyle = stroke.color;
                    ctx.lineWidth = Math.max(1, stroke.size * widthScale);
                    ctx.beginPath();
                    let started = false;
                    for (let i = 0; i + 1 < pts.length; i += 2) {
                        const boxX = pts[i] * sourceNode.width;
                        const boxY = pts[i + 1] * sourceNode.height;
                        const ix = (boxX - offX) / containScale;
                        const iy = (boxY - offY) / containScale;
                        if (!started) {
                            ctx.moveTo(ix, iy);
                            started = true;
                        } else ctx.lineTo(ix, iy);
                    }
                    if (started) ctx.stroke();
                }
                const dataUrl = canvas.toDataURL("image/png");
                const newId = nanoid();
                setNodes((prev) => [
                    ...prev,
                    {
                        id: newId,
                        type: sourceNode.type,
                        title: `${sourceNode.title || "图片"} 涂鸦`,
                        position: { x: sourceNode.position.x + sourceNode.width + 96, y: sourceNode.position.y },
                        width: sourceNode.width,
                        height: sourceNode.height,
                        metadata: {
                            ...sourceNode.metadata,
                            content: dataUrl,
                            imageTaskId: undefined,
                            hostImageTask: undefined,
                            isBatchRoot: undefined,
                            batchChildIds: undefined,
                            batchRootId: undefined,
                            primaryImageId: undefined,
                            imageBatchExpanded: undefined,
                            doodleStrokes: undefined,
                            previewTransform: undefined,
                        },
                    },
                ]);
                setConnections((prev) => [...prev, { id: nanoid(), fromNodeId: sourceNode.id, toNodeId: newId }]);
                setSelectedNodeIds(new Set([newId]));
            } catch (error) {
                console.error("[rvgR9q] 涂鸦合成失败", error);
                message.error(error instanceof Error ? `涂鸦合成失败：${error.message}` : "涂鸦合成失败");
            }
        })();
    }, [annotateNodeId, annotateStrokes, message]);

    const handleDirectorProjectChange = useCallback(
        (project: unknown) => {
            if (!openDirectorNodeId) return;
            setNodes((prev) =>
                prev.map((node) =>
                    node.id === openDirectorNodeId && node.type === CanvasNodeType.Director
                        ? { ...node, metadata: { ...node.metadata, directorProject: project } }
                        : node,
                ),
            );
        },
        [openDirectorNodeId],
    );

    const handleDirectorPanoramaRemoved = useCallback(
        ({ edgeId, sourceNodeId }: Pick<CanvasDirectorPanorama, "edgeId" | "sourceNodeId">) => {
            if (!openDirectorNodeId) return;
            const connection = connectionsRef.current.find(
                (item) => item.id === edgeId && item.fromNodeId === sourceNodeId && item.toNodeId === openDirectorNodeId,
            );
            if (!connection) return;
            setConnections((prev) => prev.filter((item) => item.id !== connection.id));
        },
        [openDirectorNodeId],
    );

    const handleDirectorCapturesSent = useCallback(
        async (directorNodeId: string, captures: CanvasDirectorCapture[]) => {
            const director = nodesRef.current.find((node) => node.id === directorNodeId && node.type === CanvasNodeType.Director);
            if (!director || captures.length === 0) return;

            const hideLoading = message.loading(captures.length > 1 ? "正在发送 " + captures.length + " 张截图到画布..." : "正在发送截图到画布...", 0);
            try {
                const images = await Promise.all(
                    captures.map(async (capture) => {
                        const image = await uploadImage(capture.dataUrl, { localOnly: true });
                        return {
                            id: nanoid(),
                            title: capture.fileName,
                            size: normalizeNodeSize(image.width, image.height),
                            metadata: imageMetadata(image),
                        };
                    }),
                );
                let y = getNextDirectorOutputY(director, nodesRef.current, connectionsRef.current);
                const imageNodes = images.map((image) => {
                    const node = {
                        id: image.id,
                        type: CanvasNodeType.Image,
                        title: image.title,
                        position: { x: director.position.x + director.width + 96, y },
                        width: image.size.width,
                        height: image.size.height,
                        metadata: image.metadata,
                    } satisfies CanvasNodeData;
                    y += node.height + 36;
                    return node;
                });
                setNodes((prev) => [...prev, ...imageNodes]);
                setConnections((prev) => [...prev, ...imageNodes.map((node) => ({ id: nanoid(), fromNodeId: director.id, toNodeId: node.id }))]);
                setSelectedNodeIds(new Set(imageNodes.map((node) => node.id)));
                setSelectedConnectionId(null);
                message.success(captures.length > 1 ? "已发送 " + captures.length + " 张截图到画布" : "截图已发送到画布");
            } catch (error) {
                console.error("Send director captures to canvas failed:", error);
                message.error("截图发送到画布失败");
            } finally {
                hideLoading();
            }
        },
        [message],
    );

    const handleDirectorVideoSent = useCallback(
        async (directorNodeId: string, output: CanvasDirectorVideo) => {
            const director = nodesRef.current.find((node) => node.id === directorNodeId && node.type === CanvasNodeType.Director);
            if (!director) return;

            const hideLoading = message.loading("正在发送视频到画布...", 0);
            try {
                const uploaded = await uploadMediaFile(output.blob, "video");
                const video = {
                    ...uploaded,
                    width: uploaded.width || output.width,
                    height: uploaded.height || output.height,
                    durationMs: uploaded.durationMs || Math.round(output.durationSeconds * 1000),
                };
                const y = getNextDirectorOutputY(director, nodesRef.current, connectionsRef.current);
                const size = normalizeNodeSize(video.width, video.height);
                const node = buildImportedVideoNode(video, output.fileName, {
                    x: director.position.x + director.width + 96 + size.width / 2,
                    y: y + size.height / 2,
                });
                setNodes((prev) => [...prev, node]);
                setConnections((prev) => [...prev, { id: nanoid(), fromNodeId: director.id, toNodeId: node.id }]);
                setSelectedNodeIds(new Set([node.id]));
                setSelectedConnectionId(null);
                setDialogNodeId(node.id);
                message.success("视频已发送到画布");
            } catch (error) {
                console.error("Send director video to canvas failed:", error);
                message.error("视频发送到画布失败");
            } finally {
                hideLoading();
            }
        },
        [message],
    );

    const downloadNodeImage = useCallback((node: CanvasNodeData) => {
        if ((!isCanvasImageNodeType(node.type) && node.type !== CanvasNodeType.Video && node.type !== CanvasNodeType.Audio) || !node.metadata?.content) return;
        const name = `canvas-${node.type}-${node.id}.${node.type === CanvasNodeType.Video ? "mp4" : node.type === CanvasNodeType.Audio ? audioExtension(node.metadata.mimeType) : imageExtension(node.metadata.content)}`;
        const url = String(node.metadata.content);
        // 064：data:/blob: 直接存；协议地址（intl-canvas://）浏览器 <a download> 无效——
        // 先从画布本地存储取文件本体（040 结论），不行再 fetch 协议（宿主落盘的文件可取到）
        if (/^(data|blob):/i.test(url)) {
            try { saveAs(url, name); } catch { /* 静默 */ }
            return;
        }
        void (async () => {
            try {
                let blob: Blob | null = null;
                const storageKey = node.metadata?.storageKey;
                if (isCanvasImageNodeType(node.type) && storageKey) blob = await getImageBlob(storageKey);
                else if ((node.type === CanvasNodeType.Video || node.type === CanvasNodeType.Audio) && storageKey) blob = await getMediaBlob(storageKey);
                if (!blob || !blob.size) {
                    const response = await fetch(url);
                    if (response.ok) blob = await response.blob();
                }
                if (blob && blob.size) saveAs(blob, name);
                else saveAs(url, name);
            } catch {
                try { saveAs(url, name); } catch { /* 静默 */ }
            }
        })();
    }, []);

    // 024：批量下载统一入口（≤5 个逐个下载，>5 个打包 zip）
    const downloadNodesBatch = useCallback((nodes: CanvasNodeData[]) => {
        const items: BatchDownloadItem[] = nodes
            .filter((node) => Boolean(node.metadata?.content))
            .map((node) => ({
                id: node.id,
                label: `canvas-${node.type}-${node.id}.${node.type === CanvasNodeType.Video ? "mp4" : node.type === CanvasNodeType.Audio ? audioExtension(node.metadata.mimeType) : imageExtension(node.metadata.content)}`,
                url: node.metadata.content as string,
            }));
        void downloadBatchItems(items, "canvas");
    }, []);

    const disconnectNodeReference = useCallback((fromNodeId: string, toNodeId: string) => {
        setConnections((prev) => prev.filter((connection) => connection.fromNodeId !== fromNodeId || connection.toNodeId !== toNodeId));
    }, []);

    // 重排某节点的参考顺序：参考顺序 = 指向该节点的连线在数组中的顺序，直接重排连线
    const reorderNodeReferences = useCallback((nodeId: string, orderedFromNodeIds: string[]) => {
        setConnections((prev) => {
            const mine = prev.filter((connection) => connection.toNodeId === nodeId);
            const others = prev.filter((connection) => connection.toNodeId !== nodeId);
            const byFromNodeId = new Map(mine.map((connection) => [connection.fromNodeId, connection]));
            const reordered = orderedFromNodeIds.map((id) => byFromNodeId.get(id)).filter((connection): connection is CanvasConnection => Boolean(connection));
            const rest = mine.filter((connection) => !orderedFromNodeIds.includes(connection.fromNodeId));
            return [...others, ...reordered, ...rest];
        });
    }, []);

    const startNodeReferenceSelection = useCallback((nodeId: string) => {
        setReferencePickerNodeId(nodeId);
        setSelectedNodeIds(new Set([nodeId]));
        setSelectedConnectionId(null);
        setContextMenu(null);
        setToolbarNodeId(null);
        setDialogNodeId(null);
    }, []);

    const exitNodeReferenceSelection = useCallback(() => {
        if (!referencePickerNodeId) return;
        setSelectedNodeIds(new Set([referencePickerNodeId]));
        setDialogNodeId(referencePickerNodeId);
        setReferencePickerNodeId(null);
    }, [referencePickerNodeId]);

    const selectNodeReference = useCallback((fromNodeId: string) => {
        if (!referencePickerNodeId || referenceConnectedNodeIds.has(fromNodeId)) return;
        const source = nodesRef.current.find((node) => node.id === fromNodeId);
        if (!source || !isCanvasReferenceNode(source)) return;
        setConnections((prev) => [...prev, { id: nanoid(), fromNodeId, toNodeId: referencePickerNodeId }]);
    }, [referenceConnectedNodeIds, referencePickerNodeId]);

    useEffect(() => {
        if (!referencePickerNodeId) return;
        const exit = (event: KeyboardEvent) => {
            if (event.key !== "Escape") return;
            event.preventDefault();
            event.stopImmediatePropagation();
            exitNodeReferenceSelection();
        };
        window.addEventListener("keydown", exit, true);
        return () => window.removeEventListener("keydown", exit, true);
    }, [exitNodeReferenceSelection, referencePickerNodeId]);

    const captureVideoNodeFrame = useCallback(
        async (nodeId: string, position: VideoFramePosition) => {
            setContextMenu(null);
            const node = nodesRef.current.find((item) => item.id === nodeId);
            const video = containerRef.current?.querySelector<HTMLVideoElement>(`[data-node-id="${CSS.escape(nodeId)}"] video`);
            if (node?.type !== CanvasNodeType.Video || !node.metadata?.content || !video) return message.error("无法截取该画面，请重试");
            try {
                const image = await uploadImage(await captureVideoFrame(node.metadata.content, position, video.currentTime));
                const size = normalizeNodeSize(image.width, image.height);
                const id = nanoid();
                const x = node.position.x + node.width + 96;
                let y = node.position.y + node.height / 2 - size.height / 2;
                while (nodesRef.current.some((item) => item.id !== node.id && item.position.x < x + size.width && item.position.x + item.width > x && item.position.y < y + size.height && item.position.y + item.height > y)) y += size.height + 24;
                const frameName = position === "first" ? "首帧" : position === "last" ? "尾帧" : "当前帧";
                const child: CanvasNodeData = {
                    id,
                    type: CanvasNodeType.Image,
                    title: `${node.title || "视频"} ${frameName}`,
                    position: { x, y },
                    ...size,
                    metadata: imageMetadata(image),
                };
                setNodes((prev) => [...prev, child]);
                setConnections((prev) => [...prev, { id: nanoid(), fromNodeId: node.id, toNodeId: id }]);
                setSelectedNodeIds(new Set([id]));
                setSelectedConnectionId(null);
                setDialogNodeId(id);
                message.success("已生成图片节点");
            } catch {
                message.error("无法截取该画面，请重试");
            }
        },
        [message],
    );

    const uploadNodeMediaToCloud = useCallback(async (node: CanvasNodeData) => {
        if ((node.type !== CanvasNodeType.Video && node.type !== CanvasNodeType.Audio) || !node.metadata?.content || node.metadata.storageKey?.startsWith("server:") || uploadingMediaNodeIdsRef.current.has(node.id)) return;
        uploadingMediaNodeIdsRef.current.add(node.id);
        const isAudio = node.type === CanvasNodeType.Audio;
        const mediaName = isAudio ? "音频" : "视频";
        const hideLoading = message.loading(`正在上传${mediaName}至云存储...`, 0);
        try {
            const mediaUrl = await resolveMediaUrl(node.metadata.storageKey, node.metadata.content);
            const filename = `canvas-${node.type}-${node.id}.${isAudio ? audioExtension(node.metadata.mimeType) : "mp4"}`;
            const uploaded = await uploadRemoteMediaToServer(mediaUrl, filename);
            setNodes((nodes) => nodes.map((item) => (item.id === node.id ? {
                ...item,
                metadata: {
                    ...item.metadata,
                    content: uploaded.url,
                    storageKey: uploaded.storageKey,
                    bytes: uploaded.bytes,
                    mimeType: uploaded.mimeType,
                    naturalWidth: uploaded.width || item.metadata?.naturalWidth,
                    naturalHeight: uploaded.height || item.metadata?.naturalHeight,
                },
            } : item)));
            message.success(`${mediaName}已上传至云存储`);
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : "";
            if (errorMessage.includes("服务端对象存储未启用") || errorMessage.includes("用户对象存储配置不完整")) {
                message.error("未添加云存储");
            } else {
                message.error(errorMessage || `${mediaName}上传失败`);
            }
        } finally {
            hideLoading();
            uploadingMediaNodeIdsRef.current.delete(node.id);
        }
    }, [message]);

    const uploadNodeImageToCloud = useCallback(async (node: CanvasNodeData) => {
        if (!isCanvasImageNodeType(node.type) || !node.metadata?.content || node.metadata.storageKey?.startsWith("server:") || uploadingImageNodeIdsRef.current.has(node.id)) return;
        uploadingImageNodeIdsRef.current.add(node.id);
        const hideLoading = message.loading("正在上传图片至云存储...", 0);
        try {
            const imageUrl = await resolveImageUrl(node.metadata.storageKey, node.metadata.content);
            const uploaded = await uploadRemoteImageToServer(imageUrl, "canvas-image-" + node.id + ".png");
            setNodes((nodes) => nodes.map((item) => (item.id === node.id ? {
                ...item,
                metadata: {
                    ...item.metadata,
                    content: uploaded.url,
                    storageKey: uploaded.storageKey,
                    bytes: uploaded.bytes,
                    mimeType: uploaded.mimeType,
                    naturalWidth: uploaded.width || item.metadata?.naturalWidth,
                    naturalHeight: uploaded.height || item.metadata?.naturalHeight,
                },
            } : item)));
            setChatSessions((sessions) => syncAssistantReferences(sessions, [{
                ...node,
                metadata: {
                    ...node.metadata,
                    content: uploaded.url,
                    storageKey: uploaded.storageKey,
                    mimeType: uploaded.mimeType,
                },
            }]));
            message.success("图片已上传至云存储");
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : "";
            if (errorMessage.includes("服务端对象存储未启用") || errorMessage.includes("用户对象存储配置不完整")) {
                message.error("未添加云存储");
            } else {
                message.error(errorMessage || "图片上传失败");
            }
        } finally {
            hideLoading();
            uploadingImageNodeIdsRef.current.delete(node.id);
        }
    }, [message]);

    const saveNodeAsset = useCallback(
        async (node: CanvasNodeData, category = "other", titleOverride?: string) => {
            // 029：category 由保存对话框选择（人物/场景/服装/道具/其他），随资产入库并转发宿主
            if (node.type === CanvasNodeType.Text) {
                const content = node.metadata?.content?.trim();
                if (!content) return message.error("没有可保存的文本");
                const textResult = await addAssetAsync({ kind: "text", title: titleOverride || node.metadata?.prompt?.slice(0, 24) || "画布文本", coverUrl: "", tags: [], category, source: "Canvas", data: { content }, metadata: { source: "canvas", nodeId: node.id, category } });
                if (textResult.ok) message.success("已加入我的素材");
                else message.error(textResult.message || "保存失败");
                return;
            }
            if (node.type === CanvasNodeType.Video) {
                if (!node.metadata?.content) return message.error("没有可保存的视频");
                const videoResult = await addAssetAsync({ kind: "video", title: titleOverride || node.metadata?.prompt?.slice(0, 24) || "画布视频", coverUrl: "", tags: [], category, source: "Canvas", data: { url: node.metadata.content, storageKey: node.metadata.storageKey, width: node.width, height: node.height, bytes: node.metadata.bytes || 0, mimeType: node.metadata.mimeType || "video/mp4" }, metadata: { source: "canvas", nodeId: node.id, prompt: node.metadata?.prompt, category } });
                if (videoResult.ok) message.success("已加入我的素材");
                else message.error(videoResult.message || "视频加入素材失败");
                return;
            }
            if (!node.metadata?.content) return message.error("没有可保存的图片");
            try {
                const stored = !node.metadata.storageKey && node.metadata.content.startsWith("blob:") ? await uploadImage(node.metadata.content, { localOnly: true }) : null;
                const imageUrl = stored?.url || node.metadata.content;
                const storageKey = stored?.storageKey || node.metadata.storageKey;
                const dataUrl = storageKey ? "" : imageUrl;
                const imageResult = await addAssetAsync({
                    kind: "image",
                    title: titleOverride || node.metadata?.prompt?.slice(0, 24) || "画布图片",
                    coverUrl: imageUrl,
                    tags: [],
                    category,
                    source: "Canvas",
                    data: {
                        dataUrl,
                        storageKey,
                        width: stored?.width || node.metadata.naturalWidth || node.width,
                        height: stored?.height || node.metadata.naturalHeight || node.height,
                        bytes: stored?.bytes || node.metadata.bytes || getDataUrlByteSize(dataUrl),
                        mimeType: stored?.mimeType || node.metadata.mimeType || "image/png",
                    },
                    metadata: { source: "canvas", nodeId: node.id, prompt: node.metadata?.prompt, category },
                });
                if (imageResult.ok) message.success("已加入我的素材");
                else message.error(imageResult.message || "图片加入素材失败");
            } catch (error) {
                message.error(error instanceof Error ? `图片加入素材失败：${error.message}` : "图片加入素材失败");
            }
        },
        [addAssetAsync, message, uploadImage],
    );

    // 029：保存到资产前的分类选择（框选批量 / 单节点共用）
    const [assetSavePending, setAssetSavePending] = useState<CanvasNodeData[] | null>(null);
    const assetSaveDefaultName = useMemo(() => {
        if (!assetSavePending?.length) return "";
        if (assetSavePending.length > 1) return "";
        const prompt = assetSavePending[0]?.metadata?.prompt?.trim();
        return prompt?.slice(0, 24) || "";
    }, [assetSavePending]);

    const createImageReversePromptNodes = useCallback(
        (node: CanvasNodeData) => {
            if (!isCanvasImageNodeType(node.type) || !node.metadata?.content) {
                message.warning("图片节点为空，无法反推提示词");
                return;
            }

            const gap = 96;
            const textSpec = NODE_DEFAULT_SIZE[CanvasNodeType.Text];
            const configSpec = NODE_DEFAULT_SIZE[CanvasNodeType.Config];
            const centerY = node.position.y + node.height / 2;
            const textNode = {
                ...createCanvasNode(
                    CanvasNodeType.Text,
                    { x: node.position.x + node.width + gap + textSpec.width / 2, y: centerY },
                    { content: IMAGE_PROMPT_REVERSE_PRESET, prompt: IMAGE_PROMPT_REVERSE_PRESET, status: NODE_STATUS_SUCCESS, fontSize: 14 },
                ),
                title: "反推提示词",
            };
            const configNode = {
                ...createCanvasNode(
                    CanvasNodeType.Config,
                    { x: textNode.position.x + textNode.width + gap + configSpec.width / 2, y: centerY },
                    {
                        generationMode: "text",
                        model: effectiveConfig.textModel || effectiveConfig.model || defaultConfig.textModel,
                        count: 1,
                        composerContent: `参考图片：@[node:${node.id}]\n任务说明：@[node:${textNode.id}]`,
                    },
                ),
                title: "反推提示词配置",
            };

            setNodes((prev) => [...prev, textNode, configNode]);
            setConnections((prev) => [
                ...prev,
                { id: nanoid(), fromNodeId: node.id, toNodeId: configNode.id },
                { id: nanoid(), fromNodeId: textNode.id, toNodeId: configNode.id },
            ]);
            setSelectedNodeIds(new Set([configNode.id]));
            setSelectedConnectionId(null);
            setDialogNodeId(configNode.id);
            setContextMenu(null);
        },
        [effectiveConfig.model, effectiveConfig.textModel, message],
    );

    const cropImageNode = useCallback(async (node: CanvasNodeData, crop: CanvasImageCropRect) => {
        if (!node.metadata?.content) return;
        const cropped = await cropDataUrl(node.metadata.content, crop);
        const image = await uploadImage(cropped);
        const width = Math.min(node.width, Math.max(220, image.width));
        const childId = nanoid();
        const child: CanvasNodeData = {
            id: childId,
            type: CanvasNodeType.Image,
            title: "Cropped Image",
            position: { x: node.position.x + node.width + 96, y: node.position.y },
            width,
            height: width * (image.height / image.width),
            metadata: {
                ...imageMetadata(image),
                prompt: node.metadata?.prompt,
            },
        };
        setNodes((prev) => [...prev, child]);
        setConnections((prev) => [...prev, { id: nanoid(), fromNodeId: node.id, toNodeId: childId }]);
        setSelectedNodeIds(new Set([childId]));
        setDialogNodeId(childId);
        setCropNodeId(null);
    }, []);

    const splitImageNode = useCallback(
        async (node: CanvasNodeData, params: CanvasImageSplitParams) => {
            if (!node.metadata?.content) return;
            setSplitNodeId(null);
            const hideSplitLoading = message.loading("正在处理切图...", 0);
            let uploadedImages: UploadedImage[] = [];

            try {
                const pieces = await splitDataUrl(node.metadata.content, params);
                const rows = params.horizontalLines.length + 1;
                const columns = params.verticalLines.length + 1;
                const gap = 16;
                const cellWidth = node.width / columns;
                const cellHeight = node.height / rows;
                const startX = node.position.x + node.width + 96;
                const startY = node.position.y;
                const uploadResults = await Promise.allSettled(
                    pieces.map(async (piece) => ({
                        piece,
                        image: await uploadImage(piece.dataUrl),
                    })),
                );
                const uploadedPieces = uploadResults.flatMap((result) => result.status === "fulfilled" ? [result.value] : []);
                uploadedImages = uploadedPieces.map(({ image }) => image);
                const failedUpload = uploadResults.find((result) => result.status === "rejected");

                if (failedUpload?.status === "rejected") throw failedUpload.reason;

                const childNodes = uploadedPieces.map(({ piece, image }) => {
                    const id = nanoid();
                    return {
                        id,
                        type: CanvasNodeType.Image,
                        title: `${node.title || "图片"} ${piece.row + 1}-${piece.column + 1}`,
                        position: { x: startX + piece.column * (cellWidth + gap), y: startY + piece.row * (cellHeight + gap) },
                        width: cellWidth,
                        height: cellHeight,
                        metadata: {
                            ...imageMetadata(image),
                            prompt: node.metadata?.prompt,
                        },
                    } satisfies CanvasNodeData;
                });

                setNodes((prev) => [...prev, ...childNodes]);
                setConnections((prev) => [...prev, ...childNodes.map((child) => ({ id: nanoid(), fromNodeId: node.id, toNodeId: child.id }))]);
                setSelectedNodeIds(new Set(childNodes.map((child) => child.id)));
                setSelectedConnectionId(null);
                setDialogNodeId(null);
                uploadedImages = [];
                message.success(`已切分为 ${childNodes.length} 个子节点`);
            } catch (error) {
                let cleanupFailed = false;

                if (uploadedImages.length) {
                    try {
                        await deleteStoredImages(uploadedImages.map((image) => image.storageKey));
                    } catch {
                        cleanupFailed = true;
                    }
                }

                const errorMessage = error instanceof Error ? error.message : "切图失败";
                message.error(cleanupFailed ? `${errorMessage}；部分临时图片清理失败` : errorMessage);
            } finally {
                hideSplitLoading();
            }
        },
        [message],
    );

    const maskEditImageNode = useCallback(
        async (node: CanvasNodeData, payload: CanvasImageMaskEditPayload) => {
            if (!node.metadata?.content) return;
            const baseGenerationConfig = buildGenerationConfig(effectiveConfig, node, "image");
            const generationConfig = { ...baseGenerationConfig, model: payload.model || baseGenerationConfig.model, activeChannelId: payload.channelId || baseGenerationConfig.imageChannelId || baseGenerationConfig.activeChannelId, imageChannelId: payload.channelId || baseGenerationConfig.imageChannelId, count: "1", size: node.metadata?.size || "auto" };
            if (!isAiConfigReady(generationConfig, generationConfig.model)) {
                openConfigDialog(true);
                return;
            }
            const userPrompt = payload.prompt.trim();
            const prompt = `参考图中蓝色高亮覆盖区域是需要修改的位置，蓝色只是编辑标记，不要保留在最终图像中。只修改蓝色高亮区域，其他区域的构图、人物、文字、光影和风格保持不变。修改要求：${userPrompt}`;
            const childId = nanoid();
            const clientTaskId = `client_image_task_${childId}`;
            const markedReference = { id: `${node.id}-marked`, name: `image-${node.id}-marked.png`, type: "image/png", dataUrl: payload.markedDataUrl };
            const generationMetadata = buildImageGenerationMetadata("edit", generationConfig, 1, [markedReference]);
            const childNode: CanvasNodeData = {
                id: childId,
                type: CanvasNodeType.Image,
                title: userPrompt.slice(0, 32) || "局部编辑结果",
                position: { x: node.position.x + node.width + 96, y: node.position.y },
                width: node.width,
                height: node.height,
                metadata: { prompt, status: NODE_STATUS_LOADING, startedAt: Date.now(), progress: 0, imageTaskId: clientTaskId, ...generationMetadata },
            };
            setMaskEditNodeId(null);
            setRunningNodeId(childId);
            setNodes((prev) => [...prev, childNode]);
            setConnections((prev) => [...prev, { id: nanoid(), fromNodeId: node.id, toNodeId: childId }]);
            setSelectedNodeIds(new Set([childId]));
            setSelectedConnectionId(null);
            setDialogNodeId(childId);
            try {
                const task = await createCanvasImageTask(generationConfig, prompt, [markedReference], { nodeId: childId, sourceId: projectId, clientTaskId });
                setNodes((prev) => applyCanvasImageTaskUpdate(prev, childId, task, childNode.metadata?.startedAt || Date.now(), { width: node.width, height: node.height }));
                setConnections((prev) => applyCanvasImageTaskConnections(prev, childId, task));
            } catch (error) {
                const errorDetails = error instanceof Error ? error.message : "局部修改失败";
                message.error(errorDetails);
                setNodes((prev) => prev.map((item) => (item.id === childId ? { ...item, metadata: { ...item.metadata, status: NODE_STATUS_ERROR, errorDetails } } : item)));
            } finally {
                setRunningNodeId(null);
            }
        },
        [effectiveConfig, isAiConfigReady, message, openConfigDialog, projectId],
    );

    const upscaleImageNode = useCallback(async (node: CanvasNodeData, params: CanvasImageUpscaleParams) => {
        if (!node.metadata?.content) return;
        setUpscaleNodeId(null);
        const hideLoading = message.loading("正在放大图片...", 0);
        try {
            const upscaled = await upscaleDataUrl(node.metadata.content, params);
            const image = await uploadImage(upscaled);
            const size = normalizeNodeSize(image.width, image.height);
            const childId = nanoid();
            const child: CanvasNodeData = {
                id: childId,
                type: CanvasNodeType.Image,
                title: "Upscaled Image",
                position: { x: node.position.x + node.width + 96, y: node.position.y },
                width: size.width,
                height: size.height,
                metadata: {
                    ...imageMetadata(image),
                    prompt: node.metadata?.prompt,
                },
            };
            setNodes((prev) => [...prev, child]);
            setConnections((prev) => [...prev, { id: nanoid(), fromNodeId: node.id, toNodeId: childId }]);
            setSelectedNodeIds(new Set([childId]));
            setDialogNodeId(childId);
        } catch (error) {
            message.error(error instanceof Error ? error.message : "图片放大失败");
        } finally {
            hideLoading();
        }
    }, [message]);

    const generateAngleNode = useCallback(
        async (node: CanvasNodeData, params: CanvasImageAngleParams) => {
            if (!node.metadata?.content) return;
            const generationConfig = { ...buildGenerationConfig(effectiveConfig, node, "image"), count: "1" };
            if (!isAiConfigReady(generationConfig, generationConfig.model)) {
                openConfigDialog(true);
                return;
            }
            const childId = nanoid();
            const imageConfig = NODE_DEFAULT_SIZE[CanvasNodeType.Image];
            const title = buildAngleLabel(params);
            const prompt = buildAnglePrompt(params);
            const referenceImages = [{ id: node.id, name: `image-${node.id}.png`, type: node.metadata.mimeType || "image/png", dataUrl: node.metadata.content, storageKey: node.metadata.storageKey }];
            const generationMetadata = buildImageGenerationMetadata("edit", generationConfig, 1, referenceImages);
            const clientTaskId = `client_image_task_${childId}`;
            const startedAt = Date.now();
            setAngleNodeId(null);
            setRunningNodeId(childId);
            setNodes((prev) => [
                ...prev,
                {
                    id: childId,
                    type: CanvasNodeType.Image,
                    title,
                    position: { x: node.position.x + node.width + 96, y: node.position.y },
                    width: imageConfig.width,
                    height: imageConfig.height,
                    metadata: { prompt, status: NODE_STATUS_LOADING, imageTaskId: clientTaskId, startedAt, progress: 0, ...generationMetadata },
                },
            ]);
            setConnections((prev) => [...prev, { id: nanoid(), fromNodeId: node.id, toNodeId: childId }]);
            setSelectedNodeIds(new Set([childId]));
            setDialogNodeId(childId);
            try {
                const task = await createCanvasImageTask(generationConfig, prompt, referenceImages, { nodeId: childId, sourceId: projectId, clientTaskId });
                setNodes((prev) => applyCanvasImageTaskUpdate(prev, childId, task, startedAt, { width: imageConfig.width, height: imageConfig.height }));
                setConnections((prev) => applyCanvasImageTaskConnections(prev, childId, task));
            } catch (error) {
                const errorDetails = error instanceof Error ? error.message : "生成失败";
                setNodes((prev) => prev.map((item) => (item.id === childId ? { ...item, metadata: { ...item.metadata, status: NODE_STATUS_ERROR, errorDetails } } : item)));
            } finally {
                setRunningNodeId(null);
            }
        },
        [effectiveConfig, message, openConfigDialog, projectId],
    );

    // 任务rDjmof：「旋转与镜像」——点击工具条旋转图标：拎出独立新节点（原节点保留）并进入变换模式
    const startNodeTransform = useCallback((node: CanvasNodeData) => {
        if (!node.metadata?.content) return;
        const newId = nanoid();
        setNodes((prev) => [
            ...prev,
            {
                id: newId,
                type: node.type,
                title: `${node.title || "图片"} 旋转`,
                position: { x: node.position.x + node.width + 96, y: node.position.y },
                width: node.width,
                height: node.height,
                metadata: {
                    ...node.metadata,
                    content: node.metadata.content,
                    imageTaskId: undefined,
                    hostImageTask: undefined,
                    isBatchRoot: undefined,
                    batchChildIds: undefined,
                    batchRootId: undefined,
                    primaryImageId: undefined,
                    imageBatchExpanded: undefined,
                    doodleStrokes: undefined,
                    previewTransform: undefined,
                },
            },
        ]);
        setConnections((prev) => [...prev, { id: nanoid(), fromNodeId: node.id, toNodeId: newId }]);
        setSelectedNodeIds(new Set([newId]));
        // boss 2026-10-07：点旋转即进入编辑页面——关掉原节点提示词浮栏，编辑期间不再弹出
        setDialogNodeId(null);
        setTransformNodeId(newId);
        setTransformState({ angle: 0, flipH: false, flipV: false });
    }, []);

    // 任务rDjmof：变换参数变化 → 实时预览（CSS transform 挂在节点外层）
    const handleTransformStateChange = useCallback((next: NodeTransformState) => {
        setTransformState(next);
        const nodeId = transformNodeId;
        if (!nodeId) return;
        const css = transformToCss(next);
        setNodes((prev) => prev.map((item) => (item.id === nodeId ? { ...item, metadata: { ...item.metadata, previewTransform: css || undefined } } : item)));
    }, [transformNodeId]);

    // 任务rDjmof：保存 → 像素级落定（canvas rotate+scale 绘制外接矩形），清预览标记
    const saveNodeTransform = useCallback(() => {
        const nodeId = transformNodeId;
        const node = nodeId ? nodesRef.current.find((item) => item.id === nodeId) : null;
        if (!node?.metadata?.content) return;
        void (async () => {
            try {
                const content = String(node.metadata?.content || "");
                const image = new Image();
                await new Promise<void>((resolve, reject) => {
                    image.onload = () => resolve();
                    image.onerror = () => reject(new Error("图片加载失败"));
                    image.src = content;
                });
                const rad = (transformState.angle * Math.PI) / 180;
                const sin = Math.abs(Math.sin(rad));
                const cos = Math.abs(Math.cos(rad));
                const naturalWidth = image.naturalWidth || node.width;
                const naturalHeight = image.naturalHeight || node.height;
                const outWidth = Math.round(naturalWidth * cos + naturalHeight * sin);
                const outHeight = Math.round(naturalWidth * sin + naturalHeight * cos);
                const canvas = document.createElement("canvas");
                canvas.width = outWidth;
                canvas.height = outHeight;
                const ctx = canvas.getContext("2d");
                if (!ctx) throw new Error("无法创建画布");
                ctx.translate(outWidth / 2, outHeight / 2);
                ctx.rotate(rad);
                ctx.scale(transformState.flipH ? -1 : 1, transformState.flipV ? -1 : 1);
                ctx.drawImage(image, -naturalWidth / 2, -naturalHeight / 2);
                const dataUrl = canvas.toDataURL("image/png");
                // 节点显示尺寸：90° 倍数互换宽高；任意角度按外接矩形等比适配节点面积
                let nextWidth = node.width;
                let nextHeight = node.height;
                const normalized = ((transformState.angle % 180) + 180) % 180;
                if (normalized === 90) {
                    nextWidth = node.height;
                    nextHeight = node.width;
                } else if (normalized !== 0) {
                    const areaScale = Math.sqrt((node.width * node.height) / Math.max(1, outWidth * outHeight));
                    nextWidth = Math.max(1, Math.round(outWidth * areaScale));
                    nextHeight = Math.max(1, Math.round(outHeight * areaScale));
                }
                setNodes((prev) => prev.map((item) => (item.id === nodeId ? { ...item, width: nextWidth, height: nextHeight, metadata: { ...item.metadata, content: dataUrl, previewTransform: undefined, naturalWidth: outWidth, naturalHeight: outHeight } } : item)));
                setTransformNodeId(null);
            } catch (error) {
                message.error(error instanceof Error ? error.message : "保存失败");
            }
        })();
    }, [message, transformNodeId, transformState]);

    // 任务rDjmof：关闭（X）→ 放弃变换，删除独立节点与连线
    const closeNodeTransform = useCallback(() => {
        const nodeId = transformNodeId;
        setTransformNodeId(null);
        if (!nodeId) return;
        setNodes((prev) => prev.filter((item) => item.id !== nodeId));
        setConnections((prev) => prev.filter((item) => item.toNodeId !== nodeId && item.fromNodeId !== nodeId));
    }, [transformNodeId]);

    const handleFontSizeChange = useCallback((nodeId: string, fontSize: number) => {
        setNodes((prev) => prev.map((node) => (node.id === nodeId ? { ...node, metadata: { ...node.metadata, fontSize } } : node)));
    }, []);

    const handleUploadRequest = useCallback((nodeId?: string, position?: Position) => {
        uploadTargetRef.current = { nodeId, position };
        imageInputRef.current?.click();
    }, []);

    const handleImageInputChange = useCallback(
        async (event: ReactChangeEvent<HTMLInputElement>) => {
            const file = event.target.files?.[0];
            const target = uploadTargetRef.current;
            if (!file || (!file.type.startsWith("image/") && !file.type.startsWith("video/") && !isAudioFile(file))) return;
            const targetNode = target?.nodeId ? nodesRef.current.find((node) => node.id === target.nodeId) : null;
            if (isPanoramaNodeType(targetNode?.type) && !file.type.startsWith("image/")) {
                message.warning("全景图节点仅支持上传图片作为参考");
                uploadTargetRef.current = null;
                event.target.value = "";
                return;
            }

            if (target?.nodeId) {
                const hideLoading = message.loading(isAudioFile(file) ? "正在上传音频..." : file.type.startsWith("video/") ? "正在上传视频..." : "正在上传图片...", 0);
                try {
                    if (isAudioFile(file)) {
                        const audio = await uploadMediaFile(file, "audio");
                        const spec = NODE_DEFAULT_SIZE[CanvasNodeType.Audio];
                        setNodes((prev) => prev.map((node) => (node.id === target.nodeId ? { ...node, type: CanvasNodeType.Audio, title: file.name, position: { x: node.position.x + node.width / 2 - spec.width / 2, y: node.position.y + node.height / 2 - spec.height / 2 }, width: spec.width, height: spec.height, metadata: { ...node.metadata, ...audioMetadata(audio), errorDetails: undefined } } : node)));
                        setSelectedNodeIds(new Set([target.nodeId]));
                        setSelectedConnectionId(null);
                    } else if (file.type.startsWith("video/")) {
                        const video = await uploadMediaFile(file, "video");
                        const nextSize = normalizeNodeSize(video.width || 1280, video.height || 720);
                        setNodes((prev) => prev.map((node) => (node.id === target.nodeId ? { ...node, type: CanvasNodeType.Video, title: file.name, position: { x: node.position.x + node.width / 2 - nextSize.width / 2, y: node.position.y + node.height / 2 - nextSize.height / 2 }, width: nextSize.width, height: nextSize.height, metadata: { ...node.metadata, ...videoMetadata(video), errorDetails: undefined } } : node)));
                        setSelectedNodeIds(new Set([target.nodeId]));
                        setSelectedConnectionId(null);
                        setDialogNodeId(target.nodeId);
                    } else {
                        const image = await uploadImage(file);
                        const size = normalizeNodeSize(image.width, image.height);
                        setNodes((prev) =>
                            prev.map((node) => {
                                if (node.id !== target.nodeId) return node;
                                const isPanorama = isPanoramaNodeType(node.type);
                                const nextSize = isPanorama ? PANORAMA_NODE_SIZE : size;
                                return {
                                    ...node,
                                    type: isPanorama ? CanvasNodeType.Panorama : CanvasNodeType.Image,
                                    title: isPanorama ? node.title : file.name,
                                    position: isPanorama ? { x: node.position.x + node.width / 2 - nextSize.width / 2, y: node.position.y + node.height / 2 - nextSize.height / 2 } : node.position,
                                    width: nextSize.width,
                                    height: nextSize.height,
                                    metadata: {
                                        ...node.metadata,
                                        ...imageMetadata(image),
                                        errorDetails: undefined,
                                        freeResize: false,
                                        isBatchRoot: undefined,
                                        batchRootId: undefined,
                                        batchChildIds: undefined,
                                        batchUsesReferenceImages: undefined,
                                        generationType: undefined,
                                        model: isPanorama ? node.metadata?.model : undefined,
                                        size: isPanorama ? PANORAMA_IMAGE_SIZE : undefined,
                                        quality: isPanorama ? node.metadata?.quality : undefined,
                                        count: isPanorama ? node.metadata?.count : undefined,
                                        references: undefined,
                                        primaryImageId: undefined,
                                        imageBatchExpanded: undefined,
                                        imageTaskId: undefined,
                                        imageTaskResultId: undefined,
                                        panoramaSourcePrompt: isPanorama ? node.metadata?.panoramaSourcePrompt : undefined,
                                        panoramaFinalPrompt: undefined,
                                        panoramaProjection: undefined,
                                    },
                                };
                            }),
                        );
                        setSelectedNodeIds(new Set([target.nodeId]));
                        setSelectedConnectionId(null);
                        setDialogNodeId(target.nodeId);
                    }
                } catch (error) {
                    console.error("Upload node file failed:", error);
                    message.error("上传失败");
                } finally {
                    hideLoading();
                }
            } else {
                const position = target?.position || screenToCanvas((containerRef.current?.getBoundingClientRect().left || 0) + size.width / 2, (containerRef.current?.getBoundingClientRect().top || 0) + size.height / 2);
                // 空画布上传支持多选：批量导入并自动排布
                const files = Array.from(event.target.files || []).filter((item) => item.type.startsWith("image/") || item.type.startsWith("video/") || isAudioFile(item));
                void importFilesAt(files.length ? files : [file], position);
            }

            uploadTargetRef.current = null;
            event.target.value = "";
        },
        [createAudioFileNode, createImageFileNode, createVideoFileNode, importFilesAt, screenToCanvas, size.height, size.width],
    );

    function insertAssetAt(payload: InsertAssetPayload, position?: Position, nodeId?: string) {
        const center = position || screenToCanvas((containerRef.current?.getBoundingClientRect().left || 0) + size.width / 2, (containerRef.current?.getBoundingClientRect().top || 0) + size.height / 2);
        if (payload.kind === "text") {
            createNode(CanvasNodeType.Text, position, payload.content, nodeId);
            return;
        }
        if (payload.kind === "video") {
            const spec = NODE_DEFAULT_SIZE[CanvasNodeType.Video];
            const id = nodeId || `video-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
            const nextSize = normalizeNodeSize(payload.width || spec.width, payload.height || spec.height);
            setNodes((prev) => [...prev, { id, type: CanvasNodeType.Video, title: payload.title, position: { x: center.x - nextSize.width / 2, y: center.y - nextSize.height / 2 }, width: nextSize.width, height: nextSize.height, metadata: { content: payload.url, storageKey: payload.storageKey, status: NODE_STATUS_SUCCESS, naturalWidth: payload.width, naturalHeight: payload.height, source: "import" } }]);
            setSelectedNodeIds(new Set([id]));
            setSelectedConnectionId(null);
            return;
        }
        if (payload.kind === "audio") {
            const spec = NODE_DEFAULT_SIZE[CanvasNodeType.Audio];
            const id = nodeId || `audio-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
            setNodes((prev) => [...prev, { id, type: CanvasNodeType.Audio, title: payload.title, position: { x: center.x - spec.width / 2, y: center.y - spec.height / 2 }, width: spec.width, height: spec.height, metadata: { content: payload.url, storageKey: payload.storageKey, status: NODE_STATUS_SUCCESS, bytes: payload.bytes, mimeType: payload.mimeType || "audio/mpeg", durationMs: payload.durationMs, source: "import" } }]);
            setSelectedNodeIds(new Set([id]));
            setSelectedConnectionId(null);
            return;
        }
        return insertAssistantImage({ id: nodeId || `asset-${Date.now()}`, prompt: payload.title, dataUrl: payload.dataUrl, storageKey: payload.storageKey, source: payload.source }, position, nodeId);
    }

    const handleDrop = useCallback(
        (event: ReactDragEvent<HTMLDivElement>) => {
            event.preventDefault();
            const payload = draggedAssetPayloadRef.current;
            if (event.dataTransfer.getData(CANVAS_ASSET_DRAG_TYPE) && payload) {
                void insertAssetAt(payload, screenToCanvas(event.clientX, event.clientY));
                return;
            }
            // 支持一次拖入多个素材文件（批量导入 → 自动排布）
            const files = Array.from(event.dataTransfer.files).filter((item) => item.type.startsWith("image/") || item.type.startsWith("video/") || isAudioFile(item));
            if (!files.length) return;
            const pos = screenToCanvas(event.clientX, event.clientY);
            void importFilesAt(files, pos);
        },
        [importFilesAt, insertAssetAt, screenToCanvas],
    );

    const pasteAssistantImage = useCallback(
        (file: File) => {
            const position = screenToCanvas((containerRef.current?.getBoundingClientRect().left || 0) + size.width / 2, (containerRef.current?.getBoundingClientRect().top || 0) + size.height / 2);
            void createImageFileNode(file, position);
            message.success("已从剪切板添加图片");
        },
        [createImageFileNode, message, screenToCanvas, size.height, size.width],
    );

    const handleAssistantSessionsChange = useCallback((sessions: CanvasAssistantSession[], activeId: string | null) => {
        setChatSessions(sessions);
        setActiveChatId(activeId);
    }, []);

    const handleAgentConfigChange = useCallback((patch: Partial<CanvasAgentConfig>) => {
        setAgentConfig((current) => ({ ...(current || resolvedAgentConfig), ...patch }));
    }, [resolvedAgentConfig]);

    const startTitleEditing = useCallback(() => {
        setTitleDraft(currentProject?.title || "未命名画布");
        setTitleEditing(true);
    }, [currentProject?.title]);

    const finishTitleEditing = useCallback(() => {
        const nextTitle = titleDraft.trim();
        if (nextTitle) renameProject(projectId, nextTitle);
        setTitleEditing(false);
    }, [projectId, renameProject, titleDraft]);

    const preventCanvasContextMenu = useCallback((event: ReactMouseEvent) => {
        if ((event.target as HTMLElement).closest("[data-node-id]")) return;
        event.preventDefault();
        // 任务04：空白处右键 → LibTV 原版 pane 菜单（节点/连线/多选右键走各自 handler，不受影响）
        setNodeCreateAnchor(null);
        setNodeCreatePosition(null);
        setContextMenu({ type: "pane", x: event.clientX, y: event.clientY });
    }, []);

    const handleGenerateNode = useCallback(
        async (nodeId: string, mode: CanvasNodeGenerationMode, prompt: string) => {
            const sourceNode = nodesRef.current.find((node) => node.id === nodeId);
            const generationConfig = buildGenerationConfig(effectiveConfig, sourceNode, mode);
            const workflowRef = mode === "text" ? undefined : sourceNode?.metadata?.workflowRef;
            const usesSaintDolaPool = mode === "video" && isEmbeddedSaintCanvas() && isSaintDolaPoolModel(generationConfig.model);
            if (workflowRef && !useUserStore.getState().token) {
                message.error("工作流生成需要先登录");
                return;
            }
            if (!workflowRef && !usesSaintDolaPool && !isAiConfigReady(generationConfig, generationConfig.model)) {
                openConfigDialog(true);
                return;
            }

            setRunningNodeId(nodeId);
            const sourceTextContent = sourceNode?.type === CanvasNodeType.Text ? sourceNode.metadata?.content?.trim() || "" : "";
            const editingTextNode = mode === "text" && Boolean(sourceTextContent);
            const generationContext = await hydrateNodeGenerationContext(
                buildNodeGenerationContext(nodeId, nodesRef.current, connectionsRef.current, editingTextNode ? `请根据要求修改以下文本。\n\n原文：\n${sourceTextContent}\n\n修改要求：\n${prompt}` : prompt),
            );
            const effectivePrompt = generationContext.prompt.trim();
            const requestPrompt =
                mode === "video" || (mode === "image" && !isPanoramaNodeType(sourceNode?.type))
                    ? applyCameraPrompt(effectivePrompt, sourceNode?.metadata?.cameraControl)
                    : effectivePrompt;
            const markSourceStatus = !isCanvasImageNodeType(sourceNode?.type) && !editingTextNode;
            const statusPrompt = sourceNode?.type === CanvasNodeType.Config ? effectivePrompt : prompt;
            if (!effectivePrompt && (mode === "text" || (mode === "audio" && !workflowRef))) {
                setRunningNodeId(null);
                return;
            }
            let pendingChildIds: string[] = [];
            const generationStartedAt = Date.now();
            if (markSourceStatus) setNodes((prev) => prev.map((node) => (node.id === nodeId ? { ...node, metadata: { ...node.metadata, prompt: statusPrompt, status: NODE_STATUS_LOADING, startedAt: generationStartedAt, durationMs: undefined, errorDetails: undefined } } : node)));

            try {
                if (mode === "image" && isPanoramaNodeType(sourceNode?.type)) {
                    const panoramaSourcePrompt = prompt.trim();
                    const sourceReference: ReferenceImage[] = sourceNode?.metadata?.content
                        ? [{ id: sourceNode.id, name: `image-${sourceNode.id}.png`, type: sourceNode.metadata.mimeType || "image/png", dataUrl: sourceNode.metadata.content, storageKey: sourceNode.metadata.storageKey }]
                        : [];
                    const referenceImages = [...generationContext.referenceImages, ...sourceReference];
                    const panoramaPrompt = buildPanoramaPrompt(effectivePrompt, referenceImages.length > 0);
                    const panoramaGenerationConfig = { ...generationConfig, size: PANORAMA_IMAGE_SIZE };
                    const count = getGenerationCount(panoramaGenerationConfig.count);
                    const isEmptyPanoramaNode = !sourceNode?.metadata?.content;
                    const panoramaNodeConfig = NODE_DEFAULT_SIZE[CanvasNodeType.Panorama];
                    const parentPosition = sourceNode?.position || { x: 0, y: 0 };
                    const gap = 96;
                    // 092：LibTV 原版展开网格行间距 8
                    const rowGap = 8;
                    const rootId = isEmptyPanoramaNode ? nodeId : nanoid();
                    const childIds = count > 1 ? Array.from({ length: count }, () => nanoid()) : [];
                    const targetIds = count > 1 ? childIds : [rootId];
                    const targetTaskIds = Object.fromEntries(targetIds.map((id) => [id, "client_image_task_" + id]));
                    const primaryTargetId = targetIds[0];
                    pendingChildIds = isEmptyPanoramaNode ? childIds : [rootId, ...childIds];
                    const rootNode: CanvasNodeData = {
                        id: rootId,
                        type: CanvasNodeType.Panorama,
                        title: sourceNode?.title || "全景图",
                        position: {
                            x: isEmptyPanoramaNode ? parentPosition.x : parentPosition.x + panoramaNodeConfig.width + gap,
                            y: parentPosition.y + panoramaNodeConfig.height / 2 - panoramaNodeConfig.height / 2,
                        },
                        width: isEmptyPanoramaNode ? sourceNode?.width || panoramaNodeConfig.width : panoramaNodeConfig.width,
                        height: isEmptyPanoramaNode ? sourceNode?.height || panoramaNodeConfig.height : panoramaNodeConfig.height,
                        metadata: {
                            ...buildImageGenerationMetadata(referenceImages.length ? "edit" : "generation", panoramaGenerationConfig, count, referenceImages),
                            workflowRef,
                            prompt: panoramaSourcePrompt,
                            panoramaSourcePrompt,
                            panoramaFinalPrompt: panoramaPrompt,
                            panoramaProjection: undefined,
                            status: NODE_STATUS_LOADING,
                            startedAt: generationStartedAt,
                            progress: 0,
                            imageTaskId: workflowRef && count > 1 ? undefined : primaryTargetId ? targetTaskIds[primaryTargetId] : undefined,
                            primaryImageId: count > 1 ? primaryTargetId : undefined,
                            isBatchRoot: count > 1,
                            batchChildIds: count > 1 ? childIds : undefined,
                            batchUsesReferenceImages: referenceImages.length > 0,
                            imageBatchExpanded: count > 1 ? true : undefined,
                        },
                    };
                    // 093：主图占田字格 (0,0)，子图按阅读顺序填其余格（LibTV 真值，gap 8、行底对齐）
                    const childBoxes = layoutBatchExpandedChildren({ x: rootNode.position.x, y: rootNode.position.y, width: rootNode.width, height: rootNode.height }, childIds.map(() => ({ width: panoramaNodeConfig.width, height: panoramaNodeConfig.height })));
                    const childNodes: CanvasNodeData[] = childIds.map((id, index) => ({
                        id,
                        type: CanvasNodeType.Panorama,
                        title: sourceNode?.title || "全景图",
                        position: childBoxes[index],
                        width: panoramaNodeConfig.width,
                        height: panoramaNodeConfig.height,
                        metadata: {
                            ...buildImageGenerationMetadata(referenceImages.length ? "edit" : "generation", panoramaGenerationConfig, count, referenceImages),
                            workflowRef,
                            prompt: panoramaSourcePrompt,
                            panoramaSourcePrompt,
                            panoramaFinalPrompt: panoramaPrompt,
                            panoramaProjection: undefined,
                            status: NODE_STATUS_LOADING,
                            startedAt: generationStartedAt,
                            progress: 0,
                            imageTaskId: targetTaskIds[id],
                            batchRootId: count > 1 ? rootId : undefined,
                        },
                    }));
                    const batchConnections = [...(isEmptyPanoramaNode ? [] : [{ id: nanoid(), fromNodeId: nodeId, toNodeId: rootId }]), ...childIds.map((childId) => ({ id: nanoid(), fromNodeId: rootId, toNodeId: childId }))];

                    setNodes((prev) => [
                        ...prev.map((node) =>
                            node.id === nodeId
                                ? isEmptyPanoramaNode
                                    ? {
                                        ...node,
                                        position: rootNode.position,
                                        width: rootNode.width,
                                        height: rootNode.height,
                                        title: rootNode.title,
                                        metadata: { ...node.metadata, ...rootNode.metadata, errorDetails: undefined },
                                    }
                                    : { ...node, metadata: { ...node.metadata, status: NODE_STATUS_SUCCESS, errorDetails: undefined } }
                                : node,
                        ),
                        ...(isEmptyPanoramaNode ? [] : [rootNode]),
                        ...childNodes,
                    ]);
                    setConnections((prev) => [...prev, ...batchConnections]);
                    setSelectedNodeIds(new Set([nodeId]));
                    setSelectedConnectionId(null);
                    setDialogNodeId(nodeId);

                    const taskResults = await Promise.all(
                        targetIds.map(async (targetId) => {
                            try {
                                const task = workflowRef
                                    ? await workflowImageTask(await submitCanvasWorkflowTask(workflowRef, panoramaGenerationConfig, "image", panoramaPrompt, referenceImages, [], [], targetId, projectId, targetTaskIds[targetId]))
                                    : await createCanvasImageTask({ ...panoramaGenerationConfig, count: "1", quality: panoramaGenerationConfig.quality === "auto" ? "medium" : panoramaGenerationConfig.quality }, panoramaPrompt, referenceImages, { nodeId: targetId, sourceId: projectId, clientTaskId: targetTaskIds[targetId] });
                                if (task.image_url || task.url) {
                                    setNodes((prev) => {
                                        const root = prev.find((node) => node.id === rootId);
                                        let next = applyCanvasImageTaskUpdate(prev, targetId, task, generationStartedAt, { width: panoramaNodeConfig.width, height: panoramaNodeConfig.height });
                                        if (task.source !== "workflow" && targetId !== rootId && root?.metadata?.primaryImageId === targetId) {
                                            next = applyCanvasImageTaskUpdate(next, rootId, task, generationStartedAt, { width: panoramaNodeConfig.width, height: panoramaNodeConfig.height });
                                        }
                                        return next;
                                    });
                                    if (task.source === "workflow") setConnections((prev) => applyCanvasImageTaskConnections(prev, targetId, task, count > 1 ? rootId : undefined));
                                    return true;
                                }
                                setNodes((prev) => {
                                    const root = prev.find((node) => node.id === rootId);
                                    return prev.map((node) => {
                                        if (node.id !== targetId && node.id !== rootId) return node;
                                        if (node.id === rootId && (targetId === rootId || !root?.metadata?.primaryImageId)) {
                                            return { ...node, metadata: { ...node.metadata, status: NODE_STATUS_LOADING, imageTaskId: task.id, imageTaskResultId: undefined, primaryImageId: targetId, startedAt: parseCanvasTaskTime(task.started_at ?? task.startedAt ?? task.created_at ?? task.createdAt) || generationStartedAt, progress: task.progress || 0, errorDetails: undefined } };
                                        }
                                        if (node.id === targetId) {
                                            return { ...node, metadata: { ...node.metadata, status: NODE_STATUS_LOADING, imageTaskId: task.id, imageTaskResultId: undefined, startedAt: parseCanvasTaskTime(task.started_at ?? task.startedAt ?? task.created_at ?? task.createdAt) || generationStartedAt, progress: task.progress || 0, errorDetails: undefined } };
                                        }
                                        return node;
                                    });
                                });
                                return true;
                            } catch (error) {
                                const errorDetails = error instanceof Error ? error.message : "全景图生成失败";
                                setNodes((prev) => workflowRef
                                    ? applyCanvasImageTaskUpdate(prev, targetId, { id: targetTaskIds[targetId], source: "workflow", status: "failed", error: { message: errorDetails } }, generationStartedAt, { width: panoramaNodeConfig.width, height: panoramaNodeConfig.height })
                                    : prev.map((node) => (node.id === targetId ? { ...node, metadata: { ...node.metadata, status: NODE_STATUS_ERROR, errorDetails } } : node)));
                                return false;
                            }
                        }),
                    );
                    const hasSuccess = taskResults.some(Boolean);
                    const hasFailure = taskResults.some((result) => !result);
                    if (hasFailure) message.error(hasSuccess ? "部分全景图任务创建失败" : "全部全景图任务创建失败");
                    setNodes((prev) =>
                        prev.map((node) =>
                            node.id === rootId && !hasSuccess
                                ? { ...node, metadata: { ...node.metadata, status: NODE_STATUS_ERROR, errorDetails: "全部全景图任务创建失败" } }
                                : node,
                        ),
                    );
                    return;
                }

                if (mode === "image") {
                    const count = !workflowRef && isKIESeedreamLayerDecompositionModel(generationConfig.model) ? 1 : getGenerationCount(generationConfig.count);
                    // 054：宿主模型（Dola 账号池生图 / ChatGPT image2 / saint-api 渠道）走宿主任务，轮询与状态更新由宿主推送驱动
                    const isHostImage = !workflowRef && isEmbeddedSaintCanvas() && isHostDispatchedModel(generationConfig.model);
                    const isConfigNode = sourceNode?.type === CanvasNodeType.Config;
                    const isImageNode = sourceNode?.type === CanvasNodeType.Image;
                    const isEmptyImageNode = isImageNode && !sourceNode?.metadata?.content;
                    const sourceReference =
                        isImageNode && sourceNode?.metadata?.content
                            ? [{ id: sourceNode.id, name: `image-${sourceNode.id}.png`, type: sourceNode.metadata.mimeType || "image/png", dataUrl: sourceNode.metadata.content, storageKey: sourceNode.metadata.storageKey }]
                            : [];
                    const referenceImages = [...generationContext.referenceImages, ...sourceReference];
                    const generationType = referenceImages.length ? ("edit" as const) : ("generation" as const);
                    const generationMetadata = buildImageGenerationMetadata(generationType, generationConfig, count, referenceImages);
                    const parentConfig = NODE_DEFAULT_SIZE[isConfigNode ? CanvasNodeType.Config : isImageNode ? CanvasNodeType.Image : CanvasNodeType.Text];
                    const imageConfig = NODE_DEFAULT_SIZE[CanvasNodeType.Image];
                    const imageSize = nodeSizeFromRatio(generationConfig.size, imageConfig.width, imageConfig.height) || imageConfig;
                    const parentPosition = sourceNode?.position || { x: 0, y: 0 };
                    const gap = 96;
                    // 092：LibTV 原版展开网格行间距 8
                    const rowGap = 8;
                    const rootId = isEmptyImageNode ? nodeId : nanoid();
                    const childIds = count > 1 ? Array.from({ length: count }, () => nanoid()) : [];
                    const targetIds = count > 1 ? childIds : [rootId];
                    const targetTaskIds = Object.fromEntries(targetIds.map((id) => [id, `client_image_task_${id}`]));
                    const primaryTargetId = targetIds[0];
                    pendingChildIds = isEmptyImageNode ? childIds : [rootId, ...childIds];
                    const rootNode: CanvasNodeData = {
                        id: rootId,
                        type: CanvasNodeType.Image,
                        title: effectivePrompt.slice(0, 32) || "Generated Image",
                        position: {
                            x: isEmptyImageNode ? parentPosition.x : parentPosition.x + parentConfig.width + gap,
                            y: parentPosition.y + parentConfig.height / 2 - imageSize.height / 2,
                        },
                        width: isEmptyImageNode ? sourceNode?.width || imageSize.width : imageSize.width,
                        height: isEmptyImageNode ? sourceNode?.height || imageSize.height : imageSize.height,
                        metadata: {
                            prompt: effectivePrompt,
                            cameraControl: sourceNode?.metadata?.cameraControl,
                            status: NODE_STATUS_LOADING,
                            startedAt: generationStartedAt,
                            progress: 0,
                            imageTaskId: workflowRef && count > 1 ? undefined : primaryTargetId ? targetTaskIds[primaryTargetId] : undefined,
                            primaryImageId: count > 1 ? primaryTargetId : undefined,
                            isBatchRoot: count > 1,
                            batchChildIds: count > 1 ? childIds : undefined,
                            batchUsesReferenceImages: referenceImages.length > 0,
                            ...generationMetadata,
                            workflowRef,
                            imageBatchExpanded: count > 1 ? true : undefined,
                        },
                    };
                    // 093：主图占田字格 (0,0)，子图按阅读顺序填其余格（LibTV 真值，gap 8、行底对齐）
                    const childBoxes = layoutBatchExpandedChildren({ x: rootNode.position.x, y: rootNode.position.y, width: rootNode.width, height: rootNode.height }, childIds.map(() => ({ width: imageSize.width, height: imageSize.height })));
                    const childNodes: CanvasNodeData[] = childIds.map((id, index) => ({
                        id,
                        type: CanvasNodeType.Image,
                        title: effectivePrompt.slice(0, 32) || "Generated Image",
                        position: childBoxes[index],
                        width: imageSize.width,
                        height: imageSize.height,
                        metadata: { prompt: effectivePrompt, cameraControl: sourceNode?.metadata?.cameraControl, status: NODE_STATUS_LOADING, startedAt: generationStartedAt, progress: 0, imageTaskId: targetTaskIds[id], batchRootId: count > 1 ? rootId : undefined, ...generationMetadata, workflowRef },
                    }));
                    const batchConnections = [...(isEmptyImageNode ? [] : [{ id: nanoid(), fromNodeId: nodeId, toNodeId: rootId }]), ...childIds.map((childId) => ({ id: nanoid(), fromNodeId: rootId, toNodeId: childId }))];

                    setNodes((prev) => [
                        ...prev.map((node) =>
                            node.id === nodeId
                                ? isConfigNode
                                    ? {
                                        ...node,
                                        metadata: { ...node.metadata, prompt: effectivePrompt, status: NODE_STATUS_LOADING, startedAt: generationStartedAt, durationMs: undefined, errorDetails: undefined },
                                    }
                                    : isEmptyImageNode
                                        ? {
                                            ...node,
                                            position: rootNode.position,
                                            width: rootNode.width,
                                            height: rootNode.height,
                                            title: rootNode.title,
                                            metadata: { ...node.metadata, ...rootNode.metadata, errorDetails: undefined },
                                        }
                                        : isImageNode
                                            ? {
                                                ...node,
                                                metadata: { ...node.metadata, status: NODE_STATUS_SUCCESS, errorDetails: undefined },
                                            }
                                            : {
                                                ...node,
                                                type: CanvasNodeType.Text,
                                                title: prompt.slice(0, 32) || "Prompt",
                                                width: parentConfig.width,
                                                height: parentConfig.height,
                                                metadata: { ...node.metadata, content: prompt, prompt, status: NODE_STATUS_SUCCESS, fontSize: 14, errorDetails: undefined },
                                            }
                                : node,
                        ),
                        ...(isEmptyImageNode ? [] : [rootNode]),
                        ...childNodes,
                    ]);
                    setConnections((prev) => [...prev, ...batchConnections]);
                    setSelectedNodeIds(new Set([nodeId]));
                    setSelectedConnectionId(null);
                    setDialogNodeId(nodeId);

                    const taskResults = await Promise.all(
                        targetIds.map(async (targetId) => {
                            try {
                                // 054：嵌入宿主时，Dola 账号池生图 / ChatGPT image2 / saint-api 渠道模型走宿主任务（主进程按模型名分派）
                                const task = workflowRef
                                    ? await workflowImageTask(await submitCanvasWorkflowTask(workflowRef, generationConfig, "image", requestPrompt, referenceImages, [], [], targetId, projectId, targetTaskIds[targetId]))
                                    : isEmbeddedSaintCanvas() && isHostDispatchedModel(generationConfig.model)
                                        ? await requestSaintHostImageTask({ source: "canvas", sourceId: projectId, nodeId: targetId, taskId: targetTaskIds[targetId], clientTaskId: targetTaskIds[targetId], model: generationConfig.model, prompt: requestPrompt, count: "1", size: generationConfig.size, quality: generationConfig.quality, references: referenceImages })
                                        : await createCanvasImageTask({ ...generationConfig, count: "1" }, requestPrompt, referenceImages, { nodeId: targetId, sourceId: projectId, clientTaskId: targetTaskIds[targetId] });
                                if (task.image_url || task.url) {
                                    setNodes((prev) => {
                                        const root = prev.find((node) => node.id === rootId);
                                        let next = applyCanvasImageTaskUpdate(prev, targetId, task, generationStartedAt, { width: imageSize.width, height: imageSize.height });
                                        if (task.source !== "workflow" && targetId !== rootId && root?.metadata?.primaryImageId === targetId) {
                                            next = applyCanvasImageTaskUpdate(next, rootId, task, generationStartedAt, { width: imageSize.width, height: imageSize.height });
                                        }
                                        return next;
                                    });
                                    setConnections((prev) => applyCanvasImageTaskConnections(prev, targetId, task, task.source === "workflow" && count > 1 ? rootId : undefined));
                                    return true;
                                }
                                setNodes((prev) => {
                                    const root = prev.find((node) => node.id === rootId);
                                    return prev.map((node) => {
                                        if (node.id !== targetId && node.id !== rootId) return node;
                                        if (node.id === rootId && (targetId === rootId || !root?.metadata?.primaryImageId))
                                            return {
                                                ...node,
                                                metadata: { ...node.metadata, status: NODE_STATUS_LOADING, imageTaskId: task.id, imageTaskResultId: undefined, primaryImageId: targetId, startedAt: parseCanvasTaskTime(task.started_at ?? task.startedAt ?? task.created_at ?? task.createdAt) || generationStartedAt, progress: task.progress || 0, errorDetails: undefined, hostImageTask: isHostImage || undefined },
                                            };
                                        if (node.id === targetId)
                                            return {
                                                ...node,
                                                metadata: { ...node.metadata, status: NODE_STATUS_LOADING, imageTaskId: task.id, imageTaskResultId: undefined, startedAt: parseCanvasTaskTime(task.started_at ?? task.startedAt ?? task.created_at ?? task.createdAt) || generationStartedAt, progress: task.progress || 0, errorDetails: undefined, hostImageTask: isHostImage || undefined },
                                            };
                                        return node;
                                    });
                                });
                                if (isConfigNode) setNodes((prev) => prev.map((node) => (node.id === nodeId ? { ...node, metadata: { ...node.metadata, status: NODE_STATUS_SUCCESS, errorDetails: undefined } } : node)));
                                return true;
                            } catch (error) {
                                const errorDetails = error instanceof Error ? error.message : "生成失败";
                                setNodes((prev) => workflowRef
                                    ? applyCanvasImageTaskUpdate(prev, targetId, { id: targetTaskIds[targetId], source: "workflow", status: "failed", error: { message: errorDetails } }, generationStartedAt, { width: imageSize.width, height: imageSize.height })
                                    : prev.map((node) => (node.id === targetId ? { ...node, metadata: { ...node.metadata, status: NODE_STATUS_ERROR, errorDetails } } : node)));
                                return false;
                            }
                        }),
                    );
                    const hasSuccess = taskResults.some(Boolean);
                    setNodes((prev) =>
                        prev.map((node) =>
                            node.id === nodeId && isConfigNode
                                ? { ...node, metadata: { ...node.metadata, status: hasSuccess ? NODE_STATUS_SUCCESS : NODE_STATUS_ERROR } }
                                : node.id === rootId && !hasSuccess
                                    ? { ...node, metadata: { ...node.metadata, status: NODE_STATUS_ERROR } }
                                    : node,
                        ),
                    );
                    return;
                }

                if (mode === "video") {
                    const videoGenerationConfig = workflowRef ? generationConfig : withCanvasVideoAdvancedConfig(generationConfig, generationContext);
                    const frameReferencesEnabled = Boolean(workflowRef) || supportsVideoFrameReferences(videoGenerationConfig.model, channelProtocolForConfig(videoGenerationConfig));
                    const firstFrame = frameReferencesEnabled ? generationContext.firstFrame : null;
                    const lastFrame = frameReferencesEnabled ? generationContext.lastFrame : null;
                    const videoReferenceImages = frameReferencesEnabled || isAutoDLConfig(videoGenerationConfig) ? generationContext.referenceImages : [...generationContext.referenceImages, ...[generationContext.firstFrame, generationContext.lastFrame].filter((image): image is ReferenceImage => Boolean(image))];
                    const spec = nodeSizeFromRatio(videoGenerationConfig.size, NODE_DEFAULT_SIZE[CanvasNodeType.Video].width, NODE_DEFAULT_SIZE[CanvasNodeType.Video].height) || NODE_DEFAULT_SIZE[CanvasNodeType.Video];
                    const isEmptyVideoNode = sourceNode?.type === CanvasNodeType.Video && !sourceNode.metadata?.content;
                    const videoId = isEmptyVideoNode ? nodeId : nanoid();
                    const clientTaskId = `client_video_task_${videoId}`;
                    const parent = sourceNode?.position || { x: 0, y: 0 };
                    const videoNode: CanvasNodeData = {
                        id: videoId,
                        type: CanvasNodeType.Video,
                        title: effectivePrompt.slice(0, 32) || "Generated Video",
                        position: isEmptyVideoNode ? sourceNode.position : { x: parent.x + (sourceNode?.width || spec.width) + 96, y: parent.y },
                        width: isEmptyVideoNode ? sourceNode.width : spec.width,
                        height: isEmptyVideoNode ? sourceNode.height : spec.height,
                        metadata: { prompt: effectivePrompt, cameraControl: sourceNode?.metadata?.cameraControl, status: NODE_STATUS_LOADING, model: videoGenerationConfig.model, channelId: videoGenerationConfig.videoChannelId || videoGenerationConfig.activeChannelId, workflowRef, size: videoGenerationConfig.size, seconds: videoGenerationConfig.videoSeconds, vquality: videoGenerationConfig.vquality, mode: videoGenerationConfig.videoMode, negativePrompt: videoGenerationConfig.videoNegativePrompt, multiShot: videoGenerationConfig.videoMultiShot, shotType: videoGenerationConfig.videoShotType, generateAudio: videoGenerationConfig.videoGenerateAudio, characterOrientation: videoGenerationConfig.videoCharacterOrientation, watermark: videoGenerationConfig.videoWatermark, references: generationReferenceUrls({ ...generationContext, referenceImages: videoReferenceImages, firstFrame, lastFrame }), firstFrameNodeId: sourceNode?.metadata?.firstFrameNodeId, lastFrameNodeId: sourceNode?.metadata?.lastFrameNodeId, klingImageNodeIds: sourceNode?.metadata?.klingImageNodeIds, klingMultiPrompt: sourceNode?.metadata?.klingMultiPrompt, klingElementList: sourceNode?.metadata?.klingElementList, startedAt: generationStartedAt, progress: 0, videoTaskId: clientTaskId },
                    };
                    pendingChildIds = [videoId];
                    setNodes((prev) => (isEmptyVideoNode ? prev.map((node) => (node.id === nodeId ? { ...node, ...videoNode } : node)) : [...prev.map((node) => (node.id === nodeId ? { ...node, metadata: { ...node.metadata, status: NODE_STATUS_SUCCESS } } : node)), videoNode]));
                    if (!isEmptyVideoNode) setConnections((prev) => [...prev, { id: nanoid(), fromNodeId: nodeId, toNodeId: videoId }]);
                    const useSaintDolaPool = isEmbeddedSaintCanvas() && !workflowRef && isSaintDolaPoolModel(videoGenerationConfig.model);
                    const videoTask = workflowRef
                        ? await workflowVideoTask(await submitCanvasWorkflowTask(workflowRef, videoGenerationConfig, "video", requestPrompt, [firstFrame, ...videoReferenceImages, lastFrame].filter((image): image is ReferenceImage => Boolean(image)), generationContext.referenceVideos, generationContext.referenceAudios, videoId, projectId, clientTaskId))
                        : useSaintDolaPool
                            ? await requestSaintHostVideoTask({
                                source: "canvas",
                                sourceId: projectId,
                                nodeId: videoId,
                                clientTaskId,
                                prompt: requestPrompt,
                                duration: Number(videoGenerationConfig.videoSeconds) || 30,
                                resolution: "720p",
                                aspectRatio: ratioFromCanvasSize(videoGenerationConfig.size),
                                references: videoReferenceImages,
                                firstFrame,
                                lastFrame,
                                videoReferences: generationContext.referenceVideos,
                                audioReferences: generationContext.referenceAudios,
                            })
                        : (await createVideoGenerationTask(videoGenerationConfig, requestPrompt, { references: videoReferenceImages, firstFrame, lastFrame, videoReferences: generationContext.referenceVideos, audioReferences: generationContext.referenceAudios }, undefined, { clientTaskId, source: "canvas", sourceId: videoId })).task;
                    setNodes((prev) => applyCanvasVideoTaskUpdate(prev, videoId, videoTask, videoGenerationConfig, generationStartedAt, spec));
                    return;
                }

                if (mode === "audio") {
                    const workflowAudios = workflowRef ? generationContext.referenceAudios : [];
                    const referenceAudio = workflowRef ? undefined : selectAudioReference(generationConfig, sourceNode?.metadata, generationContext.referenceAudios);
                    const spec = NODE_DEFAULT_SIZE[CanvasNodeType.Audio];
                    const isEmptyAudioNode = sourceNode?.type === CanvasNodeType.Audio && !sourceNode.metadata?.content;
                    const audioId = isEmptyAudioNode ? nodeId : nanoid();
                    const clientAudioTaskId = `client_audio_task_${audioId}`;
                    const parent = sourceNode?.position || { x: 0, y: 0 };
                    const audioNode: CanvasNodeData = {
                        id: audioId,
                        type: CanvasNodeType.Audio,
                        title: effectivePrompt.slice(0, 32) || "Generated Audio",
                        position: isEmptyAudioNode ? sourceNode.position : { x: parent.x + (sourceNode?.width || spec.width) + 96, y: parent.y + ((sourceNode?.height || spec.height) - spec.height) / 2 },
                        width: isEmptyAudioNode ? sourceNode.width : spec.width,
                        height: isEmptyAudioNode ? sourceNode.height : spec.height,
                        metadata: { prompt: effectivePrompt, status: NODE_STATUS_LOADING, startedAt: generationStartedAt, progress: 0, audioTaskId: clientAudioTaskId, ...buildAudioGenerationMetadata(generationConfig, sourceNode?.metadata), workflowRef },
                    };
                    pendingChildIds = [audioId];
                    setNodes((prev) => (isEmptyAudioNode ? prev.map((node) => (node.id === nodeId ? { ...node, ...audioNode } : node)) : [...prev.map((node) => (node.id === nodeId ? { ...node, metadata: { ...node.metadata, status: NODE_STATUS_SUCCESS } } : node)), audioNode]));
                    if (!isEmptyAudioNode) setConnections((prev) => [...prev, { id: nanoid(), fromNodeId: nodeId, toNodeId: audioId }]);
                    const task = workflowRef
                        ? await workflowAudioTask(await submitCanvasWorkflowTask(workflowRef, generationConfig, "audio", effectivePrompt, [], [], workflowAudios, audioId, projectId, clientAudioTaskId))
                        : await createCanvasAudioTask(generationConfig, effectivePrompt, { nodeId: audioId, sourceId: projectId, clientTaskId: clientAudioTaskId }, referenceAudio);
                    setNodes((prev) => applyCanvasAudioTaskUpdate(prev, audioId, task, generationStartedAt));
                    return;
                }

                let streamed = "";
                const isConfigNode = sourceNode?.type === CanvasNodeType.Config;
                const textCount = isConfigNode ? getGenerationCount(generationConfig.count) : 1;
                const parentConfig = NODE_DEFAULT_SIZE[isConfigNode ? CanvasNodeType.Config : CanvasNodeType.Text];
                const textConfig = NODE_DEFAULT_SIZE[CanvasNodeType.Text];
                const parentPosition = sourceNode?.position || { x: 0, y: 0 };
                const childIds = isConfigNode || editingTextNode ? Array.from({ length: textCount }, () => nanoid()) : [];
                pendingChildIds = childIds;
                if (isConfigNode || editingTextNode) {
                    const childNodes: CanvasNodeData[] = childIds.map((id, index) => ({
                        id,
                        type: CanvasNodeType.Text,
                        title: effectivePrompt.slice(0, 32) || "Generated Text",
                        position: {
                            x: parentPosition.x + parentConfig.width + 96,
                            y: parentPosition.y + parentConfig.height / 2 - textConfig.height / 2 + (index - (textCount - 1) / 2) * (textConfig.height + 36),
                        },
                        width: textConfig.width,
                        height: textConfig.height,
                        metadata: { prompt: effectivePrompt, status: NODE_STATUS_LOADING, fontSize: 14 },
                    }));
                    setNodes((prev) => [...prev.map((node) => (node.id === nodeId && isConfigNode ? { ...node, metadata: { ...node.metadata, prompt: effectivePrompt, status: NODE_STATUS_LOADING, errorDetails: undefined } } : node)), ...childNodes]);
                    setConnections((prev) => [...prev, ...childIds.map((childId) => ({ id: nanoid(), fromNodeId: nodeId, toNodeId: childId }))]);
                }

                const useHostText = isEmbeddedSaintCanvas() && isHostDispatchedModel(generationConfig.model);
                const answers = await Promise.all(
                    (childIds.length ? childIds : [nodeId]).map(async (targetNodeId) => {
                        // 056：宿主文本模型（Dola text / ChatGPT text 账号池）走宿主任务，完成后一次性写入（宿主任务非流式）
                        if (useHostText) {
                            setNodes((prev) => prev.map((node) => (node.id === targetNodeId ? { ...node, type: CanvasNodeType.Text, metadata: { ...node.metadata, content: "", status: NODE_STATUS_LOADING } } : node)));
                            const task = await requestSaintHostTextTask({ source: "canvas", sourceId: projectId, nodeId: targetNodeId, clientTaskId: `client_text_task_${targetNodeId}`, prompt: effectivePrompt, model: generationConfig.model, references: generationContext.referenceImages });
                            const answer = await waitSaintHostTextTask(String(task.id || ""));
                            return { nodeId: targetNodeId, content: answer };
                        }
                        let localStreamed = "";
                        return requestImageQuestion(generationConfig, buildNodeChatMessages({ ...generationContext, prompt: effectivePrompt }), (text) => {
                            localStreamed = text;
                            streamed = text;
                            setNodes((prev) => prev.map((node) => (node.id === targetNodeId ? { ...node, type: CanvasNodeType.Text, metadata: { ...node.metadata, content: text, status: NODE_STATUS_LOADING } } : node)));
                        }).then((answer) => ({ nodeId: targetNodeId, content: answer || localStreamed }));
                    }),
                );
                const answerByNodeId = new Map(answers.map((item) => [item.nodeId, item.content]));
                setNodes((prev) =>
                    prev.map((node) =>
                        childIds.includes(node.id)
                            ? { ...node, metadata: { ...node.metadata, content: answerByNodeId.get(node.id) || streamed, status: NODE_STATUS_SUCCESS } }
                            : node.id === nodeId && isConfigNode
                                ? { ...node, metadata: { ...node.metadata, status: NODE_STATUS_SUCCESS } }
                                : node.id === nodeId && !editingTextNode
                                    ? { ...node, type: CanvasNodeType.Text, title: prompt.slice(0, 32) || "Generated Text", metadata: { ...node.metadata, content: answerByNodeId.get(node.id) || streamed, status: NODE_STATUS_SUCCESS } }
                                    : node,
                    ),
                );
            } catch (error) {
                const errorDetails = error instanceof Error ? error.message : "生成失败";
                message.error(errorDetails);
                setNodes((prev) =>
                    prev.map((node) => (node.id === nodeId || pendingChildIds.includes(node.id) ? (node.id === nodeId && !markSourceStatus ? node : { ...node, metadata: { ...node.metadata, status: NODE_STATUS_ERROR, errorDetails } }) : node)),
                );
            } finally {
                setRunningNodeId(null);
            }
        },
        [effectiveConfig, openConfigDialog, requestSaintHostVideoTask, requestSaintHostTextTask, waitSaintHostTextTask],
    );

    const getCanvasAgentContext = useCallback(
        (agentState: CanvasAgentState) =>
            buildCanvasAgentContext({
                projectId,
                projectTitle: currentProject?.title || "未命名画布",
                nodes: nodesRef.current,
                connections: connectionsRef.current,
                selectedNodeIds: selectedNodeIdsRef.current,
                config: agentEffectiveConfig,
                autoGenerateMedia: resolvedAgentConfig.autoGenerateMedia,
                agentState,
            }),
        [agentEffectiveConfig, currentProject?.title, projectId, resolvedAgentConfig.autoGenerateMedia],
    );

    const executeCanvasAgentAction = useCallback(
        async (action: CanvasAgentAction, messageReferenceNodeIds: string[]): Promise<CanvasAgentToolResult> => {
            const args = action.arguments;
            const stringValue = (key: string) => (typeof args[key] === "string" ? (args[key] as string).trim() : "");
            const stringValues = (key: string) =>
                Array.isArray(args[key])
                    ? [...new Set((args[key] as unknown[]).filter((value): value is string => typeof value === "string").map((value) => value.trim()).filter(Boolean))]
                    : [];
            const getNode = (nodeId: string) => nodesRef.current.find((node) => node.id === nodeId);
            const missingNodeResult = (nodeId: string): CanvasAgentToolResult => ({ ok: false, code: "node_not_found", message: "找不到节点 " + nodeId });
            const validateNodeIds = (nodeIds: string[]) => nodeIds.find((nodeId) => !getNode(nodeId)) || "";
            const selectOnly = (nodeId: string) => {
                const nextSelection = new Set([nodeId]);
                selectedNodeIdsRef.current = nextSelection;
                setSelectedNodeIds(nextSelection);
                setSelectedConnectionId(null);
            };
            const commitNodes = (nextNodes: CanvasNodeData[]) => {
                nodesRef.current = nextNodes;
                setNodes(nextNodes);
            };
            const commitConnections = (nextConnections: CanvasConnection[]) => {
                connectionsRef.current = nextConnections;
                setConnections(nextConnections);
            };
            const nextNodeCenter = (type: CanvasNodeType, sourceNodes: CanvasNodeData[], sizeOverride?: { width: number; height: number }) => {
                const spec = sizeOverride ? { ...getNodeSpec(type), ...sizeOverride } : getNodeSpec(type);
                const gapX = 72;
                const gapY = 72;
                const columns = 3;
                const fallbackNodes = nodesRef.current.filter(
                    (node) =>
                        node.type !== CanvasNodeType.Group &&
                        node.type !== CanvasNodeType.Config &&
                        node.type !== CanvasNodeType.Director &&
                        !node.metadata?.groupId &&
                        !node.metadata?.excludeUpstreamText,
                );
                const candidates = sourceNodes.length ? sourceNodes : fallbackNodes;
                const source = candidates.length
                    ? candidates.reduce((rightmost, node) => (node.position.x + node.width > rightmost.position.x + rightmost.width ? node : rightmost))
                    : null;
                const canvasCenter = getCanvasCenter();
                const startX = source ? source.position.x + source.width + 96 + spec.width / 2 : canvasCenter.x;
                const startY = source ? source.position.y + spec.height / 2 : canvasCenter.y;
                const collides = (x: number, y: number) => {
                    const left = x - spec.width / 2;
                    const right = x + spec.width / 2;
                    const top = y - spec.height / 2;
                    const bottom = y + spec.height / 2;
                    return nodesRef.current.some(
                        (node) =>
                            left < node.position.x + node.width + gapX &&
                            right + gapX > node.position.x &&
                            top < node.position.y + node.height + gapY &&
                            bottom + gapY > node.position.y,
                    );
                };
                const maxSlots = Math.max(30, (nodesRef.current.length + 1) * columns * 2);

                for (let slot = 0; slot < maxSlots; slot += 1) {
                    const x = startX + (slot % columns) * (spec.width + gapX);
                    const y = startY + Math.floor(slot / columns) * (spec.height + gapY);
                    if (!collides(x, y)) return { x, y };
                }

                return {
                    x: startX,
                    y: Math.max(canvasCenter.y, ...nodesRef.current.map((node) => node.position.y + node.height + gapY + spec.height / 2)),
                };
            };

            const isAgentWriteAction = action.name === "generate_image" || action.name === "edit_image" || action.name === "generate_video" || action.name === "generate_audio" || action.name === "create_text_node" || action.name === "update_text_node" || action.name === "update_node" || action.name === "delete_node" || action.name === "create_connection" || action.name === "delete_connection" || action.name === "create_group" || action.name === "arrange_nodes";
            const autoTitlePending = useCanvasStore.getState().projects.find((project) => project.id === projectId)?.autoTitlePending === true;
            if (autoTitlePending && action.name !== "create_primary_script_node" && isAgentWriteAction) {
                updateProject(projectId, { autoTitlePending: false });
            }

            try {
                if (action.name === "set_agent_state") {
                    const referencedNodeIds = [...stringValues("approvedNodeIds"), ...stringValues("referenceNodeIds")];
                    const missingNodeId = validateNodeIds(referencedNodeIds);
                    return missingNodeId ? missingNodeResult(missingNodeId) : { ok: true };
                }

                if (action.name === "get_canvas_summary") {
                    return {
                        ok: true,
                        project: { id: projectId, title: currentProject?.title || "未命名画布" },
                        selectedNodeIds: Array.from(selectedNodeIdsRef.current),
                        nodes: nodesRef.current.slice(0, 120).map(canvasAgentNodeSummary),
                        connections: connectionsRef.current.slice(0, 240),
                    };
                }

                if (action.name === "get_selected_nodes") {
                    return { ok: true, nodes: nodesRef.current.filter((node) => selectedNodeIdsRef.current.has(node.id)).map(canvasAgentNodeSummary) };
                }

                if (action.name === "query_canvas_nodes") {
                    const nodeId = stringValue("nodeId");
                    const keyword = stringValue("keyword").toLowerCase();
                    const type = stringValue("type");
                    const page = Math.max(1, Math.floor(Number(args.page) || 1));
                    const pageSize = Math.max(1, Math.min(50, Math.floor(Number(args.pageSize) || 20)));
                    const filtered = nodesRef.current.filter((node) => {
                        if (nodeId && node.id !== nodeId) return false;
                        if (type && node.type !== type) return false;
                        if (!keyword) return true;
                        const content = isCanvasImageNodeType(node.type) || node.type === CanvasNodeType.Video || node.type === CanvasNodeType.Audio ? "" : node.metadata?.content || "";
                        return `${node.title} ${content} ${node.metadata?.prompt || ""}`.toLowerCase().includes(keyword);
                    });
                    return {
                        ok: true,
                        items: filtered.slice((page - 1) * pageSize, page * pageSize).map((node) => ({
                            id: node.id,
                            type: node.type,
                            title: node.title,
                            status: node.metadata?.status,
                            groupId: node.metadata?.groupId,
                        })),
                        total: filtered.length,
                        page,
                        pageSize,
                    };
                }

                if (action.name === "get_generation_config") {
                    const videoModel = agentEffectiveConfig.videoModel || agentEffectiveConfig.model;
                    const audioModel = agentEffectiveConfig.audioModel;
                    const grokTts = isGrok2APITtsConfig({ ...agentEffectiveConfig, model: audioModel }, audioModel);
                    return {
                        ok: true,
                        models: {
                            text: agentEffectiveConfig.textModel || agentEffectiveConfig.model,
                            image: agentEffectiveConfig.imageModel || agentEffectiveConfig.model,
                            video: videoModel,
                            audio: agentEffectiveConfig.audioModel,
                        },
                        imageQuality: agentEffectiveConfig.quality,
                        imageSize: agentEffectiveConfig.size,
                        videoQuality: agentEffectiveConfig.vquality,
                        videoSize: agentEffectiveConfig.videoSize,
                        autoGenerateMedia: resolvedAgentConfig.autoGenerateMedia,
                        imageCount: 1,
                        videoSeconds: agentEffectiveConfig.videoSeconds,
                        videoGenerateAudio: agentEffectiveConfig.videoGenerateAudio,
                        videoSupportsAudio: supportsVideoAudioGeneration(videoModel, channelProtocolForConfig({ ...agentEffectiveConfig, model: videoModel, videoModel })),
                        videoDuration: canvasAgentVideoDurationHint(videoModel),
                        audioVoice: isGeminiTtsModel(audioModel) && isGeminiConfig({ ...agentEffectiveConfig, model: audioModel }, audioModel) ? agentEffectiveConfig.geminiTtsVoice : isGlmTtsModel(audioModel) ? agentEffectiveConfig.glmTtsVoice : grokTts ? agentEffectiveConfig.grokTtsVoice : agentEffectiveConfig.audioVoice,
                        audioLanguage: grokTts ? agentEffectiveConfig.grokTtsLanguage : "",
                        audioFormat: isGlmTtsModel(audioModel) ? agentEffectiveConfig.glmTtsFormat : grokTts ? agentEffectiveConfig.grokTtsFormat : agentEffectiveConfig.audioFormat,
                        audioSpeed: isGlmTtsModel(audioModel) ? agentEffectiveConfig.glmTtsSpeed : grokTts ? agentEffectiveConfig.grokTtsSpeed : agentEffectiveConfig.audioSpeed,
                    };
                }

                if (action.name === "get_node") {
                    const nodeId = stringValue("nodeId");
                    const node = getNode(nodeId);
                    return node ? { ok: true, node: canvasAgentNodeSummary(node) } : missingNodeResult(nodeId);
                }

                if (action.name === "get_upstream_nodes" || action.name === "get_downstream_nodes" || action.name === "get_connected_nodes") {
                    const nodeId = stringValue("nodeId");
                    if (!getNode(nodeId)) return missingNodeResult(nodeId);
                    const upstreamIds = connectionsRef.current.filter((connection) => connection.toNodeId === nodeId).map((connection) => connection.fromNodeId);
                    const downstreamIds = connectionsRef.current.filter((connection) => connection.fromNodeId === nodeId).map((connection) => connection.toNodeId);
                    const upstream = nodesRef.current.filter((node) => upstreamIds.includes(node.id)).map(canvasAgentNodeSummary);
                    const downstream = nodesRef.current.filter((node) => downstreamIds.includes(node.id)).map(canvasAgentNodeSummary);
                    if (action.name === "get_upstream_nodes") return { ok: true, nodes: upstream };
                    if (action.name === "get_downstream_nodes") return { ok: true, nodes: downstream };
                    return { ok: true, upstream, downstream };
                }

                if (action.name === "get_generation_task" || action.name === "get_media_task_status") {
                    const nodeId = stringValue("nodeId");
                    const node = getNode(nodeId);
                    if (!node) return missingNodeResult(nodeId);
                    if (![CanvasNodeType.Image, CanvasNodeType.Panorama, CanvasNodeType.Video, CanvasNodeType.Audio].includes(node.type)) {
                        return { ok: false, code: "not_media_node", message: "节点 " + nodeId + " 不是媒体节点" };
                    }
                    return { ok: true, ...canvasAgentTaskSummary(node) };
                }

                if (action.name === "create_primary_script_node" || action.name === "create_text_node") {
                    const sourceNodeIds = stringValues("sourceNodeIds");
                    const missingNodeId = validateNodeIds(sourceNodeIds);
                    if (missingNodeId) return missingNodeResult(missingNodeId);
                    const sourceNodes = sourceNodeIds.map((nodeId) => getNode(nodeId)!);
                    const content = stringValue("content");
                    const nodeSize = action.name === "create_primary_script_node" ? AGENT_PRIMARY_SCRIPT_NODE_SIZE : undefined;
                    const nodeCenter = nextNodeCenter(CanvasNodeType.Text, sourceNodes, nodeSize);
                    const node = createCanvasNode(CanvasNodeType.Text, nodeCenter, {
                        content,
                        prompt: content,
                        status: NODE_STATUS_SUCCESS,
                    });
                    if (nodeSize) {
                        node.position = { x: nodeCenter.x - nodeSize.width / 2, y: nodeCenter.y - nodeSize.height / 2 };
                        node.width = nodeSize.width;
                        node.height = nodeSize.height;
                    }
                    node.title = stringValue("title") || content.slice(0, 32) || "文本";
                    const createdConnections = sourceNodeIds.map((sourceNodeId) => ({ id: nanoid(), fromNodeId: sourceNodeId, toNodeId: node.id }));
                    commitNodes([...nodesRef.current, node]);
                    commitConnections([...connectionsRef.current, ...createdConnections]);
                    selectOnly(node.id);
                    const projectTitle = stringValue("projectTitle");
                    if (action.name === "create_primary_script_node" && autoTitlePending) {
                        renameProject(projectId, projectTitle);
                    }
                    return { ok: true, nodeId: node.id, connectionIds: createdConnections.map((connection) => connection.id), node: canvasAgentNodeSummary(node) };
                }

                if (action.name === "update_text_node") {
                    const nodeId = stringValue("nodeId");
                    const node = getNode(nodeId);
                    if (!node) return missingNodeResult(nodeId);
                    if (node.type !== CanvasNodeType.Text) return { ok: false, code: "invalid_node_type", message: "只能用 update_text_node 修改文本节点" };
                    const title = stringValue("title");
                    const content = stringValue("content");
                    const nextNodes = nodesRef.current.map((item) =>
                        item.id === nodeId
                            ? {
                                ...item,
                                title: title || item.title,
                                metadata: content ? { ...item.metadata, content, prompt: content, status: NODE_STATUS_SUCCESS, errorDetails: undefined } : item.metadata,
                            }
                            : item,
                    );
                    commitNodes(nextNodes);
                    return { ok: true, nodeId, node: canvasAgentNodeSummary(nextNodes.find((item) => item.id === nodeId)!) };
                }

                if (action.name === "update_node") {
                    const nodeId = stringValue("nodeId");
                    if (!getNode(nodeId)) return missingNodeResult(nodeId);
                    const nextNodes = nodesRef.current.map((node) => (node.id === nodeId ? { ...node, title: stringValue("title") || node.title } : node));
                    commitNodes(nextNodes);
                    return { ok: true, nodeId, node: canvasAgentNodeSummary(nextNodes.find((node) => node.id === nodeId)!) };
                }

                if (action.name === "delete_node") {
                    const nodeId = stringValue("nodeId");
                    if (!getNode(nodeId)) return missingNodeResult(nodeId);
                    const beforeNodeIds = nodesRef.current.map((node) => node.id);
                    deleteNodes(new Set([nodeId]));
                    const remainingNodeIds = new Set(nodesRef.current.map((node) => node.id));
                    return { ok: true, deletedNodeIds: beforeNodeIds.filter((id) => !remainingNodeIds.has(id)) };
                }

                if (action.name === "create_connection") {
                    const fromNodeId = stringValue("fromNodeId");
                    const toNodeId = stringValue("toNodeId");
                    const fromNode = getNode(fromNodeId);
                    const toNode = getNode(toNodeId);
                    if (!fromNode) return missingNodeResult(fromNodeId);
                    if (!toNode) return missingNodeResult(toNodeId);
                    if (fromNodeId === toNodeId) return { ok: false, code: "self_connection", message: "节点不能连接到自身" };
                    if (fromNode.type === CanvasNodeType.Config && toNode.type === CanvasNodeType.Config) {
                        return { ok: false, code: "invalid_connection", message: "配置节点之间不能连接" };
                    }
                    const existing = connectionsRef.current.find((connection) => connection.fromNodeId === fromNodeId && connection.toNodeId === toNodeId);
                    if (existing) return { ok: true, connectionId: existing.id, alreadyExists: true };
                    const connection = { id: nanoid(), fromNodeId, toNodeId };
                    commitConnections([...connectionsRef.current, connection]);
                    return { ok: true, connectionId: connection.id };
                }

                if (action.name === "delete_connection") {
                    const connectionId = stringValue("connectionId");
                    if (!connectionsRef.current.some((connection) => connection.id === connectionId)) {
                        return { ok: false, code: "connection_not_found", message: "找不到连线 " + connectionId };
                    }
                    deleteConnection(connectionId);
                    return { ok: true, deletedConnectionId: connectionId };
                }

                if (action.name === "create_group") {
                    const nodeIds = stringValues("nodeIds");
                    const missingNodeId = validateNodeIds(nodeIds);
                    if (missingNodeId) return missingNodeResult(missingNodeId);
                    const groupId = createGroupFromSelection(nodeIds);
                    if (!groupId) return { ok: false, code: "invalid_group", message: "分组至少需要两个未分组的普通节点" };
                    const title = stringValue("title");
                    if (title) {
                        const nextNodes = nodesRef.current.map((node) => (node.id === groupId ? { ...node, title } : node));
                        commitNodes(nextNodes);
                    }
                    return { ok: true, groupId, nodeIds };
                }

                if (action.name === "arrange_nodes") {
                    const requestedIds = stringValues("nodeIds");
                    const missingNodeId = validateNodeIds(requestedIds);
                    if (missingNodeId) return missingNodeResult(missingNodeId);
                    const targetNodes = requestedIds.length
                        ? requestedIds.map((nodeId) => getNode(nodeId)!)
                        : nodesRef.current.filter((node) => !node.metadata?.groupId && !node.metadata?.batchRootId);
                    if (!targetNodes.length) return { ok: true, arrangedNodeIds: [] };
                    const startX = Math.min(...targetNodes.map((node) => node.position.x));
                    const startY = Math.min(...targetNodes.map((node) => node.position.y));
                    const positions = new Map<string, Position>();
                    let x = startX;
                    let y = startY;
                    let rowHeight = 0;
                    targetNodes.forEach((node, index) => {
                        if (index > 0 && index % 4 === 0) {
                            x = startX;
                            y += rowHeight + 72;
                            rowHeight = 0;
                        }
                        positions.set(node.id, { x, y });
                        x += node.width + 72;
                        rowHeight = Math.max(rowHeight, node.height);
                    });
                    targetNodes
                        .filter((node) => node.type === CanvasNodeType.Group)
                        .forEach((group) => {
                            const groupPosition = positions.get(group.id);
                            if (!groupPosition) return;
                            const offsetX = groupPosition.x - group.position.x;
                            const offsetY = groupPosition.y - group.position.y;
                            nodesRef.current
                                .filter((node) => node.metadata?.groupId === group.id && !positions.has(node.id))
                                .forEach((node) => positions.set(node.id, { x: node.position.x + offsetX, y: node.position.y + offsetY }));
                        });
                    const nextNodes = nodesRef.current.map((node) => (positions.has(node.id) ? { ...node, position: positions.get(node.id)! } : node));
                    commitNodes(nextNodes);
                    return { ok: true, arrangedNodeIds: targetNodes.map((node) => node.id) };
                }

                if (action.name === "generate_image" || action.name === "edit_image" || action.name === "generate_video" || action.name === "generate_audio") {
                    const mode: CanvasNodeGenerationMode = action.name === "generate_video" ? "video" : action.name === "generate_audio" ? "audio" : "image";
                    const targetType = mode === "video" ? CanvasNodeType.Video : mode === "audio" ? CanvasNodeType.Audio : CanvasNodeType.Image;
                    const sourceNodeIds = Object.prototype.hasOwnProperty.call(args, "sourceNodeIds")
                        ? stringValues("sourceNodeIds")
                        : messageReferenceNodeIds;
                    const missingNodeId = validateNodeIds(sourceNodeIds);
                    if (missingNodeId) return missingNodeResult(missingNodeId);
                    const sourceNodes = sourceNodeIds.map((nodeId) => getNode(nodeId)!);
                    if (action.name === "edit_image" && !sourceNodes.some((node) => isCanvasImageNodeType(node.type) && Boolean(node.metadata?.content))) {
                        return { ok: false, code: "image_reference_required", message: "图片编辑需要至少一个已有内容的图片节点" };
                    }

                    const generationConfig = buildGenerationConfig(agentEffectiveConfig, undefined, mode);
                    const agentWorkflowRef = mode === "image" ? agentEffectiveConfig.imageWorkflowRef : mode === "video" ? agentEffectiveConfig.videoWorkflowRef : agentEffectiveConfig.audioWorkflowRef;
                    if (!agentWorkflowRef && (!generationConfig.model || !isAiConfigReady(generationConfig, generationConfig.model))) {
                        return { ok: false, code: "model_not_configured", message: "请先在全局配置中完成" + (mode === "video" ? "视频" : mode === "audio" ? "音频" : "图片") + "模型配置" };
                    }
                    if (agentWorkflowRef && !useUserStore.getState().token) return { ok: false, code: "login_required", message: "工作流生成需要先登录" };

                    const prompt = stringValue("prompt");
                    const metadata: CanvasNodeMetadata = {
                        prompt,
                        excludeUpstreamText: true,
                        status: "idle",
                        model: generationConfig.model,
                        workflowRef: agentWorkflowRef,
                        channelId: mode === "video" ? generationConfig.videoChannelId : mode === "audio" ? generationConfig.audioChannelId : generationConfig.imageChannelId,
                        size: stringValue("size") || generationConfig.size,
                    };
                    if (mode === "image") {
                        metadata.quality = generationConfig.quality;
                        metadata.count = typeof args.count === "number" ? Math.max(1, Math.floor(args.count)) : 1;
                    }
                    if (mode === "video") {
                        metadata.vquality = generationConfig.vquality;
                        const seconds = typeof args.seconds === "number" ? args.seconds : Number(generationConfig.videoSeconds);
                        const durationError = agentWorkflowRef ? "" : validateCanvasAgentVideoSeconds(generationConfig.model, seconds);
                        if (durationError) return { ok: false, code: "unsupported_duration", message: durationError, supported: canvasAgentVideoDurationHint(generationConfig.model) };
                        const generateAudio = typeof args.generateAudio === "boolean" ? args.generateAudio : generationConfig.videoGenerateAudio === "true";
                        if (!agentWorkflowRef && generateAudio && !supportsVideoAudioGeneration(generationConfig.model, channelProtocolForConfig(generationConfig))) {
                            return { ok: false, code: "video_audio_not_supported", message: "当前全局视频模型不支持视频原生声音" };
                        }
                        metadata.seconds = String(seconds);
                        metadata.generateAudio = String(generateAudio);
                    }
                    if (mode === "audio") {
                        if (isGeminiTtsModel(generationConfig.model) && isGeminiConfig(generationConfig, generationConfig.model)) {
                            metadata.geminiTtsVoice = stringValue("voice") || generationConfig.geminiTtsVoice;
                        } else if (isGlmTtsModel(generationConfig.model)) {
                            metadata.glmTtsVoice = stringValue("voice") || generationConfig.glmTtsVoice;
                            metadata.glmTtsFormat = generationConfig.glmTtsFormat;
                            metadata.glmTtsSpeed = generationConfig.glmTtsSpeed;
                        } else if (isGrok2APITtsConfig(generationConfig, generationConfig.model)) {
                            metadata.grokTtsVoice = stringValue("voice") || generationConfig.grokTtsVoice;
                            metadata.grokTtsLanguage = generationConfig.grokTtsLanguage;
                            metadata.grokTtsFormat = generationConfig.grokTtsFormat;
                            metadata.grokTtsSpeed = generationConfig.grokTtsSpeed;
                        } else {
                            metadata.audioVoice = stringValue("voice") || generationConfig.audioVoice;
                            metadata.audioInstructions = stringValue("instructions") || generationConfig.audioInstructions;
                        }
                    }

                    const layoutSourceNodes = mode === "image" ? [] : mode === "video" ? nodesRef.current.filter((node) => !node.metadata?.groupId && (node.type === CanvasNodeType.Text || isCanvasImageNodeType(node.type) || node.type === CanvasNodeType.Group)) : sourceNodes;
                    let node = createCanvasNode(targetType, nextNodeCenter(targetType, layoutSourceNodes), metadata);
                    if (mode === "video") node = applyNodeConfigPatch(node, { size: generationConfig.size });
                    node.title = stringValue("title") || prompt.slice(0, 32) || (mode === "video" ? "视频" : mode === "audio" ? "音频" : "图片");
                    const createdConnections = sourceNodeIds.map((sourceNodeId) => ({ id: nanoid(), fromNodeId: sourceNodeId, toNodeId: node.id }));
                    commitNodes([...nodesRef.current, node]);
                    commitConnections([...connectionsRef.current, ...createdConnections]);
                    selectOnly(node.id);

                    if (!resolvedAgentConfig.autoGenerateMedia) {
                        return {
                            ok: true,
                            message: "媒体节点已创建并完成参数配置，尚未提交生成",
                            submitted: false,
                            nodeId: node.id,
                            createdNodeIds: [node.id],
                            connectionIds: createdConnections.map((connection) => connection.id),
                            type: node.type,
                            status: "idle",
                        };
                    }

                    await handleGenerateNode(node.id, mode, prompt);
                    await new Promise<void>((resolve) => setTimeout(resolve, 0));
                    const generatedNode = getNode(node.id) || node;
                    const createdNodeIds = [
                        node.id,
                        ...connectionsRef.current.filter((connection) => connection.fromNodeId === node.id).map((connection) => connection.toNodeId),
                    ].filter((nodeId, index, values) => values.indexOf(nodeId) === index && Boolean(getNode(nodeId)));
                    const task = canvasAgentTaskSummary(generatedNode);
                    if (generatedNode.metadata?.status === NODE_STATUS_ERROR) {
                        return {
                            ok: false,
                            code: "generation_failed",
                            message: generatedNode.metadata.errorDetails || "生成失败",
                            nodeId: node.id,
                            createdNodeIds,
                            connectionIds: createdConnections.map((connection) => connection.id),
                            ...task,
                        };
                    }
                    return {
                        ok: true,
                        submitted: true,
                        nodeId: node.id,
                        createdNodeIds,
                        connectionIds: createdConnections.map((connection) => connection.id),
                        ...task,
                    };
                }

                return { ok: false, code: "unsupported_tool", message: "未实现工具 " + action.name };
            } catch (error) {
                return { ok: false, code: "tool_error", message: error instanceof Error ? error.message : "画布工具执行失败" };
            }
        },
        [agentEffectiveConfig, createGroupFromSelection, currentProject?.title, deleteConnection, deleteNodes, getCanvasCenter, handleGenerateNode, isAiConfigReady, projectId, renameProject, resolvedAgentConfig.autoGenerateMedia, updateProject],
    );

    const handleRetryNode = useCallback(
        async (node: CanvasNodeData) => {
            const sourceNode = findRetrySourceNode(node.id, nodesRef.current, connectionsRef.current) || node;
            const retryWorkflowRef = node.metadata?.workflowRef;
            const batchPrimaryId = retryWorkflowRef && isCanvasImageNodeType(node.type) && node.metadata?.isBatchRoot ? node.metadata.primaryImageId : undefined;
            const retryTargetId = batchPrimaryId && nodesRef.current.some((item) => item.id === batchPrimaryId) ? batchPrimaryId : node.id;
            const retryBatchRootId = retryWorkflowRef && isCanvasImageNodeType(node.type) ? (retryTargetId === node.id ? node.metadata?.batchRootId : node.id) : undefined;
            const retryBatchRoot = retryBatchRootId ? nodesRef.current.find((item) => item.id === retryBatchRootId) : null;
            const retryMirrorsRoot = retryBatchRoot?.metadata?.primaryImageId === retryTargetId;
            const isPanorama = isPanoramaNodeType(node.type);
            const batchRoot = node.metadata?.batchRootId ? nodesRef.current.find((item) => item.id === node.metadata?.batchRootId) : null;
            const savedImageMetadata = isCanvasImageNodeType(node.type) ? { ...batchRoot?.metadata, ...node.metadata } : undefined;
            const hasSavedImageMetadata = Boolean(savedImageMetadata?.generationType);
            const generationConfig =
                hasSavedImageMetadata && savedImageMetadata
                    ? {
                        ...effectiveConfig,
                        model: savedImageMetadata.model || effectiveConfig.imageModel || effectiveConfig.model,
                        imageChannelId: savedImageMetadata.channelId || effectiveConfig.imageChannelId,
                        activeChannelId: savedImageMetadata.channelId || effectiveConfig.imageChannelId,
                        quality: savedImageMetadata.quality || effectiveConfig.quality,
                        size: isPanorama ? PANORAMA_IMAGE_SIZE : savedImageMetadata.size || effectiveConfig.size,
                        count: "1",
                    }
                    : { ...buildGenerationConfig(effectiveConfig, sourceNode, node.type === CanvasNodeType.Text ? "text" : node.type === CanvasNodeType.Video ? "video" : node.type === CanvasNodeType.Audio ? "audio" : "image"), count: "1" };
            if (retryWorkflowRef && !useUserStore.getState().token) {
                message.error("工作流生成需要先登录");
                return;
            }
            const usesSaintDolaPool = node.type === CanvasNodeType.Video && isEmbeddedSaintCanvas() && isSaintDolaPoolModel(generationConfig.model);
            if (!retryWorkflowRef && !usesSaintDolaPool && !isAiConfigReady(generationConfig, generationConfig.model)) {
                openConfigDialog(true);
                return;
            }

            const context = hasSavedImageMetadata ? null : await hydrateNodeGenerationContext(buildNodeGenerationContext(sourceNode.id, nodesRef.current, connectionsRef.current, sourceNode.metadata?.prompt || node.metadata?.prompt || ""));
            const prompt = (isPanorama ? savedImageMetadata?.panoramaFinalPrompt || "" : savedImageMetadata?.prompt || context?.prompt || "").trim();
            const requestPrompt = isPanorama ? prompt : applyCameraPrompt(prompt, savedImageMetadata?.cameraControl || node.metadata?.cameraControl);
            if (!prompt && !retryWorkflowRef && !(node.type === CanvasNodeType.Video && isAutoDLConfig(generationConfig))) {
                message.warning("找不到提示词，无法重试");
                return;
            }
            const generationType = savedImageMetadata?.generationType;
            const useReferenceImages = generationType ? generationType === "edit" : Boolean(context?.referenceImages.length);
            const retryReferenceImages =
                hasSavedImageMetadata && savedImageMetadata ? await resolveMetadataReferences(savedImageMetadata) : useReferenceImages ? (context?.referenceImages.length ? context.referenceImages : sourceNodeReferenceImages(batchRoot || sourceNode)) : [];
            if (useReferenceImages && !retryReferenceImages) {
                message.error("参考图片已丢失，无法继续重试");
                setNodes((prev) => prev.map((item) => (item.id === node.id ? { ...item, metadata: { ...item.metadata, status: NODE_STATUS_ERROR, errorDetails: "参考图片已丢失，无法继续重试" } } : item)));
                return;
            }
            const retryImages = retryReferenceImages || [];

            setRunningNodeId(node.id);
            const retryStartedAt = Date.now();
            const retrySuffix = retryWorkflowRef ? nanoid() : node.id;
            const retryVideoTaskId = node.type === CanvasNodeType.Video ? `client_video_task_${retrySuffix}` : "";
            const retryImageTaskId = isCanvasImageNodeType(node.type) ? `client_image_task_${retrySuffix}` : "";
            const retryAudioTaskId = node.type === CanvasNodeType.Audio ? `client_audio_task_${retrySuffix}` : "";
            setNodes((prev) => prev.map((item) => {
                const isRetryTarget = item.id === retryTargetId;
                if (!isRetryTarget && !(retryMirrorsRoot && item.id === retryBatchRootId)) return item;
                return { ...item, metadata: { ...item.metadata, status: NODE_STATUS_LOADING, errorDetails: undefined, content: undefined, storageKey: "", progress: 0, startedAt: retryStartedAt, ...(item.type === CanvasNodeType.Video ? { videoTaskId: retryVideoTaskId, videoTaskVideoId: undefined } : {}), ...(isCanvasImageNodeType(item.type) ? { imageTaskId: isRetryTarget ? retryImageTaskId : undefined, imageTaskResultId: undefined } : {}), ...(item.type === CanvasNodeType.Audio ? { audioTaskId: retryAudioTaskId, audioTaskResultId: undefined } : {}) } };
            }));

            try {
                if (node.type === CanvasNodeType.Text) {
                    if (!context) return;
                    let streamed = "";
                    const answer = await requestImageQuestion(generationConfig, buildNodeChatMessages({ ...context, prompt }), (text) => {
                        streamed = text;
                        setNodes((prev) => prev.map((item) => (item.id === node.id ? { ...item, type: CanvasNodeType.Text, metadata: { ...item.metadata, content: text, status: NODE_STATUS_LOADING } } : item)));
                    });
                    setNodes((prev) => prev.map((item) => (item.id === node.id ? { ...item, type: CanvasNodeType.Text, metadata: { ...item.metadata, content: answer || streamed, prompt, status: NODE_STATUS_SUCCESS } } : item)));
                    return;
                }
                if (node.type === CanvasNodeType.Video) {
                    const videoGenerationConfig = retryWorkflowRef ? generationConfig : context ? withCanvasVideoAdvancedConfig(generationConfig, context) : generationConfig;
                    const frameReferencesEnabled = Boolean(retryWorkflowRef) || supportsVideoFrameReferences(videoGenerationConfig.model, channelProtocolForConfig(videoGenerationConfig));
                    const firstFrame = frameReferencesEnabled ? context?.firstFrame || null : null;
                    const lastFrame = frameReferencesEnabled ? context?.lastFrame || null : null;
                    const references = frameReferencesEnabled || isAutoDLConfig(videoGenerationConfig) ? retryImages : [...retryImages, ...[context?.firstFrame, context?.lastFrame].filter((image): image is ReferenceImage => Boolean(image))];
                    const useSaintDolaPool = isEmbeddedSaintCanvas() && !retryWorkflowRef && isSaintDolaPoolModel(videoGenerationConfig.model);
                    const task = retryWorkflowRef
                        ? await workflowVideoTask(await submitCanvasWorkflowTask(retryWorkflowRef, videoGenerationConfig, "video", requestPrompt, [firstFrame, ...references, lastFrame].filter((image): image is ReferenceImage => Boolean(image)), context?.referenceVideos || [], context?.referenceAudios || [], node.id, projectId, retryVideoTaskId))
                        : useSaintDolaPool
                            ? await requestSaintHostVideoTask({ source: "canvas", sourceId: projectId, nodeId: node.id, clientTaskId: retryVideoTaskId, prompt: requestPrompt, duration: Number(videoGenerationConfig.videoSeconds) || 30, resolution: "720p", aspectRatio: ratioFromCanvasSize(videoGenerationConfig.size), references, firstFrame, lastFrame, videoReferences: context?.referenceVideos || [], audioReferences: context?.referenceAudios || [] })
                        : (await createVideoGenerationTask(videoGenerationConfig, requestPrompt, { references, firstFrame, lastFrame, videoReferences: context?.referenceVideos || [], audioReferences: context?.referenceAudios || [] }, undefined, { clientTaskId: retryVideoTaskId, source: "canvas", sourceId: node.id })).task;
                    setNodes((prev) => applyCanvasVideoTaskUpdate(prev, node.id, task, videoGenerationConfig, retryStartedAt, { width: node.width, height: node.height }));
                    return;
                }
                if (node.type === CanvasNodeType.Audio) {
                    const workflowAudios = retryWorkflowRef ? context?.referenceAudios || [] : [];
                    const referenceAudio = retryWorkflowRef ? undefined : selectAudioReference(generationConfig, sourceNode?.metadata, context?.referenceAudios || []);
                    const task = retryWorkflowRef
                        ? await workflowAudioTask(await submitCanvasWorkflowTask(retryWorkflowRef, generationConfig, "audio", prompt, [], [], workflowAudios, node.id, projectId, retryAudioTaskId))
                        : await createCanvasAudioTask(generationConfig, prompt, { nodeId: node.id, sourceId: projectId, clientTaskId: retryAudioTaskId }, referenceAudio);
                    setNodes((prev) => applyCanvasAudioTaskUpdate(prev.map((item) => (item.id === node.id ? { ...item, metadata: { ...item.metadata, prompt, ...buildAudioGenerationMetadata(generationConfig, sourceNode?.metadata) } } : item)), node.id, task, retryStartedAt));
                    return;
                }

                const task = retryWorkflowRef
                    ? await workflowImageTask(await submitCanvasWorkflowTask(retryWorkflowRef, generationConfig, "image", requestPrompt, useReferenceImages ? retryImages : [], [], [], retryTargetId, projectId, retryImageTaskId))
                    : isEmbeddedSaintCanvas() && isHostDispatchedModel(generationConfig.model)
                        ? await requestSaintHostImageTask({ source: "canvas", sourceId: projectId, nodeId: retryTargetId, clientTaskId: retryImageTaskId, model: generationConfig.model, prompt: requestPrompt, count: "1", size: generationConfig.size, quality: generationConfig.quality, references: useReferenceImages ? retryImages : [] })
                        : await createCanvasImageTask({ ...generationConfig, quality: isPanorama && generationConfig.quality === "auto" ? "medium" : generationConfig.quality }, requestPrompt, useReferenceImages ? retryImages : [], { nodeId: node.id, sourceId: projectId, clientTaskId: retryImageTaskId });
                const generationMetadata = savedImageMetadata?.generationType
                    ? { generationType: savedImageMetadata.generationType, model: generationConfig.model, channelId: generationConfig.imageChannelId || generationConfig.activeChannelId, size: generationConfig.size, quality: generationConfig.quality, count: savedImageMetadata.count || 1, references: savedImageMetadata.references }
                    : buildImageGenerationMetadata(useReferenceImages ? "edit" : "generation", generationConfig, 1, retryImages);
                setNodes((prev) => {
                    const next = prev.map((item) =>
                        item.id === retryTargetId
                            ? {
                                ...item,
                                type: isPanoramaNodeType(item.type) ? CanvasNodeType.Panorama : CanvasNodeType.Image,
                                metadata: {
                                    ...item.metadata,
                                    ...(isPanoramaNodeType(item.type) ? { prompt: item.metadata?.panoramaSourcePrompt || item.metadata?.prompt || "", panoramaSourcePrompt: item.metadata?.panoramaSourcePrompt || item.metadata?.prompt || "", panoramaFinalPrompt: prompt, panoramaProjection: undefined } : { prompt }),
                                    ...generationMetadata,
                                    imageTaskId: task.id,
                                    imageTaskResultId: undefined,
                                    startedAt: parseCanvasTaskTime(task.started_at ?? task.startedAt ?? task.created_at ?? task.createdAt) || retryStartedAt,
                                    progress: task.progress || 0,
                                    errorDetails: undefined,
                                    // 065：重试走宿主通道时打标记（轮询兜底与失败推送匹配依赖它）
                                    ...(isEmbeddedSaintCanvas() && isHostDispatchedModel(generationConfig.model) && !retryWorkflowRef ? { hostImageTask: true } : {}),
                                },
                            }
                            : item,
                    );
                    return task.source === "workflow" || task.image_url || task.url ? applyCanvasImageTaskUpdate(next, retryTargetId, task, retryStartedAt, { width: node.width, height: node.height }) : next;
                });
                if (task.source === "workflow" || task.image_url || task.url) setConnections((prev) => applyCanvasImageTaskConnections(prev, retryTargetId, task, retryBatchRootId));
            } catch (error) {
                const errorDetails = error instanceof Error ? error.message : "生成失败";
                message.error(errorDetails);
                if (retryWorkflowRef && isCanvasImageNodeType(node.type)) {
                    const failedTask: CanvasImageTask = { id: retryImageTaskId, source: "workflow", status: "failed", error: { message: errorDetails } };
                    setNodes((prev) => applyCanvasImageTaskUpdate(prev, retryTargetId, failedTask, retryStartedAt, { width: node.width, height: node.height }));
                    setConnections((prev) => applyCanvasImageTaskConnections(prev, retryTargetId, failedTask, retryBatchRootId));
                } else {
                    setNodes((prev) => prev.map((item) => (item.id === retryTargetId || (retryMirrorsRoot && item.id === retryBatchRootId) ? { ...item, metadata: { ...item.metadata, status: NODE_STATUS_ERROR, errorDetails } } : item)));
                }
            } finally {
                setRunningNodeId(null);
            }
        },
        [effectiveConfig, message, openConfigDialog, projectId, requestSaintHostVideoTask],
    );

    const handleSimulateSaintFailure = useCallback(async (node: CanvasNodeData) => {
        if (node.type !== CanvasNodeType.Video || !isEmbeddedSaintCanvas()) return;
        const generationConfig = buildGenerationConfig(effectiveConfig, node, "video");
        const startedAt = Date.now();
        const clientTaskId = `canvas_failure_test_${node.id}_${nanoid()}`;
        setRunningNodeId(node.id);
        setNodes((prev) => prev.map((item) => item.id === node.id ? {
            ...item,
            metadata: {
                ...item.metadata,
                status: NODE_STATUS_LOADING,
                progress: 10,
                startedAt,
                durationMs: undefined,
                errorDetails: undefined,
                statusMessage: "正在执行失败回传测试",
                stage: "testing",
                stageLabel: "正在执行失败回传测试",
                generationMessage: "正在执行失败回传测试",
                videoTaskId: clientTaskId,
                videoTaskVideoId: undefined,
            },
        } : item));
        try {
            const task = await requestSaintHostVideoTask({
                source: "canvas",
                sourceId: projectId,
                nodeId: node.id,
                clientTaskId,
                testFailure: true,
                prompt: "画布失败回传测试",
                duration: Number(generationConfig.videoSeconds) || 30,
                resolution: "720p",
                aspectRatio: ratioFromCanvasSize(generationConfig.size),
            });
            setNodes((prev) => applyCanvasVideoTaskUpdate(prev, node.id, task, generationConfig, startedAt, { width: node.width, height: node.height }));
        } catch (error) {
            const errorDetails = error instanceof Error ? error.message : "失败回传测试无法启动";
            setNodes((prev) => prev.map((item) => item.id === node.id ? {
                ...item,
                metadata: {
                    ...item.metadata,
                    status: NODE_STATUS_ERROR,
                    progress: 100,
                    errorDetails,
                    statusMessage: errorDetails,
                    stage: "failed",
                    stageLabel: "Dola 生成失败",
                    generationMessage: errorDetails,
                    durationMs: Date.now() - startedAt,
                },
            } : item));
            message.error(errorDetails);
        } finally {
            setRunningNodeId(null);
        }
    }, [effectiveConfig, message, projectId, requestSaintHostVideoTask]);

    const generateImageFromTextNode = useCallback(
        (node: CanvasNodeData) => {
            const prompt = (node.metadata?.content || node.metadata?.prompt || "").trim();
            if (!prompt) {
                message.warning("文本节点为空，无法生图");
                return;
            }
            const sourceNode = nodesRef.current.find((item) => item.id === node.id);
            if (!sourceNode) return;
            const nodeSize = getNodeSpec(CanvasNodeType.Config);
            const configNode = createCanvasNode(
                CanvasNodeType.Config,
                {
                    x: sourceNode.position.x + sourceNode.width + 96 + nodeSize.width / 2,
                    y: sourceNode.position.y + sourceNode.height / 2,
                },
                {
                    prompt: "",
                    model: effectiveConfig.imageModel || effectiveConfig.model,
                    size: effectiveConfig.size,
                    count: getGenerationCount(effectiveConfig.canvasImageCount || effectiveConfig.count),
                },
            );
            const connection = { id: nanoid(), fromNodeId: sourceNode.id, toNodeId: configNode.id };
            const nextNodes = nodesRef.current.map((item) => (item.id === sourceNode.id ? { ...item, metadata: { ...item.metadata, content: prompt, prompt, status: NODE_STATUS_SUCCESS } } : item)).concat(configNode);
            const nextConnections = [...connectionsRef.current, connection];
            nodesRef.current = nextNodes;
            connectionsRef.current = nextConnections;
            setNodes(nextNodes);
            setConnections(nextConnections);
            setSelectedNodeIds(new Set([configNode.id]));
            setSelectedConnectionId(null);
            setDialogNodeId(configNode.id);
        },
        [effectiveConfig.canvasImageCount, effectiveConfig.count, effectiveConfig.imageModel, effectiveConfig.model, effectiveConfig.size, message],
    );

    const insertAssistantImage = useCallback(
        async (image: CanvasAssistantImage, position?: Position, nodeId?: string) => {
            const storedImage = { url: image.dataUrl, storageKey: image.storageKey || "", width: 1, height: 1, bytes: 0, mimeType: "image/png" };
            const meta = storedImage.width === 1 && storedImage.height === 1 ? await readImageMeta(storedImage.url) : storedImage;
            const config = normalizeNodeSize(meta.width, meta.height);
            const center = position || screenToCanvas((containerRef.current?.getBoundingClientRect().left || 0) + size.width / 2, (containerRef.current?.getBoundingClientRect().top || 0) + size.height / 2);
            const id = nodeId || `image-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
            const node: CanvasNodeData = {
                id,
                type: CanvasNodeType.Image,
                title: image.prompt.slice(0, 32) || "Generated Image",
                position: { x: center.x - config.width / 2, y: center.y - config.height / 2 },
                width: config.width,
                height: config.height,
                metadata: { ...imageMetadata({ ...storedImage, width: meta.width, height: meta.height }), prompt: image.prompt },
            };

            setNodes((prev) => [...prev, node]);
            setSelectedNodeIds(new Set([id]));
            setSelectedConnectionId(null);
            setDialogNodeId(id);
        },
        [screenToCanvas, size.height, size.width],
    );

    const insertAssetAtRef = useRef(insertAssetAt);
    useLayoutEffect(() => {
        insertAssetAtRef.current = insertAssetAt;
    });

    useEffect(() => {
        if (!projectLoaded || consumedAgentRequestProjectRef.current === projectId) return;
        const request = useCanvasStore.getState().projects.find((project) => project.id === projectId)?.pendingAgentRequest;
        if (!request) return;
        consumedAgentRequestProjectRef.current = projectId;

        void (async () => {
            const center = getCanvasCenter();
            const references: CanvasAssistantReference[] = [];
            for (const [index, asset] of request.assets.entries()) {
                let payload = asset.payload;
                if (payload.kind === "image" && payload.storageKey) {
                    const dataUrl = await resolveImageUrl(payload.storageKey, payload.dataUrl);
                    payload = { ...payload, dataUrl };
                } else if ((payload.kind === "video" || payload.kind === "audio") && payload.storageKey) {
                    const url = await resolveMediaUrl(payload.storageKey, payload.url);
                    payload = { ...payload, url };
                }
                const position = { x: center.x + (index - (request.assets.length - 1) / 2) * 360, y: center.y };
                await insertAssetAtRef.current(payload, position, asset.nodeId);
                references.push(
                    payload.kind === "image"
                        ? { ...asset.reference, dataUrl: payload.dataUrl }
                        : payload.kind === "video" || payload.kind === "audio"
                            ? { ...asset.reference, url: payload.url }
                            : asset.reference,
                );
            }
            updateProject(projectId, { pendingAgentRequest: undefined });
            setInitialAgentRequest({ prompt: request.prompt, references, skills: request.skills });
        })().catch((error) => {
            consumedAgentRequestProjectRef.current = null;
            message.error(error instanceof Error ? error.message : "首页素材插入失败");
        });
    }, [getCanvasCenter, message, projectId, projectLoaded, updateProject]);
    const handleAssetInsert = useCallback(
        (payload: InsertAssetPayload) => {
            const position = assetInsertPositionRef.current || undefined;
            assetInsertPositionRef.current = null;
            void insertAssetAtRef.current(payload, position);
            setAssetPickerOpen(false);
        },
        [],
    );

    // 026：素材弹窗框选多选 → 整批插入（以基准位置为原点，每个错开 48px 避免完全重叠）
    const handleAssetInsertBatch = useCallback(
        (payloads: InsertAssetPayload[]) => {
            if (!payloads?.length) return;
            const base = assetInsertPositionRef.current
                || screenToCanvas(
                    (containerRef.current?.getBoundingClientRect().left || 0) + size.width / 2,
                    (containerRef.current?.getBoundingClientRect().top || 0) + size.height / 2,
                );
            assetInsertPositionRef.current = null;
            payloads.forEach((payload, index) => {
                void insertAssetAtRef.current(payload, { x: base.x + index * 48, y: base.y + index * 48 });
            });
            setAssetPickerOpen(false);
        },
        [screenToCanvas, size.height, size.width],
    );

    // 030：分类库选中的素材 → 直接插到目标节点右侧并自动连线为参考（多个时错开 48px）
    const handleLibraryAssetInsert = useCallback(
        (payloads: InsertAssetPayload[]) => {
            if (!payloads?.length || !categoryLibrary) return;
            const target = nodesRef.current.find((item) => item.id === categoryLibrary.nodeId);
            setCategoryLibrary(null);
            if (!target) return;
            payloads.forEach((payload, index) => {
                const newId = `${payload.kind}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
                const position = { x: target.position.x + target.width + 60 + index * 48, y: target.position.y + index * 48 };
                void insertAssetAtRef.current(payload, position, newId);
                setConnections((prev) => (prev.some((conn) => conn.fromNodeId === newId && conn.toNodeId === target.id) ? prev : [...prev, { id: `conn-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, fromNodeId: newId, toNodeId: target.id }]));
            });
            message.success(`已添加 ${payloads.length} 个素材并连线为参考`);
        },
        [categoryLibrary, message],
    );

    const focusNode = useCallback(
        (nodeId: string) => {
            const node = nodesRef.current.find((item) => item.id === nodeId);
            if (!node) return;
            const rootId = node.metadata?.batchRootId;
            if (rootId && !nodesRef.current.find((item) => item.id === rootId)?.metadata?.imageBatchExpanded) {
                toggleBatchExpanded(rootId);
            }
            const worldX = node.position.x + node.width / 2;
            const worldY = node.position.y + node.height / 2;
            const k = Math.min(Math.max(Math.min((size.width * 0.6) / node.width, (size.height * 0.6) / node.height), 0.05), 1);
            const target = { x: size.width / 2 - worldX * k, y: size.height / 2 - worldY * k, k };
            setSelectedNodeIds(new Set([node.id]));
            setSelectedConnectionId(null);
            setContextMenu(null);
            if (focusAnimationRef.current) cancelAnimationFrame(focusAnimationRef.current);
            const start = { ...viewportRef.current };
            const duration = 450;
            let startTime: number | null = null;
            const step = (now: number) => {
                if (!startTime) startTime = now;
                const progress = Math.min(1, (now - startTime) / duration);
                const eased = 1 - Math.pow(1 - progress, 3);
                const next = { x: start.x + (target.x - start.x) * eased, y: start.y + (target.y - start.y) * eased, k: start.k + (target.k - start.k) * eased };
                viewportRef.current = next;
                setViewport(next);
                focusAnimationRef.current = progress < 1 ? requestAnimationFrame(step) : null;
            };
            focusAnimationRef.current = requestAnimationFrame(step);
        },
        [size.height, size.width, toggleBatchExpanded],
    );

    useEffect(() => () => {
        if (focusAnimationRef.current) cancelAnimationFrame(focusAnimationRef.current);
    }, []);

    // 提示词面板渲染器（供画布节点与屏幕空间悬浮层复用）
    const renderNodePanel = useCallback(
        (panelNode: CanvasNodeData) =>
            panelNode.type === CanvasNodeType.Config ? (
                <CanvasConfigComposer
                    value={panelNode.metadata?.composerContent ?? panelNode.metadata?.prompt ?? ""}
                    inputs={configInputsById.get(panelNode.id) || []}
                    onChange={(composerContent) => handleConfigNodeChange(panelNode.id, { composerContent })}
                    onClose={() => setDialogNodeId(null)}
                />
            ) : panelNode.type === CanvasNodeType.Director ? null : (
                <CanvasNodePromptPanel
                    node={panelNode}
                    /* boss 2026-10-07 批次 125：生成动画（粒子流+按钮 spinner）只看瞬态 runningNodeId 会在任务派发完成后（几秒）消失——
                       补上节点级持久状态 status==="loading"：生成全程动画持续；关闭面板不渲染；重新点击生成中的节点动画恢复；生成完毕 status 离开 loading 自动还原 */
                    isRunning={runningNodeId === panelNode.id || panelNode.metadata?.status === NODE_STATUS_LOADING}
                    mentionReferences={mentionReferencesByNodeId.get(panelNode.id) || []}
                    connectedNodes={connectedNodesByNodeId.get(panelNode.id) || []}
                    videoFrameOptions={videoFrameOptionsByNodeId.get(panelNode.id) || []}
                    videoResourceOptions={videoResourceOptionsByNodeId.get(panelNode.id) || []}
                    onPromptChange={handleNodePromptChange}
                    onConfigChange={handleConfigNodeChange}
                    onGenerate={handleGenerateNode}
                    onDisconnectReference={disconnectNodeReference}
                    onReorderReference={(orderedFromNodeIds) => reorderNodeReferences(panelNode.id, orderedFromNodeIds)}
                    onStartReferenceSelection={startNodeReferenceSelection}
                    onOpenCategoryLibrary={(libraryNodeId, category) => setCategoryLibrary({ nodeId: libraryNodeId, category })}
                    onImageSettingsOpenChange={(open) => {
                        setNodeImageSettingsOpen(open);
                        if (open) setToolbarNodeId(null);
                    }}
                />
            ),
        [
            configInputsById,
            connectedNodesByNodeId,
            disconnectNodeReference,
            handleConfigNodeChange,
            handleGenerateNode,
            handleNodePromptChange,
            mentionReferencesByNodeId,
            reorderNodeReferences,
            runningNodeId,
            startNodeReferenceSelection,
            videoFrameOptionsByNodeId,
            videoResourceOptionsByNodeId,
        ],
    );

    // 屏幕空间悬浮面板：面板不在画布缩放层内（缩放层的小数偏移会让文字发虚），
    // 位置按整像素对齐渲染，任何缩放级别下文字都是清晰的
    // boss 2026-10-07：编辑态（旋转与镜像 / 涂鸦标注）中不弹提示词浮栏——渲染层兜底，任何路径设置的 dialogNodeId 都不显示；保存确定后重新点击图片才出现
    const floatingPanelNode = dialogNodeId && !selectionBox && !transformNodeId && !annotateNodeId ? nodes.find((node) => node.id === dialogNodeId) || null : null;
    const floatingPanelWidth = floatingPanelNode
        ? isCanvasImageNodeType(floatingPanelNode.type) || floatingPanelNode.type === CanvasNodeType.Video || floatingPanelNode.type === CanvasNodeType.Audio
            ? 660
            : 440
        : 0;

    if (!projectLoaded) return <CanvasRefreshShell />;
    return (
        <main
            className="flex h-full min-h-0 overflow-hidden"
            style={{ background: theme.canvas.background, color: theme.node.text }}
            onPointerDownCapture={(event) => {
                const panel = document.querySelector("[data-canvas-agent-panel]");
                const selection = window.getSelection();
                if (selection?.toString() && panel?.contains(selection.anchorNode) && !panel.contains(event.target as Node)) selection.removeAllRanges();
            }}
        >
            <section className="relative min-w-0 flex-1 overflow-hidden">
                {/* 资产面板：覆盖在画布左侧，锚定左下角，由“资产管理”按钮或面板内 « 按钮开关 */}
                <CanvasSidePanel
                    nodes={nodes}
                    selectedNodeIds={selectedNodeIds}
                    open={sidePanel.open}
                    width={sidePanel.width}
                    onWidthChange={handleSidePanelWidthChange}
                    onClose={() => setSidePanel((current) => ({ ...current, open: false }))}
                    onFocusNode={focusNode}
                    onAssetDragStart={(payload) => {
                        draggedAssetPayloadRef.current = payload;
                    }}
                    onAssetDragEnd={() => {
                        window.setTimeout(() => {
                            draggedAssetPayloadRef.current = null;
                        }, 0);
                    }}
                    onInsertAsset={handleAssetInsert}
                />
                {/* rf8HzD：左侧面板停靠推开——面板改为“占位式”停靠：TopBar+画布区+底栏+缩放控件包进本容器，
                    left 随面板开合/宽度推移（0.3s cubic-bezier(0.22,1,0.36,1)，与 CanvasSidePanel 动画同时长同缓动——
                    boss 2026-10-07 批次 124：0.5s→0.3s 且两侧同为 CSS transition，共享合成时钟合并 reflow，优化卡顿），
                    面板不再覆盖画布与顶栏内容。注意：容器不得加 transform/will-change，否则会劫持内部 fixed 元素的 containing block。 */}
                <div
                    className="absolute inset-y-0 right-0 overflow-hidden"
                    style={{
                        left: sidePanel.open ? sidePanel.width : 0,
                        transition: sidePanelResizing ? "none" : "left 0.3s cubic-bezier(0.22, 1, 0.36, 1)",
                    }}
                >
                <CanvasTopBar
                    title={currentProject?.title || "未命名画布"}
                    sidePanelOpen={sidePanel.open}
                    onToggleSidePanel={() => setSidePanel((current) => ({ ...current, open: !current.open }))}
                    titleDraft={titleDraft}
                    isTitleEditing={titleEditing}
                    onTitleDraftChange={setTitleDraft}
                    onStartTitleEditing={startTitleEditing}
                    onFinishTitleEditing={finishTitleEditing}
                    onCancelTitleEditing={() => setTitleEditing(false)}
                    canUndo={historyState.canUndo}
                    canRedo={historyState.canRedo}
                    onHome={() => router.push("/")}
                    onProjects={() => router.push("/canvas")}
                    onCreateProject={createAndOpenProject}
                    onDeleteProject={deleteCurrentProject}
                    onImportImage={() => handleUploadRequest()}
                    onUndo={undoCanvas}
                    onRedo={redoCanvas}
                />

                <NovusAI
                    containerRef={containerRef}
                    viewport={viewport}
                    screenOverlay={
                        floatingPanelNode && floatingPanelNode.type !== CanvasNodeType.Director ? (
                            <div
                                className="absolute z-[70] max-w-[calc(100vw-24px)]"
                                data-canvas-no-zoom
                                style={{
                                    // 位置按整像素对齐：文字不落小数偏移，任何缩放都清晰
                                    left: Math.round((floatingPanelNode.position.x + floatingPanelNode.width / 2) * viewport.k + viewport.x),
                                    // 真值（LibTV GeneratorMainColumn 包装）：卡片 absolute -bottom-4 left-1/2 translate-y-full
                                    // = 卡片顶边距节点底边 16px（画布坐标、随缩放），水平居中于节点，双向跟随
                                    top: Math.round((floatingPanelNode.position.y + floatingPanelNode.height + 16) * viewport.k + viewport.y),
                                    width: floatingPanelWidth,
                                    transform: "translateX(-50%)",
                                }}
                            >
                                {renderNodePanel(floatingPanelNode)}
                            </div>
                        ) : null
                    }
                    tool={canvasTool}
                    backgroundMode={backgroundMode}
                    onViewportChange={(next) => {
                        setViewport(next);
                        setContextMenu(null);
                    }}
                    onCanvasMouseDown={(event) => {
                        if (!referencePickerNodeId) handleCanvasMouseDown(event);
                    }}
                    onCanvasDeselect={referencePickerNodeId ? undefined : deselectCanvas}
                    panRegionBounds={selectionProxyFrame && !selectionBox ? selectionProxyFrame : null}
                    onPanRegionPointerDown={() => {
                        setContextMenu(null);
                        setNodeCreatePosition(null);
                        if (pendingConnectionCreateRef.current) cancelPendingConnectionCreate();
                    }}
                    onSelectionAreaDragStart={startSelectionAreaDrag}
                    onPanningChange={(panning) => {
                        canvasPanningRef.current = panning;
                        setCanvasPanning(panning);
                    }}
                    onCanvasDoubleClick={(event) => {
                        if (referencePickerNodeId) return;
                        setContextMenu(null);
                        setNodeCreateAnchor(null);
                        setNodeCreatePosition(screenToCanvas(event.clientX, event.clientY));
                    }}
                    onContextMenu={preventCanvasContextMenu}
                    onDrop={handleDrop}
                >
                    {alignGuides.vLines.map((x) => (
                        <div
                            key={`align-v-${x}`}
                            className="pointer-events-none absolute"
                            style={{ left: x, top: -viewport.y / viewport.k, width: 0, height: size.height / viewport.k, borderLeftWidth: "calc(1px * var(--canvas-inverse-scale))", borderLeftStyle: "dashed", borderColor: "rgba(110,126,255,.8)" }}
                        />
                    ))}
                    {alignGuides.hLines.map((y) => (
                        <div
                            key={`align-h-${y}`}
                            className="pointer-events-none absolute"
                            style={{ top: y, left: -viewport.x / viewport.k, height: 0, width: size.width / viewport.k, borderTopWidth: "calc(1px * var(--canvas-inverse-scale))", borderTopStyle: "dashed", borderColor: "rgba(110,126,255,.8)" }}
                        />
                    ))}
                    <svg className="absolute left-0 top-0 h-[10000px] w-[10000px] overflow-visible" style={{ pointerEvents: "none", transform: "translateZ(0)", zIndex: 6, display: hideConnections ? "none" : undefined }}>
                        {visibleConnections.map((connection) => {
                            const from = nodeById.get(connection.fromNodeId);
                            const to = nodeById.get(connection.toNodeId);
                            if (!from || !to) return null;

                            return (
                                <ConnectionPath
                                    key={connection.id}
                                    connection={connection}
                                    from={from}
                                    to={to}
                                    active={
                                        selectedConnectionId === connection.id ||
                                        selectedConnectionIds.has(connection.id) ||
                                        relatedHighlight.connectionIds.has(connection.id)
                                    }
                                    onSelect={() => {
                                        setSelectedConnectionId(connection.id);
                                        setSelectedConnectionIds(new Set());
                                        setSelectedNodeIds(new Set());
                                        setToolbarNodeId(null);
                                        setContextMenu(null);
                                    }}
                                    onContextMenu={(event) => {
                                        setSelectedConnectionId(connection.id);
                                        setSelectedConnectionIds(new Set());
                                        setSelectedNodeIds(new Set());
                                        setToolbarNodeId(null);
                                        setContextMenu({ type: "connection", x: event.clientX, y: event.clientY, connectionId: connection.id });
                                    }}
                                />
                            );
                        })}
                        {connectingParams ? <ActiveConnectionPath node={nodeById.get(connectingParams.nodeId)} handle={connectingParams} mouseWorld={mouseWorld} target={connectionTargetNodeId ? nodeById.get(connectionTargetNodeId) : undefined} /> : null}
                    </svg>

                    {visibleNodes.map((node) => (
                        <Fragment key={node.id}>
                        <CanvasNode
                            key={node.id}
                            data={node}
                            scale={viewport.k}
                            screenBorder={nodeScreenBorder(node, relatedHighlight.nodeIds) ?? undefined}
                            isSelected={selectedNodeIds.has(node.id)}
                            isRelated={relatedHighlight.nodeIds.has(node.id)}
                            isFocusRelated={activeNodeId === node.id}
                            isConnectionTarget={connectionTargetNodeId === node.id}
                            isConnecting={Boolean(connectingParams)}
                            isConnectingFrom={connectingParams}
                            referenceSelectionState={!referencePickerNodeId ? undefined : node.id === referencePickerNodeId ? "target" : referenceConnectedNodeIds.has(node.id) || !isCanvasReferenceNode(node) ? "disabled" : "available"}
                            showPanel={false}
                            batchCount={batchChildCountById.get(node.id) || 0}
                            groupChildCount={groupChildCountById.get(node.id) || 0}
                            isGroupDropTarget={dropTargetGroupId === node.id}
                            batchExpanded={Boolean(node.metadata?.imageBatchExpanded)}
                            batchClosing={Boolean(node.metadata?.batchRootId && collapsingBatchIds.has(node.metadata.batchRootId))}
                            batchOpening={openingBatchIds.has(node.id)}
                            batchRecovering={collapsingBatchIds.has(node.id)}
                            batchMotion={batchMotionById.get(node.id)}
                            showImageInfo={showImageInfo}
                            mentionReferences={mentionReferencesByNodeId.get(node.id) || []}
                            now={node.metadata?.status === NODE_STATUS_LOADING && !node.metadata.content && (node.type === CanvasNodeType.Video || isCanvasImageNodeType(node.type) || node.type === CanvasNodeType.Audio) ? canvasNow : undefined}
                            renderPanel={renderNodePanel}
                            renderNodeContent={(contentNode) =>
                                contentNode.type === CanvasNodeType.Director ? (
                                    <CanvasDirectorNodePanel onOpen={() => setOpenDirectorNodeId(contentNode.id)} />
                                ) : (
                                    <CanvasConfigNodePanel
                                        node={contentNode}
                                        isRunning={runningNodeId === contentNode.id}
                                        inputSummary={getInputSummary(configInputsById.get(contentNode.id) || [])}
                                        videoFrameOptions={videoFrameOptionsByNodeId.get(contentNode.id) || []}
                                        videoResourceOptions={videoResourceOptionsByNodeId.get(contentNode.id) || []}
                                        onConfigChange={handleConfigNodeChange}
                                        onComposerToggle={() => setDialogNodeId((current) => (current === contentNode.id ? null : contentNode.id))}
                                        onGenerate={(nodeId) => {
                                            const target = nodesRef.current.find((item) => item.id === nodeId);
                                            void handleGenerateNode(nodeId, target?.metadata?.generationMode || "image", target?.metadata?.composerContent ?? target?.metadata?.prompt ?? "");
                                        }}
                                    />
                                )
                            }
                            onMouseDown={handleNodeMouseDown}
                            onHoverStart={(nodeId) => {
                                if (nodeDraggingRef.current || canvasPanningRef.current) return;
                                setHoveredNodeId(nodeId);
                            }}
                            onHoverEnd={(nodeId) => {
                                if (canvasPanningRef.current) return;
                                setHoveredNodeId((current) => (current === nodeId ? null : current));
                            }}
                            onConnectStart={handleConnectStart}
                            onResize={handleNodeResize}
                            onContentChange={handleNodeContentChange}
                            onTitleChange={handleNodeTitleChange}
                            onToggleBatch={toggleBatchExpanded}
                            onSetBatchPrimary={setBatchPrimary}
                            onRetry={(node) => void handleRetryNode(node)}
                            onViewImage={(node) => setPreviewNodeId(node.id)}
                            onSelectReference={selectNodeReference}
                            onContextMenu={(event, id) => {
                                event.preventDefault();
                                event.stopPropagation();
                                setDialogNodeId(null);
                                // 多选状态下右键已选中的节点：弹「选择菜单」（整理/排序），保留多选
                                if (selectedNodeIdsRef.current.has(id) && selectedNodeIdsRef.current.size > 1) {
                                    setToolbarNodeId(null);
                                    setContextMenu({ type: "selection", x: event.clientX, y: event.clientY });
                                    return;
                                }
                                setSelectedNodeIds(new Set([id]));
                                setSelectedConnectionId(null);
                                setToolbarNodeId(null);
                                setContextMenu({ type: "node", x: event.clientX, y: event.clientY, nodeId: id });
                            }}
                        />
                        {/* 078：非编辑态笔迹显示层（编辑中的节点由 ImageDoodleEditor 负责渲染）
                            任务rvgR9q：本层在画布变换层内，DoodleStrokesOverlay 已改用画布坐标（不再传 viewport） */}
                        {node.id !== annotateNodeId && node.metadata?.doodleStrokes?.length ? (
                            <DoodleStrokesOverlay node={node} />
                        ) : null}
                        </Fragment>
                    ))}

                    {selectionProxyFrame && !selectionBox && !singleSelectedGroup ? (
                        <>
                            {/* 框内空白处抓手热区：压在节点下方，空白拖动即平移画布 */}
                            <div
                                className="absolute"
                                style={{ left: selectionProxyFrame.left, top: selectionProxyFrame.top, width: selectionProxyFrame.right - selectionProxyFrame.left, height: selectionProxyFrame.bottom - selectionProxyFrame.top, cursor: canvasPanning ? "grabbing" : "grab", zIndex: 0 }}
                                onContextMenu={(event) => {
                                    if (selectedNodeIds.size < 2) return;
                                    event.preventDefault();
                                    event.stopPropagation();
                                    setContextMenu({ type: "selection", x: event.clientX, y: event.clientY });
                                }}
                            />
                            <svg className="pointer-events-none absolute left-0 top-0 z-[34] h-[10000px] w-[10000px] overflow-visible">
                                {/* 组选中时组框自带蓝边，不再叠加代理虚线框 */}
                                {!selectionProxyFrame.isGroupFrame ? (
                                    <rect
                                        x={selectionProxyFrame.left - 14}
                                        y={selectionProxyFrame.top - 14}
                                        width={selectionProxyFrame.right - selectionProxyFrame.left + 28}
                                        height={selectionProxyFrame.bottom - selectionProxyFrame.top + 28}
                                        rx={12 / viewport.k}
                                        fill={theme.canvas.selectionFill}
                                        stroke={theme.canvas.selectionStroke}
                                        strokeWidth={0.8 / viewport.k}
                                        strokeOpacity={0.55}
                                        strokeDasharray={`${4 / viewport.k} ${4 / viewport.k}`}
                                    />
                                ) : null}
                                {selectionConnectionDrag || pendingConnectionCreate?.selection
                                    ? selectionProxyNodes.map((node) => {
                                          const startX = node.position.x + node.width;
                                          const startY = node.position.y + node.height / 2;
                                          // 菜单垂直居中于松手点，汇聚线终点即松手点（菜单左缘中点）
                                          const endX = selectionConnectionDrag ? mouseWorld.x : pendingConnectionCreate!.position.x;
                                          const endY = selectionConnectionDrag ? mouseWorld.y : pendingConnectionCreate!.position.y;
                                          const pathD = buildConnectionPath(startX, startY, endX, endY);
                                          return (
                                              <g key={`selection-drag-line-${node.id}`}>
                                                  {/* 汇聚线：与默认连线同色（哑光灰细线） */}
                                                  <path d={pathD} fill="none" stroke={theme.node.faint} strokeWidth={1.5 / viewport.k} />
                                              </g>
                                          );
                                      })
                                    : null}
                            </svg>
                            <OriginalMultiSelectionToolbar
                                left={(selectionProxyFrame.left + selectionProxyFrame.right) / 2}
                                top={selectionProxyFrame.top - 14}
                                onSave={() => {
                                    // 029：先弹分类选择再入库
                                    const nodes = selectionProxyNodes.filter((node) => isCanvasReferenceNode(node));
                                    if (nodes.length) setAssetSavePending(nodes);
                                }}
                                onCopy={() => {
                                    copySelectedNodes();
                                    pasteCopiedNodes();
                                }}
                                onGroup={() => createGroupFromSelection([...selectedNodeIds])}
                                onDownload={() => downloadNodesBatch(selectionProxyNodes)}
                            />
                            <FloatingConnectPlus
                                bounds={selectionProxyFrame}
                                theme={theme}
                                screenToCanvas={screenToCanvas}
                                onConnectStart={handleSelectionConnectStart}
                                sourceNodeIds={selectionProxyNodes.map((node) => node.id)}
                                dragging={Boolean(selectionConnectionDrag || pendingConnectionCreate?.selection)}
                                dragWorld={selectionConnectionDrag ? mouseWorld : pendingConnectionCreate?.selection ? pendingConnectionCreate.position : null}
                            />
                        </>
                    ) : null}

                    {/* 组工具栏：仅选中单个 Group 时显示，与多选工具栏互斥 */}
                    {singleSelectedGroup && !selectionBox ? (
                        <OriginalGroupToolbar
                            left={singleSelectedGroup.position.x + singleSelectedGroup.width / 2}
                            top={singleSelectedGroup.position.y - 14}
                            groupId={singleSelectedGroup.id}
                            groupColor={singleSelectedGroup.metadata?.groupColor ?? null}
                            onColorChange={(color) => handleGroupColorChange(singleSelectedGroup.id, color)}
                            onUngroup={ungroupSelection}
                            onLayoutChange={(mode) => layoutGroupChildren(singleSelectedGroup.id, mode)}
                            onDownloadAll={() => {
                                const children = nodes.filter((node) => node.metadata?.groupId === singleSelectedGroup.id);
                                downloadNodesBatch(children);
                            }}
                        />
                    ) : null}

                    {selectionBox ? (
                        <svg
                            className="pointer-events-none absolute z-[100] overflow-visible"
                            style={{
                                left: Math.min(selectionBox.startWorldX, selectionBox.currentWorldX),
                                top: Math.min(selectionBox.startWorldY, selectionBox.currentWorldY),
                                width: Math.abs(selectionBox.currentWorldX - selectionBox.startWorldX),
                                height: Math.abs(selectionBox.currentWorldY - selectionBox.startWorldY),
                            }}
                        >
                            <rect width="100%" height="100%" rx={8 / viewport.k} fill={theme.canvas.selectionFill} stroke={theme.canvas.selectionStroke} strokeWidth={0.8 / viewport.k} strokeDasharray={`${6 / viewport.k} ${6 / viewport.k}`} />
                        </svg>
                    ) : null}
                    {pendingConnectionCreate ? <ConnectionCreateMenu pending={pendingConnectionCreate} nodes={nodes} onCreate={(type) => createConnectedNode(type, pendingConnectionCreate)} /> : null}
                    {nodeCreatePosition ? (
                        <OriginalNodeMenu
                            position={nodeCreatePosition}
                            onCreate={(type) => {
                                createNode(type, nodeCreatePosition);
                                setNodeCreatePosition(null);
                            }}
                            onUpload={() => {
                                handleUploadRequest(undefined, nodeCreatePosition);
                                setNodeCreatePosition(null);
                            }}
                            onOpenAssetLibrary={() => {
                                assetInsertPositionRef.current = nodeCreatePosition;
                                setNodeCreatePosition(null);
                                setAssetPickerTab("library");
                                setAssetPickerOpen(true);
                            }}
                            onOpenHistory={() => {
                                setNodeCreatePosition(null);
                                setGenerationHistoryOpen(true);
                            }}
                            onClose={() => setNodeCreatePosition(null)}
                        />
                    ) : null}
                </NovusAI>

                {/* 任务06+02：原版导航＋按钮 → 原版添加节点菜单（屏幕固定锚定在按钮正上方，与双击画布的现有菜单互斥） */}
                {nodeCreateAnchor ? (
                    <OriginalNodeMenu
                        screenAnchor={nodeCreateAnchor}
                        onCreate={(type) => {
                            createNode(type, getCanvasCenter());
                            setNodeCreateAnchor(null);
                        }}
                        onUpload={() => {
                            handleUploadRequest(undefined, getCanvasCenter());
                            setNodeCreateAnchor(null);
                        }}
                        onOpenAssetLibrary={() => {
                            assetInsertPositionRef.current = getCanvasCenter();
                            setNodeCreateAnchor(null);
                            setAssetPickerTab("library");
                            setAssetPickerOpen(true);
                        }}
                        onOpenHistory={() => {
                            setNodeCreateAnchor(null);
                            setGenerationHistoryOpen(true);
                        }}
                        onClose={() => setNodeCreateAnchor(null)}
                    />
                ) : null}

                {nodes.length === 0 && !nodeCreatePosition && !nodeCreateAnchor && !referencePickerNodeId ? (
                    <CanvasEmptyState
                        onPick={(action) => {
                            if (action === "clip") {
                                setAssistantMounted(true);
                                setAgentPanel((current) => ({ ...current, open: true }));
                                return;
                            }
                            if (action === "script") {
                                createNode(CanvasNodeType.Text);
                                return;
                            }
                            createNode(action === "image" ? CanvasNodeType.Image : action === "video" ? CanvasNodeType.Video : CanvasNodeType.Audio);
                        }}
                    />
                ) : null}

                {referencePickerNodeId ? <button type="button" className="absolute left-1/2 top-4 z-[90] -translate-x-1/2 rounded-full border px-4 py-2 text-sm font-medium shadow-lg backdrop-blur" style={{ background: theme.toolbar.panel, borderColor: theme.toolbar.border }} onClick={exitNodeReferenceSelection}>从画布选择参考 · ESC 返回输入框</button> : null}

                {openDirectorNode?.type === CanvasNodeType.Director ? (
                    <CanvasDirector
                        nodeId={openDirectorNode.id}
                        project={openDirectorNode.metadata?.directorProject}
                        panoramas={directorPanoramasByNodeId.get(openDirectorNode.id) || []}
                        theme={colorTheme}
                        onClose={() => setOpenDirectorNodeId(null)}
                        onProjectChange={handleDirectorProjectChange}
                        onPanoramaRemoved={handleDirectorPanoramaRemoved}
                        onCapturesSent={handleDirectorCapturesSent}
                        onVideoSent={handleDirectorVideoSent}
                    />
                ) : null}

                <CanvasNodeHoverToolbar
                    node={isNodeDragging || nodeImageSettingsOpen || transformNodeId || annotateNodeId ? null : toolbarNode}
                    viewport={viewport}
                    onKeep={keepNodeToolbar}
                    onLeave={hideNodeToolbar}
                    onInfo={(node) => setInfoNodeId(node.id)}
                    onDecreaseFont={(node) => handleFontSizeChange(node.id, Math.max(10, (node.metadata?.fontSize || 14) - 2))}
                    onIncreaseFont={(node) => handleFontSizeChange(node.id, Math.min(32, (node.metadata?.fontSize || 14) + 2))}
                    onToggleDialog={(node) => setDialogNodeId((current) => (current === node.id ? null : node.id))}
                    onGenerateImage={generateImageFromTextNode}
                    onUpload={(node) => handleUploadRequest(node.id)}
                    onExtractAudio={(node) => void extractAudio(node)}
                    onTrimAudio={(node) => setAudioTrimNodeId(node.id)}
                    onDownload={downloadNodeImage}
                    onSaveAsset={(node) => setAssetSavePending([node])}
                    onUploadMediaToCloud={(node) => void uploadNodeMediaToCloud(node)}
                    onUploadImageToCloud={(node) => void uploadNodeImageToCloud(node)}
                    onMaskEdit={(node) => {
                        const nodeConfig = buildGenerationConfig(effectiveConfig, node, "image");
                        setMaskEditModel(nodeConfig.model);
                        setMaskEditChannelId(nodeConfig.imageChannelId || nodeConfig.activeChannelId || "");
                        setMaskEditNodeId(node.id);
                    }}
                    onCrop={(node) => setCropNodeId(node.id)}
                    onSplit={(node) => setSplitNodeId(node.id)}
                    onUpscale={(node) => setUpscaleNodeId(node.id)}
                    onSuperResolve={(node) => setSuperResolveNodeId(node.id)}
                    onAngle={(node) => setAngleNodeId(node.id)}
                    onViewImage={(node) => setPreviewNodeId(node.id)}
                    onReversePrompt={createImageReversePromptNodes}
                    onRetry={(node) => void handleRetryNode(node)}
                    showSaintBridgeTest={isEmbeddedSaintCanvas()}
                    onSimulateFailure={(node) => void handleSimulateSaintFailure(node)}
                    onToggleFreeResize={(node) => toggleNodeFreeResize(node.id)}
                    onDelete={(node) => deleteNodes(new Set([node.id]))}
                />

                {/* 任务03：原版图片节点工具栏（单选图片节点时显示；现有悬停栏为 mousedown 禁用的死代码、功能在右键菜单，未删） */}
                <OriginalImageToolbar
                    node={annotateNodeId || isNodeDragging || nodeImageSettingsOpen || transformNodeId ? null : selectedNodeIds.size === 1 ? nodeById.get(Array.from(selectedNodeIds)[0]) || null : null}
                    viewport={viewport}
                    onUpscale={(node) => setUpscaleNodeId(node.id)}
                    onSplit={(node) => setSplitNodeId(node.id)}
                    onAngle={(node) => setAngleNodeId(node.id)}
                    onTransform={(node) => startNodeTransform(node)}
                    onViewImage={(node) => setPreviewNodeId(node.id)}
                    onDownload={downloadNodeImage}
                    onAnnotate={openDoodleEditor}
                />

                {/* 任务rDjmof：「旋转与镜像」变换工具条（浮在变换目标节点上方；保存落像素、X 放弃并删节点） */}
                {transformNode ? (
                    <div className="original-ui-scope absolute z-[72] -translate-x-1/2 -translate-y-full" style={{ left: viewport.x + (transformNode.position.x + transformNode.width / 2) * viewport.k, top: viewport.y + transformNode.position.y * viewport.k - 14 }}>
                        <CanvasNodeTransformBar state={transformState} onStateChange={handleTransformStateChange} onSave={saveNodeTransform} onClose={closeNodeTransform} />
                    </div>
                ) : null}

                {/* rvgR9q：涂鸦编辑层（笔迹走会话状态；完成=右侧出新合成节点，取消/Esc=丢弃） */}
                {annotateNodeId && nodeById.get(annotateNodeId) ? (
                    <ImageDoodleEditor
                        key={annotateNodeId}
                        node={nodeById.get(annotateNodeId)!}
                        viewport={viewport}
                        strokes={annotateStrokes}
                        onChange={setAnnotateStrokes}
                        onFinish={finishDoodleEditor}
                        onClose={closeDoodleEditor}
                    />
                ) : null}

                <CanvasToolbar
                    selectedCount={selectedNodeIds.size}
                    hideDock
                    canvasTool={canvasTool}
                    canUndo={historyState.canUndo}
                    canRedo={historyState.canRedo}
                    backgroundMode={backgroundMode}
                    snapToGrid={snapToGrid}
                    showImageInfo={showImageInfo}
                    onAddImage={() => createNode(CanvasNodeType.Image)}
                    onAddVideo={() => createNode(CanvasNodeType.Video)}
                    onAddAudio={() => createNode(CanvasNodeType.Audio)}
                    onAddText={() => createNode(CanvasNodeType.Text)}
                    onAddPanorama={() => createNode(CanvasNodeType.Panorama)}
                    onAddDirector={() => createNode(CanvasNodeType.Director)}
                    onAddConfig={() => createNode(CanvasNodeType.Config)}
                    onUndo={undoCanvas}
                    onRedo={redoCanvas}
                    onUpload={() => handleUploadRequest()}
                    onDelete={() => deleteNodes(new Set(selectedNodeIds))}
                    onClear={() => setClearConfirmOpen(true)}
                    onCanvasToolChange={setCanvasTool}
                    onBackgroundModeChange={setBackgroundMode}
                    onSnapToGridChange={setSnapToGrid}
                    onShowImageInfoChange={setShowImageInfo}
                    onOpenAssetLibrary={() => {
                        setAssetPickerTab("library");
                        setAssetPickerOpen(true);
                    }}
                    onOpenMyAssets={() => {
                        setAssetPickerTab("my-assets");
                        setAssetPickerOpen(true);
                    }}
                    onOpenHistory={() => setGenerationHistoryOpen(true)}
                    onOpenShortcuts={() => setToolbarShortcutsOpen(true)}
                    onOpenAgent={() => {
                        // 020-D（boss 2026-10-04）：修复 018-4 —— 面板渲染条件是 assistantMounted 而非 agentPanel.open，上次改错状态导致关不掉
                        if (assistantMounted) {
                            setAssistantMounted(false);
                            setAgentPanel((current) => ({ ...current, open: false }));
                            return;
                        }
                        setAssistantMounted(true);
                        setAgentPanel((current) => ({ ...current, open: true }));
                    }}
                />

                {/* 任务01 原版底部导航（boss 已取消现有工具栏圆角框，位置冲突消除：原版导航回到真实位置 bottom-12px 居中；外层 pointer-events 镂空、导航条自身可点） */}
                <div style={{ position: "absolute", left: 0, right: 0, top: 0, bottom: 0, pointerEvents: "none", zIndex: 40 }}>
                    <OriginalBottomNav
                        canvasTool={canvasTool}
                        onCanvasToolChange={setCanvasTool}
                        onAddNode={toggleNodeCreateMenuAtNav}
                        addMenuOpen={nodeCreatePosition != null || nodeCreateAnchor != null}
                        onOpenAssetLibrary={() => {
                            setAssetPickerTab("library");
                            setAssetPickerOpen(true);
                        }}
                        onOpenHistory={() => setGenerationHistoryOpen(true)}
                        onOpenShortcuts={() => setOriginalShortcutsOpen((value) => !value)}
                    />
                </div>

                {/* 任务05 原版快捷键面板：底栏 keyboard 按钮 toggle 触发（现有快捷键 Modal 走现有 toolbar 按钮，两套并存） */}
                <div className="original-ui-scope">
                    <OriginalShortcutsPanel open={originalShortcutsOpen} onClose={() => setOriginalShortcutsOpen(false)} />
                </div>

                {/* boss 2026-10-04：画布节点搜索浮层（Ctrl+F） */}
                <CanvasNodeSearchPanel
                    open={nodeSearchOpen}
                    nodes={nodes}
                    onPick={(nodeId) => {
                        focusNode(nodeId);
                        setNodeSearchOpen(false);
                    }}
                    onClose={() => setNodeSearchOpen(false)}
                />

                <Modal title="快捷键" open={toolbarShortcutsOpen} onCancel={() => setToolbarShortcutsOpen(false)} footer={null} centered>
                    <div className="space-y-2 border-t pt-4 text-sm" style={{ borderColor: theme.node.stroke }}>
                        <Shortcut keys={["Space", "拖动"]} value="临时反转选择/移动工具" />
                        <Shortcut keys={["滚轮"]} value="缩放画布" />
                        <Shortcut keys={["拖动"]} value="使用当前工具操作画布" />
                        <Shortcut keys={["Shift / Ctrl / Cmd", "点击"]} value="追加选择节点" />
                        <Shortcut keys={["Ctrl / Cmd", "G"]} value="创建组" />
                        <Shortcut keys={["Ctrl / Cmd", "C / V"]} value="复制 / 粘贴节点，或粘贴剪切板文本/图片" />
                        <Shortcut keys={["Ctrl / Cmd", "Z"]} value="撤销" />
                        <Shortcut keys={["Ctrl / Cmd", "Shift", "Z"]} value="重做" />
                        <Shortcut keys={["Delete / Backspace"]} value="删除选中" />
                        <Shortcut keys={["Esc"]} value="取消选择并关闭浮层" />
                        <Shortcut keys={["拖入图片/视频/音频"]} value="上传到画布" />
                    </div>
                </Modal>

                {isMiniMapOpen ? <Minimap nodes={nodes} viewport={viewport} viewportSize={size} onViewportChange={setViewport} /> : null}

                <CanvasZoomControls
                    scale={viewport.k}
                    onScaleChange={setZoomScale}
                    onReset={resetViewport}
                    isMiniMapOpen={isMiniMapOpen}
                    onToggleMiniMap={() => setIsMiniMapOpen((value) => !value)}
                    onOrganize={organizeNodes}
                    hideConnections={hideConnections}
                    onToggleConnections={() => setHideConnections((value) => !value)}
                    snapToGrid={snapToGrid}
                    onToggleSnap={() => setSnapToGrid((value) => !value)}
                    assetPanelOpen={sidePanel.open}
                    onToggleAssetPanel={() => setSidePanel((current) => ({ ...current, open: !current.open }))}
                />
                </div>

                {contextMenu?.type === "selection" ? (
                    <CanvasSelectionContextMenu
                        menu={contextMenu}
                        onClose={() => setContextMenu(null)}
                        onOrganize={() => {
                            setContextMenu(null);
                            layoutNodesByDepth(selectionVisualNodes);
                        }}
                        onGridSort={() => {
                            setContextMenu(null);
                            arrangeSelectedNodes("grid");
                        }}
                        onVerticalSort={() => {
                            setContextMenu(null);
                            arrangeSelectedNodes("column");
                        }}
                        onHorizontalSort={() => {
                            setContextMenu(null);
                            arrangeSelectedNodes("row");
                        }}
                        onSaveAsset={(category) => {
                            // 033（boss 2026-10-05）：框选右键也能整批存入素材库（按选中分类，逐个走 saveNodeAsset 转发宿主）
                            setContextMenu(null);
                            const targets = selectionVisualNodes.filter((node) => node.metadata?.content || node.type === CanvasNodeType.Text);
                            if (!targets.length) return;
                            targets.forEach((node) => void saveNodeAsset(node, category));
                        }}
                        onDownload={() => {
                            // 033：框选右键批量下载（复用统一入口：≤5 逐个、>5 打包 zip）
                            setContextMenu(null);
                            downloadNodesBatch(selectionVisualNodes);
                        }}
                        onDelete={() => {
                            setContextMenu(null);
                            const ids = new Set(selectedNodeIdsRef.current);
                            if (ids.size) deleteNodes(ids);
                        }}
                    />
                ) : null}
                {contextMenu?.type === "pane" ? (
                    <OriginalPaneContextMenu
                        x={contextMenu.x}
                        y={contextMenu.y}
                        actions={{
                            canUndo: historyState.canUndo,
                            canRedo: historyState.canRedo,
                            onUpload: () => handleUploadRequest(undefined, screenToCanvas(contextMenu.x, contextMenu.y)),
                            onAddAsset: () => undefined,
                            onAddNode: () => setNodeCreatePosition(screenToCanvas(contextMenu.x, contextMenu.y)),
                            onUndo: undoCanvas,
                            onRedo: redoCanvas,
                            onPaste: () => {
                                pasteCopiedNodes();
                            },
                        }}
                        onClose={() => setContextMenu(null)}
                    />
                ) : null}
                {contextMenu && contextMenu.type !== "selection" && contextMenu.type !== "pane" ? (
                    <CanvasNodeContextMenu
                        menu={contextMenu}
                        node={contextMenuNode}
                        canCaptureVideoFrame={contextMenuNode?.type === CanvasNodeType.Video && Boolean(contextMenuNode.metadata?.content)}
                        showSaintBridgeTest={isEmbeddedSaintCanvas()}
                        onClose={() => setContextMenu(null)}
                        onInfo={() => {
                            if (contextMenu.type !== "node") return;
                            setInfoNodeId(contextMenu.nodeId);
                            setContextMenu(null);
                        }}
                        onExpandBatch={() => {
                            // 097：堆叠批次 → 展开节点（每张图一个独立节点）
                            if (contextMenu.type !== "node") return;
                            expandBatchToNodes(contextMenu.nodeId);
                            setContextMenu(null);
                        }}
                        onRetry={() => {
                            if (contextMenu.type !== "node" || !contextMenuNode) return;
                            setContextMenu(null);
                            void handleRetryNode(contextMenuNode);
                        }}
                        onEdit={() => {
                            if (contextMenu.type !== "node") return;
                            setDialogNodeId(contextMenu.nodeId);
                            setContextMenu(null);
                        }}
                        onUpload={() => {
                            if (contextMenu.type !== "node") return;
                            setContextMenu(null);
                            handleUploadRequest(contextMenu.nodeId);
                        }}
                        onExtractAudio={() => {
                            if (contextMenu.type !== "node" || !contextMenuNode) return;
                            setContextMenu(null);
                            void extractAudio(contextMenuNode);
                        }}
                        onTrimAudio={() => {
                            if (contextMenu.type !== "node") return;
                            setAudioTrimNodeId(contextMenu.nodeId);
                            setContextMenu(null);
                        }}
                        onDownload={() => {
                            if (contextMenu.type !== "node" || !contextMenuNode) return;
                            setContextMenu(null);
                            downloadNodeImage(contextMenuNode);
                        }}
                        onSaveAsset={(category) => {
                            // 031：右键子菜单直选分类，直接入库不再弹「保存为什么资产」对话框
                            if (contextMenu.type !== "node" || !contextMenuNode) return;
                            setContextMenu(null);
                            void saveNodeAsset(contextMenuNode, category);
                        }}
                        onUploadMediaToCloud={() => {
                            if (contextMenu.type !== "node" || !contextMenuNode) return;
                            setContextMenu(null);
                            void uploadNodeMediaToCloud(contextMenuNode);
                        }}
                        onUploadImageToCloud={() => {
                            if (contextMenu.type !== "node" || !contextMenuNode) return;
                            setContextMenu(null);
                            void uploadNodeImageToCloud(contextMenuNode);
                        }}
                        onSimulateFailure={() => {
                            if (contextMenu.type !== "node" || !contextMenuNode) return;
                            setContextMenu(null);
                            void handleSimulateSaintFailure(contextMenuNode);
                        }}
                        onCaptureVideoFrame={(position) => {
                            if (contextMenu.type !== "node") return;
                            void captureVideoNodeFrame(contextMenu.nodeId, position);
                        }}
                        onDuplicate={() => {
                            if (contextMenu.type !== "node") return;
                            duplicateNode(contextMenu.nodeId);
                            setContextMenu(null);
                        }}
                        onDelete={() => {
                            if (contextMenu.type === "node") {
                                deleteNodes(new Set([contextMenu.nodeId]));
                            } else {
                                deleteConnection(contextMenu.connectionId);
                            }
                            setContextMenu(null);
                        }}
                    />
                ) : null}

                {pendingPanoramaImport ? (
                    <div
                        className="fixed left-1/2 top-1/2 z-[130] w-56 -translate-x-1/2 -translate-y-1/2 overflow-hidden rounded-lg border shadow-xl backdrop-blur"
                        style={{ background: theme.toolbar.panel, borderColor: theme.toolbar.border }}
                        onMouseDown={(event) => event.stopPropagation()}
                        onPointerDown={(event) => event.stopPropagation()}
                    >
                        <button
                            type="button"
                            className="flex h-10 w-full items-center px-3 text-left text-sm transition-colors"
                            style={{ color: theme.toolbar.item }}
                            onClick={() => finishPanoramaImport(CanvasNodeType.Panorama)}
                            onMouseEnter={(event) => { event.currentTarget.style.background = theme.toolbar.itemHover; }}
                            onMouseLeave={(event) => { event.currentTarget.style.background = "transparent"; }}
                        >
                            作为全景图导入
                        </button>
                        <div className="h-px" style={{ background: theme.toolbar.border }} />
                        <button
                            type="button"
                            className="flex h-10 w-full items-center px-3 text-left text-sm transition-colors"
                            style={{ color: theme.toolbar.item }}
                            onClick={() => finishPanoramaImport(CanvasNodeType.Image)}
                            onMouseEnter={(event) => { event.currentTarget.style.background = theme.toolbar.itemHover; }}
                            onMouseLeave={(event) => { event.currentTarget.style.background = "transparent"; }}
                        >
                            作为普通图片导入
                        </button>
                    </div>
                ) : null}
                <input ref={imageInputRef} type="file" multiple accept="image/*,video/*,audio/mpeg,audio/wav,audio/x-wav,.mp3,.wav" className="hidden" onChange={handleImageInputChange} />

                <CanvasNodeInfoModal node={infoNode} open={Boolean(infoNode)} onClose={() => setInfoNodeId(null)} />

                <Modal
                    title="截取音频"
                    open={Boolean(audioTrimNode)}
                    centered
                    width={360}
                    confirmLoading={trimmingAudio}
                    closable={!trimmingAudio}
                    okText="确认截取"
                    cancelText="取消"
                    okButtonProps={{ disabled: audioTrimTooShort }}
                    cancelButtonProps={{ disabled: trimmingAudio }}
                    onCancel={() => {
                        if (!trimmingAudio) setAudioTrimNodeId(null);
                    }}
                    onOk={async () => {
                        if (!audioTrimNode || audioTrimTooShort) return;

                        audioTrimRef.current?.pause();
                        const id = await extractAudio(audioTrimNode, {
                            start: audioTrimStart,
                            end: audioTrimEnd,
                        });
                        if (id) setAudioTrimNodeId(null);
                    }}
                    modalRender={(content) => <div className="select-none" data-canvas-no-zoom>{content}</div>}
                >
                    <div className="space-y-4 py-2">
                        <Slider
                            {...{ allowCross: false, pushable: 0.5 }}
                            range={{ draggableTrack: true }}
                            min={0}
                            max={audioTrimDuration || 1}
                            step={0.01}
                            value={[audioTrimStart, audioTrimEnd]}
                            disabled={trimmingAudio || audioTrimDuration < 0.5}
                            ariaLabelForHandle={["截取开始时间", "截取结束时间"]}
                            tooltip={{ formatter: (value) => `${(value ?? 0).toFixed(2)} 秒` }}
                            onChange={(value: number | number[]) => {
                                if (!Array.isArray(value)) return;
                                const [start, end] = value;
                                if (Math.round((end - start) * 100) < 50) return;
                                audioTrimRef.current?.pause();
                                if (audioTrimRef.current) audioTrimRef.current.currentTime = start;
                                setAudioTrimStart(start);
                                setAudioTrimEnd(end);
                            }}
                        />

                        <div className="flex justify-between text-xs tabular-nums opacity-60">
                            <span>{audioTrimStart.toFixed(2)} 秒</span>
                            <span>选中 {(audioTrimEnd - audioTrimStart).toFixed(2)} 秒</span>
                            <span>{audioTrimEnd.toFixed(2)} 秒</span>
                        </div>

                        <div className="flex justify-center">
                            <Button
                                type="text"
                                shape="circle"
                                aria-label={audioTrimPlaying ? "暂停" : "播放"}
                                disabled={trimmingAudio || audioTrimTooShort}
                                icon={audioTrimPlaying ? <Pause className="size-4" /> : <Play className="size-4" />}
                                onClick={() => {
                                    const audio = audioTrimRef.current;
                                    if (!audio) return;

                                    if (!audio.paused) {
                                        audio.pause();
                                        return;
                                    }

                                    if (audio.currentTime < audioTrimStart || audio.currentTime >= audioTrimEnd) {
                                        audio.currentTime = audioTrimStart;
                                    }

                                    void audio.play().catch((error) => {
                                        if (error.name !== "AbortError") message.error("音频试听失败");
                                    });
                                }}
                            />
                        </div>
                    </div>
                </Modal>

                {cropNode?.metadata?.content ? <CanvasNodeCropDialog dataUrl={cropNode.metadata.content} open={Boolean(cropNode)} onClose={() => setCropNodeId(null)} onConfirm={(crop) => cropImageNode(cropNode!, crop)} /> : null}

                {maskEditNode?.metadata?.content && maskEditConfig ? (
                    <CanvasNodeMaskEditDialog
                        dataUrl={maskEditNode.metadata.content}
                        open={Boolean(maskEditNode)}
                        config={{ ...maskEditConfig, model: currentMaskEditModel, imageChannelId: currentMaskEditChannelId }}
                        model={currentMaskEditModel}
                        channelId={currentMaskEditChannelId}
                        onModelChange={(model, channelId) => {
                            setMaskEditModel(model);
                            setMaskEditChannelId(channelId || "");
                        }}
                        onMissingConfig={() => openConfigDialog(true)}
                        onClose={() => {
                            setMaskEditNodeId(null);
                            setMaskEditModel("");
                            setMaskEditChannelId("");
                        }}
                        onConfirm={(payload) => void maskEditImageNode(maskEditNode!, payload)}
                    />
                ) : null}

                {splitNode?.metadata?.content ? <CanvasNodeSplitDialog dataUrl={splitNode.metadata.content} open={Boolean(splitNode)} onClose={() => setSplitNodeId(null)} onConfirm={(params) => splitImageNode(splitNode!, params)} /> : null}

                {upscaleNode?.metadata?.content ? <CanvasNodeUpscaleDialog dataUrl={upscaleNode.metadata.content} open={Boolean(upscaleNode)} onClose={() => setUpscaleNodeId(null)} onConfirm={(params) => void upscaleImageNode(upscaleNode!, params)} /> : null}

                <Modal title="AI 超分" open={Boolean(superResolveNode?.metadata?.content)} centered footer={null} onCancel={() => setSuperResolveNodeId(null)}>
                    <div className="py-8 text-center text-base font-medium">暂未实现</div>
                </Modal>

                {angleNode?.metadata?.content ? <CanvasNodeAngleDialog dataUrl={angleNode.metadata.content} open={Boolean(angleNode)} onClose={() => setAngleNodeId(null)} onConfirm={(params) => void generateAngleNode(angleNode!, params)} /> : null}

                <CanvasGenerationHistoryModal
                    open={generationHistoryOpen}
                    onClose={() => setGenerationHistoryOpen(false)}
                    projects={canvasProjects}
                    currentProjectId={projectId}
                    onLocate={(nodeId) => {
                        setGenerationHistoryOpen(false);
                        focusNode(nodeId);
                    }}
                    onPreview={(node) => {
                        setGenerationHistoryOpen(false);
                        setPreviewNodeId(node.id);
                    }}
                    onDownload={downloadNodeImage}
                    onDelete={deleteNodes}
                    onAddToCanvas={(node) => {
                        // 018-6：生成历史 → 加入画布，复用素材插入链路，落点默认画布中心
                        setGenerationHistoryOpen(false);
                        const content = node.metadata?.content || "";
                        const title = node.title || "生成结果";
                        if (node.type === CanvasNodeType.Video) {
                            insertAssetAt({ kind: "video", url: content, title, storageKey: node.metadata?.storageKey, width: node.metadata?.naturalWidth, height: node.metadata?.naturalHeight });
                            return;
                        }
                        if (node.type === CanvasNodeType.Audio) {
                            insertAssetAt({ kind: "audio", url: content, title, storageKey: node.metadata?.storageKey });
                            return;
                        }
                        if (node.type === CanvasNodeType.Text) {
                            insertAssetAt({ kind: "text", content, title });
                            return;
                        }
                        insertAssetAt({ kind: "image", dataUrl: content, title, storageKey: node.metadata?.storageKey, width: node.metadata?.naturalWidth, height: node.metadata?.naturalHeight });
                    }}
                    onSaveToAsset={(node) => {
                        // 批次129：原版详情面板"保存到资产"按钮，复用画布右键"保存到素材库"链路（029）
                        void saveNodeAsset(node);
                    }}
                />

                {previewNode?.metadata?.content ? (() => {                    const group = getBatchGroupNodes(previewNode);
                    const isRoot = previewNode.metadata?.isBatchRoot;
                    const activeItemNode = isRoot
                        ? (group.find((n) => n.id === previewNode.metadata?.primaryImageId) || group[0] || previewNode)
                        : previewNode;
                    const currentIndex = group.findIndex((n) => n.id === activeItemNode.id);
                    return (
                        <FullscreenPreview
                            src={activeItemNode.metadata?.content || ""}
                            alt={activeItemNode.title || "图片"}
                            isVideo={activeItemNode.type === CanvasNodeType.Video}
                            isPanorama={activeItemNode.type === CanvasNodeType.Panorama}
                            proxyGeneratedPanorama={activeItemNode.type === CanvasNodeType.Panorama && Boolean(activeItemNode.metadata?.imageTaskId || activeItemNode.metadata?.imageTaskResultId) && !activeItemNode.metadata?.storageKey}
                            onDownload={() => downloadNodeImage(activeItemNode)}
                            onClose={() => setPreviewNodeId(null)}
                            hasPrev={currentIndex > 0}
                            hasNext={currentIndex < group.length - 1}
                            onPrev={() => setPreviewNodeId(group[currentIndex - 1].id)}
                            onNext={() => setPreviewNodeId(group[currentIndex + 1].id)}
                        />
                    );
                })() : null}

                <Modal
                    title="清空画布？"
                    open={clearConfirmOpen}
                    centered
                    onCancel={() => setClearConfirmOpen(false)}
                    footer={
                        <>
                            <Button onClick={() => setClearConfirmOpen(false)}>取消</Button>
                            <Button danger type="primary" onClick={clearCanvas}>
                                清空
                            </Button>
                        </>
                    }
                >
                    <p className="text-sm opacity-60">这会删除当前画布上的所有节点和连线。</p>
                </Modal>

                <AssetPickerModal open={assetPickerOpen} defaultTab={assetPickerTab} onInsert={handleAssetInsert} onInsertBatch={handleAssetInsertBatch} onClose={() => { assetInsertPositionRef.current = null; setAssetPickerOpen(false); }} />
                {/* 030：分类库（角色/场景/服装/道具/其他库）→ 从我的资产按分类选素材，选中即上画布并连线为参考 */}
                <AssetPickerModal
                    open={Boolean(categoryLibrary)}
                    categoryFilter={categoryLibrary?.category}
                    onInsert={(payload) => handleLibraryAssetInsert([payload])}
                    onInsertBatch={(payloads) => handleLibraryAssetInsert(payloads)}
                    onClose={() => setCategoryLibrary(null)}
                />
                {/* 029：保存到资产 → 先选分类（人物/场景/服装/道具/其他）+ 单节点可改名 */}
                <CategoryPickDialog
                    open={Boolean(assetSavePending?.length)}
                    title="保存为什么资产？"
                    count={assetSavePending?.length || 0}
                    defaultName={assetSaveDefaultName}
                    onConfirm={(category, nameOverride) => {
                        const nodes = assetSavePending || [];
                        setAssetSavePending(null);
                        nodes.forEach((node) => void saveNodeAsset(node, category, nodes.length === 1 ? nameOverride : undefined));
                    }}
                    onCancel={() => setAssetSavePending(null)}
                />
            </section>
            {assistantMounted ? (
                <CanvasAssistantPanel
                    canvasId={projectId}
                    nodes={nodes}
                    selectedNodeIds={selectedNodeIds}
                    referenceNodeClick={agentReferenceNodeClick}
                    sessions={chatSessions}
                    activeSessionId={activeChatId}
                    agentConfig={resolvedAgentConfig}
                    onFocusNode={focusNode}
                    onSessionsChange={handleAssistantSessionsChange}
                    onAgentConfigChange={handleAgentConfigChange}
                    onPasteImage={pasteAssistantImage}
                    onOpenUpload={() => handleUploadRequest()}
                    onOpenAssets={() => {
                        setAssetPickerTab("my-assets");
                        setAssetPickerOpen(true);
                    }}
                    getAgentContext={getCanvasAgentContext}
                    onExecuteAction={executeCanvasAgentAction}
                    onCollapseStart={() =>
                        setAgentPanel((current) => ({ ...current, open: false }))
                    }
                    onCollapse={() => setAssistantMounted(false)}
                    initialRequest={initialAgentRequest}
                    onInitialRequestConsumed={() => setInitialAgentRequest(null)}
                    historySignal={assistantHistorySignal}
                    onOpenShortcuts={() => setToolbarShortcutsOpen(true)}
                />
            ) : null}
        </main>
    );
}

function FullscreenPreview({ src, alt, isVideo, isPanorama, proxyGeneratedPanorama = false, onDownload, onClose, hasPrev, hasNext, onPrev, onNext }: { src: string; alt: string; isVideo?: boolean; isPanorama?: boolean; proxyGeneratedPanorama?: boolean; onDownload: () => void; onClose: () => void; hasPrev?: boolean; hasNext?: boolean; onPrev?: () => void; onNext?: () => void }) {
    const [zoom, setZoom] = useState<number>(1);
    const [panOffset, setPanOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
    const [isDragging, setIsDragging] = useState<boolean>(false);
    const [videoDuration, setVideoDuration] = useState(0);
    const [videoTime, setVideoTime] = useState(0);
    const [isVideoPlaying, setIsVideoPlaying] = useState(false);
    const [videoVolume, setVideoVolume] = useState(1);
    const dragStartRef = useRef<{ x: number; y: number; panX: number; panY: number }>({ x: 0, y: 0, panX: 0, panY: 0 });
    const imgRef = useRef<HTMLImageElement>(null);
    const videoRef = useRef<HTMLVideoElement>(null);
    const videoPlayerRef = useRef<HTMLDivElement>(null);

    const toggleVideoPlayback = () => {
        const video = videoRef.current;
        if (!video) return;
        if (video.paused) void video.play();
        else video.pause();
    };

    useEffect(() => {
        if (!isVideo) return;
        const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
        videoRef.current?.focus({ preventScroll: true });
        return () => previousFocus?.focus({ preventScroll: true });
    }, [isVideo]);

    useEffect(() => {
        const el = imgRef.current;
        if (!el) return;
        el.addEventListener("wheel", handleWheel, { passive: false });
        return () => el.removeEventListener("wheel", handleWheel);
    });

    const handleWheel = (e: WheelEvent) => {
        e.stopPropagation();
        e.preventDefault();
        setZoom((z) => {
            const next = Math.max(0.2, Math.min(8, z - e.deltaY * 0.001));
            if (next <= 1) setPanOffset({ x: 0, y: 0 });
            return next;
        });
    };

    const handlePointerDown = (e: ReactPointerEvent) => {
        e.stopPropagation();
        e.preventDefault();
        e.currentTarget.setPointerCapture(e.pointerId);
        setIsDragging(true);
        dragStartRef.current = { x: e.clientX, y: e.clientY, panX: panOffset.x, panY: panOffset.y };
    };

    const handlePointerMove = (e: ReactPointerEvent) => {
        if (!isDragging) return;
        e.preventDefault();
        setPanOffset({
            x: dragStartRef.current.panX + (e.clientX - dragStartRef.current.x),
            y: dragStartRef.current.panY + (e.clientY - dragStartRef.current.y),
        });
    };

    const handlePointerUp = (e: ReactPointerEvent) => {
        setIsDragging(false);
        e.currentTarget.releasePointerCapture(e.pointerId);
    };

    return (
        <div className="fixed inset-0 z-[2000] flex items-center justify-center bg-black/80 backdrop-blur-sm" data-canvas-no-zoom={isPanorama ? "" : undefined} onClick={onClose}>
            {hasPrev || hasNext ? (
                <>
                    <button
                        type="button"
                        disabled={!hasPrev}
                        onClick={(e) => { e.stopPropagation(); onPrev?.(); }}
                        onPointerDown={(e) => e.stopPropagation()}
                        className="absolute left-4 top-1/2 z-[2010] -translate-y-1/2 flex size-10 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white transition-all hover:bg-white/10 hover:scale-105 active:scale-95 disabled:opacity-20 disabled:cursor-not-allowed"
                    >
                        <ChevronLeft className="size-6" />
                    </button>
                    <button
                        type="button"
                        disabled={!hasNext}
                        onClick={(e) => { e.stopPropagation(); onNext?.(); }}
                        onPointerDown={(e) => e.stopPropagation()}
                        className="absolute right-4 top-1/2 z-[2010] -translate-y-1/2 flex size-10 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white transition-all hover:bg-white/10 hover:scale-105 active:scale-95 disabled:opacity-20 disabled:cursor-not-allowed"
                    >
                        <ChevronRight className="size-6" />
                    </button>
                </>
            ) : null}
            {isPanorama ? (
                <div className="h-[85vh] w-[85vw] supports-[height:round(1px,1px)]:h-[round(85vh,1px)] supports-[height:round(1px,1px)]:w-[round(85vw,1px)] overflow-hidden rounded-2xl shadow-[0_24px_72px_rgba(0,0,0,0.4)]" onClick={(event) => event.stopPropagation()}>
                    <CanvasPanoramaViewer src={src} alt={alt} proxyGeneratedPanorama={proxyGeneratedPanorama} immersive />
                </div>
            ) : isVideo ? (
                <div
                    ref={videoPlayerRef}
                    className="relative flex max-h-[85vh] max-w-[85vw] items-center justify-center overflow-hidden rounded-2xl bg-black shadow-[0_24px_72px_rgba(0,0,0,0.4)] fullscreen:h-screen fullscreen:w-screen fullscreen:max-h-none fullscreen:max-w-none fullscreen:rounded-none [&:fullscreen>video]:h-screen [&:fullscreen>video]:w-screen [&:fullscreen>video]:max-h-none [&:fullscreen>video]:max-w-none"
                    onClick={(event) => event.stopPropagation()}
                    onKeyDownCapture={(event) => {
                        if (event.code !== "Space") return;
                        event.preventDefault();
                        event.stopPropagation();
                        toggleVideoPlayback();
                    }}
                    data-canvas-no-zoom
                >
                    <video
                        ref={videoRef}
                        src={src}
                        aria-label={alt}
                        tabIndex={-1}
                        playsInline
                        preload="metadata"
                        onLoadStart={() => { setVideoDuration(0); setVideoTime(0); setIsVideoPlaying(false); }}
                        onDurationChange={(event) => setVideoDuration(event.currentTarget.duration)}
                        onTimeUpdate={(event) => setVideoTime(event.currentTarget.currentTime)}
                        onPlay={() => setIsVideoPlaying(true)}
                        onPause={() => setIsVideoPlaying(false)}
                        onVolumeChange={(event) => setVideoVolume(event.currentTarget.muted ? 0 : event.currentTarget.volume)}
                        onDoubleClick={(event) => { event.preventDefault(); event.stopPropagation(); }}
                        className="block max-h-[85vh] max-w-[85vw] object-contain outline-none"
                    />
                    <button type="button" aria-label="关闭预览" onClick={onClose} className="absolute right-4 top-4 z-20 flex size-9 items-center justify-center rounded-lg text-white transition-colors hover:bg-black/25">
                        <X className="size-6" />
                    </button>
                    <div className="pointer-events-none absolute inset-x-0 bottom-0 z-10 bg-gradient-to-t from-black/85 via-black/40 to-transparent px-5 pb-3 pt-24">
                        <div className="mb-2 flex justify-between text-xs font-medium tabular-nums text-white">
                            <span>{formatPreviewTime(videoTime)}</span>
                            <span>{formatPreviewTime(videoDuration)}</span>
                        </div>
                        <input
                            type="range"
                            min={0}
                            max={videoDuration || 0}
                            step="0.01"
                            value={Math.min(videoTime, videoDuration || 0)}
                            aria-label="视频进度"
                            onChange={(event) => {
                                const time = Number(event.currentTarget.value);
                                if (videoRef.current) videoRef.current.currentTime = time;
                                setVideoTime(time);
                            }}
                            onPointerUp={() => videoRef.current?.focus({ preventScroll: true })}
                            className="pointer-events-auto block h-1 w-full cursor-pointer appearance-none rounded-full focus-visible:outline-none [&::-moz-range-thumb]:size-3 [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:border-0 [&::-moz-range-thumb]:bg-white [&::-webkit-slider-thumb]:size-3 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-white"
                            style={{ background: `linear-gradient(to right, #67e8f9 ${videoDuration ? Math.min(videoTime / videoDuration, 1) * 100 : 0}%, rgba(255,255,255,0.35) 0)` }}
                        />
                        <div className="pointer-events-auto mt-2 flex items-center justify-between">
                            <div className="flex items-center gap-1">
                                <button type="button" aria-label={isVideoPlaying ? "暂停" : "播放"} onPointerDown={(event) => event.preventDefault()} onClick={toggleVideoPlayback} className={VIDEO_PREVIEW_CONTROL_CLASS}>
                                    {isVideoPlaying ? <Pause className="size-5" /> : <Play className="size-5" />}
                                </button>
                                <div className="group/volume flex items-center">
                                    <button type="button" aria-label={videoVolume === 0 ? "恢复声音" : "静音"} onPointerDown={(event) => event.preventDefault()} onClick={() => { if (videoRef.current) videoRef.current.muted = !videoRef.current.muted; }} className={VIDEO_PREVIEW_CONTROL_CLASS}>
                                        {videoVolume === 0 ? <VolumeX className="size-5" /> : <Volume2 className="size-5" />}
                                    </button>
                                    <input type="range" min={0} max={1} step="0.01" value={videoVolume} aria-label="音量" onChange={(event) => { const volume = Number(event.currentTarget.value); if (!videoRef.current) return; if (volume === 0) videoRef.current.muted = true; else { videoRef.current.volume = volume; videoRef.current.muted = false; } }} onPointerUp={() => videoRef.current?.focus({ preventScroll: true })} className="h-1 w-0 pointer-events-none cursor-pointer appearance-none rounded-full opacity-0 transition-[width,opacity] duration-200 focus-visible:outline-none group-hover/volume:mx-1 group-hover/volume:w-20 group-hover/volume:pointer-events-auto group-hover/volume:opacity-100 [&::-moz-range-thumb]:size-2 [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:border-0 [&::-moz-range-thumb]:bg-white [&::-webkit-slider-thumb]:size-2 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-white" style={{ background: `linear-gradient(to right, white ${videoVolume * 100}%, rgba(255,255,255,0.35) 0)` }} />
                                </div>
                            </div>
                            <div className="flex items-center gap-1">
                                <button type="button" aria-label="下载视频" onPointerDown={(event) => event.preventDefault()} onClick={onDownload} className={VIDEO_PREVIEW_CONTROL_CLASS}>
                                    <Download className="size-5" />
                                </button>
                                <button type="button" aria-label="全屏播放" onPointerDown={(event) => event.preventDefault()} onClick={() => { if (document.fullscreenElement) void document.exitFullscreen(); else void videoPlayerRef.current?.requestFullscreen(); }} className={VIDEO_PREVIEW_CONTROL_CLASS}>
                                    <Maximize className="size-5" />
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            ) : (
                <img
                    ref={imgRef}
                    src={src}
                    alt={alt}
                    draggable={false}
                    onPointerDown={handlePointerDown}
                    onPointerMove={handlePointerMove}
                    onPointerUp={handlePointerUp}
                    className={`max-h-[85vh] max-w-[85vw] object-contain rounded-2xl shadow-[0_24px_72px_rgba(0,0,0,0.4)] ${zoom > 1 ? "cursor-grab active:cursor-grabbing" : "cursor-default"}`}
                    onClick={(e) => e.stopPropagation()}
                    onDragStart={(e) => e.preventDefault()}
                    style={{
                        transform: `translate(${panOffset.x}px, ${panOffset.y}px) scale(${zoom})`,
                        transition: isDragging ? "none" : "transform 0.12s cubic-bezier(0.25, 0.46, 0.45, 0.94)",
                    }}
                />
            )}
        </div>
    );
}

function CanvasTopBar({
    title,
    sidePanelOpen,
    onToggleSidePanel,
    titleDraft,
    isTitleEditing,
    onTitleDraftChange,
    onStartTitleEditing,
    onFinishTitleEditing,
    onCancelTitleEditing,
    canUndo,
    canRedo,
    onHome,
    onProjects,
    onCreateProject,
    onDeleteProject,
    onImportImage,
    onUndo,
    onRedo,
}: {
    title: string;
    sidePanelOpen: boolean;
    onToggleSidePanel: () => void;
    titleDraft: string;
    isTitleEditing: boolean;
    onTitleDraftChange: (value: string) => void;
    onStartTitleEditing: () => void;
    onFinishTitleEditing: () => void;
    onCancelTitleEditing: () => void;
    canUndo: boolean;
    canRedo: boolean;
    onHome: () => void;
    onProjects: () => void;
    onCreateProject: () => void;
    onDeleteProject: () => void;
    onImportImage: () => void;
    onUndo: () => void;
    onRedo: () => void;
}) {
    const colorTheme = useThemeStore((state) => state.theme);
    const theme = canvasThemes[colorTheme];
    const titleRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (!isTitleEditing) return;
        const close = (event: PointerEvent) => {
            if (!titleRef.current?.contains(event.target as Node)) onFinishTitleEditing();
        };
        document.addEventListener("pointerdown", close, true);
        return () => document.removeEventListener("pointerdown", close, true);
    }, [isTitleEditing, onFinishTitleEditing]);

    return (
        <>
            <div className="pointer-events-none absolute left-0 right-0 top-0 z-50 flex h-16 items-center justify-between px-4">
                <div className="pointer-events-auto flex min-w-0 items-center gap-3">
                    <button type="button" onClick={onToggleSidePanel} className="grid size-7 place-items-center rounded-full transition hover:bg-black/5 dark:hover:bg-white/10" style={{ color: theme.node.text }} aria-label={sidePanelOpen ? "收起左侧面板" : "展开左侧面板"}>
                        {sidePanelOpen ? <PanelLeftClose className="size-4" /> : <PanelLeftOpen className="size-4" />}
                    </button>
                    <Dropdown
                        trigger={["click"]}
                        menu={{
                            items: [
                                { key: "home", icon: <Home className="size-4" />, label: "主页", onClick: onHome },
                                { key: "projects", icon: <Images className="size-4" />, label: "我的画布", onClick: onProjects },
                                { type: "divider" },
                                { key: "new", icon: <Plus className="size-4" />, label: "新建画布", onClick: onCreateProject },
                                { key: "delete", danger: true, icon: <Trash2 className="size-4" />, label: "删除当前画布", onClick: onDeleteProject },
                                { type: "divider" },
                                { key: "import", icon: <Upload className="size-4" />, label: "导入素材", onClick: onImportImage },
                                { type: "divider" },
                                { key: "undo", disabled: !canUndo, icon: <Undo2 className="size-4" />, label: <MenuLabel text="撤销" shortcut="⌘ Z" />, onClick: onUndo },
                                { key: "redo", disabled: !canRedo, icon: <Redo2 className="size-4" />, label: <MenuLabel text="重做" shortcut="⌘ ⇧ Z / ⌘ Y" />, onClick: onRedo },
                            ],
                        }}
                    >
                        <button type="button" className="grid size-9 place-items-center rounded-full transition hover:bg-black/5 dark:hover:bg-white/10" style={{ color: theme.node.text }} aria-label="打开画布菜单">
                            <Menu className="size-5" />
                        </button>
                    </Dropdown>

                    <div ref={titleRef} className="flex min-w-0 items-center gap-2">
                        {isTitleEditing ? (
                            <input
                                autoFocus
                                value={titleDraft}
                                onChange={(event) => onTitleDraftChange(event.target.value)}
                                onBlur={onFinishTitleEditing}
                                onKeyDown={(event) => {
                                    if (event.key === "Enter") onFinishTitleEditing();
                                    if (event.key === "Escape") onCancelTitleEditing();
                                }}
                                className="max-w-[280px] bg-transparent p-0 text-left text-lg font-semibold tracking-normal outline-none"
                                style={{ color: theme.node.text }}
                            />
                        ) : (
                            <button
                                type="button"
                                className="max-w-[280px] truncate border-b border-dashed border-transparent text-left text-lg font-semibold tracking-normal transition hover:border-current"
                                onDoubleClick={onStartTitleEditing}
                                title="双击修改画布名称"
                            >
                                {title}
                            </button>
                        )}
                    </div>
                </div>
            </div>
        </>
    );
}

function MenuLabel({ text, shortcut }: { text: string; shortcut: string }) {
    return (
        <span className="flex min-w-36 items-center justify-between gap-8">
            <span>{text}</span>
            <span className="text-xs opacity-45">{shortcut}</span>
        </span>
    );
}

function Shortcut({ keys, value }: { keys: string[]; value: string }) {
    return (
        <div className="grid grid-cols-[minmax(0,1fr)_120px] items-center gap-6 rounded-lg px-1 py-1.5">
            <span className="flex min-w-0 flex-wrap items-center gap-1.5">
                {keys.map((key, index) => (
                    <span key={`${key}-${index}`} className="flex items-center gap-1.5">
                        {index ? <span className="text-xs opacity-35">+</span> : null}
                        <kbd
                            className="min-w-9 rounded-md border px-2.5 py-1.5 text-center text-xs font-medium leading-none shadow-[inset_0_-1px_0_rgba(0,0,0,.08),0_1px_2px_rgba(0,0,0,.06)]"
                            style={{ borderColor: "rgba(120,113,108,.28)", background: "linear-gradient(#fff, rgba(245,245,244,.92))", color: "rgb(68,64,60)" }}
                        >
                            {key}
                        </kbd>
                    </span>
                ))}
            </span>
            <span className="text-right text-sm opacity-55">{value}</span>
        </div>
    );
}

function imageExtension(dataUrl: string) {
    return dataUrl.match(/^data:image[/]([^;]+)/)?.[1] || dataUrl.match(/image[/]([^;]+)/)?.[1] || "png";
}

function audioExtension(mimeType?: string) {
    if (mimeType?.includes("wav")) return "wav";
    if (mimeType?.includes("opus")) return "opus";
    if (mimeType?.includes("aac")) return "aac";
    if (mimeType?.includes("flac")) return "flac";
    if (mimeType?.includes("pcm")) return "pcm";
    return "mp3";
}

function imageMetadata(image: UploadedImage): CanvasNodeMetadata {
    return { content: image.url, storageKey: image.storageKey, status: "success", naturalWidth: image.width, naturalHeight: image.height, bytes: image.bytes, mimeType: image.mimeType, source: "import" };
}

function videoMetadata(video: UploadedFile): CanvasNodeMetadata {
    return { content: video.url, storageKey: video.storageKey, status: "success", naturalWidth: video.width, naturalHeight: video.height, bytes: video.bytes, mimeType: video.mimeType || "video/mp4", durationMs: video.durationMs, source: "import" };
}

function buildImportedVideoNode(video: UploadedFile, title: string, center: Position): CanvasNodeData {
    const size = normalizeNodeSize(video.width || 1280, video.height || 720);
    return {
        id: `video-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        type: CanvasNodeType.Video,
        title,
        position: { x: center.x - size.width / 2, y: center.y - size.height / 2 },
        width: size.width,
        height: size.height,
        metadata: videoMetadata(video),
    };
}

function getNextDirectorOutputY(
    director: CanvasNodeData,
    nodes: CanvasNodeData[],
    connections: CanvasConnection[],
) {
    return connections.reduce((y, connection) => {
        if (connection.fromNodeId !== director.id) return y;
        const output = nodes.find((node) => node.id === connection.toNodeId);
        return output?.type === CanvasNodeType.Image || output?.type === CanvasNodeType.Video
            ? Math.max(y, output.position.y + output.height + 36)
            : y;
    }, director.position.y);
}

function audioMetadata(audio: UploadedFile): CanvasNodeMetadata {
    return { content: audio.url, storageKey: audio.storageKey, status: "success", bytes: audio.bytes, mimeType: audio.mimeType || "audio/mpeg", durationMs: audio.durationMs };
}

function buildImageGenerationMetadata(type: CanvasImageGenerationType, config: AiConfig, count: number, references: ReferenceImage[]): CanvasNodeMetadata {
    return {
        generationType: type,
        model: config.model,
        channelId: config.imageChannelId || config.activeChannelId,
        size: config.size,
        quality: config.quality,
        count,
        references: references.map(referenceUrl).filter((url): url is string => Boolean(url)),
    };
}

function buildAudioGenerationMetadata(config: AiConfig, sourceMetadata?: CanvasNodeMetadata): CanvasNodeMetadata {
    return {
        model: config.model,
        channelId: config.audioChannelId || config.activeChannelId,
        audioVoice: config.audioVoice,
        audioFormat: config.audioFormat,
        audioSpeed: config.audioSpeed,
        audioInstructions: config.audioInstructions,
        grokTtsVoice: config.grokTtsVoice,
        grokTtsLanguage: config.grokTtsLanguage,
        grokTtsFormat: config.grokTtsFormat,
        grokTtsSpeed: config.grokTtsSpeed,
        glmTtsVoice: config.glmTtsVoice,
        glmTtsFormat: config.glmTtsFormat,
        glmTtsSpeed: config.glmTtsSpeed,
        mimoTtsVoice: config.mimoTtsVoice,
        mimoTtsFormat: config.mimoTtsFormat,
        mimoVoiceDesignPrompt: config.mimoVoiceDesignPrompt,
        geminiTtsVoice: config.geminiTtsVoice,
        mimoVoiceCloneAudioNodeId: sourceMetadata?.mimoVoiceCloneAudioNodeId,
        referenceAudioNodeId: sourceMetadata?.referenceAudioNodeId,
    };
}

function selectAudioReference(config: AiConfig, metadata: CanvasNodeMetadata | undefined, references: ReferenceAudio[]) {
    const autodl = isAutoDLConfig(config, config.model || config.audioModel);
    if (!autodl && !isMimoVoiceCloneModel(config.model || config.audioModel)) return undefined;
    const selectedId = (autodl ? metadata?.referenceAudioNodeId : metadata?.mimoVoiceCloneAudioNodeId) || "";
    if (selectedId) {
        const selected = references.find((item) => item.id === selectedId);
        if (selected) return selected;
    }
    if (references.length === 1) return references[0];
    if (!references.length) throw new Error("请连接参考音频节点");
    throw new Error("已连接多个音频节点，请在音频设置中选择参考音频");
}

function referenceUrl(image: ReferenceImage) {
    return image.storageKey || image.url || (!image.dataUrl.startsWith("data:") ? image.dataUrl : undefined);
}

function withCanvasVideoAdvancedConfig(config: AiConfig, context: Pick<NodeGenerationContext, "videoMultiPrompt" | "videoElementList">): AiConfig {
    const kieKlingV3 = isKIEKlingV3Config(config, config.model || config.videoModel);
    const kieKlingOmni = kieKlingOmniVariant(config, config.model || config.videoModel);
    return {
        ...config,
        videoNegativePrompt: kieKlingV3 ? "" : config.videoNegativePrompt,
        videoMultiShot: kieKlingOmni === "transformation" ? "false" : config.videoMultiShot,
        videoShotType: kieKlingV3 && !kieKlingOmni ? "intelligence" : config.videoShotType,
        videoMultiPrompt: context.videoMultiPrompt.length ? context.videoMultiPrompt : config.videoMultiPrompt,
        videoElementList: context.videoElementList.length ? context.videoElementList : config.videoElementList,
    };
}

function generationReferenceUrls(context: { referenceImages: ReferenceImage[]; firstFrame?: ReferenceImage | null; lastFrame?: ReferenceImage | null; referenceVideos: Array<{ storageKey?: string; url?: string }>; referenceAudios?: Array<{ storageKey?: string; url?: string }> }) {
    return [
        context.firstFrame ? referenceUrl(context.firstFrame) : null,
        context.lastFrame ? referenceUrl(context.lastFrame) : null,
        ...context.referenceImages.map(referenceUrl).filter((url): url is string => Boolean(url)),
        ...context.referenceVideos.map((video) => video.storageKey || video.url).filter((url): url is string => Boolean(url)),
        ...(context.referenceAudios || []).map((audio) => audio.storageKey || audio.url).filter((url): url is string => Boolean(url)),
    ].filter((url): url is string => Boolean(url));
}

async function resolveMetadataReferences(metadata: CanvasNodeMetadata) {
    if (metadata.generationType !== "edit") return [];
    if (!metadata.references?.length) return null;
    const references = await Promise.all(
        metadata.references.map(async (url, index) => {
            const dataUrl = url.startsWith("image:") ? await resolveImageUrl(url, "") : url;
            return dataUrl ? { id: `${index}`, name: `reference-${index}.png`, type: "image/png", dataUrl, storageKey: url.startsWith("image:") ? url : undefined } : null;
        }),
    );
    return references.every(Boolean) ? (references as ReferenceImage[]) : null;
}

async function hydrateCanvasImages(nodes: CanvasNodeData[]) {
    return Promise.all(
        nodes.map(async (node) => {
            const content = node.metadata?.content;
            if ((node.type === CanvasNodeType.Video || node.type === CanvasNodeType.Audio) && node.metadata?.storageKey) return { ...node, metadata: { ...node.metadata, content: await resolveMediaUrl(node.metadata.storageKey, content) } };
            if (!isCanvasImageNodeType(node.type) || !content) return node;
            if (node.metadata?.storageKey) return { ...node, metadata: { ...node.metadata, content: await resolveImageUrl(node.metadata.storageKey, content) } };
            if (!content.startsWith("data:image/")) return node;
            return { ...node, metadata: { ...node.metadata, ...imageMetadata(await uploadImage(content, { localOnly: true })) } };
        }),
    );
}

function syncAssistantReferences(sessions: CanvasAssistantSession[], nodes: CanvasNodeData[], restoreInterrupted = false) {
    const nodeById = new Map(nodes.map((node) => [node.id, node]));
    return sessions.map((session) => ({
        ...session,
        messages: session.messages.map((message) => {
            const interrupted = restoreInterrupted && (message.status === "thinking" || message.status === "running");
            return {
                ...message,
                text: interrupted && !message.text ? "上次 Agent 执行因页面关闭而中断；已提交的媒体任务会继续恢复，你可以让我从当前画布继续。" : message.text,
                status: interrupted ? ("waiting" as const) : message.status,
                activity: interrupted ? undefined : message.activity,
                references: message.references?.map((reference) => {
                    const node = nodeById.get(reference.id);
                    const content = node && assistantReferenceContentFromNode(node);
                    return content ? { ...reference, ...content } : reference;
                }),
            };
        }),
    }));
}

function getGenerationCount(count: string) {
    return Math.max(1, Math.min(15, Math.floor(Math.abs(Number(count)) || 1)));
}

function applyNodeConfigPatch(node: CanvasNodeData, patch: Partial<CanvasNodeData["metadata"]>) {
    const safePatch = patch || {};
    const isPanorama = isPanoramaNodeType(node.type);
    const next = { ...node, metadata: { ...node.metadata, ...safePatch, ...(isPanorama ? { size: PANORAMA_IMAGE_SIZE } : {}) } };
    const spec = isPanorama ? NODE_DEFAULT_SIZE[CanvasNodeType.Panorama] : node.type === CanvasNodeType.Video ? NODE_DEFAULT_SIZE[CanvasNodeType.Video] : NODE_DEFAULT_SIZE[CanvasNodeType.Image];
    const size = !isPanorama && typeof safePatch.size === "string" && !node.metadata?.content ? nodeSizeFromRatio(safePatch.size, spec.width, spec.height) : null;
    return size && (isCanvasImageNodeType(node.type) || node.type === CanvasNodeType.Video) ? { ...next, ...size, position: { x: node.position.x + node.width / 2 - size.width / 2, y: node.position.y + node.height / 2 - size.height / 2 } } : next;
}

function getConnectionTargetAnchor(node: CanvasNodeData, current: ConnectionHandle) {
    return {
        x: current.handleType === "source" ? node.position.x : node.position.x + node.width,
        y: node.position.y + node.height / 2,
    };
}

function normalizeConnection(firstNodeId: string, secondNodeId: string, nodes: CanvasNodeData[], firstHandleType: "source" | "target") {
    const first = nodes.find((node) => node.id === firstNodeId);
    const second = nodes.find((node) => node.id === secondNodeId);
    if (!first || !second || first.id === second.id) return null;
    if (first.type === CanvasNodeType.Group || second.type === CanvasNodeType.Group) return null;
    if (second.type === CanvasNodeType.Director) {
        if (!isCanvasImageNodeType(first.type)) return null;
        return firstHandleType === "target" ? { fromNodeId: second.id, toNodeId: first.id } : { fromNodeId: first.id, toNodeId: second.id };
    }
    if (first.type === CanvasNodeType.Director) {
        if (!isCanvasImageNodeType(second.type)) return null;
        return firstHandleType === "target" ? { fromNodeId: second.id, toNodeId: first.id } : { fromNodeId: first.id, toNodeId: second.id };
    }
    if (first.type === CanvasNodeType.Config && second.type === CanvasNodeType.Config) return null;
    if (second.type === CanvasNodeType.Config) return { fromNodeId: first.id, toNodeId: second.id };
    if (first.type === CanvasNodeType.Config && firstHandleType === "target") return { fromNodeId: second.id, toNodeId: first.id };
    if (first.type === CanvasNodeType.Config) return { fromNodeId: first.id, toNodeId: second.id };
    return { fromNodeId: first.id, toNodeId: second.id };
}

function getInputSummary(inputs: NodeGenerationInput[]) {
    return {
        textCount: inputs.filter((input) => input.type === "text").length,
        imageCount: inputs.filter((input) => input.type === "image").length,
        videoCount: inputs.filter((input) => input.type === "video").length,
        audioCount: inputs.filter((input) => input.type === "audio").length,
    };
}

function applyCanvasVideoTaskUpdate(nodes: CanvasNodeData[], nodeId: string, task: VideoResponse, config: AiConfig, startedAt: number, fallbackSize: { width: number; height: number }) {
    return nodes.map((node) => {
        if (node.id !== nodeId) return node;
        const hostTask = task as VideoResponse & { message?: string; stage?: string; stageLabel?: string; generationMessage?: string; failureReason?: string; accountName?: string; accountId?: string; account?: string; channelName?: string; taskNumber?: string };
        const progress = typeof task.progress === "number" ? Math.max(0, Math.min(100, task.progress)) : node.metadata?.progress || 0;
        const url = task.video_url || task.url || "";
        const completed = canvasVideoTaskCompleted(task);
        const failed = canvasVideoTaskFailed(task) || (completed && !url);
        const taskStartedAt = parseCanvasVideoTaskTime(task.started_at ?? task.startedAt ?? task.created_at ?? task.createdAt) || startedAt;
        const taskMessage = String(hostTask.message || hostTask.generationMessage || "").trim();
        const stage = String(hostTask.stage || "").trim();
        const stageLabel = String(hostTask.stageLabel || "").trim();
        const errorMessage = String(task.error?.message || hostTask.failureReason || taskMessage || "").trim();
        const statusMessage = failed
            ? (errorMessage || "Dola 生成失败")
            : completed
                ? "Dola 生成完成"
                : (stageLabel || taskMessage || node.metadata?.statusMessage || "Dola 正在生成");
        const taskNumber = hostTask.taskNumber || task.task_id || task.id || node.metadata?.videoTaskId || "";
        const metadata: CanvasNodeMetadata = {
            ...node.metadata,
            status: failed ? NODE_STATUS_ERROR : completed ? NODE_STATUS_SUCCESS : NODE_STATUS_LOADING,
            errorDetails: failed ? errorMessage || (completed ? "视频生成完成但没有返回视频地址" : "视频生成失败") : undefined,
            model: task.model || config.model,
            size: task.size || node.metadata?.size || config.size,
            seconds: task.seconds || node.metadata?.seconds || config.videoSeconds,
            vquality: node.metadata?.vquality || config.vquality,
            mode: node.metadata?.mode || config.videoMode,
            negativePrompt: node.metadata?.negativePrompt || config.videoNegativePrompt,
            generateAudio: node.metadata?.generateAudio || config.videoGenerateAudio,
            characterOrientation: node.metadata?.characterOrientation || config.videoCharacterOrientation,
            watermark: node.metadata?.watermark || config.videoWatermark,
            startedAt: taskStartedAt,
            durationMs: Date.now() - taskStartedAt,
            progress,
            statusMessage,
            stage: stage || node.metadata?.stage,
            stageLabel: stageLabel || node.metadata?.stageLabel,
            generationMessage: taskMessage || node.metadata?.generationMessage,
            videoTaskId: task.task_id || task.id || node.metadata?.videoTaskId,
            videoTaskVideoId: task.video_id || node.metadata?.videoTaskVideoId,
            taskNumber: taskNumber || node.metadata?.taskNumber,
            accountName: hostTask.accountName || hostTask.account || hostTask.channelName || node.metadata?.accountName,
            accountId: hostTask.accountId || node.metadata?.accountId,
        };
        const nextTitle = taskNumber && (!node.title || node.title === "视频生成" || node.title === "视频任务（待生成）") ? `视频任务 ${taskNumber}` : node.title;
        if (!completed || !url) return { ...node, title: nextTitle, metadata };
        const taskSize = parseCanvasVideoTaskSize(task.size, fallbackSize);
        const videoSize = normalizeNodeSize(taskSize.width, taskSize.height);
        return {
            ...node,
            title: nextTitle,
            width: videoSize.width,
            height: videoSize.height,
            position: { x: node.position.x + node.width / 2 - videoSize.width / 2, y: node.position.y + node.height / 2 - videoSize.height / 2 },
            metadata: {
                ...metadata,
                content: url,
                storageKey: task.storageKey || "",
                status: NODE_STATUS_SUCCESS,
                naturalWidth: taskSize.width,
                naturalHeight: taskSize.height,
                bytes: 0,
                mimeType: "video/mp4",
                progress: 100,
            },
        };
    });
}

function canvasImageTaskURLs(task: CanvasImageTask) {
    return [...new Set([...(task.image_urls || []), task.image_url || task.url || ""].map((url) => url.trim()).filter(Boolean))];
}

function canvasImageTaskChildIds(nodeId: string, task: CanvasImageTask) {
    return canvasImageTaskURLs(task).map((_, index) => `${nodeId}-result-${index}`);
}

function applyCanvasImageTaskUpdate(nodes: CanvasNodeData[], nodeId: string, task: CanvasImageTask, startedAt: number, fallbackSize: { width: number; height: number }) {
    const urls = canvasImageTaskURLs(task);
    const updated = nodes.map((node) => {
        if (node.id !== nodeId) return node;
        const progress = typeof task.progress === "number" ? Math.max(0, Math.min(100, task.progress)) : node.metadata?.progress || 0;
        const url = urls[0] || "";
        const completed = canvasTaskCompleted(task.status) || Boolean(url);
        const failed = canvasTaskFailed(task.status) || (completed && !url);
        const taskStartedAt = parseCanvasTaskTime(task.started_at ?? task.startedAt ?? task.created_at ?? task.createdAt) || startedAt;
        const metadata: CanvasNodeMetadata = {
            ...node.metadata,
            status: failed ? NODE_STATUS_ERROR : completed ? NODE_STATUS_SUCCESS : NODE_STATUS_LOADING,
            errorDetails: failed ? task.error?.message || "图片生成失败" : undefined,
            startedAt: taskStartedAt,
            durationMs: Date.now() - taskStartedAt,
            progress,
            imageTaskId: task.id || node.metadata?.imageTaskId,
        };
        if (!completed || !url) return { ...node, metadata };
        const stored = task.imageStorage?.find((image) => image?.url === url);
        const isPanorama = isPanoramaNodeType(node.type);
        const requestedSize = nodeSizeFromRatio(node.metadata?.size || "", fallbackSize.width, fallbackSize.height);
        const naturalWidth = task.width || requestedSize?.width || fallbackSize.width || node.width;
        const naturalHeight = task.height || requestedSize?.height || fallbackSize.height || node.height;
        const imageSize = isPanorama ? PANORAMA_NODE_SIZE : normalizeNodeSize(naturalWidth, naturalHeight);
        return {
            ...node,
            width: imageSize.width,
            height: imageSize.height,
            position: { x: node.position.x + node.width / 2 - imageSize.width / 2, y: node.position.y + node.height / 2 - imageSize.height / 2 },
            metadata: {
                ...metadata,
                content: url,
                storageKey: task.storageKey || "",
                status: NODE_STATUS_SUCCESS,
                naturalWidth: stored?.width || naturalWidth,
                naturalHeight: stored?.height || naturalHeight,
                bytes: task.bytes || 0,
                mimeType: task.mimeType || "image/png",
                progress: 100,
                imageTaskResultId: task.id,
                panoramaProjection: isPanorama ? ("equirectangular" as const) : undefined,
            },
        };
    });
    const root = updated.find((node) => node.id === nodeId);
    if (!root) return updated;
    const batchRootId = task.source === "workflow" ? root.metadata?.batchRootId : undefined;
    if (batchRootId) {
        const batchRoot = updated.find((node) => node.id === batchRootId);
        if (!batchRoot) return updated;
        const resultPrefix = `${nodeId}-result-`;
        const extraIds = canvasImageTaskChildIds(nodeId, task).slice(1);
        const taskChildIds = [nodeId, ...extraIds];
        const currentChildIds = (batchRoot.metadata?.batchChildIds || []).filter((id) => !id.startsWith(resultPrefix));
        const batchChildIds = currentChildIds.includes(nodeId)
            ? currentChildIds.flatMap((id) => id === nodeId ? taskChildIds : [id])
            : [...currentChildIds, ...taskChildIds];
        const targetNode: CanvasNodeData = {
            ...root,
            metadata: {
                ...root.metadata,
                isBatchRoot: undefined,
                batchChildIds: undefined,
                primaryImageId: undefined,
                imageBatchExpanded: undefined,
                batchRootId,
            },
        };
        const extraNodes = urls.slice(1).map((url, index): CanvasNodeData => {
            const stored = task.imageStorage?.find((image) => image?.url === url);
            const naturalWidth = stored?.width || root.metadata?.naturalWidth || root.width;
            const naturalHeight = stored?.height || root.metadata?.naturalHeight || root.height;
            const imageSize = isPanoramaNodeType(root.type) ? PANORAMA_NODE_SIZE : normalizeNodeSize(naturalWidth, naturalHeight);
            return {
                ...targetNode,
                id: extraIds[index],
                width: imageSize.width,
                height: imageSize.height,
                metadata: {
                    ...targetNode.metadata,
                    content: url,
                    storageKey: stored?.storageKey || "",
                    mimeType: stored?.mimeType || "image/png",
                    bytes: stored?.bytes || 0,
                    naturalWidth,
                    naturalHeight,
                    status: NODE_STATUS_SUCCESS,
                    progress: 100,
                    imageTaskId: undefined,
                    imageTaskResultId: task.id,
                },
            };
        });
        const childIndex = new Map(batchChildIds.map((id, index) => [id, index]));
        // 093：主图占田字格 (0,0)，子图按阅读顺序填其余格（LibTV 真值，gap 8、行底对齐）
        const childBoxes = layoutBatchExpandedChildren({ x: batchRoot.position.x, y: batchRoot.position.y, width: batchRoot.width, height: batchRoot.height }, batchChildIds.map(() => ({ width: fallbackSize.width, height: fallbackSize.height })));
        const flatNodes = updated
            .flatMap((node): CanvasNodeData[] => {
                if (node.id === nodeId) return [targetNode, ...extraNodes];
                return node.id.startsWith(resultPrefix) ? [] : [node];
            })
            .map((node) => {
                const index = childIndex.get(node.id);
                if (index === undefined || node.metadata?.batchRootId !== batchRootId) return node;
                return {
                    ...node,
                    position: childBoxes[index],
                };
            });
        const flatNodeById = new Map(flatNodes.map((node) => [node.id, node]));
        let primaryImageId = batchChildIds.includes(batchRoot.metadata?.primaryImageId || "") ? batchRoot.metadata?.primaryImageId : batchChildIds[0];
        let primaryNode = primaryImageId ? flatNodeById.get(primaryImageId) : undefined;
        if (primaryNode?.metadata?.status === NODE_STATUS_ERROR && !primaryNode.metadata.content) {
            const children = batchChildIds.flatMap((id) => {
                const child = flatNodeById.get(id);
                return child ? [child] : [];
            });
            const replacement = children.find((node) => Boolean(node.metadata?.content)) || children.find((node) => node.metadata?.status === NODE_STATUS_LOADING);
            if (replacement) {
                primaryNode = replacement;
                primaryImageId = replacement.id;
            }
        }
        return flatNodes.map((node) => {
            if (node.id !== batchRootId) return node;
            const primary = primaryNode?.metadata;
            return {
                ...node,
                ...(primaryNode?.metadata?.content ? { width: primaryNode.width, height: primaryNode.height } : {}),
                metadata: {
                    ...node.metadata,
                    isBatchRoot: true,
                    batchChildIds,
                    primaryImageId,
                    imageBatchExpanded: node.metadata?.imageBatchExpanded ?? true,
                    status: primary?.status || node.metadata?.status,
                    errorDetails: primary?.errorDetails,
                    startedAt: primary?.startedAt,
                    durationMs: primary?.durationMs,
                    progress: primary?.progress,
                    content: primary?.content,
                    storageKey: primary?.storageKey || "",
                    mimeType: primary?.mimeType,
                    bytes: primary?.bytes || 0,
                    naturalWidth: primary?.naturalWidth,
                    naturalHeight: primary?.naturalHeight,
                    panoramaProjection: primary?.panoramaProjection,
                    imageTaskId: undefined,
                    imageTaskResultId: primary?.imageTaskResultId,
                },
            };
        });
    }
    if (urls.length < 2) return updated;
    const supportsMultiOutput = task.source === "workflow"
        ? isCanvasImageNodeType(root.type)
        : root.type === CanvasNodeType.Image && isKIESeedreamLayerDecompositionModel(task.model);
    if (!supportsMultiOutput) return updated;
    const childIds = canvasImageTaskChildIds(nodeId, task);
    // 093：主图占田字格 (0,0)，子图按阅读顺序填其余格（LibTV 真值，gap 8、行底对齐）
    const childBoxes = layoutBatchExpandedChildren({ x: root.position.x, y: root.position.y, width: root.width, height: root.height }, urls.map(() => ({ width: root.width, height: root.height })));
    const childNodes = urls.map((url, index): CanvasNodeData => {
        const id = childIds[index];
        const stored = task.imageStorage?.find((image) => image?.url === url);
        return {
            ...root,
            id,
            position: childBoxes[index],
            metadata: {
                ...root.metadata,
                content: url,
                status: NODE_STATUS_SUCCESS,
                progress: 100,
                storageKey: stored?.storageKey || "",
                mimeType: stored?.mimeType || "image/png",
                bytes: stored?.bytes || 0,
                naturalWidth: stored?.width || root.metadata?.naturalWidth,
                naturalHeight: stored?.height || root.metadata?.naturalHeight,
                imageTaskId: undefined,
                imageTaskResultId: task.id,
                isBatchRoot: undefined,
                batchChildIds: undefined,
                primaryImageId: undefined,
                imageBatchExpanded: undefined,
                batchRootId: nodeId,
            },
        };
    });
    return [
        ...updated.filter((node) => !childIds.includes(node.id)).map((node) => {
            if (node.id === nodeId) return { ...node, metadata: { ...node.metadata, isBatchRoot: true, batchChildIds: childIds, primaryImageId: childIds[0], imageBatchExpanded: true, count: urls.length } };
            if (node.metadata?.batchRootId === nodeId) return { ...node, metadata: { ...node.metadata, batchRootId: undefined } };
            return node;
        }),
        ...childNodes,
    ];
}

function applyCanvasImageTaskConnections(connections: CanvasConnection[], nodeId: string, task: CanvasImageTask, batchRootId?: string) {
    if (task.source === "workflow" && batchRootId) {
        const resultPrefix = `${nodeId}-result-`;
        const childIds = [nodeId, ...canvasImageTaskChildIds(nodeId, task).slice(1)];
        const childIdSet = new Set(childIds);
        const next = connections.filter((connection) => {
            if (connection.fromNodeId === nodeId && connection.toNodeId.startsWith(resultPrefix)) return false;
            return connection.fromNodeId !== batchRootId || !connection.toNodeId.startsWith(resultPrefix) || childIdSet.has(connection.toNodeId);
        });
        const existing = new Set(next.map((connection) => `${connection.fromNodeId}:${connection.toNodeId}`));
        return [...next, ...childIds.flatMap((childId): CanvasConnection[] => existing.has(`${batchRootId}:${childId}`) ? [] : [{ id: `${batchRootId}-connection-${childId}`, fromNodeId: batchRootId, toNodeId: childId }])];
    }
    if (task.source !== "workflow" && !isKIESeedreamLayerDecompositionModel(task.model)) return connections;
    const childIds = canvasImageTaskChildIds(nodeId, task);
    if (childIds.length < 2) return connections;
    const existing = new Set(connections.map((connection) => `${connection.fromNodeId}:${connection.toNodeId}`));
    return [...connections, ...childIds.flatMap((childId): CanvasConnection[] => existing.has(`${nodeId}:${childId}`) ? [] : [{ id: `${nodeId}-connection-${childId}`, fromNodeId: nodeId, toNodeId: childId }])];
}

function applyCanvasAudioTaskUpdate(nodes: CanvasNodeData[], nodeId: string, task: CanvasAudioTask, startedAt: number) {
    return nodes.map((node) => {
        if (node.id !== nodeId) return node;
        const progress = typeof task.progress === "number" ? Math.max(0, Math.min(100, task.progress)) : node.metadata?.progress || 0;
        const url = task.audio_url || task.url || "";
        const completed = canvasTaskCompleted(task.status) || Boolean(url);
        const failed = canvasTaskFailed(task.status) || (completed && !url);
        const taskStartedAt = parseCanvasTaskTime(task.started_at ?? task.startedAt ?? task.created_at ?? task.createdAt) || startedAt;
        const metadata: CanvasNodeMetadata = {
            ...node.metadata,
            status: failed ? NODE_STATUS_ERROR : completed ? NODE_STATUS_SUCCESS : NODE_STATUS_LOADING,
            errorDetails: failed ? task.error?.message || "音频生成失败" : undefined,
            startedAt: taskStartedAt,
            durationMs: Date.now() - taskStartedAt,
            progress,
            audioTaskId: task.id || node.metadata?.audioTaskId,
        };
        if (!completed || !url) return { ...node, metadata };
        return {
            ...node,
            metadata: {
                ...metadata,
                content: url,
                storageKey: task.storageKey || "",
                status: NODE_STATUS_SUCCESS,
                bytes: task.bytes || 0,
                mimeType: task.mimeType || "audio/mpeg",
                progress: 100,
                audioTaskResultId: task.id,
            },
        };
    });
}

function canvasVideoTaskFromMetadata(metadata?: CanvasNodeMetadata): VideoResponse {
    return {
        id: canvasVideoTaskId(metadata),
        task_id: metadata?.videoTaskId,
        video_id: metadata?.videoTaskVideoId,
        model: metadata?.model,
        status: metadata?.status,
        progress: metadata?.progress,
    };
}

function canvasVideoTaskId(metadata?: CanvasNodeMetadata) {
    return metadata?.videoTaskVideoId || metadata?.videoTaskId || "";
}

function canvasVideoTaskCompleted(task: VideoResponse) {
    return Boolean(task.video_url || task.url) || ["completed", "complete", "done", "succeeded", "success"].includes((task.status || "").toLowerCase());
}

function canvasVideoTaskFailed(task: VideoResponse) {
    return ["failed", "fail", "error", "cancelled", "canceled"].includes((task.status || "").toLowerCase());
}

function parseCanvasVideoTaskSize(value: unknown, fallback: { width: number; height: number }) {
    const match = typeof value === "string" ? value.match(/^(\d+)x(\d+)$/) : null;
    return { width: match ? Number(match[1]) : fallback.width, height: match ? Number(match[2]) : fallback.height };
}

function parseCanvasVideoTaskTime(value: unknown) {
    return parseCanvasTaskTime(value);
}

function parseCanvasTaskTime(value: unknown) {
    if (typeof value === "number") return value > 100000000000 ? value : value * 1000;
    if (typeof value !== "string" || !value.trim()) return 0;
    const numeric = Number(value);
    if (Number.isFinite(numeric)) return numeric > 100000000000 ? numeric : numeric * 1000;
    const parsed = Date.parse(value);
    return Number.isFinite(parsed) ? parsed : 0;
}

function canvasAgentNodeSummary(node: CanvasNodeData) {
    const content = node.metadata?.content || "";
    const isText = node.type === CanvasNodeType.Text;
    return {
        id: node.id,
        type: node.type,
        title: node.title,
        text: isText ? content.slice(0, 4000) : undefined,
        mediaUrl: !isText && content && !content.startsWith("data:") ? content : undefined,
        hasMedia: !isText ? Boolean(content) : undefined,
        status: node.metadata?.status || "idle",
        prompt: node.metadata?.prompt?.slice(0, 4000),
        model: node.metadata?.model,
        size: node.metadata?.size,
        seconds: node.metadata?.seconds,
        generateAudio: node.metadata?.generateAudio,
        taskId: canvasRecoverableTaskId(node) || undefined,
        progress: node.metadata?.progress,
        error: node.metadata?.errorDetails,
        groupId: node.metadata?.groupId,
    };
}

function canvasAgentTaskSummary(node: CanvasNodeData) {
    const content = node.metadata?.content || "";
    return {
        type: node.type,
        status: node.metadata?.status || "idle",
        taskId: canvasRecoverableTaskId(node) || undefined,
        progress: node.metadata?.progress,
        error: node.metadata?.errorDetails,
        mediaUrl: content && !content.startsWith("data:") ? content : undefined,
    };
}

function canvasAgentVideoDurationHint(modelName: string) {
    const key = modelKey(modelName);
    if (isCogVideoX3Model(key)) return { values: [5, 10], range: "仅 5 或 10 秒" };
    if (key.includes("seedance-2-5")) return { min: 4, max: 30, auto: -1, range: "智能（-1）或 4-30 秒，范围内任意整数秒数均可；videoSeconds 仅为默认值，可由本次 seconds 覆盖" };
    if (key.includes("seedance")) return { values: [-1, 4, 5, 6, 8, 10, 12, 15], range: "智能或 4-15 秒" };
    if (isCanvasAgentKlingV3(key)) return { values: [3, 15], range: "3-15 秒" };
    if (isCanvasAgentKlingV26(key)) return { values: [5, 10], range: "仅 5 或 10 秒" };
    return { values: [6, 10, 12, 16, 20], range: "1-30 秒" };
}

function validateCanvasAgentVideoSeconds(modelName: string, seconds: number) {
    if (!Number.isInteger(seconds)) return "视频总时长必须为整数秒";
    const key = modelKey(modelName);
    if (isCogVideoX3Model(key) && seconds !== 5 && seconds !== 10) return "当前 CogVideoX-3 模型仅支持 5 或 10 秒";
    const seedanceMaxSeconds = key.includes("seedance-2-5") ? 30 : 15;
    if (key.includes("seedance") && seconds !== -1 && (seconds < 4 || seconds > seedanceMaxSeconds)) return `当前 Seedance 模型仅支持智能时长或 4-${seedanceMaxSeconds} 秒`;
    if (isCanvasAgentKlingV3(key) && (seconds < 3 || seconds > 15)) return "当前 Kling 3 模型仅支持 3-15 秒";
    if (isCanvasAgentKlingV26(key) && seconds !== 5 && seconds !== 10) return "当前 Kling 2.6 模型仅支持 5 或 10 秒";
    if (!key.includes("seedance") && !key.includes("kling") && (seconds < 1 || seconds > 30)) return "当前视频模型仅支持 1-30 秒";
    return "";
}

function isCanvasAgentKlingV3(key: string) {
    return key.includes("kling-v3") || key.includes("kling-3-0");
}

function isCanvasAgentKlingV26(key: string) {
    return key.includes("kling-v2-6") || key.includes("kling-2-6");
}

function buildGenerationConfig(config: AiConfig, node: CanvasNodeData | undefined, mode: CanvasNodeGenerationMode): AiConfig {
    const configuredVideoModel = config.videoModel;
    const canvasVideoModel = mode === "video" && isEmbeddedSaintCanvas() && (!configuredVideoModel || configuredVideoModel === "grok-imagine-video") ? SAINT_DOLA_POOL_MODEL : configuredVideoModel;
    const defaultModel = mode === "image" ? config.imageModel : mode === "video" ? canvasVideoModel : mode === "audio" ? config.audioModel : config.textModel;
    const channelId = node?.metadata?.channelId || "";
    const imageChannelId = mode === "image" ? channelId || config.imageChannelId : config.imageChannelId;
    const videoChannelId = mode === "video" ? channelId || config.videoChannelId : config.videoChannelId;
    const textChannelId = mode === "text" ? channelId || config.textChannelId : config.textChannelId;
    const audioChannelId = mode === "audio" ? channelId || config.audioChannelId : config.audioChannelId;
    const activeChannelId = mode === "image" ? imageChannelId : mode === "video" ? videoChannelId : mode === "text" ? textChannelId : mode === "audio" ? audioChannelId || config.activeChannelId : config.activeChannelId;
    return {
        ...config,
        model: mode === "text" ? resolveModelForCapability(config, node?.metadata?.model, "text") : node?.metadata?.model || defaultModel || (mode === "audio" ? defaultConfig.audioModel : config.model || defaultConfig.model),
        activeChannelId,
        imageChannelId,
        videoChannelId,
        textChannelId,
        audioChannelId,
        quality: node?.metadata?.quality || config.quality || defaultConfig.quality,
        size: isPanoramaNodeType(node?.type) ? PANORAMA_IMAGE_SIZE : node?.metadata?.size || (mode === "video" ? config.videoSize || defaultConfig.videoSize : config.size || defaultConfig.size),
        videoSeconds: normalizeSaintPoolSeconds(node?.metadata?.model || defaultModel, node?.metadata?.seconds || config.videoSeconds || defaultConfig.videoSeconds),
        vquality: node?.metadata?.vquality || config.vquality || defaultConfig.vquality,
        videoMode: node?.metadata?.mode || config.videoMode || defaultConfig.videoMode,
        videoNegativePrompt: node?.metadata?.negativePrompt || config.videoNegativePrompt || defaultConfig.videoNegativePrompt,
        videoMultiShot: node?.metadata?.multiShot || config.videoMultiShot || defaultConfig.videoMultiShot,
        videoShotType: node?.metadata?.shotType || config.videoShotType || defaultConfig.videoShotType,
        videoGenerateAudio: node?.metadata?.generateAudio || config.videoGenerateAudio || defaultConfig.videoGenerateAudio,
        videoCharacterOrientation: node?.metadata?.characterOrientation || config.videoCharacterOrientation || defaultConfig.videoCharacterOrientation,
        videoWatermark: node?.metadata?.watermark || config.videoWatermark || defaultConfig.videoWatermark,
        audioVoice: node?.metadata?.audioVoice || config.audioVoice || defaultConfig.audioVoice,
        audioFormat: node?.metadata?.audioFormat || config.audioFormat || defaultConfig.audioFormat,
        audioSpeed: node?.metadata?.audioSpeed || config.audioSpeed || defaultConfig.audioSpeed,
        audioInstructions: node?.metadata?.audioInstructions || config.audioInstructions || defaultConfig.audioInstructions,
        grokTtsVoice: node?.metadata?.grokTtsVoice || config.grokTtsVoice || defaultConfig.grokTtsVoice,
        grokTtsLanguage: node?.metadata?.grokTtsLanguage || config.grokTtsLanguage || defaultConfig.grokTtsLanguage,
        grokTtsFormat: node?.metadata?.grokTtsFormat || config.grokTtsFormat || defaultConfig.grokTtsFormat,
        grokTtsSpeed: node?.metadata?.grokTtsSpeed || config.grokTtsSpeed || defaultConfig.grokTtsSpeed,
        glmTtsVoice: node?.metadata?.glmTtsVoice || config.glmTtsVoice || defaultConfig.glmTtsVoice,
        glmTtsFormat: node?.metadata?.glmTtsFormat || config.glmTtsFormat || defaultConfig.glmTtsFormat,
        glmTtsSpeed: node?.metadata?.glmTtsSpeed || config.glmTtsSpeed || defaultConfig.glmTtsSpeed,
        mimoTtsVoice: node?.metadata?.mimoTtsVoice || config.mimoTtsVoice || defaultConfig.mimoTtsVoice,
        mimoTtsFormat: node?.metadata?.mimoTtsFormat || config.mimoTtsFormat || defaultConfig.mimoTtsFormat,
        mimoVoiceDesignPrompt: node?.metadata?.mimoVoiceDesignPrompt || config.mimoVoiceDesignPrompt || defaultConfig.mimoVoiceDesignPrompt,
        geminiTtsVoice: node?.metadata?.geminiTtsVoice || config.geminiTtsVoice || defaultConfig.geminiTtsVoice,
        count: String(node?.metadata?.count || (mode === "image" ? config.canvasImageCount || config.count : config.count) || defaultConfig.count),
    };
}

function resetInterruptedGeneration(nodes: CanvasNodeData[]) {
    return nodes.map((node) => (node.metadata?.status === "loading" && !canvasRecoverableTaskId(node) ? { ...node, metadata: { ...node.metadata, status: "error" as const, errorDetails: "页面刷新后生成已中断，请重新生成。" } } : node));
}

function canvasRecoverableTaskId(node: CanvasNodeData) {
    if (node.type === CanvasNodeType.Video) return canvasVideoTaskId(node.metadata);
    if (isCanvasImageNodeType(node.type)) return node.metadata?.imageTaskId || "";
    if (node.type === CanvasNodeType.Audio) return node.metadata?.audioTaskId || "";
    return "";
}

function canvasTaskCompleted(status?: string) {
    return ["completed", "complete", "done", "succeeded", "success"].includes((status || "").toLowerCase());
}

function canvasTaskFailed(status?: string) {
    return ["failed", "fail", "error", "cancelled", "canceled"].includes((status || "").toLowerCase());
}

async function submitCanvasWorkflowTask(ref: WorkflowRef, config: AiConfig, mode: "image" | "video" | "audio", prompt: string, images: ReferenceImage[], videos: ReferenceVideo[], audios: ReferenceAudio[], nodeId: string, projectId: string, clientTaskId: string) {
    const token = useUserStore.getState().token;
    if (!token) throw new Error("工作流生成需要先登录");
    const [referenceImages, referenceVideos, referenceAudios] = await Promise.all([
        Promise.all(images.map((image) => workflowMediaSource(image.dataUrl))),
        Promise.all(videos.map((video) => workflowMediaSource(video.url))),
        Promise.all(audios.map((audio) => workflowMediaSource(audio.url))),
    ]);
    if (useUserStore.getState().token !== token) throw new Error("登录状态已变化");
    const task = await submitWorkflowTask(token, {
        ref,
        expectedCapability: mode,
        prompt,
        systemPrompt: config.systemPrompt,
        referenceImages,
        referenceVideos,
        referenceAudios,
        size: config.size,
        quality: config.quality,
        count: mode === "image" ? 1 : undefined,
        videoSeconds: config.videoSeconds,
        videoQuality: config.vquality,
        videoGenerateAudio: config.videoGenerateAudio === "true",
        videoWatermark: config.videoWatermark === "true",
        audioVoice: config.audioVoice,
        audioFormat: config.audioFormat,
        audioSpeed: Number(config.audioSpeed) || 1,
        audioInstructions: config.audioInstructions,
        source: "canvas", sourceId: projectId, nodeId, clientTaskId,
    });
    if (useUserStore.getState().token !== token) throw new Error("登录状态已变化");
    return task;
}

async function workflowImageTask(task: WorkflowGenerationTask, token = useUserStore.getState().token): Promise<CanvasImageTask> {
    if (!token || useUserStore.getState().token !== token) throw new Error("登录状态已变化");
    const images = task.status === "succeeded" ? await Promise.all((task.urls || []).map((url) => {
        const storageKey = comfyOutputStorageKey(url);
        return storageKey ? { url, storageKey, width: 0, height: 0, bytes: 0, mimeType: "image/png" } : uploadImage(url, { token });
    })) : [];
    if (useUserStore.getState().token !== token) throw new Error("登录状态已变化");
    return { id: task.id, source: "workflow", status: task.status === "succeeded" ? "completed" : task.status, progress: task.progress, image_url: images[0]?.url, image_urls: images.map((image) => image.url), imageStorage: images, storageKey: images[0]?.storageKey, width: images[0]?.width, height: images[0]?.height, mimeType: images[0]?.mimeType, bytes: images[0]?.bytes, error: task.error ? { message: task.error } : undefined };
}

async function workflowVideoTask(task: WorkflowGenerationTask, token = useUserStore.getState().token): Promise<VideoResponse> {
    if (!token || useUserStore.getState().token !== token) throw new Error("登录状态已变化");
    const url = task.status === "succeeded" ? task.urls?.[0] || "" : "";
    const storageKey = comfyOutputStorageKey(url);
    const video = url && !storageKey ? await uploadMediaFile(await downloadRemoteMedia(url), "workflow-video", undefined, token) : null;
    if (useUserStore.getState().token !== token) throw new Error("登录状态已变化");
    return { id: task.id, task_id: task.id, status: task.status === "succeeded" ? "completed" : task.status, progress: task.progress, video_url: video?.url || url, url: video?.url || url, storageKey: video?.storageKey || storageKey, error: task.error ? { message: task.error } : undefined };
}

async function workflowAudioTask(task: WorkflowGenerationTask, token = useUserStore.getState().token): Promise<CanvasAudioTask> {
    if (!token || useUserStore.getState().token !== token) throw new Error("登录状态已变化");
    const url = task.status === "succeeded" ? task.urls?.[0] || "" : "";
    const storageKey = comfyOutputStorageKey(url);
    const audio = url && !storageKey ? await uploadMediaFile(await downloadRemoteMedia(url), "workflow-audio", undefined, token) : null;
    if (useUserStore.getState().token !== token) throw new Error("登录状态已变化");
    return { id: task.id, status: task.status === "succeeded" ? "completed" : task.status, progress: task.progress, audio_url: audio?.url || url, url: audio?.url || url, storageKey: audio?.storageKey || storageKey, mimeType: audio?.mimeType || "audio/mpeg", bytes: audio?.bytes || 0, error: task.error ? { message: task.error } : undefined };
}

function findRetrySourceNode(nodeId: string, nodes: CanvasNodeData[], connections: CanvasConnection[]) {
    const queue = connections.filter((connection) => connection.toNodeId === nodeId).map((connection) => connection.fromNodeId);
    const visited = new Set<string>();
    while (queue.length) {
        const id = queue.shift()!;
        if (visited.has(id)) continue;
        visited.add(id);
        const node = nodes.find((item) => item.id === id);
        if (node?.type === CanvasNodeType.Config) return node;
        connections.filter((connection) => connection.toNodeId === id).forEach((connection) => queue.push(connection.fromNodeId));
    }
    return null;
}

function sourceNodeReferenceImages(node: CanvasNodeData | null) {
    if (!node || !isCanvasImageNodeType(node.type) || !node.metadata?.content) return [];
    return [
        {
            id: node.id,
            name: `image-${node.id}.png`,
            type: node.metadata.mimeType || "image/png",
            dataUrl: node.metadata.content,
            storageKey: node.metadata.storageKey,
        },
    ];
}

function isAudioFile(file: File) {
    return file.type.startsWith("audio/") || /\.(mp3|wav)$/i.test(file.name);
}

function isHiddenBatchChild(node: CanvasNodeData, nodes: CanvasNodeData[], collapsingBatchIds?: Set<string>) {
    const rootId = node.metadata?.batchRootId;
    if (!rootId) return false;
    const root = nodes.find((item) => item.id === rootId);
    if (root && collapsingBatchIds?.has(rootId)) return false;
    return Boolean(root && !root.metadata?.imageBatchExpanded);
}

function isHiddenBatchConnectionEndpoint(node: CanvasNodeData, nodes: CanvasNodeData[]) {
    const rootId = node.metadata?.batchRootId;
    if (!rootId) return false;
    const root = nodes.find((item) => item.id === rootId);
    return Boolean(root && !root.metadata?.imageBatchExpanded);
}

function buildAngleLabel(params: CanvasImageAngleParams) {
    const horizontal = params.horizontalAngle === 0 ? "正面视角" : params.horizontalAngle > 0 ? `向右旋转 ${params.horizontalAngle} 度` : `向左旋转 ${Math.abs(params.horizontalAngle)} 度`;
    const pitch = params.pitchAngle === 0 ? "水平视角" : params.pitchAngle > 0 ? `俯视 ${params.pitchAngle} 度` : `仰视 ${Math.abs(params.pitchAngle)} 度`;
    return `AI 多角度：${horizontal}，${pitch}，镜头距离 ${params.cameraDistance.toFixed(1)}，${params.wideAngle ? "广角" : "标准"}镜头`;
}

function buildAnglePrompt(params: CanvasImageAngleParams) {
    return `基于参考图重新生成同一主体的新视角，保持主体、颜色、材质和画面风格一致，不要只做透视变形。${buildAngleLabel(params)}。`;
}
