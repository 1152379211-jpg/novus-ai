import type { CSSProperties, MouseEvent as ReactMouseEvent, ReactNode, RefObject } from "react";
import { useRef, useState } from "react";
import { createPortal } from "react-dom";
import { Button } from "antd";
import { FolderOpen, Globe2, Hand, History, Image as ImageIcon, Images, Keyboard, Layers3, MousePointer2, Music2, Plus, Settings2, Type, Upload, Video, X } from "lucide-react";

import { canvasThemes, type CanvasBackgroundMode, type CanvasTheme } from "@/lib/canvas-theme";
import { useThemeStore } from "@/stores/use-theme-store";

// boss 2026-10-07 批次 130：Agent 常驻按钮光环中央文字 = 软件名（同 canvas-node.tsx 批次 128 的 GEN_LOADER_TEXT）
const AGENT_FAB_TEXT = "Novus AI";

export function CanvasToolbar({
    canvasTool,
    onAddImage,
    onAddVideo,
    onAddAudio,
    onAddText,
    onAddPanorama,
    onAddDirector,
    onAddConfig,
    onUpload,
    onCanvasToolChange,
    onOpenAssetLibrary,
    onOpenMyAssets,
    onOpenHistory,
    onOpenShortcuts,
    onOpenAgent,
    hideDock = false,
}: {
    selectedCount?: number;
    canvasTool: "select" | "pan";
    canUndo?: boolean;
    canRedo?: boolean;
    backgroundMode?: CanvasBackgroundMode;
    snapToGrid?: boolean;
    showImageInfo?: boolean;
    onAddImage: () => void;
    onAddVideo: () => void;
    onAddAudio: () => void;
    onAddText: () => void;
    onAddPanorama: () => void;
    onAddDirector?: () => void;
    onAddConfig?: () => void;
    /** 撤销/重做已从工具栏移除（两个箭头按钮已取消），保留 prop 兼容旧调用 */
    onUndo?: () => void;
    onRedo?: () => void;
    onUpload: () => void;
    onDelete?: () => void;
    /** 已从工具栏移除“清空画布”按钮，保留 prop 兼容旧调用 */
    onClear?: () => void;
    onCanvasToolChange: (tool: "select" | "pan") => void;
    onBackgroundModeChange?: (mode: CanvasBackgroundMode) => void;
    onSnapToGridChange?: (snap: boolean) => void;
    onShowImageInfoChange?: (show: boolean) => void;
    onOpenAssetLibrary: () => void;
    onOpenMyAssets: () => void;
    /** 生成历史：打开 Agent 面板的历史记录视图 */
    onOpenHistory: () => void;
    /** 快捷键说明 */
    onOpenShortcuts: () => void;
    /** 右侧蓝色圆球：打开 Agent 面板（原右上角 Agent 按钮） */
    onOpenAgent: () => void;
    /** boss 2026-10-03：取消现有工具栏圆角框（留原版底部导航），仅保留蓝色 Agent 按钮 */
    hideDock?: boolean;
}) {
    const wrapRef = useRef<HTMLDivElement>(null);
    const colorTheme = useThemeStore((state) => state.theme);
    const theme = canvasThemes[colorTheme];
    const [hovered, setHovered] = useState<string | null>(null);
    const [tipX, setTipX] = useState(0);
    const [addMenuOpen, setAddMenuOpen] = useState(false);
    /** 菜单用视口坐标定位（portal 到 body），避免被工具栏容器裁剪或定位参照出错 */
    const [menuPos, setMenuPos] = useState<{ left: number; bottom: number; maxHeight: number } | null>(null);
    const dockStyle = { background: theme.toolbar.panel, borderColor: theme.toolbar.border, color: theme.toolbar.item, boxShadow: colorTheme === "dark" ? "0 18px 45px rgba(0,0,0,.32)" : "0 16px 40px rgba(28,25,23,.12)" };
    const hoverStyle = { background: theme.toolbar.itemHover, color: theme.toolbar.activeText };
    const activeStyle = { background: theme.toolbar.activeBg, color: theme.toolbar.activeText };
    const tip = hovered ? toolLabel(hovered) : "";

    return (
        <div className={`pointer-events-none absolute ${hideDock ? "bottom-6 md:bottom-3" : "bottom-5"} z-50 flex gap-3 ${hideDock ? "" : "justify-start"}`} style={hideDock ? { left: "50%", transform: "translateX(134.5px)" } : { left: 16, right: 16 }}>
            {tip ? <DockTip label={tip} x={tipX} theme={theme} /> : null}
            {!hideDock ? <div ref={wrapRef} className="thin-scrollbar pointer-events-auto flex h-14 max-w-full items-center gap-1 overflow-x-auto rounded-xl border px-2 shadow-lg backdrop-blur [&>*]:shrink-0" style={dockStyle}>
                <ToolbarButton
                    id="tool-add"
                    label="添加节点"
                    highlight
                    active={addMenuOpen}
                    hovered={hovered}
                    activeStyle={activeStyle}
                    hoverStyle={hoverStyle}
                    wrapRef={wrapRef}
                    onTipX={setTipX}
                    onHover={setHovered}
                    onClick={(event) => {
                        const rect = event.currentTarget.getBoundingClientRect();
                        const menuWidth = 272;
                        const left = Math.min(Math.max(rect.left + rect.width / 2, menuWidth / 2 + 8), window.innerWidth - menuWidth / 2 - 8);
                        const bottom = Math.max(window.innerHeight - rect.top + 12, 12);
                        const maxHeight = Math.max(Math.min(window.innerHeight - bottom - 12, 640), 220);
                        setMenuPos({ left, bottom, maxHeight });
                        setAddMenuOpen((value) => !value);
                    }}
                >
                    <Plus className="size-4.5" />
                </ToolbarButton>
                <ToolbarButton id={`tool-${canvasTool}`} label={canvasTool === "select" ? "选择" : "移动"} active hovered={hovered} activeStyle={activeStyle} hoverStyle={hoverStyle} wrapRef={wrapRef} onTipX={setTipX} onHover={setHovered} onClick={() => onCanvasToolChange(canvasTool === "select" ? "pan" : "select")}>
                    {canvasTool === "select" ? <MousePointer2 className="size-4.5" /> : <Hand className="size-4.5" />}
                </ToolbarButton>
                <ToolbarButton id="tool-library" label="素材库" hovered={hovered} hoverStyle={hoverStyle} wrapRef={wrapRef} onTipX={setTipX} onHover={setHovered} onClick={onOpenAssetLibrary}>
                    <Images className="size-4.5" />
                </ToolbarButton>
                <ToolbarButton id="tool-history" label="生成历史" hovered={hovered} hoverStyle={hoverStyle} wrapRef={wrapRef} onTipX={setTipX} onHover={setHovered} onClick={onOpenHistory}>
                    <History className="size-4.5" />
                </ToolbarButton>
                <Divider theme={theme} />
                <ToolbarButton id="tool-shortcuts" label="快捷键" hovered={hovered} hoverStyle={hoverStyle} wrapRef={wrapRef} onTipX={setTipX} onHover={setHovered} onClick={onOpenShortcuts}>
                    <Keyboard className="size-4.5" />
                </ToolbarButton>
            </div> : null}
            <button
                type="button"
                aria-label="Agent"
                title="Agent"
                className={`pointer-events-auto grid size-[50px] shrink-0 place-items-center self-center rounded-full transition hover:scale-105`}
                onClick={onOpenAgent}
            >
                {/* boss 2026-10-07 批次 130：蓝钮常驻外观换 Uiverse dexter-st 光环 loader（同 128 节点内 loader），文字=软件名；点击仍打开 Agent。
                    原蓝底渐变移除（原版 wrapper 即透明底）；size-11→size-[50px] 与原版导航条等高齐平（p-2+h-8+hair边框=50px；boss 2026-10-07 三次打回后按截图像素定案）；容器贴底与导航条同款（<768px 24px / >=768px 12px，md 断点同 b768）；间距 134.5px 定的是按钮左缘（导航右缘 124.5 + 10）。 */}
                <span className="agent-fab-loader">
                    {AGENT_FAB_TEXT.split("").map((ch, index) => (
                        <span key={`${ch}-${index}`} className="agent-fab-loader-letter" style={{ animationDelay: `${index * 0.1}s` }}>
                            {ch === " " ? "\u00A0" : ch}
                        </span>
                    ))}
                    <span className="agent-fab-loader-ring" />
                </span>
            </button>

            {!hideDock && addMenuOpen && menuPos
                ? createPortal(
                    <div
                        className="thin-scrollbar pointer-events-auto fixed z-[200] max-h-[min(72vh,640px)] w-[272px] overflow-y-auto rounded-2xl border p-3 shadow-xl backdrop-blur"
                        style={{
                            left: menuPos.left,
                            bottom: menuPos.bottom,
                            maxHeight: menuPos.maxHeight,
                            transform: "translateX(-50%)",
                            background: theme.toolbar.panel,
                            borderColor: theme.toolbar.border,
                            color: theme.toolbar.item,
                        }}
                    >
                    <div className="flex items-center justify-between px-1 pb-2">
                        <span className="text-sm font-semibold">添加节点</span>
                        <button
                            type="button"
                            aria-label="关闭"
                            className="grid size-6 place-items-center rounded-md transition"
                            style={{ color: theme.toolbar.item }}
                            onMouseEnter={(event) => { event.currentTarget.style.background = theme.toolbar.itemHover; }}
                            onMouseLeave={(event) => { event.currentTarget.style.background = "transparent"; }}
                            onClick={() => setAddMenuOpen(false)}
                        >
                            <X className="size-3.5" />
                        </button>
                    </div>
                    {[
                        { key: "text", title: "文本生成", desc: "脚本、广告词、品牌文案", icon: <Type className="size-4" />, onClick: onAddText },
                        { key: "image", title: "图片生成", desc: null, icon: <ImageIcon className="size-4" />, onClick: onAddImage },
                        { key: "video", title: "视频生成", desc: null, icon: <Video className="size-4" />, onClick: onAddVideo },
                        { key: "audio", title: "音频参考", desc: null, icon: <Music2 className="size-4" />, onClick: onAddAudio },
                        { key: "panorama", title: "全景图", desc: "文生全景、图生全景", icon: <Globe2 className="size-4" />, onClick: onAddPanorama },
                        { key: "director", title: "3D 导演台", desc: "3D 场景、角色、机位", icon: <Layers3 className="size-4" />, onClick: onAddDirector ?? (() => {}) },
                        { key: "config", title: "配置节点", desc: "模型、尺寸、数量和输入顺序", icon: <Settings2 className="size-4" />, onClick: onAddConfig ?? (() => {}) },
                    ].map((item) => (
                        <button
                            key={item.key}
                            type="button"
                            className="flex w-full items-center gap-3 rounded-xl px-2 py-2 text-left transition"
                            style={{ color: theme.toolbar.item }}
                            onMouseEnter={(event) => { event.currentTarget.style.background = theme.toolbar.itemHover; }}
                            onMouseLeave={(event) => { event.currentTarget.style.background = "transparent"; }}
                            onClick={() => {
                                setAddMenuOpen(false);
                                item.onClick();
                            }}
                        >
                            <span className="grid size-9 shrink-0 place-items-center rounded-lg" style={{ background: theme.toolbar.itemHover, color: theme.toolbar.item }}>
                                {item.icon}
                            </span>
                            <span className="min-w-0">
                                <span className="block text-sm font-medium leading-5">{item.title}</span>
                                {item.desc ? <span className="block truncate text-xs opacity-50">{item.desc}</span> : null}
                            </span>
                        </button>
                    ))}
                    <div className="px-1 pb-2 pt-3 text-sm font-semibold opacity-80">添加资源</div>
                    {[
                        { key: "upload", title: "上传", desc: "图片、视频或音频", icon: <Upload className="size-4" />, onClick: onUpload },
                        { key: "assets", title: "从素材库选择", desc: "文本、图片或视频", icon: <FolderOpen className="size-4" />, onClick: onOpenMyAssets },
                    ].map((item) => (
                        <button
                            key={item.key}
                            type="button"
                            className="flex w-full items-center gap-3 rounded-xl px-2 py-2 text-left transition"
                            style={{ color: theme.toolbar.item }}
                            onMouseEnter={(event) => { event.currentTarget.style.background = theme.toolbar.itemHover; }}
                            onMouseLeave={(event) => { event.currentTarget.style.background = "transparent"; }}
                            onClick={() => {
                                setAddMenuOpen(false);
                                item.onClick();
                            }}
                        >
                            <span className="grid size-9 shrink-0 place-items-center rounded-lg" style={{ background: theme.toolbar.itemHover, color: theme.toolbar.item }}>
                                {item.icon}
                            </span>
                            <span className="min-w-0">
                                <span className="block text-sm font-medium leading-5">{item.title}</span>
                                {item.desc ? <span className="block truncate text-xs opacity-50">{item.desc}</span> : null}
                            </span>
                        </button>
                    ))}
                </div>,
                    document.body,
                )
                : null}
        </div>
    );
}

function ToolbarButton({
    id,
    label,
    active,
    highlight = false,
    hovered,
    activeStyle,
    hoverStyle,
    wrapRef,
    onTipX,
    onHover,
    onClick,
    disabled = false,
    danger = false,
    children,
}: {
    id: string;
    label: string;
    active?: boolean;
    /** 白底高亮样式（参考图工具栏的 ＋ 按钮） */
    highlight?: boolean;
    hovered: string | null;
    activeStyle?: CSSProperties;
    hoverStyle: CSSProperties;
    wrapRef: RefObject<HTMLDivElement | null>;
    onTipX: (x: number) => void;
    onHover: (id: string | null) => void;
    onClick?: (event: ReactMouseEvent<HTMLElement>) => void;
    disabled?: boolean;
    danger?: boolean;
    children: ReactNode;
}) {
    const theme = canvasThemes[useThemeStore((state) => state.theme)];

    return (
        <Button
            type="text"
            aria-label={label}
            /* 外层容器是 pointer-events-none（让画布透传点击），按钮必须显式恢复可点击；
               ＋ 移到圆角框外后曾漏掉这一点，导致点击完全没反应 */
            className="!h-8 !w-8 !min-w-8 !p-0 pointer-events-auto"
            disabled={disabled}
            style={highlight
                ? { background: theme.node.text, color: theme.node.panel, opacity: 1 }
                : active ? activeStyle : hovered === id && !disabled ? hoverStyle : { color: danger ? "#f87171" : theme.toolbar.item, opacity: disabled ? 0.35 : 1 }}
            icon={children}
            onMouseEnter={(event) => {
                onHover(id);
                onTipX(getTipX(wrapRef.current, event.currentTarget));
            }}
            onMouseLeave={() => onHover(null)}
            onClick={onClick}
        />
    );
}

function Divider({ theme }: { theme: CanvasTheme }) {
    return <div className="mx-1 h-6 w-px" style={{ background: theme.toolbar.border }} />;
}

/** Agent 专属图标：主四角星 + 右上次星（替换 lucide Sparkles） */
export function AgentSparkleIcon({ className, style }: { className?: string; style?: CSSProperties }) {
    return (
        <svg viewBox="0 0 24 24" fill="currentColor" className={className} style={style} aria-hidden="true">
            <path d="M11 5.5c.7 4.1 2.05 5.45 6.15 6.15-4.1.7-5.45 2.05-6.15 6.15-.7-4.1-2.05-5.45-6.15-6.15 4.1-.7 5.45-2.05 6.15-6.15Z" />
            <path d="M18.5 2c.3 1.75.9 2.35 2.65 2.65-1.75.3-2.35.9-2.65 2.65-.3-1.75-.9-2.35-2.65-2.65 1.75-.3 2.35-.9 2.65-2.65Z" opacity=".92" />
        </svg>
    );
}

function DockTip({ label, x, theme }: { label: string; x: number; theme: CanvasTheme }) {
    return (
        <span className="absolute bottom-[calc(100%+8px)] -translate-x-1/2 rounded-md px-2 py-1 text-xs shadow-lg" style={{ left: x, background: theme.node.text, color: theme.node.panel }}>
            {label}
        </span>
    );
}

function toolLabel(id: string) {
    if (id === "tool-select") return "选择";
    if (id === "tool-pan") return "移动";
    if (id === "tool-undo") return "撤销";
    if (id === "tool-redo") return "重做";
    if (id === "tool-add") return "添加节点";
    if (id === "tool-image") return "图片";
    if (id === "tool-video") return "视频";
    if (id === "tool-audio") return "音频";
    if (id === "tool-panorama") return "全景图";
    if (id === "tool-director") return "导演台";
    if (id === "tool-config") return "生成配置";
    if (id === "tool-upload") return "上传素材";
    if (id === "tool-library") return "素材库";
    if (id === "tool-history") return "生成历史";
    if (id === "tool-shortcuts") return "快捷键";
    if (id === "tool-assets") return "我的素材";
    if (id === "tool-style") return "画布外观";
    if (id === "tool-delete") return "删除选中";
    if (id === "tool-selection-video") return "选中生成视频";
    return "";
}

function getTipX(wrap: HTMLDivElement | null, target: HTMLElement) {
    if (!wrap) return 0;
    const wrapBox = wrap.parentElement?.getBoundingClientRect() || wrap.getBoundingClientRect();
    const box = target.getBoundingClientRect();
    return box.left - wrapBox.left + box.width / 2;
}
