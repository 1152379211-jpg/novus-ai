"use client";

import { useMemo, type CSSProperties, type ReactNode } from "react";
import { ArrowUp, Brain, ChevronDown, Cpu, FolderOpen, Gauge, ImageIcon, Menu, Square, Upload, Video, WandSparkles } from "lucide-react";
import { Button, Dropdown, Tooltip } from "antd";

import { canvasThemes } from "@/lib/canvas-theme";
import { useConfigStore, useEffectiveConfig } from "@/stores/use-config-store";
import { useThemeStore } from "@/stores/use-theme-store";
import { cn } from "@/lib/utils";
import { friendlyModelName } from "@/lib/model-display-name";
import { CanvasNodeType, type CanvasAgentConfig, type CanvasAgentSkillSelection, type CanvasAssistantReference } from "../types";
import type { CanvasResourceReference } from "../utils/canvas-resource-references";
import { CanvasAgentSkillPopover } from "./canvas-agent-skill-popover";
import { CanvasPromptChipInput } from "./canvas-prompt-chip-input";
import styles from "./canvas-prompt-bar.module.css";

export type CanvasAssistantComposerProps = {
    prompt: string;
    isRunning: boolean;
    codexControls?: ReactNode;
    references: CanvasAssistantReference[];
    availableReferences?: CanvasResourceReference[];
    pendingReferences?: CanvasResourceReference[];
    selectedSkills?: CanvasAgentSkillSelection[];
    agentConfig: CanvasAgentConfig;
    onAgentConfigChange: (patch: Partial<CanvasAgentConfig>) => void;
    onPromptChange: (prompt: string) => void;
    onReferenceIdsChange: (ids: string[]) => void;
    onSkillSelect?: (skill: CanvasAgentSkillSelection) => void;
    onSkillRemove?: (id: string, source: CanvasAgentSkillSelection["source"]) => void;
    onSubmit: (prompt?: string, referenceIds?: string[]) => void | Promise<void>;
    onStop?: () => void;
    onOpenUpload: () => void;
    onOpenAssets: () => void;
    onPasteImage: (file: File) => void;
};

export function CanvasAssistantComposer({
    prompt,
    isRunning,
    codexControls,
    references,
    availableReferences,
    pendingReferences,
    selectedSkills,
    agentConfig,
    onAgentConfigChange,
    onPromptChange,
    onReferenceIdsChange,
    onSkillSelect,
    onSkillRemove,
    onSubmit,
    onStop,
    onOpenUpload,
    onOpenAssets,
    onPasteImage,
}: CanvasAssistantComposerProps) {
    const theme = canvasThemes[useThemeStore((state) => state.theme)];
    const effectiveConfig = useEffectiveConfig();
    const updateConfig = useConfigStore((state) => state.updateConfig);
    const reasoningEnabled = agentConfig.textReasoningEnabled === true;
    // 070：Dola 系模型不能做 Agent 的 chat 对话（网页自动化无 chat 接口）——从 Agent 文本模型中排除
    const textModels = (effectiveConfig.textModels?.length ? effectiveConfig.textModels : effectiveConfig.models || [])
        .filter((model) => !/^dola-(expert-web|text|seedream)/i.test(model));
    const hostModels = useConfigStore((state) => state.hostModels);
    // 066-T5：模型显示一律友好名（boss：什么模型就是什么模型，禁止 ID/UUID 乱码）
    const modelLabel = (model: string) => friendlyModelName(model, hostModels);
    const selectedTextModel = effectiveConfig.textModel || effectiveConfig.model || "未选择模型";
    const promptReferences = useMemo(() => {
        const seen = new Set<string>();
        return [...(availableReferences || []), ...references.map(assistantToPromptReference)].filter((reference) => {
            if (seen.has(reference.nodeId)) return false;
            seen.add(reference.nodeId);
            return true;
        });
    }, [availableReferences, references]);
    const submit = (nextPrompt = prompt, referenceIds = references.map((reference) => reference.id)) => onSubmit(nextPrompt, referenceIds);

    const promptBarStyle = {
        "--prompt-bar-bg": theme.toolbar.panel,
        "--prompt-bar-border": theme.node.stroke,
        "--prompt-bar-text": theme.node.text,
        "--prompt-bar-muted": theme.node.muted,
        "--prompt-bar-hover": theme.toolbar.itemHover,
        "--prompt-bar-active": theme.toolbar.activeBg,
    } as CSSProperties;

    return (
        <div className={cn("px-2 pb-2", styles.host)} onWheelCapture={(event) => event.stopPropagation()}>
            <div className={styles.bar} data-running={isRunning ? "true" : undefined} style={promptBarStyle}>
                <div className={styles.editorFrame}>
                    <span className={styles.editorGlow} aria-hidden="true" />
                    <CanvasPromptChipInput
                        value={prompt}
                        references={promptReferences}
                        pendingReferences={pendingReferences}
                        skills={selectedSkills}
                        onSkillRemove={onSkillRemove}
                        onChange={onPromptChange}
                        onReferenceIdsChange={onReferenceIdsChange}
                        onPasteImage={onPasteImage}
                        onSubmit={submit}
                        className={cn("thin-scrollbar min-h-20 max-h-[220px] w-full px-1 py-0 text-sm leading-5", styles.editor)}
                        style={{ color: theme.node.text }}
                        placeholder="开始你的创作，或者 @ 引用工作流/节点/资源"
                        placeholderClassName="!left-1 !top-0"
                    />
                </div>
                <div className={cn("@container", styles.toolbar)}>
                    <div className="flex min-w-0 flex-1 items-center gap-1 overflow-hidden">
                        <Dropdown
                            trigger={["click"]}
                            menu={{
                                items: [
                                    { key: "upload", icon: <Upload className="size-4" />, label: "上传文件" },
                                    { key: "assets", icon: <FolderOpen className="size-4" />, label: "我的素材" },
                                ],
                                onClick: ({ key }) => (key === "upload" ? onOpenUpload() : onOpenAssets()),
                            }}
                        >
                            <Button type="text" shape="circle" className={cn("!h-8 !w-8 !min-w-8", styles.toolButton)} style={{ color: theme.node.text }} icon={<Menu className="size-4" />} aria-label="添加素材" />
                        </Dropdown>
                        {agentConfig.mode !== "codex" && textModels.length ? (
                            <Dropdown
                                trigger={["click"]}
                                placement="topLeft"
                                disabled={isRunning}
                                menu={{
                                    selectable: true,
                                    selectedKeys: [selectedTextModel],
                                    items: textModels.map((model) => ({ key: model, label: modelLabel(model) })),
                                    onClick: ({ key }) => updateConfig("textModel", key),
                                }}
                            >
                                <Button type="text" className={cn("!h-8 !max-w-[148px] !min-w-0 !justify-start !px-2", styles.modelButton)} style={{ color: theme.node.text }} icon={<Cpu className="size-3.5" />} aria-label="选择文本模型">
                                    <span className="truncate">{modelLabel(selectedTextModel)}</span>
                                    <ChevronDown className="ml-1 size-3 shrink-0 opacity-60" />
                                </Button>
                            </Dropdown>
                        ) : null}
                        {onSkillSelect && onSkillRemove ? <CanvasAgentSkillPopover selectedSkills={selectedSkills} onSelect={onSkillSelect} onDeleteSelected={onSkillRemove} /> : null}
                        {agentConfig.mode !== "codex" ? (
                            <Dropdown
                                trigger={["click"]}
                                placement="topLeft"
                                menu={{
                                    selectable: true,
                                    selectedKeys: [agentConfig.autoGenerateMedia ? "auto" : "manual"],
                                    items: [
                                        {
                                            key: "manual",
                                            label: (
                                                <div className="py-0.5">
                                                    <div className="text-sm font-medium">手动生成</div>
                                                    <div className="mt-0.5 text-xs opacity-55">每次生成图片/视频/音频前先询问确认</div>
                                                </div>
                                            ),
                                        },
                                        {
                                            key: "auto",
                                            label: (
                                                <div className="py-0.5">
                                                    <div className="text-sm font-medium">自动生成</div>
                                                    <div className="mt-0.5 text-xs opacity-55">Agent 可直接提交图片/视频/音频生成，无需再次确认</div>
                                                </div>
                                            ),
                                        },
                                    ],
                                    onClick: ({ key }) => onAgentConfigChange({ autoGenerateMedia: key === "auto" }),
                                }}
                            >
                                <Button
                                    type="text"
                                    className={cn("!h-8 !shrink-0 !px-2", styles.toolButton)}
                                    style={{ color: theme.node.text, background: agentConfig.autoGenerateMedia ? theme.toolbar.activeBg : undefined }}
                                    icon={<WandSparkles className="size-3.5" />}
                                    aria-pressed={agentConfig.autoGenerateMedia}
                                >
                                    <span className="text-xs">{agentConfig.autoGenerateMedia ? "自动" : "手动"}</span>
                                </Button>
                            </Dropdown>
                        ) : null}
                        {codexControls}
                        {/* 066-T7：底部常驻比例/时长设置已移除——Agent 生成图片/视频时改为弹窗选择（见 canvas-assistant-panel askMediaParams） */}
                    </div>
                    <div className="flex shrink-0 items-center gap-1">
                        {agentConfig.mode !== "codex" ? (
                            <Tooltip title="上下文剩余：当前对话还能容纳的内容量">
                                <span className="flex shrink-0 items-center gap-1 whitespace-nowrap text-xs opacity-55" aria-label="上下文剩余">
                                    <Gauge className="size-3.5" />
                                    上下文剩余
                                </span>
                            </Tooltip>
                        ) : null}
                        {!codexControls ? (
                            <Button
                                type="text"
                                shape="circle"
                                className={cn("!h-8 !w-8 !min-w-8", styles.toolButton)}
                                style={{ color: theme.node.text, background: reasoningEnabled ? theme.toolbar.activeBg : undefined }}
                                icon={<Brain className="size-4" />}
                                title={reasoningEnabled ? "推理已开启" : "推理已关闭"}
                                aria-label={reasoningEnabled ? "关闭推理" : "开启推理"}
                                aria-pressed={reasoningEnabled}
                                onClick={() => onAgentConfigChange({ textReasoningEnabled: !reasoningEnabled })}
                            />
                        ) : null}
                        <Button
                            type="primary"
                            shape="circle"
                            className={cn("!size-10 !min-w-10", styles.sendButton)}
                            disabled={!isRunning && !prompt.trim()}
                            onClick={() => (isRunning ? onStop?.() : void submit())}
                            aria-label={isRunning ? "停止" : "发送"}
                            icon={isRunning ? <Square className="size-4 fill-current" /> : <ArrowUp className="size-4" />}
                        />
                    </div>
                </div>
            </div>
        </div>
    );
}

export function assistantToPromptReference(reference: CanvasAssistantReference): CanvasResourceReference {
    const kind = reference.type === CanvasNodeType.Video ? "video" : reference.type === CanvasNodeType.Audio ? "audio" : reference.type === CanvasNodeType.Text ? "text" : "image";
    return { id: reference.id, nodeId: reference.id, kind, label: reference.label || reference.title, title: reference.title, previewUrl: reference.dataUrl || reference.url, text: reference.text, active: true };
}
