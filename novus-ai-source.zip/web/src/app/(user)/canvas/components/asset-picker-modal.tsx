"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { App, Button, Dropdown, Empty, Input, Modal, Select, Slider, Spin, Tag } from "antd";
import { ImagePlus, Pencil, Plus, Search, Trash2 } from "lucide-react";

import { cn } from "@/lib/utils";
import { renameAssetTitle, useAssetStore, type Asset } from "@/stores/use-asset-store";
import { uploadAssetMediaFile } from "@/services/file-storage";
import { uploadImage } from "@/services/image-storage";
import type { InsertAssetPayload } from "../types";

export type { InsertAssetPayload } from "../types";

export type AssetPickerTab = "my-assets" | "library";

// 029（boss 2026-10-04）：业务分类——存宿主 assets.json 的 kind 字段
// 032（boss 2026-10-05）：顺序对齐「我的资产」：人物→服装→场景→道具→其他
export const ASSET_CATEGORY_OPTIONS = [
    { label: "人物", value: "character" },
    { label: "服装", value: "clothing" },
    { label: "场景", value: "scene" },
    { label: "道具", value: "prop" },
    { label: "其他", value: "other" },
];

export const assetCategoryLabel = (value?: string) => ASSET_CATEGORY_OPTIONS.find((opt) => opt.value === value)?.label || "";

type Props = {
    open: boolean;
    defaultTab?: AssetPickerTab;
    /** 030：分类过滤（角色/场景/服装/道具/其他库模式）——只显示该分类的素材，弹窗标题同步显示分类名 */
    categoryFilter?: string;
    onInsert: (payload: InsertAssetPayload) => void;
    /** 026：框选多选后整批插入（不传则退化为逐个 onInsert） */
    onInsertBatch?: (payloads: InsertAssetPayload[]) => void;
    onClose: () => void;
};

export function AssetPickerModal({ open, defaultTab = "my-assets", categoryFilter, onInsert, onInsertBatch, onClose }: Props) {
    const { message } = App.useApp();
    const addAsset = useAssetStore((state) => state.addAsset);
    // 029：拖文件进弹窗 → 先选分类再入库
    const [dropFiles, setDropFiles] = useState<File[] | null>(null);

    return (
        <Modal title={categoryFilter ? `我的资产·${assetCategoryLabel(categoryFilter)}` : "我的资产"} open={open} onCancel={onClose} footer={null} width={1200} centered destroyOnHidden transitionName="" maskTransitionName="" styles={{ body: { padding: "0 24px 24px", minHeight: 640 } }}>
            {/* 020-B：整个弹窗支持拖拽文件直接导入「我的素材」；029：先选分类 */}
            <div
                onDragOver={(event) => event.preventDefault()}
                onDrop={(event) => {
                    event.preventDefault();
                    const files = event.dataTransfer?.files;
                    if (!files?.length) return;
                    setDropFiles(Array.from(files));
                }}
            >
                {/* 029（boss 2026-10-04）：「素材库」页签按需求删除，只留「我的素材」 */}
                <div className="px-1 pt-2">
                    <MyAssetsTab onInsert={onInsert} onInsertBatch={onInsertBatch} categoryFilter={categoryFilter} />
                </div>
            </div>
            <CategoryPickDialog
                open={Boolean(dropFiles)}
                title="这批文件存为什么资产？"
                count={dropFiles?.length || 0}
                defaultCategory={categoryFilter}
                onConfirm={(category, nameOverride) => {
                    const files = dropFiles || [];
                    setDropFiles(null);
                    void importAssetFiles(files, addAsset, category, nameOverride).then(({ done, failed }) => {
                        if (done) message.success(`已新增 ${done} 个${assetCategoryLabel(category) || ""}素材`);
                        if (failed.length) message.error(`${failed.join("、")} 导入失败`);
                    });
                }}
                onCancel={() => setDropFiles(null)}
            />
        </Modal>
    );
}

// 029：入库前选分类（+ 单文件可改名）。count 为文件/节点数量
// 031：新增 defaultCategory —— 分类库模式下新增素材默认归到当前库的分类
export function CategoryPickDialog({ open, title, count, defaultName = "", defaultCategory = "character", onConfirm, onCancel }: { open: boolean; title: string; count: number; defaultName?: string; defaultCategory?: string; onConfirm: (category: string, nameOverride?: string) => void; onCancel: () => void }) {
    const [category, setCategory] = useState(defaultCategory);
    const [name, setName] = useState(defaultName);
    useEffect(() => {
        if (open) {
            setCategory(defaultCategory || "character");
            setName(defaultName);
        }
    }, [open, defaultName, defaultCategory]);
    const single = count === 1;
    return (
        <Modal
            title={title}
            open={open}
            onCancel={onCancel}
            onOk={() => onConfirm(category, single ? name.trim() || undefined : undefined)}
            okText="确定"
            cancelText="取消"
            width={380}
            centered
            destroyOnHidden
            maskClosable={false}
        >
            <div className="space-y-3 py-1">
                <div>
                    <div className="mb-1.5 text-xs text-stone-500 dark:text-stone-400">分类{count > 1 ? `（作用于全部 ${count} 项）` : ""}</div>
                    <Select className="w-full" value={category} options={ASSET_CATEGORY_OPTIONS} onChange={setCategory} />
                </div>
                <div>
                    <div className="mb-1.5 text-xs text-stone-500 dark:text-stone-400">{single ? "名称（可修改）" : "多个文件按文件名入库"}</div>
                    <Input className="w-full" value={single ? name : ""} disabled={!single} placeholder={single ? "素材名称" : "——"} onChange={(e) => setName(e.target.value)} />
                </div>
            </div>
        </Modal>
    );
}

const PAGE_SIZE = 8;

// 020-B（boss 2026-10-04）：新增素材不再弹表单填写，直接读取本地文件导入；拖拽进弹窗同样走这里
// 029：category 必选入库（人物/场景/服装/道具/其他），单文件可由调用方传改名
async function importAssetFiles(
    files: FileList | File[],
    addAsset: (asset: Asset) => void,
    category = "other",
    titleOverride?: string,
): Promise<{ done: number; failed: string[] }> {
    const list = Array.from(files);
    let done = 0;
    const failed: string[] = [];
    for (const file of list) {
        const kind: "image" | "video" | "audio" | null = file.type.startsWith("image/")
            ? "image"
            : file.type.startsWith("video/")
              ? "video"
              : file.type.startsWith("audio/")
                ? "audio"
                : null;
        if (!kind) {
            failed.push(file.name);
            continue;
        }
        try {
            const title = titleOverride || file.name.replace(/\.[^.]+$/, "") || "未命名素材";
            if (kind === "image") {
                const stored = await uploadImage(file);
                addAsset({
                    kind: "image",
                    title,
                    coverUrl: stored?.url || "",
                    tags: [],
                    category,
                    source: "素材选择器",
                    data: stored
                        ? { dataUrl: stored.url, storageKey: stored.storageKey, width: stored.width, height: stored.height, bytes: stored.bytes, mimeType: stored.mimeType }
                        : { dataUrl: "", width: 0, height: 0, bytes: 0, mimeType: file.type || "image/*" },
                });
            } else if (kind === "video") {
                const stored = await uploadAssetMediaFile(file, "asset-video");
                addAsset({
                    kind: "video",
                    title,
                    coverUrl: "",
                    tags: [],
                    category,
                    source: "素材选择器",
                    data: { url: stored.url, storageKey: stored.storageKey, width: stored.width || 0, height: stored.height || 0, bytes: stored.bytes, mimeType: stored.mimeType },
                });
            } else {
                const stored = await uploadAssetMediaFile(file, "asset-audio");
                addAsset({
                    kind: "audio",
                    title,
                    coverUrl: "",
                    tags: [],
                    category,
                    source: "素材选择器",
                    data: { url: stored.url, storageKey: stored.storageKey, bytes: stored.bytes, mimeType: stored.mimeType, durationMs: stored.durationMs },
                });
            }
            done += 1;
        } catch {
            failed.push(file.name);
        }
    }
    return { done, failed };
}

// 032（boss 2026-10-05）：筛选行对齐「我的资产」页签——全部/人物/服装/场景/道具/视频/其他。
// 人物/服装/场景/道具/其他按业务分类过滤，视频按媒体类型过滤
const kindOptions = [
    { label: "全部", value: "all" },
    { label: "人物", value: "character" },
    { label: "服装", value: "clothing" },
    { label: "场景", value: "scene" },
    { label: "道具", value: "prop" },
    { label: "视频", value: "video" },
    { label: "其他", value: "other" },
];

// 029（boss 2026-10-04）：网格缩略图降清晰度省资源——加载原图后缩到 ≤480px、JPEG 0.72 再渲染，失败回退原图
const thumbCache = new Map<string, string>();
function ThumbImg({ src, alt, className }: { src: string; alt: string; className?: string }) {
    const [thumb, setThumb] = useState(() => thumbCache.get(src) || "");
    useEffect(() => {
        if (!src) {
            setThumb("");
            return;
        }
        const cached = thumbCache.get(src);
        if (cached) {
            setThumb(cached);
            return;
        }
        let revoked = false;
        const image = new Image();
        if (/^https?:/i.test(src)) image.crossOrigin = "anonymous";
        image.onload = () => {
            if (revoked) return;
            try {
                const scale = Math.min(1, 480 / Math.max(image.naturalWidth || 1, image.naturalHeight || 1));
                const canvas = document.createElement("canvas");
                canvas.width = Math.max(1, Math.round((image.naturalWidth || 1) * scale));
                canvas.height = Math.max(1, Math.round((image.naturalHeight || 1) * scale));
                canvas.getContext("2d")?.drawImage(image, 0, 0, canvas.width, canvas.height);
                const out = canvas.toDataURL("image/jpeg", 0.72);
                thumbCache.set(src, out);
                setThumb(out);
            } catch {
                setThumb(src);
            }
        };
        image.onerror = () => {
            if (!revoked) setThumb(src);
        };
        image.src = src;
        return () => {
            revoked = true;
        };
    }, [src]);
    if (!src) return null;
    return <img src={thumb || src} alt={alt} loading="lazy" decoding="async" className={className} />;
}

// 018-5（boss 2026-10-04）：卡片增加删除入口与拖拽排序能力；可选属性不影响素材库的只读用法
// 026：新增 dataId（框选命中检测用）与 selected（框选高亮）
// 029：category 显示分类角标
function PickerCard({ title, kind, cover, loading, onClick, onDelete, onRename, onRenameTitle, onContextMenu, draggable, onDragStart, onDragEnd, onDragOver, onDrop, dimmed, dataId, selected, category }: { title: string; kind: string; cover: string; loading?: boolean; onClick: () => void; onDelete?: () => void; onRename?: () => void; onRenameTitle?: () => void; onContextMenu?: (event: React.MouseEvent) => void; draggable?: boolean; onDragStart?: () => void; onDragEnd?: () => void; onDragOver?: (event: React.DragEvent<HTMLButtonElement>) => void; onDrop?: (event: React.DragEvent<HTMLButtonElement>) => void; dimmed?: boolean; dataId?: string; selected?: boolean; category?: string }) {
    return (
        <button
            type="button"
            data-asset-card-id={dataId}
            className={cn("group relative cursor-pointer overflow-hidden rounded-lg border border-stone-200 bg-white text-left transition hover:border-stone-400 hover:shadow-md dark:border-stone-700 dark:bg-stone-900 dark:hover:border-stone-500", dimmed && "opacity-40", selected && "border-blue-500 ring-2 ring-blue-500 dark:border-blue-400 dark:ring-blue-400")}
            onClick={onClick}
            disabled={loading}
            draggable={draggable}
            onDragStart={onDragStart}
            onDragEnd={onDragEnd}
            onDragOver={onDragOver}
            onDrop={onDrop}
            onContextMenu={onContextMenu}
        >
            {cover ? (
                <ThumbImg src={cover} alt={title} className="aspect-[4/3] w-full object-cover" />
            ) : (
                <div className="flex aspect-[4/3] items-center justify-center bg-stone-100 p-3 text-center text-xs leading-5 text-stone-500 dark:bg-stone-800 dark:text-stone-400">{title}</div>
            )}
            <div className="p-2.5">
                <div className="flex items-center justify-between gap-2">
                    {/* 任务rTbGo4：素材名称可点击——直接点文字进入改名编辑态 */}
                    {onRenameTitle ? (
                        <span
                            role="button"
                            tabIndex={0}
                            title="点击改名"
                            aria-label="点击改名"
                            className="line-clamp-1 cursor-text truncate rounded px-0.5 text-xs font-medium text-stone-800 hover:bg-blue-50 hover:text-blue-600 dark:text-stone-200 dark:hover:bg-blue-500/20 dark:hover:text-blue-300"
                            onClick={(event) => {
                                event.stopPropagation();
                                onRenameTitle();
                            }}
                            onKeyDown={(event) => {
                                if (event.key === "Enter") {
                                    event.preventDefault();
                                    event.stopPropagation();
                                    onRenameTitle();
                                }
                            }}
                        >
                            {title}
                        </span>
                    ) : (
                        <span className="line-clamp-1 text-xs font-medium text-stone-800 dark:text-stone-200">{title}</span>
                    )}
                    <span className="flex shrink-0 items-center gap-1">
                        {category ? <Tag className="m-0 text-[10px]">{assetCategoryLabel(category) || category}</Tag> : null}
                        <Tag className="m-0 shrink-0 text-[10px]">{kind === "image" ? "图片" : kind === "video" ? "视频" : kind === "audio" ? "音频" : "文本"}</Tag>
                    </span>
                </div>
            </div>
            {loading && (
                <div className="absolute inset-0 flex items-center justify-center bg-white/60 dark:bg-stone-900/60">
                    <Spin size="small" />
                </div>
            )}
            <div className="pointer-events-none absolute inset-0 flex items-center justify-center bg-stone-950/0 text-sm font-medium text-white opacity-0 transition group-hover:bg-stone-950/55 group-hover:opacity-100">插入</div>
            {onRename ? (
                <span
                    role="button"
                    tabIndex={0}
                    title="重命名"
                    aria-label="重命名"
                    className="absolute right-8 top-1.5 z-10 grid size-6 place-items-center rounded-md bg-stone-950/65 text-white opacity-0 transition group-hover:opacity-100 hover:bg-blue-500"
                    onClick={(event) => {
                        event.stopPropagation();
                        onRename();
                    }}
                    onKeyDown={(event) => {
                        if (event.key === "Enter" || event.key === " ") {
                            event.preventDefault();
                            event.stopPropagation();
                            onRename();
                        }
                    }}
                >
                    <Pencil className="size-3.5" />
                </span>
            ) : null}
            {onDelete ? (
                <span
                    role="button"
                    tabIndex={0}
                    title="删除素材"
                    aria-label="删除素材"
                    className="absolute right-1.5 top-1.5 z-10 grid size-6 place-items-center rounded-md bg-stone-950/65 text-white opacity-0 transition group-hover:opacity-100 hover:bg-red-500"
                    onClick={(event) => {
                        event.stopPropagation();
                        onDelete();
                    }}
                    onKeyDown={(event) => {
                        if (event.key === "Enter" || event.key === " ") {
                            event.preventDefault();
                            event.stopPropagation();
                            onDelete();
                        }
                    }}
                >
                    <Trash2 className="size-3.5" />
                </span>
            ) : null}
        </button>
    );
}

function MyAssetsTab({ onInsert, onInsertBatch, categoryFilter }: { onInsert: (payload: InsertAssetPayload) => void; onInsertBatch?: (payloads: InsertAssetPayload[]) => void; categoryFilter?: string }) {
    const { message, modal } = App.useApp();
    const assets = useAssetStore((state) => state.assets);
    const addAsset = useAssetStore((state) => state.addAsset);
    const removeAsset = useAssetStore((state) => state.removeAsset);
    // 任务rTbGo4：右键「移动到分类」——直接改宿主镜像资产的 category
    const updateAsset = useAssetStore((state) => state.updateAsset);
    const [moveMenu, setMoveMenu] = useState<{ asset: Asset; x: number; y: number } | null>(null);
    const [renamingAsset, setRenamingAsset] = useState<Asset | null>(null);
    const [renameValue, setRenameValue] = useState("");
    const submitRename = () => {
        const asset = renamingAsset;
        if (!asset) return;
        const next = renameValue.trim();
        if (!next) {
            message.error("素材名称不能为空");
            return;
        }
        setRenamingAsset(null);
        void renameAssetTitle(asset, next).then((ok) => {
            if (ok) message.success("已改名");
            else message.error("改名失败，请重试");
        });
    };
    // 任务rTbGo4：右键素材 → 移动到某分类（宿主镜像资产改 category，分类标签计数随之更新）
    const handleMoveToCategory = (category: string) => {
        const asset = moveMenu?.asset;
        setMoveMenu(null);
        if (!asset) return;
        updateAsset(asset.id, { category } as Partial<Omit<Asset, "id" | "createdAt">>);
        message.success(`已移动到「${assetCategoryLabel(category) || category}」`);
    };
    // 018-5：sortBy=custom 时保持用户拖拽出的顺序；其余为只影响展示的排序方式
    const [sortBy, setSortBy] = useState<"custom" | "updatedAt" | "title">("custom");
    const [dragAssetId, setDragAssetId] = useState<string | null>(null);
    const dragAssetIdRef = useRef<string | null>(null);
    const [keyword, setKeyword] = useState("");
    const [kindFilter, setKindFilter] = useState("all");
    // 任务rTbGo4：取消分页，改滚轮无限滚动——renderLimit 控制一次渲染的卡片数，滚动触底追加
    const [renderLimit, setRenderLimit] = useState(PAGE_SIZE * 2);
    const [loadingMore, setLoadingMore] = useState(false);
    const loadMoreTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
    const [createOpen, setCreateOpen] = useState(false);
    const [createKind, setCreateKind] = useState<"text" | "image" | "video" | "audio">("image");
    const [createTitle, setCreateTitle] = useState("");
    const [createText, setCreateText] = useState("");
    const [createUrl, setCreateUrl] = useState("");
    const [saving, setSaving] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const importInputRef = useRef<HTMLInputElement>(null); // 020-B
    const [importFiles, setImportFiles] = useState<File[] | null>(null); // 029：待选分类的待导入文件
    const [selectedFile, setSelectedFile] = useState<File | null>(null);
    // 026（boss 2026-10-04）：缩略图大小滑块 + 空白处框选多选
    const [thumbSize, setThumbSize] = useState(176);
    const [selectedIds, setSelectedIds] = useState<string[]>([]);
    const [marquee, setMarquee] = useState<{ x0: number; y0: number; x1: number; y1: number } | null>(null);
    const marqueeStartRef = useRef<{ x: number; y: number } | null>(null);
    const gridWrapRef = useRef<HTMLDivElement>(null);

    const pointInGrid = (event: React.PointerEvent) => {
        const rect = gridWrapRef.current?.getBoundingClientRect();
        if (!rect) return null;
        return { x: event.clientX - rect.left, y: event.clientY - rect.top };
    };

    // 框选只在网格空白处发起：按住左键拖出矩形，松开时与卡片矩形相交的即选中
    const handleMarqueeDown = (event: React.PointerEvent<HTMLDivElement>) => {
        if (event.button !== 0) return;
        if (!(event.target instanceof Element) || event.target.closest("[data-asset-card-id]")) return;
        const point = pointInGrid(event);
        if (!point) return;
        marqueeStartRef.current = point;
        setMarquee({ x0: point.x, y0: point.y, x1: point.x, y1: point.y });
        try { gridWrapRef.current?.setPointerCapture(event.pointerId); } catch { /* 忽略 */ }
    };
    const handleMarqueeMove = (event: React.PointerEvent<HTMLDivElement>) => {
        if (!marqueeStartRef.current) return;
        const point = pointInGrid(event);
        if (!point) return;
        setMarquee((prev) => (prev ? { ...prev, x1: point.x, y1: point.y } : prev));
    };
    const handleMarqueeUp = (event: React.PointerEvent<HTMLDivElement>) => {
        if (!marqueeStartRef.current) return;
        marqueeStartRef.current = null;
        try { gridWrapRef.current?.releasePointerCapture(event.pointerId); } catch { /* 忽略 */ }
        const box = marquee;
        setMarquee(null);
        if (!box) return;
        const selRect = { left: Math.min(box.x0, box.x1), top: Math.min(box.y0, box.y1), right: Math.max(box.x0, box.x1), bottom: Math.max(box.y0, box.y1) };
        // 几乎没拖动 = 误触空白，清空选择
        if (selRect.right - selRect.left < 8 && selRect.bottom - selRect.top < 8) {
            setSelectedIds([]);
            return;
        }
        const wrapRect = gridWrapRef.current?.getBoundingClientRect();
        if (!wrapRect) return;
        const hits: string[] = [];
        gridWrapRef.current?.querySelectorAll("[data-asset-card-id]").forEach((el) => {
            const id = el.getAttribute("data-asset-card-id");
            if (!id) return;
            const card = el.getBoundingClientRect();
            const left = card.left - wrapRect.left;
            const top = card.top - wrapRect.top;
            if (left < selRect.right && left + card.width > selRect.left && top < selRect.bottom && top + card.height > selRect.top) hits.push(id);
        });
        setSelectedIds(hits);
        if (hits.length) message.info(`已框选 ${hits.length} 个素材，点「插入所选」上画布`);
    };

    // 026：把框选中的素材整批插入画布（按当前列表顺序）
    const insertSelected = () => {
        if (!selectedIds.length) return;
        const payloads = filtered.filter((asset) => selectedIds.includes(asset.id)).map((asset) => buildInsertPayload(asset));
        setSelectedIds([]);
        if (!payloads.length) return;
        if (onInsertBatch) {
            onInsertBatch(payloads);
        } else {
            payloads.forEach((payload) => onInsert(payload));
        }
    };

    const filtered = useMemo(() => {
        const query = keyword.trim().toLowerCase();
        const list = assets
            .filter((a) => a.kind === "text" || a.kind === "image" || a.kind === "video" || a.kind === "audio")
            // 030：分类库模式只显示对应分类（人物/场景/服装/道具/其他）
            .filter((a) => !categoryFilter || (a as Asset & { category?: string }).category === categoryFilter)
            // 032：筛选行按业务分类过滤（视频按媒体类型；其他 = 分类“其他”或未打分类的图片/文本/音频）
            .filter((a) => {
                if (kindFilter === "all") return true;
                if (kindFilter === "video") return a.kind === "video";
                const cat = (a as Asset & { category?: string }).category;
                if (kindFilter === "other") return a.kind !== "video" && (cat === "other" || !cat);
                return cat === kindFilter;
            })
            .filter((a) => !query || [a.title, ...(a.tags || [])].join(" ").toLowerCase().includes(query));
        if (sortBy === "updatedAt") return [...list].sort((a, b) => String(b.updatedAt || "").localeCompare(String(a.updatedAt || "")));
        if (sortBy === "title") return [...list].sort((a, b) => String(a.title || "").localeCompare(String(b.title || ""), "zh-Hans-CN"));
        return list;
    }, [assets, keyword, kindFilter, sortBy, categoryFilter]);

    const visible = useMemo(() => filtered.slice(0, renderLimit), [filtered, renderLimit]);

    // 任务rTbGo4：滚轮无限滚动——网格触底时追加下一页（gridWrapRef 在下方框选段声明）
    const handleGridScroll = useCallback(() => {
        const el = gridWrapRef.current;
        if (!el || loadingMore || renderLimit >= filtered.length) return;
        const nearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 320;
        if (!nearBottom) return;
        setLoadingMore(true);
        if (loadMoreTimerRef.current) clearTimeout(loadMoreTimerRef.current);
        loadMoreTimerRef.current = setTimeout(() => {
            setRenderLimit((limit) => Math.min(limit + PAGE_SIZE * 2, filtered.length));
            setLoadingMore(false);
        }, 120);
    }, [loadingMore, renderLimit, filtered.length]);
    useEffect(() => () => { if (loadMoreTimerRef.current) clearTimeout(loadMoreTimerRef.current); }, []);

    // 026：翻页 / 换筛选 / 换排序时清空框选，避免把看不见的素材一起插入
    useEffect(() => {
        setSelectedIds([]);
    }, [page, kindFilter, keyword, sortBy]);

    // 026：单个/批量插入共用一个 payload 组装
    const buildInsertPayload = (asset: Asset): InsertAssetPayload => {
        if (asset.kind === "text") {
            return { kind: "text", content: asset.data.content, title: asset.title, assetId: asset.id, source: "asset" };
        }
        return asset.kind === "video"
            ? { kind: "video", url: asset.data.url, storageKey: asset.data.storageKey, title: asset.title, assetId: asset.id, width: asset.data.width, height: asset.data.height, bytes: asset.data.bytes, mimeType: asset.data.mimeType, source: "asset" }
            : asset.kind === "audio"
              ? { kind: "audio", url: asset.data.url, storageKey: asset.data.storageKey, title: asset.title, assetId: asset.id, bytes: asset.data.bytes, mimeType: asset.data.mimeType, durationMs: asset.data.durationMs, source: "asset" }
              : { kind: "image", dataUrl: asset.data.dataUrl, storageKey: asset.data.storageKey, title: asset.title, assetId: asset.id, width: asset.data.width, height: asset.data.height, bytes: asset.data.bytes, mimeType: asset.data.mimeType, source: "asset" };
    };

    const handleInsert = (asset: Asset) => {
        onInsert(buildInsertPayload(asset));
    };

    // 018-5：删除素材（带确认）
    const handleDeleteAsset = async (asset: Asset) => {
        const ok = await modal.confirm({
            title: `删除素材「${asset.title || "未命名"}」？`,
            content: "删除后不可恢复，已插入画布的节点不受影响。",
            okText: "删除",
            cancelText: "取消",
            okButtonProps: { danger: true },
        });
        if (!ok) return;
        removeAsset(asset.id);
        message.success("已删除");
    };

    // 018-5：拖拽排列（自定义顺序下把拖动项插到目标项位置）
    const handleDropReorder = (targetId: string) => {
        const fromId = dragAssetIdRef.current;
        dragAssetIdRef.current = null;
        setDragAssetId(null);
        if (!fromId || fromId === targetId) return;
        const fromIndex = assets.findIndex((a) => a.id === fromId);
        const toIndex = assets.findIndex((a) => a.id === targetId);
        if (fromIndex < 0 || toIndex < 0) return;
        const next = [...assets];
        const [moved] = next.splice(fromIndex, 1);
        next.splice(toIndex, 0, moved);
        const order = new Map(next.map((a, index) => [a.id, index]));
        useAssetStore.setState({ assets: [...assets].sort((a, b) => (order.get(a.id) ?? 0) - (order.get(b.id) ?? 0)) });
    };

    const resetCreateForm = () => {
        setCreateTitle("");
        setCreateText("");
        setCreateUrl("");
        setSelectedFile(null);
        if (fileInputRef.current) fileInputRef.current.value = "";
    };

    const createAsset = async () => {
        const title = createTitle.trim();
        if (!title) {
            message.error("请输入素材名称");
            return;
        }
        setSaving(true);
        try {
            if (createKind === "text") {
                const content = createText.trim();
                if (!content) {
                    message.error("请输入文本内容");
                    return;
                }
                addAsset({ kind: "text", title, coverUrl: "", tags: [], source: "素材选择器", data: { content } });
            } else if (createKind === "image") {
                if (!selectedFile && !createUrl.trim()) {
                    message.error("请选择图片或填写图片 URL");
                    return;
                }
                const stored = selectedFile ? await uploadImage(selectedFile) : null;
                addAsset({
                    kind: "image",
                    title,
                    coverUrl: stored?.url || createUrl.trim(),
                    tags: [],
                    source: "素材选择器",
                    data: stored ? { dataUrl: stored.url, storageKey: stored.storageKey, width: stored.width, height: stored.height, bytes: stored.bytes, mimeType: stored.mimeType } : { dataUrl: createUrl.trim(), width: 0, height: 0, bytes: 0, mimeType: "image/*" },
                });
            } else if (createKind === "video") {
                if (!selectedFile && !createUrl.trim()) {
                    message.error("请选择视频或填写视频 URL");
                    return;
                }
                const stored = selectedFile ? await uploadAssetMediaFile(selectedFile, "asset-video") : null;
                addAsset({
                    kind: "video",
                    title,
                    coverUrl: "",
                    tags: [],
                    source: "素材选择器",
                    data: stored
                        ? { url: stored.url, storageKey: stored.storageKey, width: stored.width || 0, height: stored.height || 0, bytes: stored.bytes, mimeType: stored.mimeType }
                        : { url: createUrl.trim(), width: 0, height: 0, bytes: 0, mimeType: "video/mp4" },
                });
            } else {
                if (!selectedFile && !createUrl.trim()) {
                    message.error("请选择音频或填写音频 URL");
                    return;
                }
                const stored = selectedFile ? await uploadAssetMediaFile(selectedFile, "asset-audio") : null;
                addAsset({
                    kind: "audio",
                    title,
                    coverUrl: "",
                    tags: [],
                    source: "素材选择器",
                    data: stored ? { url: stored.url, storageKey: stored.storageKey, bytes: stored.bytes, mimeType: stored.mimeType, durationMs: stored.durationMs } : { url: createUrl.trim(), mimeType: "audio/mpeg" },
                });
            }
            message.success("素材已新增");
            setCreateOpen(false);
            resetCreateForm();
        } catch (error) {
            message.error(error instanceof Error ? error.message : "新增素材失败");
        } finally {
            setSaving(false);
        }
    };

    return (
        <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-3">
                {/* 任务rTbGo4：搜索框视觉重设计——精致胶囊，聚焦时品牌紫描边，与整体质感统一 */}
                <div className="group/search relative flex w-64 items-center rounded-xl border border-stone-200 bg-stone-50 transition-all focus-within:border-blue-400 focus-within:bg-white focus-within:shadow-[0_0_0_3px_rgba(59,130,246,0.12)] dark:border-stone-700 dark:bg-stone-800 dark:focus-within:bg-stone-800/80">
                    <Search className="ml-3 size-4 shrink-0 text-stone-400 transition-colors group-focus-within/search:text-blue-500" />
                    <input
                        type="text"
                        value={keyword}
                        placeholder="搜索素材"
                        onChange={(e) => {
                            setRenderLimit(PAGE_SIZE * 2);
                            setKeyword(e.target.value);
                        }}
                        className="h-9 w-full bg-transparent pl-2.5 pr-2 text-sm text-stone-800 outline-none placeholder:text-stone-400 dark:text-stone-100 dark:placeholder:text-stone-500"
                    />
                    {keyword ? (
                        <button
                            type="button"
                            aria-label="清空搜索"
                            onClick={() => {
                                setRenderLimit(PAGE_SIZE * 2);
                                setKeyword("");
                            }}
                            className="mr-2 grid size-5 shrink-0 place-items-center rounded-full bg-stone-300/70 text-white transition hover:bg-stone-400 dark:bg-stone-600 dark:hover:bg-stone-500"
                        >
                            <span className="text-[11px] leading-none">×</span>
                        </button>
                    ) : null}
                </div>
                <div className="flex gap-1.5">
                    {/* 031（boss 2026-10-05）：分类库模式（角色/场景/服装/道具/其他）里全是同一分类的素材，媒体类型筛选是多余的，不显示 */}
                    {!categoryFilter
                        ? kindOptions.map((opt) => (
                            <Tag.CheckableTag
                                key={opt.value}
                                checked={kindFilter === opt.value}
                                className={cn("prompt-filter-tag", kindFilter === opt.value && "is-active")}
                                onChange={() => {
                                    setRenderLimit(PAGE_SIZE * 2);
                                    setKindFilter(opt.value);
                                }}
                            >
                                {opt.label}
                            </Tag.CheckableTag>
                        ))
                        : null}
                </div>
                <Select
                    size="small"
                    className="w-40"
                    value={sortBy}
                    onChange={(value) => {
                        setRenderLimit(PAGE_SIZE * 2);
                        setSortBy(value);
                    }}
                    options={[
                        { value: "custom", label: "自定义排列（可拖拽）" },
                        { value: "updatedAt", label: "按修改时间" },
                        { value: "title", label: "按名称" },
                    ]}
                />
                {/* 020-B：直接打开本地文件选择，不再弹表单填写 */}
                <input
                    ref={importInputRef}
                    type="file"
                    multiple
                    accept="image/*,video/*,audio/*"
                    className="hidden"
                    onChange={(event) => {
                        const files = event.target.files;
                        // 029：先选分类再入库
                        if (files?.length) setImportFiles(Array.from(files));
                        event.target.value = "";
                    }}
                />
                <Button size="small" icon={<Plus className="size-3.5" />} onClick={() => importInputRef.current?.click()}>
                    新增素材
                </Button>
                {/* 026：缩略图大小滑块 */}
                <div className="ml-auto flex items-center gap-2 text-xs text-stone-500 dark:text-stone-400">
                    <span>缩略图</span>
                    <Slider
                        min={120}
                        max={320}
                        step={8}
                        value={thumbSize}
                        className="!my-0"
                        style={{ width: 116 }}
                        tooltip={{ formatter: (value) => `${value ?? 176}px` }}
                        onChange={(value) => setThumbSize(Number(value) || 176)}
                    />
                    <span className="w-9 whitespace-nowrap text-xs tabular-nums">{thumbSize}px</span>
                </div>
            </div>

            {/* 026：框选多选操作条 */}
            {selectedIds.length ? (
                <div className="flex items-center gap-2 rounded-lg border border-stone-200 bg-stone-50 px-3 py-2 text-xs dark:border-stone-700 dark:bg-stone-800/60">
                    <span className="font-medium text-stone-700 dark:text-stone-200">已框选 {selectedIds.length} 个素材</span>
                    <Button size="small" type="primary" onClick={insertSelected}>
                        插入所选（{selectedIds.length}）
                    </Button>
                    <Button size="small" onClick={() => setSelectedIds([])}>
                        清除选择
                    </Button>
                    <span className="text-stone-400">在下方网格空白处按住左键拖框可继续多选</span>
                </div>
            ) : null}

            {visible.length ? (
                // 026：网格支持空白处框选多选；列宽跟随缩略图滑块
                // 任务rTbGo4：可滚动容器 + 触底无限滚动
                <div
                    ref={gridWrapRef}
                    className="thin-scrollbar relative max-h-[600px] touch-none select-none overflow-y-auto pr-1"
                    onScroll={handleGridScroll}
                    onPointerDown={handleMarqueeDown}
                    onPointerMove={handleMarqueeMove}
                    onPointerUp={handleMarqueeUp}
                >
                    <div className="grid gap-3" style={{ gridTemplateColumns: `repeat(auto-fill, minmax(${thumbSize}px, 1fr))` }}>
                        {visible.map((asset) => (
                            <PickerCard
                                key={asset.id}
                                dataId={asset.id}
                                title={asset.title}
                                kind={asset.kind}
                                // 031：分类库模式下每张卡都标着同一个分类名，属冗余信息，不显示角标
                                category={categoryFilter ? undefined : (asset as Asset & { category?: string }).category}
                                cover={asset.coverUrl || (asset.kind === "image" ? asset.data.dataUrl : "")}
                                selected={selectedIds.includes(asset.id)}
                                onClick={() => handleInsert(asset)}
                                onDelete={() => void handleDeleteAsset(asset)}
                                onRename={() => {
                                    setRenamingAsset(asset);
                                    setRenameValue(asset.title || "");
                                }}
                                onRenameTitle={() => {
                                    setRenamingAsset(asset);
                                    setRenameValue(asset.title || "");
                                }}
                                onContextMenu={(event) => {
                                    event.preventDefault();
                                    event.stopPropagation();
                                    setMoveMenu({ asset, x: event.clientX, y: event.clientY });
                                }}
                                draggable={sortBy === "custom"}
                                onDragStart={() => {
                                    dragAssetIdRef.current = asset.id;
                                    setDragAssetId(asset.id);
                                }}
                                onDragEnd={() => {
                                    dragAssetIdRef.current = null;
                                    setDragAssetId(null);
                                }}
                                onDragOver={(event) => event.preventDefault()}
                                onDrop={(event) => {
                                    event.preventDefault();
                                    handleDropReorder(asset.id);
                                }}
                                dimmed={dragAssetId === asset.id}
                            />
                        ))}
                    </div>
                    {marquee ? (
                        <div
                            className="pointer-events-none absolute z-10 rounded-sm border border-blue-500 bg-blue-500/15"
                            style={{
                                left: Math.min(marquee.x0, marquee.x1),
                                // 任务rTbGo4：容器可滚动，框选坐标是相对可见区，可视层需补 scrollTop/scrollLeft 才对齐
                                top: Math.min(marquee.y0, marquee.y1) + (gridWrapRef.current?.scrollTop || 0),
                                width: Math.abs(marquee.x1 - marquee.x0),
                                height: Math.abs(marquee.y1 - marquee.y0),
                            }}
                        />
                    ) : null}
                </div>
            ) : (
                <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="没有素材" className="py-12" />
            )}

            {/* 任务rTbGo4：分页取消，改滚轮无限滚动——触底自动加载；这里只留加载状态提示 */}
            {visible.length && visible.length < filtered.length ? (
                <div className="flex items-center justify-center py-2 text-xs" style={{ color: "var(--muted-foreground, #9ca3af)" }}>
                    {loadingMore ? <Spin size="small" /> : "继续向下滚动加载更多"}
                </div>
            ) : null}
            {/* 任务rTbGo4：右键素材 → 移动到分类（浮动菜单，跟随鼠标） */}
            {moveMenu ? (
                <>
                    <div className="fixed inset-0 z-[999]" onClick={() => setMoveMenu(null)} onContextMenu={(event) => { event.preventDefault(); setMoveMenu(null); }} />
                    <div
                        className="thin-scrollbar fixed z-[1000] w-40 overflow-hidden rounded-lg border border-stone-200 bg-white py-1 shadow-xl dark:border-stone-700 dark:bg-stone-900"
                        style={{ left: Math.min(moveMenu.x, window.innerWidth - 176), top: Math.min(moveMenu.y, window.innerHeight - 240) }}
                    >
                        <div className="px-3 py-1 text-[11px] text-stone-400 dark:text-stone-500">移动到分类</div>
                        {ASSET_CATEGORY_OPTIONS.map((opt) => (
                            <button
                                key={opt.value}
                                type="button"
                                className="block w-full px-3 py-1.5 text-left text-xs text-stone-700 hover:bg-stone-100 dark:text-stone-200 dark:hover:bg-stone-800"
                                onClick={() => handleMoveToCategory(opt.value)}
                            >
                                {opt.label}
                            </button>
                        ))}
                    </div>
                </>
            ) : null}
            {/* 029：文件选择/拖入后先选分类（人物/场景/服装/道具/其他），单文件可改名 */}
            <CategoryPickDialog
                open={Boolean(importFiles)}
                title="这批文件存为什么资产？"
                count={importFiles?.length || 0}
                defaultCategory={categoryFilter}
                onConfirm={(category, nameOverride) => {
                    const files = importFiles || [];
                    setImportFiles(null);
                    void importAssetFiles(files, addAsset, category, nameOverride).then(({ done, failed }) => {
                        if (done) message.success(`已新增 ${done} 个${assetCategoryLabel(category) || ""}素材`);
                        if (failed.length) message.error(`${failed.join("、")} 导入失败`);
                    });
                }}
                onCancel={() => setImportFiles(null)}
            />
            {/* 041：重命名素材（宿主镜像/本地资产都支持） */}
            <Modal
                title="重命名素材"
                open={Boolean(renamingAsset)}
                onCancel={() => setRenamingAsset(null)}
                onOk={submitRename}
                okText="保存"
                destroyOnHidden
            >
                <Input
                    value={renameValue}
                    placeholder="素材名称"
                    autoFocus
                    onChange={(event) => setRenameValue(event.target.value)}
                    onPressEnter={submitRename}
                />
            </Modal>
            <Modal
                title="新增素材"
                open={createOpen}
                onCancel={() => {
                    setCreateOpen(false);
                    resetCreateForm();
                }}
                onOk={() => void createAsset()}
                okText="保存"
                confirmLoading={saving}
                destroyOnHidden
            >
                <div className="space-y-3 pt-2">
                    <div className="flex gap-2">
                        {[
                            { value: "image" as const, label: "图片" },
                            { value: "text" as const, label: "文本" },
                            { value: "video" as const, label: "视频" },
                            { value: "audio" as const, label: "音频" },
                        ].map((item) => (
                            <Tag.CheckableTag key={item.value} checked={createKind === item.value} className={cn("prompt-filter-tag", createKind === item.value && "is-active")} onChange={() => setCreateKind(item.value)}>
                                {item.label}
                            </Tag.CheckableTag>
                        ))}
                    </div>
                    <Input value={createTitle} placeholder="素材名称" onChange={(event) => setCreateTitle(event.target.value)} />
                    {createKind === "text" ? (
                        <Input.TextArea value={createText} autoSize={{ minRows: 5, maxRows: 10 }} placeholder="文本内容" onChange={(event) => setCreateText(event.target.value)} />
                    ) : (
                        <div className="space-y-2">
                            <input ref={fileInputRef} type="file" accept={createKind === "image" ? "image/*" : createKind === "video" ? "video/*" : "audio/mpeg,audio/wav,audio/x-wav,.mp3,.wav"} className="hidden" onChange={(event) => setSelectedFile(event.target.files?.[0] || null)} />
                            <Button icon={<ImagePlus className="size-4" />} onClick={() => fileInputRef.current?.click()}>
                                {selectedFile ? selectedFile.name : createKind === "image" ? "选择图片" : createKind === "video" ? "选择视频" : "选择音频"}
                            </Button>
                            <Input value={createUrl} placeholder={createKind === "image" ? "图片 URL" : createKind === "video" ? "视频 URL" : "音频 URL"} onChange={(event) => setCreateUrl(event.target.value)} />
                        </div>
                    )}
                </div>
            </Modal>
        </div>
    );
}
