"use client";

import "./original-canvas-ui.css";

/**
 * 原版多选节点工具栏（选中 2 个及以上节点时显示在选区正上方）
 *
 * 结构 / className / 内联 style / 文案 / SVG 逐字抄自
 *   ui-toolbar-original.html（= 061 chunk n6 组件 MultiSelectionToolbar 的渲染结果，
 *   061__MultiSelectionAddIndicator_..._516989.js 8045-8352 行）
 * 样式真值（GROUP_TOOLBAR_ROW_STYLE / GROUP_TOOLBAR_DIVIDER_CLASS，快照+boss 给定）：
 *   padding:8px; gap:8px; border-radius:12px; border:0.5px solid var(--canvas-controls-border);
 *   background:var(--canvas-controls-bg); box-shadow:0px 4px 10px 0px rgba(0,0,0,0.08); backdrop-filter:blur(16px)
 *   分隔线类 = "mx-0.5 min-h-8 w-px shrink-0 self-stretch bg-[var(--canvas-controls-border)]"
 *
 * 替换项（仅依赖差异，结构/样式/文案不动）：
 *   1. i18n hook t(key) → 快照中文文案硬编码（multiSelectionToolbarSaveMaterial2=保存到资产 /
 *      common:createCopy=创建副本 / canvas:groupNodes=打组 / canvas:groupMenu=打组菜单 /
 *      canvas:batchDownload=批量下载 / canvas:addToChat=添加到Chat / canvas:createAsSkill=创建为Skill）
 *   2. F.Icons 图标库（AssetsNew/Copy/chevronDown/IconDownload/ChatshapeN/Skill）→ 快照内联 SVG（path 逐字）
 *   3. Mantine Tooltip（包裹创建副本/下载按钮）→ 不实现（快照 DOM 无 tooltip 层；仅 hover 提示，无结构影响）
 *   4. React Flow nodrag 事件拦截 → onMouseDown/onPointerDown stopPropagation（本项目无 React Flow）
 *   5. 坐标系：原版挂在 viewport 屏幕坐标系（transform: translate(-50%,-100%) translateY(-14px)）；
 *      本项目挂在世界坐标容器（容器已 translate+scale(k)），故乘 --canvas-inverse-scale 反缩放保持屏幕恒定，
 *      数值不变：translate(-50%, -100%) translateY(calc(-14px * inv)) scale(inv)，origin center bottom
 *   6. 打组按钮的 hover 下拉菜单（打组/合成 storyboard）→ 不实现：快照无展开菜单，
 *      且 storyboard 合成无等价功能；chevron 图标保留，点击直接打组
 *   7. 打组按钮「新功能蓝点」（localStorage dismissed 后快照已无）→ 按快照不渲染
 *   8. 添加到Chat / 创建为Skill：项目无等价业务 → 按钮保留可视，标 data-unwired（项目既定约定）
 *   9. 源码下载按钮可用态类（canDownloadAll=true 分支）：hover:bg-canvas-controls-hover cursor-pointer
 */

type OriginalMultiSelectionToolbarProps = {
    /** 世界坐标：选区包围盒顶边中点 */
    left: number;
    top: number;
    onSave: () => void;
    onCopy: () => void;
    onGroup: () => void;
    onDownload: () => void;
};

export function OriginalMultiSelectionToolbar({
    left,
    top,
    onSave,
    onCopy,
    onGroup,
    onDownload,
}: OriginalMultiSelectionToolbarProps) {
    return (
        <div className="original-ui-scope">
            <div
                className="nodrag z-(--z-sticky) absolute flex w-max max-w-none flex-nowrap items-center whitespace-nowrap"
                style={{
                    padding: "8px",
                    gap: "8px",
                    borderRadius: "12px",
                    border: "0.5px solid var(--canvas-controls-border)",
                    background: "var(--canvas-controls-bg)",
                    boxShadow: "0px 4px 10px 0px rgba(0, 0, 0, 0.08)",
                    backdropFilter: "blur(16px)",
                    left,
                    top,
                    transform: "translate(-50%, -100%) translateY(calc(-14px * var(--canvas-inverse-scale, 1))) scale(var(--canvas-inverse-scale, 1))",
                    transformOrigin: "center bottom",
                }}
                onMouseDown={(event) => event.stopPropagation()}
                onPointerDown={(event) => event.stopPropagation()}
            >
                <button type="button" className="text-canvas-controls-text hover:bg-canvas-controls-hover flex h-8 shrink-0 cursor-pointer items-center gap-1.5 whitespace-nowrap rounded-lg px-2 text-[13px] transition-colors select-none" onClick={(event) => { event.stopPropagation(); onSave(); }}>
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M7.98 1.9c.44-.64 1.32-.8 1.95-.34l3.6 2.59c.58.43.74 1.24.35 1.85l-2.4 3.77-.09.1 1.72 3.77c.16.35-.1.75-.48.75H5.34a.52.52 0 0 1-.47-.74l.72-1.58a3.8 3.8 0 1 1 .4-7.22l.06-.1zM6.15 13.35h5.68L9 7.1zM4.62 5.63a2.76 2.76 0 1 0 1.62 5l1.14-2.5v-.01a2.77 2.77 0 0 0-2.76-2.49m4.7-3.23a.34.34 0 0 0-.48.09L6.91 5.34H6.9q.72.55 1.13 1.36l.48-1.07.04-.07a.52.52 0 0 1 .91.07l1.43 3.14L13 5.45a.34.34 0 0 0-.09-.46z" fill="currentColor" /></svg>
                    <span>保存到资产</span>
                </button>
                <button type="button" className="text-canvas-controls-text hover:bg-canvas-controls-hover flex h-8 shrink-0 cursor-pointer items-center gap-1.5 whitespace-nowrap rounded-lg px-2 text-[13px] transition-colors select-none" onClick={(event) => { event.stopPropagation(); onCopy(); }}>
                    <svg width="14" height="14" viewBox="0 0 21.8 21.8" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path fillRule="evenodd" clipRule="evenodd" d="M2.9 6A2.9 2.9 0 0 0 0 8.9v10c0 1.6 1.3 2.9 2.9 2.9h10c1.6 0 2.9-1.3 2.9-2.9v-10c0-1.6-1.3-2.9-2.9-2.9zm10 1.8c.6 0 1.1.5 1.1 1.1v10c0 .6-.5 1.1-1.1 1.1h-10c-.6 0-1.1-.5-1.1-1.1v-10c0-.6.5-1.1 1.1-1.1z" fill="currentColor" /><path d="M8.9 0A2.9 2.9 0 0 0 6 2.9a.9.9 0 0 0 1.8 0c0-.6.5-1.1 1.1-1.1h10c.6 0 1.1.5 1.1 1.1v10c0 .6-.5 1.1-1.1 1.1a.9.9 0 0 0-.1 1.8h.25a2.9 2.9 0 0 0 2.75-2.9v-10c0-1.6-1.3-2.9-2.9-2.9z" fill="currentColor" /></svg>
                    <span>创建副本</span>
                </button>
                <div className="mx-0.5 min-h-8 w-px shrink-0 self-stretch bg-[var(--canvas-controls-border)]"></div>
                <div className="relative">
                    <button type="button" aria-label="打组菜单" className="text-canvas-controls-text hover:bg-canvas-controls-hover flex h-8 shrink-0 cursor-pointer items-center gap-1.5 whitespace-nowrap rounded-lg px-2 text-[13px] transition-colors select-none relative" onClick={(event) => { event.stopPropagation(); onGroup(); }}>
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M2.33301 12.667C2.33318 13.219 2.78098 13.6668 3.33301 13.667H5.33301V14.667H3.33301L3.23047 14.6641C2.20777 14.6123 1.38775 13.7922 1.33594 12.7695L1.33301 12.667V11.333H2.33301V12.667ZM14.667 12.667C14.6668 13.7369 13.8262 14.6105 12.7695 14.6641L12.667 14.667H10.667V13.667H12.667C13.219 13.6668 13.6668 13.219 13.667 12.667V11.333H14.667V12.667ZM8.66699 4.16699C9.31107 4.16717 9.83283 4.68893 9.83301 5.33301V7.33301C9.83301 7.38965 9.82811 7.44551 9.82031 7.5H10.667C11.3112 7.50018 11.833 8.02277 11.833 8.66699V10.667C11.8328 11.3111 11.3111 11.8328 10.667 11.833H7.33301C6.68893 11.8328 6.16717 11.3111 6.16699 10.667V8.66699C6.16699 8.61035 6.17189 8.55449 6.17969 8.5H5.33301C4.68883 8.49982 4.16699 7.97723 4.16699 7.33301V5.33301C4.16717 4.68893 4.68893 4.16717 5.33301 4.16699H8.66699ZM7.33301 8.5C7.24111 8.50018 7.16699 8.57505 7.16699 8.66699V10.667C7.16717 10.7588 7.24122 10.8328 7.33301 10.833H10.667C10.7588 10.8328 10.8328 10.7588 10.833 10.667V8.66699C10.833 8.57505 10.7589 8.50018 10.667 8.5H7.33301ZM5.33301 5.16699C5.24122 5.16717 5.16717 5.24122 5.16699 5.33301V7.33301C5.16699 7.42495 5.24111 7.49982 5.33301 7.5H8.66699C8.75889 7.49982 8.83301 7.42495 8.83301 7.33301V5.33301C8.83283 5.24122 8.75878 5.16717 8.66699 5.16699H5.33301ZM5.33301 2.33301H3.33301C2.78098 2.33318 2.33318 2.78098 2.33301 3.33301V5.33301H1.33301V3.33301C1.33318 2.2287 2.2287 1.33318 3.33301 1.33301H5.33301V2.33301ZM12.667 1.33301C13.7713 1.33318 14.6668 2.2287 14.667 3.33301V5.33301H13.667V2.33301C13.6668 2.78098 13.219 2.33318 12.667 2.33301H10.667V1.33301H12.667Z" fill="currentColor" /></svg>
                        <span>打组</span>
                        <svg width="12" height="12" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" className="opacity-70" aria-hidden="true"><path d="M6.2.12a.4.4 0 0 1 .56 0l.43.42a.4.4 0 0 1 0 .57L4.15 4.15a.7.7 0 0 1-1 0L.13 1.1a.4.4 0 0 1 0-.57L.54.12a.4.4 0 0 1 .57 0l2.54 2.54z" fill="currentColor" transform="translate(4.345 5.825)" /></svg>
                    </button>
                </div>
                <button type="button" aria-label="批量下载" className="text-canvas-controls-text hover:bg-canvas-controls-hover flex h-8 w-8 shrink-0 cursor-pointer items-center justify-center rounded-lg transition-colors select-none" onClick={(event) => { event.stopPropagation(); onDownload(); }}>
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M2.5 14.38v-2.09a.62.62 0 1 1 1.25 0v2.09c0 1.03.84 1.87 1.88 1.87h8.75c1.03 0 1.87-.84 1.87-1.87v-2.09a.62.62 0 1 1 1.25 0v2.09c0 1.72-1.4 3.12-3.12 3.12H5.62a3.1 3.1 0 0 1-3.12-3.12M9.38 3.13a.62.62 0 1 1 1.24 0v7.86l1.85-1.85a.62.62 0 1 1 .89.89l-2.92 2.91a.6.6 0 0 1-.88 0l-2.92-2.91a.62.62 0 1 1 .89-.89L9.37 11z" fill="currentColor" fillOpacity=".9" /></svg>
                </button>
                {/* 024（boss 2026-10-04）：「添加到Chat」「创建为Skill」框选态按需求隐藏 */}
            </div>
        </div>
    );
}
