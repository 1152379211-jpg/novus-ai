"use client";

import "./original-canvas-ui.css";

import { Tooltip } from "antd";

/**
 * 原版底部导航栏（任务 01，共存模式：与现有 CanvasToolbar 并存，不替换）
 *
 * 结构 / className / 文案 / SVG 逐字抄自
 *   ui-original-separated/01-底部导航栏/01-bottom-navigation.html
 * 两处快照提取丢失、按 061 chunk 修正（061__MultiSelectionAddIndicator...516989.js）：
 *   1. offset 188632：普通图标 color=var(--canvas-controls-icon)；主按钮图标 color=var(--canvas-primary-btn-icon)
 *      （快照里图标继承 #f7f7f7，主按钮白底白图标不可见，为提取 artifact）
 *   2. offset 189966：分隔线类名 = "mx-0 w-px shrink-0" + style { backgroundColor: var(--canvas-controls-border), height }
 *      （快照中的 .source-divider 是预览页脚手架，非原版类名）
 *   3. 主按钮打开态：图标 transition-transform duration-200 + rotate-45（同 chunk offset 188884）
 *
 * 018-7（boss 2026-10-04）：工具按钮激活抓手时图标改为真源码图标库 hand-n（尺寸 16.3，20px 渲染），原箭头保留为未激活态
 * 接线：优先接现有等价功能；笑脸按钮（原角色造型室位）已按 boss 要求改接素材库；帮助 无等价入口 → 未接业务（按钮保留可视）
 */

type CanvasTool = "select" | "pan";

type OriginalBottomNavProps = {
    canvasTool: CanvasTool;
    onCanvasToolChange: (tool: CanvasTool) => void;
    onAddNode: () => void;
    addMenuOpen?: boolean;
    onOpenAssetLibrary?: () => void;
    onOpenHistory: () => void;
    onOpenShortcuts: () => void;
    onOpenCharacterLibrary?: () => void;
    onOpenHelp?: () => void;
};

const controlIconColor = { color: "var(--canvas-controls-icon)" } as const;
const primaryIconColor = { color: "var(--canvas-primary-btn-icon)" } as const;

export function OriginalBottomNav({
    canvasTool,
    onCanvasToolChange,
    onAddNode,
    addMenuOpen = false,
    onOpenAssetLibrary,
    onOpenHistory,
    onOpenShortcuts,
    onOpenHelp,
}: OriginalBottomNavProps) {
    return (
        <div className="original-ui-scope">
            <div data-sidebar-container className="b768:bottom-3 border-hair border-(--topnav-btn-border) absolute bottom-6 left-1/2 z-20 flex flex-row items-center gap-2 rounded-xl p-2" style={{ backgroundColor: "var(--panel-background)", transform: "translateX(-50%)" }}>
                {/* 028（boss 2026-10-04）：每个按钮悬停显示名称 tooltip，指向哪个显示哪个 */}
                <Tooltip title="添加节点" placement="top" mouseEnterDelay={0.15}>
                <button data-sidebar-btn="add-node" aria-label="添加节点" className="relative flex items-center justify-center rounded-lg transition-colors group h-8 w-8" onClick={onAddNode}>
                    <span className="bg-canvas-primary-btn hover:bg-canvas-primary-btn-hover flex h-8 w-8 cursor-pointer items-center justify-center rounded-lg transition-colors duration-200">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" className={`transition-transform duration-200 ${addMenuOpen ? "rotate-45" : ""}`} style={primaryIconColor}><path d="M9.38 16.67v-6.05H3.33a.62.62 0 1 1 0-1.24h6.05V3.33a.63.63 0 0 1 1.24 0v6.05h6.05a.63.63 0 0 1 0 1.24h-6.05v6.05a.63.63 0 0 1-1.24 0" fill="currentColor" /></svg>
                    </span>
                </button>
                </Tooltip>
                <Tooltip title={canvasTool === "pan" ? "抓手" : "移动"} placement="top" mouseEnterDelay={0.15}>
                <button data-sidebar-btn="tool-mode" aria-label={canvasTool === "pan" ? "抓手" : "移动"} className={`relative flex items-center justify-center rounded-lg transition-colors h-8 w-8 ${canvasTool === "pan" ? "bg-canvas-controls-active" : "hover:bg-canvas-controls-hover cursor-pointer"}`} onClick={() => onCanvasToolChange(canvasTool === "pan" ? "select" : "pan")}>
                    {canvasTool === "pan" ? (
                        <svg width="20" height="20" viewBox="0 0 16.3 16.3" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" style={controlIconColor}><path d="M8.6 0c.54 0 1.06.2 1.45.58.37.35.6.84.61 1.35a2.1 2.1 0 0 1 2.21.43c.37.35.58.83.6 1.33a2.1 2.1 0 0 1 2.22.43c.39.37.61.89.61 1.43v4.7c0 1.61-.67 3.15-1.85 4.29A6.4 6.4 0 0 1 10 16.3H8.6a7 7 0 0 1-4.92-1.91L.55 11.15H.54a1.97 1.97 0 0 1 .08-2.78c.37-.36.87-.57 1.4-.58.6-.01 1.13.35 1.47.62l.24.2V3.48c0-.54.22-1.05.61-1.43a2.1 2.1 0 0 1 2.24-.42q.13-.61.58-1.05C7.55.2 8.06 0 8.6 0m0 1.3q-.31 0-.54.22a.7.7 0 0 0-.21.48v5.55a.65.65 0 0 1-1.3 0V3.69a2 2 0 0 0-.17-.62l-.05-.08a.8.8 0 0 0-.54-.21.8.8 0 0 0-.55.21.7.7 0 0 0-.21.49v6.63a.65.65 0 0 1-1.09.48l-.5-.46-.37-.35-.4-.36c-.3-.25-.51-.33-.63-.33a.8.8 0 0 0-.53.22q-.2.2-.2.47-.01.25.17.47l3.13 3.22c.93.89 2.2 1.53 4 1.53H10c1.34 0 2.6-.5 3.54-1.4S15 11.5 15 10.25v-4.7a.7.7 0 0 0-.21-.49.8.8 0 0 0-.55-.21.8.8 0 0 0-.54.21.7.7 0 0 0-.22.49v2.33a.65.65 0 0 1-1.3 0v-4.1a.7.7 0 0 0-.21-.48.8.8 0 0 0-.55-.22.8.8 0 0 0-.54.22.7.7 0 0 0-.22.49v3.73a.65.65 0 0 1-1.3 0V2a.7.7 0 0 0-.2-.48.8.8 0 0 0-.55-.22" fill="currentColor" /></svg>
                    ) : (
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" style={controlIconColor}><path d="M2.33 4.72c-.5-1.48.9-2.9 2.39-2.39L17.08 6.6c1.63.57 1.7 2.85.1 3.51l-4.77 1.96a.6.6 0 0 0-.34.34l-1.96 4.77-.06.14a1.88 1.88 0 0 1-3.39-.1l-.06-.14zm1.98-1.2a.63.63 0 0 0-.8.79L7.8 16.67c.18.54.95.57 1.17.03l1.95-4.76.08-.17q.32-.6.95-.86l4.76-1.96a.62.62 0 0 0-.03-1.16z" fill="currentColor" fillOpacity=".9" /></svg>
                    )}
                </button>
                </Tooltip>
                <Tooltip title="素材库" placement="top" mouseEnterDelay={0.15}>
                <button data-sidebar-btn="character-library" aria-label="素材库" className="relative flex items-center justify-center rounded-lg transition-colors h-8 w-8 hover:bg-canvas-controls-hover cursor-pointer" onClick={onOpenAssetLibrary}>
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" style={controlIconColor}><path d="M17.08 10a7.08 7.08 0 1 0-14.16 0 7.08 7.08 0 0 0 14.16 0m-2.45 0c.34.05.58.37.53.71a5.2 5.2 0 0 1-4.45 4.45.62.62 0 1 1-.17-1.24 3.96 3.96 0 0 0 3.38-3.38.63.63 0 0 1 .7-.53M7.29 6.68a1.04 1.04 0 1 1 0 2.08 1.04 1.04 0 0 1 0-2.08m4.17 0a1.04 1.04 0 1 1 0 2.08 1.04 1.04 0 0 1 0-2.08M18.33 10a8.33 8.33 0 1 1-16.66 0 8.33 8.33 0 0 1 16.66 0" fill="currentColor" /></svg>
                </button>
                </Tooltip>
                <Tooltip title="历史记录" placement="top" mouseEnterDelay={0.15}>
                <button data-sidebar-btn="history" aria-label="历史记录" className="relative flex items-center justify-center rounded-lg transition-colors h-8 w-8 hover:bg-canvas-controls-hover cursor-pointer" onClick={onOpenHistory}>
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" style={controlIconColor}><path d="M17.08 10a7.08 7.08 0 1 0-14.16 0 7.08 7.08 0 0 0 14.16 0m-7.7-3.54a.62.62 0 1 1 1.24 0v3.28l2.11 2.11a.63.63 0 0 1-.88.88l-2.3-2.29a.6.6 0 0 1-.18-.44zM18.33 10a8.33 8.33 0 1 1-16.66 0 8.33 8.33 0 0 1 16.66 0" fill="currentColor" fillOpacity=".9" /></svg>
                </button>
                </Tooltip>
                <div className="mx-0 w-px shrink-0" style={{ backgroundColor: "var(--canvas-controls-border)", height: 24 }} />
                <Tooltip title="快捷键" placement="top" mouseEnterDelay={0.15}>
                <button data-sidebar-btn="keyboard" aria-label="快捷键" className="relative flex items-center justify-center rounded-lg transition-colors h-8 w-8 hover:bg-canvas-controls-hover cursor-pointer" onClick={onOpenShortcuts}>
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" style={controlIconColor}><path d="M16.08 3.35c1.72 0 3.12 1.4 3.12 3.13l-.03 7.05c0 1.72-1.4 3.12-3.13 3.12H3.96a3.13 3.13 0 0 1-3.13-3.13l.04-7.05c0-1.72 1.4-3.12 3.12-3.12zM3.99 4.6c-1.03 0-1.87.84-1.87 1.88l-.04 7.05c0 1.03.84 1.87 1.88 1.87h12.08c1.04 0 1.88-.84 1.88-1.88l.03-7.04v-.2c-.1-.94-.9-1.68-1.87-1.68zm.8 6.44a.83.83 0 1 1 0 1.67.83.83 0 0 1 0-1.67m10.42 0a.83.83 0 1 1 0 1.67.83.83 0 0 1 0-1.67m-3.34.21a.62.62 0 1 1 0 1.25H8.14a.62.62 0 1 1 0-1.25zM4.8 7.29a.83.83 0 1 1 0 1.67.83.83 0 0 1 0-1.67m3.34 0a.83.83 0 1 1 0 1.67.83.83 0 0 1 0-1.67m3.74 0a.83.83 0 1 1 0 1.67.83.83 0 0 1 0-1.67m3.34 0a.83.83 0 1 1 0 1.67.83.83 0 0 1 0-1.67" fill="currentColor" fillOpacity=".9" /></svg>
                </button>
                </Tooltip>
                <Tooltip title="帮助" placement="top" mouseEnterDelay={0.15}>
                <button data-sidebar-btn="contact" aria-label="帮助" className="relative flex items-center justify-center rounded-lg transition-colors h-8 w-8 hover:bg-canvas-controls-hover cursor-pointer" data-unwired="true" onClick={onOpenHelp}>
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" style={controlIconColor}><path d="M10 1.67a8.33 8.33 0 1 1 0 16.66 8.33 8.33 0 0 1 0-16.66m0 1.25a7.08 7.08 0 1 0 0 14.16 7.08 7.08 0 0 0 0-14.16m0 9.58a.83.83 0 1 1 0 1.67.83.83 0 0 1 0-1.67m.27-6.73c.54.03 1.09.21 1.52.58.43.38.71.93.71 1.6 0 1.02-.72 1.6-1.15 1.97-.49.43-.72.69-.72 1.12a.63.63 0 0 1-1.26 0c0-1.06.7-1.66 1.15-2.05.52-.45.73-.67.73-1.04q-.02-.44-.28-.65a1.3 1.3 0 0 0-.77-.28c-.66-.04-1.28.29-1.48.89a.63.63 0 0 1-1.19-.4c.43-1.28 1.68-1.8 2.74-1.74" fill="currentColor" fillOpacity=".9" /></svg>
                </button>
                </Tooltip>
            </div>
        </div>
    );
}
