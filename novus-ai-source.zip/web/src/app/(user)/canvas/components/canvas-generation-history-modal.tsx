"use client";

/**
 * 批次 129（boss 2026-10-07）：生成历史 UI 整块替换为 LibTV 原版（真源码 1:1 移植）。
 * 源码出处：generation-history-original/source/
 *   - history-module-145733-exact.js        主组件（弹窗结构/工具行/批量栏/详情面板挂载）
 *   - history-card-module-187694-exact.js   ArtifactCard / ArtifactRatingStars / BatchCheckbox / 去重 / 日期分组
 *   - history-support-modules-736355-141940-exact.js  useHistoryMarqueeSelect / HistoryDetailPanel / extractGenerationParams
 * JSX、className、inline style 均逐字取自原版压缩产物，未做近似改写。
 *
 * 本地化接线（架构不动，数据接回本项目状态管理）：
 *   - 原版 listTaskArtifacts 服务端分页 → 本地 projects（保留 047 规则：只显示本软件生成产出）
 *   - 原版 setTaskArtifactRating 服务端评级 → 会话内存 ratingMap（按 previewPath 同步卡片/详情/预览/批量）
 *   - 原版 Icons.* 自绘 SVG → lucide-react 等价物（尺寸数值保留原版 width/height）
 *   - 原版 mantine Popover/Menu/Tooltip → antd 等价物
 *   - 原版 downloadMediaAssetWithWatermark / downloadAsZip → 现有 onDownload / downloadBatchItems（033 批统一实现）
 *   - 原版团队/成员/权限体系 → 本地单机场景裁剪（无团队切换器，权限恒可操作）
 *   - 原版 page surface / 选择器模式（selectMode）→ 本入口只有 modal surface，裁剪
 */

import { memo, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import {
    ArrowDownUp,
    AudioWaveform,
    Check,
    ChevronDown,
    ChevronLeft,
    ChevronRight,
    Copy,
    Download,
    FolderInput,
    Grid3x3,
    Images,
    LayoutGrid,
    List,
    Loader2,
    Minus,
    Music2,
    Play,
    Plus,
    Star,
    Trash2,
    X,
} from "lucide-react";
import { Dropdown, Popover, Tooltip, message as antdMessage, Modal as AntdModal } from "antd";
import { AnimatePresence, motion } from "motion/react"; // 项目用 motion 包（framer-motion 新包名），与 canvas-side-panel 一致

import { CanvasNodeType, type CanvasNodeData } from "../types";
import type { CanvasProject } from "../stores/use-canvas-store";
import { isCanvasImageNodeType } from "../utils/canvas-panorama";
// 033（boss 2026-10-05）：批量打包下载复用画布统一实现（>5 走 zip，带进度与失败回退）
import { downloadBatchItems, type BatchDownloadItem } from "../utils/canvas-batch-download";

// ===== 原版常量（145733 顶部，逐字保留） =====
const RATING_VALUES = [1, 2, 3, 4, 5]; // X
const ZOOM_STEPS = [50, 75, 100, 125, 150]; // J
const ZOOM_SCALE: Record<number, number> = { 50: 71, 75: 85.5, 100: 95, 125: 120, 150: 163 }; // Q
const MEDIA_TABS = [
    { label: "图片", value: "image" }, // common:mediaTypeImage
    { label: "视频", value: "video" }, // common:mediaTypeVideo
    { label: "音频", value: "audio" }, // common:mediaTypeAudio
] as const; // ee
const RATING_FILTERS = ["all", 1, 2, 3, 4, 5] as const; // ea（原版 ei 另处理 "unrated" 文案，但筛选数组不含）
const SCOPE_OPTIONS = [
    { label: "全部画布", onlyCurrent: false }, // canvas:historyAllCanvases
    { label: "本画布", onlyCurrent: true }, // canvas:historyCurrentCanvas
]; // er
const BATCH_APPLY_MAX = { image: 30, video: 15, audio: 20 }; // en
const HISTORY_PAGE_SIZE = 60; // 本地分批渲染（原版为服务端 pageSize:50 分页，本地数据分批 + 哨兵触底加载）
const MAX_BATCH_DOWNLOAD = 300; // 原版 t7：tg.size > 300 禁用下载
const HISTORY_BACKDROP_Z_INDEX = "calc(var(--z-overlay) + 90)"; // 原版 $
const HISTORY_DIALOG_Z_INDEX = "calc(var(--z-overlay) + 91)";
const PREVIEW_Z_INDEX = 700; // 原版 eo() 非 practice 默认 700
// 原版 BOTTOM_BAR_POPOVER_TRANSITION（详情面板展开过渡）
const DETAIL_PANEL_TRANSITION = { type: "spring", stiffness: 500, damping: 40, mass: 0.8 } as const;

// ===== 原版文案（history-translations-045 真值） =====
const T = {
    generationHistory: "生成历史",
    allRatings: "所有评级",
    unrated: "未评分",
    timeAsc: "时间正序",
    timeDesc: "时间倒序",
    sortNewestFirst: "当前：最新优先",
    sortOldestFirst: "当前：最早优先",
    marqueeTip: "进入后可按住左键在素材上滑动多选，或在空白处拖拽框选",
    batchOperation: "批量操作",
    selectedCount: (n: number) => `已选择 ${n} 项`,
    downloadMaxHint: (n: number) => `单次下载素材数量上限为${n}`,
    ratingButton: "评级",
    ratingClear: "取消评级",
    saveToAsset: "保存到资产",
    addToCanvas: "添加到画布",
    confirmSelect: "确认选择",
    noHistoryRecords: "暂无历史记录",
    switchMediaTypeTitle: "切换媒体类型",
    switchMediaTypeMessage: "切换媒体类型将清空当前批量选择，是否继续？",
    ok: "确定",
    cancel: "取消",
    batchDeleteTitle: "批量删除",
    batchDeleteConfirm: (n: number) => `确认批量删除 ${n} 项`,
    deletedCount: (n: number) => `已删除 ${n} 项`,
    deleteRecordTitle: "删除记录",
    deleteConfirmIrreversible: "确认删除吗，删除后将不可恢复",
    deleted: "已删除",
    loadFailed: "加载失败",
    retry: "重试",
    noCover: "无封面",
    imgLoadFailed: "加载失败",
    unknownDate: "未知日期", // canvas:historyArtifactCardText424a01
    detailCreator: "创作者",
    detailCreatedAt: "创建于",
    detailRating: "评级",
    detailGenerationInfo: "生成信息",
    detailNoPrompt: "暂无生成信息",
    detailInputAssets: "参考",
    copySuccess: "已复制",
    copyFailed: "复制失败",
    packagingDownload: (n: number) => `正在打包下载 ${n} 个文件…`,
    downloadStarted: (n: number) => `已开始下载 ${n} 个文件`,
    downloadFailedRetry: "下载失败，请重试",
    downloading: "下载中...",
    download: "下载",
    delete: "删除",
    ratingApplied: (n: number) => `已评级 ${n} 项`,
    batchApplyMax: (kind: "image" | "video" | "audio") => `批量使用最多选择 ${BATCH_APPLY_MAX[kind]} 个${kind === "image" ? "图片" : kind === "video" ? "视频" : "音频"}`,
} as const;

function cn(...parts: Array<string | false | null | undefined>): string {
    return parts.filter(Boolean).join(" ");
}

// 033：时长角标文案（原版 formatReferenceDuration）
function formatDuration(seconds?: number): string {
    if (!Number.isFinite(seconds) || !seconds || seconds < 0) return "";
    const total = Math.round(seconds);
    const mm = Math.floor(total / 60);
    const ss = total % 60;
    return `${mm}:${String(ss).padStart(2, "0")}`;
}

// ===== 本地 artifact 结构（原版服务端 artifact 的本地映射） =====
type HistoryArtifact = {
    /** data-history-artifact-id（原版为 number 型 artifactId，本地为 `${projectId}:${nodeId}`） */
    artifactId: string;
    nodeId: string;
    projectId: string;
    projectTitle: string;
    mediaType: "image" | "video" | "audio";
    previewPath: string;
    title?: string;
    createdAtMs: number;
    rating?: number;
    node: CanvasNodeData;
};

// 043/044/047：产物是否为「本软件生成」（无条件生效，上传/素材导入不计入）
function isGeneratedOutput(node: CanvasNodeData): boolean {
    const meta = node.metadata as Record<string, unknown> | undefined;
    if (!meta) return false;
    const source = typeof meta.source === "string" ? meta.source : "";
    if (source === "import" || source === "upload" || source === "asset" || meta.imported === true) return false;
    return Boolean(meta.imageTaskId || meta.videoTaskId || meta.audioTaskId || meta.workflowTaskId || meta.model);
}

// ===== 原版 187694：DurationBadge（u） =====
function DurationBadge({ durationText, className }: { durationText: string; className?: string }) {
    return durationText ? (
        <span className={cn("pointer-events-none absolute bottom-1.5 left-1.5 z-20 flex h-4 items-center rounded bg-black/65 px-1 text-[10px] leading-none text-white backdrop-blur-sm", className)}>
            {durationText}
        </span>
    ) : null;
}

// ===== 原版 187694：BatchCheckbox（p） =====
function BatchCheckbox({ checked, indeterminate, onChange, isLight }: { checked: boolean; indeterminate?: boolean; onChange: () => void; isLight: boolean }) {
    return (
        <button
            type="button"
            onClick={(event) => {
                event.stopPropagation();
                onChange();
            }}
            className={cn(
                "flex size-[18px] shrink-0 cursor-pointer items-center justify-center rounded-md border border-solid transition-colors",
                checked || indeterminate
                    ? isLight
                        ? "border-[#2c2c2c] bg-[#2c2c2c] text-white"
                        : "border-white bg-white text-black"
                    : isLight
                      ? "border-[#2c2c2c] bg-white"
                      : "border-white/90 bg-black/30",
            )}
        >
            {checked ? <Check width={16} height={16} /> : indeterminate ? <Minus width={16} height={16} /> : null}
        </button>
    );
}

// 原版卡片媒体兜底样式（B）
const CARD_FALLBACK_CLASS = "box-border flex size-full items-center justify-center rounded-lg bg-bg-surface-secondary text-fg-default text-xs font-medium";

// 原版 CanvasAiWatermarkOverlay 的本地等价：右下角 AI 生成角标
// （原组件源码不在交接切片内；宽度公式 min(WATERMARK_MAX, max(20, 0.24*size)) 保留，上限常量交接包缺失，按 0.24×典型卡宽取 48）
function AiWatermarkOverlay({ widthPx, offsetPx }: { widthPx: number; offsetPx: number }) {
    return (
        <span
            aria-hidden
            className="pointer-events-none absolute z-10 flex items-center justify-center rounded-[4px] bg-black/55 text-[10px] font-semibold leading-none text-white backdrop-blur-sm"
            style={{ right: offsetPx, bottom: offsetPx, width: widthPx, height: Math.max(12, Math.round(widthPx * 0.42)) }}
        >
            AI
        </span>
    );
}

// ===== 原版 187694：ArtifactCard（0 号导出，JSX/className/inline style 逐字移植） =====
const ArtifactCard = memo(function ArtifactCard({
    artifact,
    size,
    batchMode,
    selected,
    active,
    onToggleSelect,
    onApply,
    onPreview,
    onDelete,
    onDownload,
    onSelect,
    onEnterBatchSelect,
    dimmed,
    fluid = false,
    isLight,
}: {
    artifact: HistoryArtifact;
    size: number;
    batchMode: boolean;
    selected: boolean;
    active: boolean;
    onToggleSelect?: (id: string) => void;
    onApply?: (artifact: HistoryArtifact) => void;
    onPreview?: (artifact: HistoryArtifact) => void;
    onDelete?: (artifact: HistoryArtifact) => void;
    onDownload?: (artifact: HistoryArtifact) => void | Promise<void>;
    onSelect?: (artifact: HistoryArtifact) => void;
    onEnterBatchSelect?: (artifact: HistoryArtifact) => void;
    dimmed?: boolean;
    fluid?: boolean;
    isLight: boolean;
}) {
    const [imgFailed, setImgFailed] = useState(false); // S
    const [videoMounted, setVideoMounted] = useState(false); // M：hover 后挂载视频
    const [downloading, setDownloading] = useState(false); // z
    const videoRef = useRef<HTMLVideoElement>(null); // _
    const hoveringRef = useRef(false); // D
    const mediaType = artifact.mediaType; // F
    const previewPath = artifact.previewPath; // L
    // 时长：优先节点元数据，缺失时按需探测（原版 O 内联 hook）
    const [probedDuration, setProbedDuration] = useState<number | undefined>(undefined);
    const knownDuration = typeof artifact.node.metadata?.durationMs === "number" ? artifact.node.metadata.durationMs / 1000 : undefined; // 本地字段 durationMs（毫秒），原版 durationSec（秒）
    const durationText = formatDuration(knownDuration ?? probedDuration);
    useEffect(() => {
        setProbedDuration(undefined);
        if (knownDuration || !previewPath || (mediaType !== "video" && mediaType !== "audio")) return;
        const el = document.createElement(mediaType);
        el.preload = "metadata";
        const onMeta = () => {
            if (Number.isFinite(el.duration) && el.duration > 0) setProbedDuration(el.duration);
        };
        el.addEventListener("loadedmetadata", onMeta);
        el.src = previewPath;
        return () => {
            el.removeEventListener("loadedmetadata", onMeta);
            el.removeAttribute("src");
        };
    }, [knownDuration, mediaType, previewPath]);

    // 视频首帧封面（原版 K = getVideoSnapshotForWidth 图片快照；本地以 preload=metadata 的 video 直显首帧，观感与交互一致）
    const showVideoFirstFrame = mediaType === "video" && !!previewPath && !videoMounted;
    // 水印显示条件（U）：非批量 && 有封面 && (图片未失败 || 视频有封面)
    const showWatermark = !batchMode && !!previewPath && (mediaType === "image" ? !imgFailed : mediaType === "video");
    const watermarkWidth = Math.round(Math.max(20, Math.min(48, 0.24 * size))); // $
    // 卡片点击（V）：批量→切换选择；onSelect→选择；否则预览
    const handleCardClick = () => {
        if (batchMode && onToggleSelect) onToggleSelect(artifact.artifactId);
        else if (onSelect) onSelect(artifact);
        else if (onPreview) onPreview(artifact);
    };
    const canDownload = !!onDownload && !!previewPath; // W
    const hoverOps = !batchMode && !!(onDelete || onApply || canDownload || onEnterBatchSelect); // q
    const hoverBottomOps = !batchMode && !!(onDelete || onApply || canDownload); // Y
    const handleDownloadClick = async (event: React.MouseEvent) => {
        event.stopPropagation();
        if (onDownload && !downloading) {
            setDownloading(true);
            try {
                await onDownload(artifact);
            } finally {
                setDownloading(false);
            }
        }
    };
    return (
        <div
            className={cn(
                "group relative transition-opacity duration-150",
                fluid && "w-full",
                (batchMode && onToggleSelect) || onSelect ? "cursor-pointer" : onPreview ? "cursor-zoom-in" : undefined,
                dimmed && "opacity-40",
            )}
            style={fluid ? undefined : { width: `${size}px` }}
            data-history-artifact-id={artifact.artifactId}
            onClick={handleCardClick}
            onMouseEnter={() => {
                if (mediaType === "video") {
                    hoveringRef.current = true;
                    if (!videoMounted) {
                        setVideoMounted(true);
                        return;
                    }
                    videoRef.current?.play().catch(() => undefined);
                }
            }}
            onMouseLeave={() => {
                hoveringRef.current = false;
                const el = videoRef.current;
                if (el) {
                    el.pause();
                    el.currentTime = 0;
                }
            }}
        >
            <div
                className={cn("border-border-default bg-bg-surface-secondary relative isolate box-border overflow-hidden rounded-lg", fluid && "aspect-square w-full")}
                style={fluid ? undefined : { width: `${size}px`, height: `${size}px` }}
            >
                <div className="absolute inset-0 transition-transform duration-200 group-hover:scale-105">
                    {previewPath ? (
                        mediaType === "audio" ? (
                            <div className={cn(CARD_FALLBACK_CLASS, "flex-col gap-1")}>
                                <Music2 width={30} height={30} className="text-fg-default opacity-80" />
                            </div>
                        ) : mediaType === "video" ? (
                            <>
                                {showVideoFirstFrame ? (
                                    <video
                                        ref={videoRef}
                                        src={previewPath}
                                        muted
                                        playsInline
                                        preload="metadata"
                                        className="absolute inset-0 size-full rounded-lg object-cover"
                                        onLoadedMetadata={(event) => {
                                            // 原版 onLoadedMetadata：未 hover 时停在首帧
                                            if (!hoveringRef.current) {
                                                event.currentTarget.pause();
                                                event.currentTarget.currentTime = 0;
                                            }
                                        }}
                                    />
                                ) : null}
                                {videoMounted ? (
                                    <video
                                        ref={videoRef}
                                        src={previewPath}
                                        loop
                                        muted
                                        autoPlay
                                        playsInline
                                        preload="metadata"
                                        className="absolute inset-0 size-full rounded-lg object-cover"
                                        onLoadedMetadata={(event) => {
                                            if (!hoveringRef.current) {
                                                event.currentTarget.pause();
                                                event.currentTarget.currentTime = 0;
                                            }
                                        }}
                                    />
                                ) : null}
                            </>
                        ) : imgFailed ? (
                            <div className={CARD_FALLBACK_CLASS}>{T.imgLoadFailed}</div>
                        ) : (
                            <img
                                src={previewPath}
                                alt=""
                                draggable={false}
                                className="absolute inset-0 size-full rounded-lg object-cover"
                                onError={() => setImgFailed(true)}
                            />
                        )
                    ) : (
                        <div className={CARD_FALLBACK_CLASS}>{T.noCover}</div>
                    )}
                </div>
                {showWatermark ? (
                    <div className={cn(hoverOps && "transition-opacity group-hover:opacity-0")}>
                        <AiWatermarkOverlay widthPx={watermarkWidth} offsetPx={6} />
                    </div>
                ) : null}
                {typeof artifact.rating === "number" && artifact.rating > 0 ? (
                    <div className="absolute left-2 top-2 z-10 flex h-4 items-center gap-0.5 rounded px-1" style={{ background: "rgba(31,31,31,0.75)" }}>
                        <span className="text-[12px] font-medium leading-4 text-[#e9931c]">{artifact.rating}</span>
                        <Star width={10} height={10} className="text-[#e9931c]" fill="currentColor" />
                    </div>
                ) : null}
                {(mediaType === "video" || mediaType === "audio") ? (
                    <DurationBadge durationText={durationText} className={cn(hoverBottomOps && "transition-opacity duration-150 group-hover:opacity-0")} />
                ) : null}
                {batchMode ? (
                    <div className="absolute right-2 top-2 z-10">
                        <BatchCheckbox checked={selected} onChange={() => onToggleSelect?.(artifact.artifactId)} isLight={isLight} />
                    </div>
                ) : null}
                {(batchMode && selected) || active ? (
                    <div className="pointer-events-none absolute inset-0 rounded-lg" style={{ border: `1px solid ${isLight ? "#2c2c2c" : "#ffffff"}` }} />
                ) : null}
                {hoverOps ? (
                    <div className="absolute inset-0 flex flex-col items-end justify-between rounded-lg p-2">
                        {onEnterBatchSelect ? (
                            <div className="opacity-0 transition-opacity duration-150 group-hover:opacity-100">
                                <BatchCheckbox checked={false} onChange={() => onEnterBatchSelect(artifact)} isLight={isLight} />
                            </div>
                        ) : (
                            <span aria-hidden />
                        )}
                        <div className="flex w-full items-center gap-1">
                            {onApply ? (
                                <button
                                    type="button"
                                    onClick={(event) => {
                                        event.stopPropagation();
                                        onApply(artifact);
                                    }}
                                    className="flex h-8 min-w-0 flex-1 cursor-pointer items-center justify-center rounded-lg border-none bg-black/25 p-2 text-white opacity-0 backdrop-blur-[10px] transition-[opacity,background-color] duration-150 hover:bg-black/40 group-hover:opacity-100"
                                >
                                    <Plus width={16} height={16} />
                                </button>
                            ) : null}
                            {canDownload ? (
                                <button
                                    type="button"
                                    onClick={(event) => void handleDownloadClick(event)}
                                    disabled={downloading}
                                    className="flex h-8 min-w-0 flex-1 cursor-pointer items-center justify-center rounded-lg border-none bg-black/25 p-2 text-white opacity-0 backdrop-blur-[10px] transition-[opacity,background-color] duration-150 hover:bg-black/40 disabled:cursor-not-allowed group-hover:opacity-100 group-hover:disabled:opacity-50"
                                >
                                    <Download width={16} height={16} />
                                </button>
                            ) : null}
                            {onDelete ? (
                                <button
                                    type="button"
                                    onClick={(event) => {
                                        event.stopPropagation();
                                        onDelete(artifact);
                                    }}
                                    className="flex h-8 min-w-0 flex-1 cursor-pointer items-center justify-center rounded-lg border-none bg-black/25 p-2 text-[#e74c3c] opacity-0 backdrop-blur-[10px] transition-[opacity,background-color] duration-150 hover:bg-black/40 group-hover:opacity-100"
                                >
                                    <Trash2 width={16} height={16} />
                                </button>
                            ) : null}
                        </div>
                    </div>
                ) : null}
            </div>
        </div>
    );
});

// ===== 原版 187694：ArtifactRatingStars =====
function ArtifactRatingStars({ rating, disabled, onRate }: { rating: number; disabled?: boolean; onRate: (value: number) => void }) {
    const [hover, setHover] = useState(0);
    const display = hover || rating;
    return (
        <span className="flex items-center gap-0.5" onMouseLeave={() => setHover(0)}>
            {RATING_VALUES.map((value) => {
                const filled = value <= display;
                return (
                    <button
                        key={value}
                        type="button"
                        disabled={disabled}
                        aria-label={`评 ${value} 星`}
                        className="flex size-6 items-center justify-center rounded-md transition-colors hover:bg-canvas-controls-hover disabled:cursor-not-allowed disabled:opacity-50"
                        onMouseEnter={() => setHover(value)}
                        onClick={(event) => {
                            event.stopPropagation();
                            onRate(value === rating ? 0 : value);
                        }}
                    >
                        <Star width={14} height={14} className="shrink-0" style={filled ? { color: "var(--nt-accent-amber)" } : { opacity: 0.2 }} fill={filled ? "currentColor" : "none"} />
                    </button>
                );
            })}
        </span>
    );
}

// ===== 原版 187694：dedupeHistoryArtifactsByUrl / getArtifactRating / groupHistoryArtifactsByDate =====
function dedupeArtifactsByPreviewPath<T extends { previewPath?: string }>(list: T[]): T[] {
    const seen = new Set<string>();
    return list.filter((item) => {
        const path = item.previewPath?.trim();
        return !path || (!seen.has(path) && (seen.add(path), true));
    });
}

function getArtifactRating(artifact?: { rating?: number } | null): number {
    const rating = artifact?.rating;
    return typeof rating === "number" && rating >= 1 && rating <= 5 ? rating : 0;
}

function formatDateKey(ms: number): string {
    const date = new Date(ms);
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, "0");
    const d = String(date.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
}

function groupArtifactsByDate(artifacts: HistoryArtifact[]): Array<{ date: string; items: HistoryArtifact[] }> {
    const map = new Map<string, HistoryArtifact[]>();
    for (const artifact of artifacts) {
        const key = artifact.createdAtMs ? formatDateKey(artifact.createdAtMs) : T.unknownDate;
        const bucket = map.get(key);
        if (bucket) bucket.push(artifact);
        else map.set(key, [artifact]);
    }
    return Array.from(map.entries()).map(([date, items]) => ({ date, items }));
}

// ===== 原版 736355：useHistoryMarqueeSelect（逐字移植，fixed 坐标系橡皮筋框选） =====
function marqueeRect(box: { x0: number; y0: number; x1: number; y1: number }) {
    return {
        left: Math.min(box.x0, box.x1),
        top: Math.min(box.y0, box.y1),
        right: Math.max(box.x0, box.x1),
        bottom: Math.max(box.y0, box.y1),
    };
}

function artifactIdFromEventTarget(target: EventTarget | null): string | null {
    if (!(target instanceof Element)) return null;
    const el = target.closest("[data-history-artifact-id]");
    if (!el) return null;
    const id = el.getAttribute("data-history-artifact-id");
    return id ?? null;
}

function setsEqual(a: Set<string>, b: Set<string>): boolean {
    if (a.size !== b.size) return false;
    for (const item of b) if (!a.has(item)) return false;
    return true;
}

function useHistoryMarqueeSelect({
    enabled,
    containerRef,
    selectedIdsRef,
    setSelectedIds,
}: {
    enabled: boolean;
    containerRef: React.RefObject<HTMLDivElement | null>;
    selectedIdsRef: React.MutableRefObject<Set<string>>;
    setSelectedIds: React.Dispatch<React.SetStateAction<Set<string>>>;
}) {
    const [rubberBox, setRubberBox] = useState<{ x0: number; y0: number; x1: number; y1: number } | null>(null);
    const boxRef = useRef<{ x0: number; y0: number; x1: number; y1: number } | null>(null); // m
    const draggingRef = useRef(false); // p
    const initialSelectionRef = useRef(new Set<string>()); // h
    const movedRef = useRef(false); // x
    const pointerIdRef = useRef<number | null>(null); // f
    const pendingPointRef = useRef<{ x: number; y: number } | null>(null); // g
    const rafRef = useRef(0); // b
    const rangeRef = useRef<{ anchorId: string; currentId: string; mode: "select" | "deselect" } | null>(null); // y

    const selectInRect = useCallback(
        (box: { x0: number; y0: number; x1: number; y1: number }) => {
            const container = containerRef.current;
            if (!container) return;
            const rect = marqueeRect(box);
            if (rect.right - rect.left < 5 && rect.bottom - rect.top < 5) return;
            const ids: string[] = [];
            container.querySelectorAll("[data-history-artifact-id]").forEach((el) => {
                const r = el.getBoundingClientRect();
                if (!(r.left < rect.right) || !(r.right > rect.left) || !(r.top < rect.bottom) || !(r.bottom > rect.top)) return;
                const id = el.getAttribute("data-history-artifact-id");
                if (id) ids.push(id);
            });
            const next = new Set(initialSelectionRef.current);
            for (const id of ids) next.add(id);
            setSelectedIds((prev) => (setsEqual(prev, next) ? prev : next));
        },
        [containerRef, setSelectedIds],
    );

    const selectRange = useCallback(() => {
        const container = containerRef.current;
        const range = rangeRef.current;
        if (!container || !range) return;
        const ordered: string[] = [];
        container.querySelectorAll("[data-history-artifact-id]").forEach((el) => {
            const id = el.getAttribute("data-history-artifact-id");
            if (id) ordered.push(id);
        });
        const start = ordered.indexOf(range.anchorId);
        if (start < 0) return;
        const end = ordered.indexOf(range.currentId);
        if (end < 0) return;
        const slice = ordered.slice(Math.min(start, end), Math.max(start, end) + 1);
        const next = new Set(initialSelectionRef.current);
        if (range.mode === "deselect") {
            for (const id of slice) next.delete(id);
        } else {
            for (const id of slice) next.add(id);
        }
        setSelectedIds((prev) => (setsEqual(prev, next) ? prev : next));
    }, [containerRef, setSelectedIds]);

    const reset = useCallback(() => {
        if (rafRef.current) {
            cancelAnimationFrame(rafRef.current);
            rafRef.current = 0;
        }
        pendingPointRef.current = null;
        draggingRef.current = false;
        pointerIdRef.current = null;
        movedRef.current = false;
        boxRef.current = null;
        rangeRef.current = null;
        document.body.style.removeProperty("user-select");
    }, []);

    useEffect(() => {
        if (!enabled) {
            setRubberBox(null);
            reset();
        }
    }, [enabled, reset]);

    useEffect(() => () => reset(), [reset]);

    const onPointerDown = useCallback(
        (event: React.PointerEvent) => {
            if (!enabled || event.button !== 0 || !(event.target instanceof Element) || event.target.closest("button") || event.target.closest("a") || event.target.closest("input") || event.target.closest("[data-no-marquee]") || !containerRef.current) return;
            initialSelectionRef.current = new Set(selectedIdsRef.current);
            movedRef.current = false;
            draggingRef.current = true;
            pointerIdRef.current = event.pointerId;
            const anchorId = artifactIdFromEventTarget(event.target);
            rangeRef.current = anchorId == null ? null : { anchorId, currentId: anchorId, mode: selectedIdsRef.current.has(anchorId) ? "deselect" : "select" };
            const startBox = { x0: event.clientX, y0: event.clientY, x1: event.clientX, y1: event.clientY };
            boxRef.current = startBox;
            if (!rangeRef.current) setRubberBox(startBox);
            document.body.style.userSelect = "none";
            const onMove = (moveEvent: PointerEvent) => {
                if (!draggingRef.current || moveEvent.pointerId !== pointerIdRef.current) return;
                pendingPointRef.current = { x: moveEvent.clientX, y: moveEvent.clientY };
                if (rafRef.current) return;
                rafRef.current = requestAnimationFrame(() => {
                    rafRef.current = 0;
                    const point = pendingPointRef.current;
                    const box = boxRef.current;
                    if (!point || !draggingRef.current || !box) return;
                    const nextBox = { ...box, x1: point.x, y1: point.y };
                    boxRef.current = nextBox;
                    const range = rangeRef.current;
                    if (!range) setRubberBox(nextBox);
                    const dx = Math.abs(nextBox.x1 - nextBox.x0);
                    const dy = Math.abs(nextBox.y1 - nextBox.y0);
                    if (dx > 5 || dy > 5) {
                        movedRef.current = true;
                        if (range) {
                            const el = document.elementFromPoint(point.x, point.y);
                            const id = artifactIdFromEventTarget(el);
                            if (id != null) {
                                range.currentId = id;
                                selectRange();
                            }
                        } else {
                            selectInRect(nextBox);
                        }
                    }
                });
            };
            const onUp = (upEvent: PointerEvent) => {
                if (upEvent.pointerId !== pointerIdRef.current) return;
                window.removeEventListener("pointermove", onMove);
                window.removeEventListener("pointerup", onUp);
                window.removeEventListener("pointercancel", onUp);
                const moved = movedRef.current;
                const box = boxRef.current;
                if (moved && box) {
                    if (rangeRef.current) selectRange();
                    else selectInRect(box);
                    // 拖框结束后吞掉随后的 click，防止误触卡片
                    const swallow = (clickEvent: MouseEvent) => {
                        clickEvent.stopPropagation();
                        clickEvent.preventDefault();
                        window.removeEventListener("click", swallow, true);
                    };
                    window.addEventListener("click", swallow, true);
                    window.setTimeout(() => window.removeEventListener("click", swallow, true), 300);
                }
                setRubberBox(null);
                reset();
            };
            window.addEventListener("pointermove", onMove);
            window.addEventListener("pointerup", onUp);
            window.addEventListener("pointercancel", onUp);
        },
        [enabled, containerRef, selectedIdsRef, selectInRect, selectRange, reset],
    );

    const rubberStyle = (() => {
        if (!rubberBox) return null;
        const rect = marqueeRect(rubberBox);
        const width = rect.right - rect.left;
        const height = rect.bottom - rect.top;
        if (width < 5 && height < 5) return null;
        return {
            position: "fixed" as const,
            left: rect.left,
            top: rect.top,
            width,
            height,
            pointerEvents: "none" as const,
            zIndex: "calc(var(--z-overlay) + 10)",
            border: "1px solid var(--btn-primary-bg)",
            backgroundColor: "color-mix(in srgb, var(--btn-primary-bg) 16%, transparent)",
        };
    })();

    return { onPointerDown, rubberStyle, isMarqueeSelecting: rubberBox != null };
}

// ===== 原版 141940：HistoryDetailPanel（memo，逐字移植） =====
const HISTORY_DETAIL_BTN_BASE = (isLight: boolean) =>
    cn(
        "text-canvas-controls-text flex min-h-8 shrink-0 cursor-pointer items-center justify-center gap-1 rounded-lg border-none px-2 py-1 text-center text-[13px] leading-4 transition-colors disabled:cursor-not-allowed disabled:opacity-40",
        isLight ? "bg-black/[0.04] hover:bg-black/[0.06]" : "bg-white/[0.06] hover:bg-white/[0.08]",
    );

function DetailRow({ label, children }: { label: string; children: React.ReactNode }) {
    return (
        <div className="flex w-full items-center justify-between px-5 py-2 text-[13px] leading-5">
            <span className="text-canvas-controls-text opacity-55">{label}</span>
            <div className="text-canvas-controls-text min-w-0 text-right">{children}</div>
        </div>
    );
}

const VIDEO_URL_RE = /\.(mp4|webm|mov|m3u8)(\?|#|$)/i;
const AUDIO_URL_RE = /\.(mp3|wav|m4a|aac|ogg|flac)(\?|#|$)/i;

function ReferenceThumb({ url, isLight }: { url: string; isLight: boolean }) {
    const boxClass = cn("flex size-8 shrink-0 items-center justify-center overflow-hidden rounded-md", isLight ? "bg-black/[0.04]" : "bg-white/[0.06]");
    if (VIDEO_URL_RE.test(url)) {
        return (
            <span className={boxClass} title={url}>
                <video src={url} muted playsInline preload="metadata" className="size-full object-cover" />
            </span>
        );
    }
    if (AUDIO_URL_RE.test(url)) {
        return (
            <span className={cn(boxClass, "text-canvas-controls-text opacity-50")} title={url}>
                <AudioWaveform width={16} height={16} />
            </span>
        );
    }
    return (
        <span className={boxClass} title={url}>
            <img src={url} alt="" loading="lazy" draggable={false} className="size-full object-cover" />
        </span>
    );
}

// 本地 extractGenerationParams（原版 141940 j：从节点 metadata 提取生成信息）
function extractGenerationParams(artifact: HistoryArtifact): { title?: string; prompt?: string; modelKey?: string; tags: string[]; inputAssets: string[] } {
    const meta = (artifact.node.metadata ?? {}) as Record<string, unknown>;
    const str = (...values: unknown[]) => {
        for (const value of values) {
            if (typeof value === "string" && value.trim()) return value.trim();
        }
        return undefined;
    };
    const prompt = str(meta.prompt, meta.positivePrompt, meta.text);
    const modelKey = str(meta.model, meta.modelName);
    const ratio = str(meta.aspectRatio, meta.ratio, meta.size);
    const resolution = str(meta.resolution, meta.quality, meta.naturalWidth && meta.naturalHeight ? `${meta.naturalWidth}×${meta.naturalHeight}` : undefined);
    const duration = typeof meta.durationSec === "number" ? meta.durationSec : undefined;
    const inputAssets = Array.isArray(meta.sourceImage)
        ? (meta.sourceImage as unknown[]).filter((item): item is string => typeof item === "string" && !!item.trim())
        : Array.isArray(meta.referenceImages)
          ? (meta.referenceImages as unknown[]).filter((item): item is string => typeof item === "string" && !!item.trim())
          : [];
    return {
        title: str(artifact.title, meta.taskName, meta.nodeName),
        prompt,
        modelKey,
        tags: [ratio, resolution, typeof duration === "number" && duration > 0 ? `${duration}s` : undefined].filter((v): v is string => !!v),
        inputAssets,
    };
}

const HistoryDetailPanel = memo(function HistoryDetailPanel({
    artifact,
    className,
    creatorName,
    isPageSurface = false,
    onClose,
    onPreviewCover,
    onApply,
    applyLabel,
    onSaveToAsset,
    onDownload,
    onDelete,
    onRate,
    isLight,
}: {
    artifact: HistoryArtifact;
    className?: string;
    creatorName?: string;
    isPageSurface?: boolean;
    onClose: () => void;
    onPreviewCover?: (artifact: HistoryArtifact) => void;
    onApply?: (artifact: HistoryArtifact) => void;
    applyLabel?: string;
    onSaveToAsset?: (artifact: HistoryArtifact) => void;
    onDownload?: (artifact: HistoryArtifact) => void | Promise<void>;
    onDelete?: (artifact: HistoryArtifact) => void;
    onRate?: (artifact: HistoryArtifact, rating: number) => void;
    isLight: boolean;
}) {
    const [downloading, setDownloading] = useState(false); // L
    const params = useMemo(() => extractGenerationParams(artifact), [artifact]);
    const title = params.title ?? (artifact.mediaType === "video" ? "视频" : artifact.mediaType === "audio" ? "音频" : "图片");
    const rating = typeof artifact.rating === "number" ? Math.min(5, Math.max(0, artifact.rating)) : 0;
    const previewPath = artifact.previewPath?.trim();
    const btnClass = HISTORY_DETAIL_BTN_BASE(isLight);
    const primaryBtnClass = cn(btnClass, "min-w-0 flex-1");
    return (
        <aside className={cn("border-canvas-controls-border flex h-full w-[300px] shrink-0 flex-col border-l", className)} data-no-marquee>
            <div className="flex shrink-0 items-center gap-1 px-5 pb-1 pt-[17px]">
                <span className="text-canvas-controls-text min-w-0 flex-1 truncate text-sm font-semibold leading-[22px]">{title}</span>
                <button type="button" onClick={onClose} className="flex size-[26px] shrink-0 cursor-pointer items-center justify-center rounded-lg opacity-50 transition-colors hover:bg-canvas-controls-hover hover:opacity-100">
                    <X width={16} height={16} />
                </button>
            </div>
            {!isPageSurface ? (
                <div className="shrink-0 px-4 py-3">
                    <button
                        type="button"
                        onClick={onPreviewCover ? () => onPreviewCover(artifact) : undefined}
                        className={cn("block h-[268px] w-full overflow-hidden rounded-xl border-none bg-black/20 p-0", onPreviewCover && previewPath ? "cursor-pointer" : "cursor-default")}
                    >
                        {artifact.mediaType === "video" && previewPath ? (
                            <span className="relative block size-full">
                                <video src={previewPath} muted playsInline preload="metadata" className="size-full object-cover" />
                                <span className="absolute inset-0 flex items-center justify-center">
                                    <span className="flex size-10 items-center justify-center rounded-full bg-black/50 text-white backdrop-blur-[4px]">
                                        <Play width={18} height={18} className="translate-x-px" fill="currentColor" />
                                    </span>
                                </span>
                            </span>
                        ) : artifact.mediaType === "audio" ? (
                            <span className="text-canvas-controls-text flex size-full items-center justify-center opacity-40">
                                <Music2 width={48} height={48} />
                            </span>
                        ) : previewPath ? (
                            <img src={previewPath} alt="" className="size-full object-cover" draggable={false} />
                        ) : null}
                    </button>
                </div>
            ) : null}
            <div className="thin-scrollbar min-h-0 flex-1 overflow-y-auto pb-1">
                <DetailRow label={T.detailCreator}>
                    <span className="block truncate">{creatorName || "-"}</span>
                </DetailRow>
                <DetailRow label={T.detailCreatedAt}>
                    {typeof artifact.createdAtMs !== "number" || artifact.createdAtMs <= 0 ? "-" : new Date(artifact.createdAtMs).toLocaleString("zh-CN", { year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" }).replace(/\//g, "-")}
                </DetailRow>
                <DetailRow label={T.detailRating}>
                    {onRate ? (
                        <span className="flex items-center justify-end">
                            <ArtifactRatingStars rating={getArtifactRating(artifact)} onRate={(value) => onRate(artifact, value)} />
                        </span>
                    ) : (
                        <span className="flex items-center justify-end gap-1">
                            {[1, 2, 3, 4, 5].map((value) => (
                                <Star key={value} width={14} height={14} className={value <= rating ? "text-[#e9931c]" : isLight ? "text-black/15" : "text-white/20"} fill={value <= rating ? "currentColor" : "none"} />
                            ))}
                        </span>
                    )}
                </DetailRow>
                <div className="flex flex-col px-5 pb-3">
                    <div className="flex h-9 items-center justify-between py-2">
                        <span className="text-canvas-controls-text text-[13px] leading-5 opacity-55">{T.detailGenerationInfo}</span>
                        {params.prompt ? (
                            <button
                                type="button"
                                onClick={() => {
                                    const text = params.prompt;
                                    if (text) {
                                        void navigator.clipboard
                                            .writeText(text)
                                            .then(() => antdMessage.success(T.copySuccess))
                                            .catch(() => antdMessage.error(T.copyFailed));
                                    }
                                }}
                                className={cn("text-canvas-controls-text flex size-[22px] cursor-pointer items-center justify-center rounded-md border-none transition-colors", isLight ? "bg-black/[0.06] hover:bg-black/[0.1]" : "bg-white/[0.08] hover:bg-white/[0.12]")}
                            >
                                <Copy width={14} height={14} />
                            </button>
                        ) : null}
                    </div>
                    {params.prompt ? (
                        <div className="text-canvas-controls-text line-clamp-3 whitespace-pre-wrap break-words text-[13px] leading-5">{params.prompt}</div>
                    ) : (
                        <div className="text-canvas-controls-text py-1 text-[13px] leading-5 opacity-40">{T.detailNoPrompt}</div>
                    )}
                    {params.tags.length > 0 ? (
                        <div className="flex flex-wrap items-center gap-1.5 pt-2">
                            {params.tags.map((tag) => (
                                <span key={tag} className={cn("text-canvas-controls-text rounded-md px-1 py-px text-[12px] leading-[18px] opacity-55", isLight ? "bg-black/[0.04]" : "bg-white/[0.06]")}>
                                    {tag}
                                </span>
                            ))}
                        </div>
                    ) : null}
                    {params.inputAssets.length > 0 ? (
                        <div className="flex flex-col pb-5">
                            <span className="text-canvas-controls-text py-2 text-[13px] leading-5 opacity-55">{T.detailInputAssets}</span>
                            <div className="flex flex-wrap gap-1.5">
                                {params.inputAssets.slice(0, 8).map((url) => (
                                    <ReferenceThumb key={url} url={url} isLight={isLight} />
                                ))}
                                {params.inputAssets.length > 8 ? (
                                    <span className={cn("text-canvas-controls-text flex size-8 shrink-0 items-center justify-center rounded-md text-[12px] opacity-70", isLight ? "bg-black/[0.04]" : "bg-white/[0.06]")}>+{params.inputAssets.length - 8}</span>
                                ) : null}
                            </div>
                        </div>
                    ) : null}
                </div>
            </div>
            <div className="flex shrink-0 flex-col gap-2 p-4">
                {onSaveToAsset || onApply ? (
                    <div className="flex items-stretch gap-2">
                        {onSaveToAsset ? (
                            <button type="button" onClick={() => onSaveToAsset(artifact)} className={primaryBtnClass}>
                                <FolderInput width={16} height={16} className="shrink-0" />
                                <span>{T.saveToAsset}</span>
                            </button>
                        ) : null}
                        {onApply ? (
                            <button type="button" onClick={() => onApply(artifact)} className={primaryBtnClass}>
                                <Plus width={16} height={16} className="shrink-0" />
                                <span>{applyLabel ?? T.addToCanvas}</span>
                            </button>
                        ) : null}
                    </div>
                ) : null}
                <div className="flex items-stretch gap-2">
                    {onDelete ? (
                        <button
                            type="button"
                            onClick={() => onDelete(artifact)}
                            className="flex min-h-8 min-w-0 flex-1 cursor-pointer items-center justify-center gap-1 rounded-lg border-none px-2 py-1 text-center text-[13px] leading-4 text-[#e74c3c] transition-opacity hover:opacity-90"
                            style={{ background: "rgba(231,76,60,0.12)" }}
                        >
                            <Trash2 width={16} height={16} className="shrink-0" />
                            <span>{T.delete}</span>
                        </button>
                    ) : null}
                    {onDownload ? (
                        <button
                            type="button"
                            disabled={downloading || !previewPath}
                            onClick={() => {
                                setDownloading(true);
                                void Promise.resolve(onDownload(artifact)).finally(() => setDownloading(false));
                            }}
                            className={primaryBtnClass}
                        >
                            <Download width={16} height={16} className="shrink-0" />
                            <span>{T.download}</span>
                        </button>
                    ) : null}
                </div>
            </div>
        </aside>
    );
});

// ===== 原版 145733：评级筛选 Popover（ec） =====
function ratingFilterLabel(value: string | number): string {
    return value === "all" ? T.allRatings : String(value);
}

function RatingFilterPopover({ value, onChange, isLight }: { value: string | number; onChange: (value: string | number) => void; isLight: boolean }) {
    const [open, setOpen] = useState(false);
    const content = (
        <div className="flex flex-col" style={{ minWidth: 132 }}>
            {RATING_FILTERS.map((option) => {
                const selected = option === value;
                return (
                    <button
                        key={String(option)}
                        type="button"
                        onClick={() => {
                            onChange(option);
                            setOpen(false);
                        }}
                        className={cn(
                            "text-canvas-controls-text flex h-9 w-full cursor-pointer items-center justify-between rounded-[10px] border-none px-2 text-left text-[14px] leading-[22px] transition-colors",
                            isLight ? "hover:bg-black/[0.04]" : "hover:bg-white/[0.05]",
                        )}
                    >
                        {typeof option === "number" ? (
                            <span className="flex items-center gap-1.5">
                                {option}
                                <Star width={14} height={14} className="text-[#E9931C]" fill="currentColor" />
                            </span>
                        ) : (
                            ratingFilterLabel(option)
                        )}
                        {selected ? <Check className="text-fg-default size-4" /> : null}
                    </button>
                );
            })}
        </div>
    );
    return (
        <Popover
            open={open}
            onOpenChange={setOpen}
            placement="bottomRight"
            align={{ offset: [0, 4] }}
            arrow={false}
            content={content}
            styles={{ content: { padding: 6, backgroundColor: "var(--canvas-controls-bg)", border: "0.5px solid var(--canvas-controls-border)", borderRadius: 16, width: 200, backdropFilter: "blur(16px)", boxShadow: "0 1px 1px 0 rgba(0,0,0,0.02), 0 4px 8px -4px rgba(0,0,0,0.04), 0 16px 24px -8px rgba(0,0,0,0.06)" } }}
        >
            <button type="button" onClick={() => setOpen((prev) => !prev)} className="text-fg-default flex h-8 cursor-pointer items-center gap-1 rounded-lg border-none bg-transparent px-2 text-[13px] transition-colors hover:bg-canvas-controls-hover">
                {ratingFilterLabel(value)}
                {typeof value === "number" ? <Star width={14} height={14} className="text-[#E9931C]" fill="currentColor" /> : null}
                <ChevronDown width={14} height={14} className="text-fg-default transition-transform" style={open ? { transform: "rotate(180deg)" } : undefined} />
            </button>
        </Popover>
    );
}

// ===== 原版 145733：ed 预览浮层（MediaPreviewOverlay 本地等价：全屏媒体 + 导航 + 页码/评级/下载 footer） =====
function HistoryPreviewOverlay({
    artifacts,
    currentIndex,
    onNavigate,
    onClose,
    onRate,
    onDownload,
}: {
    artifacts: HistoryArtifact[];
    currentIndex: number;
    onNavigate: (index: number | null) => void;
    onClose: () => void;
    onRate?: (artifact: HistoryArtifact, rating: number) => void;
    onDownload?: (artifact: HistoryArtifact) => void;
}) {
    const artifact = artifacts[currentIndex];
    const [downloading, setDownloading] = useState(false);
    const hasPrev = currentIndex > 0;
    const hasNext = currentIndex < artifacts.length - 1;
    const mediaType = artifact?.mediaType ?? "image";
    if (!artifact) return null;
    return createPortal(
        <div className="fixed inset-0 flex flex-col" style={{ zIndex: PREVIEW_Z_INDEX, background: "rgba(0,0,0,0.88)" }} onClick={onClose}>
            <div className="relative flex min-h-0 flex-1 items-center justify-center p-10" onClick={(event) => event.stopPropagation()}>
                {mediaType === "video" ? (
                    <video src={artifact.previewPath ?? ""} controls autoPlay playsInline className="max-h-full max-w-full rounded-xl object-contain" />
                ) : mediaType === "audio" ? (
                    <div className="flex flex-col items-center gap-8 p-8" onClick={(event) => event.stopPropagation()}>
                        <Music2 width={60} height={60} className="text-fg-default opacity-80" />
                        <audio src={artifact.previewPath ?? ""} controls autoPlay className="min-w-[400px] max-w-[600px]" />
                    </div>
                ) : (
                    <img src={artifact.previewPath ?? ""} alt="" draggable={false} className="max-h-full max-w-full rounded-xl object-contain" onClick={(event) => event.stopPropagation()} />
                )}
                {hasPrev ? (
                    <button
                        type="button"
                        aria-label="上一个"
                        className="absolute left-4 top-1/2 flex size-10 -translate-y-1/2 cursor-pointer items-center justify-center rounded-full border-none bg-black/50 text-white backdrop-blur-[4px] transition-colors hover:bg-black/70"
                        onClick={(event) => {
                            event.stopPropagation();
                            onNavigate(currentIndex - 1);
                        }}
                    >
                        <ChevronLeft width={20} height={20} />
                    </button>
                ) : null}
                {hasNext ? (
                    <button
                        type="button"
                        aria-label="下一个"
                        className="absolute right-4 top-1/2 flex size-10 -translate-y-1/2 cursor-pointer items-center justify-center rounded-full border-none bg-black/50 text-white backdrop-blur-[4px] transition-colors hover:bg-black/70"
                        onClick={(event) => {
                            event.stopPropagation();
                            onNavigate(currentIndex + 1);
                        }}
                    >
                        <ChevronRight width={20} height={20} />
                    </button>
                ) : null}
                <button
                    type="button"
                    aria-label="关闭"
                    className="absolute right-4 top-4 flex size-9 cursor-pointer items-center justify-center rounded-full border-none bg-black/50 text-white backdrop-blur-[4px] transition-colors hover:bg-black/70"
                    onClick={onClose}
                >
                    <X width={18} height={18} />
                </button>
            </div>
            <div className="flex shrink-0 items-center justify-center gap-4 pb-6" onClick={(event) => event.stopPropagation()}>
                <span className="text-sm text-white opacity-50">
                    {currentIndex + 1} / {artifacts.length}
                </span>
                {onRate ? (
                    <div className="flex rounded-lg bg-black/60 px-1 py-0.5" onClick={(event) => event.stopPropagation()}>
                        <span className="flex items-center [&_button]:hover:bg-transparent">
                            <span className="pointer-events-none [&_span]:pointer-events-auto [&_button]:pointer-events-auto">
                                <span className="flex" onClick={(event) => event.stopPropagation()}>
                                    <span className="flex items-center">
                                        <span className="contents">
                                            <span className="flex [&_button]:bg-transparent">
                                                <span className="flex items-center">
                                                    <span className="flex [&_span]:flex [&_span]:items-center" onClick={(e) => e.stopPropagation()}>
                                                        <span className="flex" onClick={(e) => e.stopPropagation()} />
                                                        <span className="flex cursor-pointer items-center" onClick={(e) => e.stopPropagation()}>
                                                            <span className="flex items-center gap-0.5 [&_button]:pointer-events-auto">
                                                                <DarkPreviewRating artifact={artifact} onRate={(value) => onRate(artifact, value)} />
                                                            </span>
                                                        </span>
                                                    </span>
                                                </span>
                                            </span>
                                        </span>
                                    </span>
                                </span>
                            </span>
                        </span>
                    </div>
                ) : null}
                <button
                    type="button"
                    disabled={downloading}
                    onClick={() => {
                        if (downloading) return;
                        setDownloading(true);
                        void Promise.resolve(onDownload?.(artifact)).finally(() => window.setTimeout(() => setDownloading(false), 2000));
                    }}
                    className="flex h-9 cursor-pointer items-center gap-2 rounded-lg border-none bg-canvas-controls-active px-5 text-sm text-white opacity-80 transition-colors hover:bg-canvas-controls-hover hover:opacity-100 disabled:cursor-not-allowed disabled:opacity-50"
                >
                    <Download width={16} height={16} />
                    {downloading ? T.downloading : T.download}
                </button>
            </div>
        </div>,
        document.body,
    );
}

// 预览 footer 里的评级星（黑底胶囊内，原版 footer rating 容器 rounded-lg bg-black/60 px-1 py-0.5）
function DarkPreviewRating({ artifact, onRate }: { artifact: HistoryArtifact; onRate: (value: number) => void }) {
    const [hover, setHover] = useState(0);
    const rating = getArtifactRating(artifact);
    const display = hover || rating;
    return (
        <span className="flex items-center gap-0.5" onMouseLeave={() => setHover(0)}>
            {RATING_VALUES.map((value) => {
                const filled = value <= display;
                return (
                    <button
                        key={value}
                        type="button"
                        aria-label={`评 ${value} 星`}
                        className="flex size-6 cursor-pointer items-center justify-center rounded-md transition-colors"
                        onMouseEnter={() => setHover(value)}
                        onClick={(event) => {
                            event.stopPropagation();
                            onRate(value === rating ? 0 : value);
                        }}
                    >
                        <Star width={14} height={14} className="shrink-0" style={filled ? { color: "#e9931c" } : { opacity: 0.2, color: "#fff" }} fill={filled ? "currentColor" : "none"} />
                    </button>
                );
            })}
        </span>
    );
}

// ===== 主组件（原版 145733 default 导出，modal surface） =====
export function CanvasGenerationHistoryModal({
    open,
    onClose,
    projects,
    currentProjectId,
    onLocate,
    onPreview,
    onDownload,
    onDelete,
    onAddToCanvas,
    onSaveToAsset,
    onBatchAddToCanvas,
}: {
    open: boolean;
    onClose: () => void;
    projects: CanvasProject[];
    currentProjectId: string;
    onLocate: (nodeId: string) => void;
    onPreview: (node: CanvasNodeData) => void;
    onDownload: (node: CanvasNodeData) => void;
    /** 018-6（boss 2026-10-04）：把该产出插入当前画布 */
    onAddToCanvas: (node: CanvasNodeData) => void;
    onDelete: (ids: Set<string>) => void;
    /** 批次 129：原版"保存到资产"按钮 → 接现有 saveNodeAsset 链路（可选） */
    onSaveToAsset?: (node: CanvasNodeData) => void;
    /** 批次 129：批量添加到画布（可选；缺省时逐个调 onAddToCanvas） */
    onBatchAddToCanvas?: (nodes: CanvasNodeData[]) => void;
}) {
    const isLight = useLightTheme();
    const [activeTab, setActiveTab] = useState<"image" | "video" | "audio">("image"); // eL
    const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc"); // tl
    const [onlyCurrentCanvas, setOnlyCurrentCanvas] = useState(false); // td
    const [ratingFilter, setRatingFilter] = useState<string | number>("all"); // tm
    const [batchMode, setBatchMode] = useState(false); // tf
    const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set()); // tg
    const [detailArtifact, setDetailArtifact] = useState<HistoryArtifact | null>(null); // e9/th（th 是选中态源，此处合并）
    const [previewIndex, setPreviewIndex] = useState<number | null>(null); // e3
    const [zoomIndex, setZoomIndex] = useState(2); // e5（J=[50,75,100,125,150] 下标，默认 2=100%）
    const [renderLimit, setRenderLimit] = useState(HISTORY_PAGE_SIZE);
    const [ratingMap, setRatingMap] = useState<Record<string, number>>({}); // 会话级评级（原版为服务端持久化）
    const [deleting, setDeleting] = useState(false); // tw（批量操作进行中）
    const [downloadPercent, setDownloadPercent] = useState<number | null>(null); // ta
    const [applying, setApplying] = useState(false); // aa
    const applyingRef = useRef(false); // an

    const listRef = useRef<HTMLDivElement>(null); // e1
    const selectedIdsRef = useRef(selectedIds);
    selectedIdsRef.current = selectedIds;
    const sentinelRef = useRef<HTMLDivElement>(null); // aN
    const { onPointerDown: marqueePointerDown, rubberStyle } = useHistoryMarqueeSelect({
        enabled: batchMode,
        containerRef: listRef,
        selectedIdsRef,
        setSelectedIds,
    });

    // ===== 数据层：本地 projects → artifacts（保留 047 只显示生成产出） =====
    const allArtifacts = useMemo<HistoryArtifact[]>(() => {
        if (!open) return [];
        const list: HistoryArtifact[] = [];
        projects.forEach((project) => {
            const fallbackTime = Date.parse(project.updatedAt || "") || Date.now();
            project.nodes.forEach((node) => {
                if (!node.metadata?.content) return;
                const kind = isCanvasImageNodeType(node.type) ? "image" : node.type === CanvasNodeType.Video ? "video" : node.type === CanvasNodeType.Audio ? "audio" : null;
                if (!kind) return;
                if (!isGeneratedOutput(node)) return;
                const meta = node.metadata as Record<string, unknown>;
                list.push({
                    artifactId: `${project.id}:${node.id}`,
                    nodeId: node.id,
                    projectId: project.id,
                    projectTitle: project.title,
                    mediaType: kind,
                    previewPath: node.metadata.content,
                    title: node.title || project.title,
                    createdAtMs: node.metadata.generatedAt || fallbackTime,
                    rating: ratingMap[node.metadata.content] ?? (typeof meta.rating === "number" ? meta.rating : undefined),
                    node,
                });
            });
        });
        return list;
    }, [open, projects, ratingMap]);

    // 原版 tn：按 previewPath 去重（在当前筛选集合内）
    const filteredArtifacts = useMemo(() => {
        let list = allArtifacts;
        if (onlyCurrentCanvas) list = list.filter((artifact) => artifact.projectId === currentProjectId);
        if (ratingFilter !== "all") list = list.filter((artifact) => getArtifactRating(artifact) === ratingFilter);
        return dedupeArtifactsByPreviewPath(list);
    }, [allArtifacts, onlyCurrentCanvas, currentProjectId, ratingFilter]);

    const tabArtifacts = useMemo(() => {
        const list = filteredArtifacts.filter((artifact) => artifact.mediaType === activeTab);
        list.sort((a, b) => (sortOrder === "desc" ? b.createdAtMs - a.createdAtMs : a.createdAtMs - b.createdAtMs));
        return list;
    }, [filteredArtifacts, activeTab, sortOrder]);

    // 原版 tO：tab 计数（按当前 scope + 评级筛选）
    const tabCounts = useMemo(
        () => ({
            image: filteredArtifacts.filter((a) => a.mediaType === "image").length,
            video: filteredArtifacts.filter((a) => a.mediaType === "video").length,
            audio: filteredArtifacts.filter((a) => a.mediaType === "audio").length,
        }),
        [filteredArtifacts],
    );

    const dateGroups = useMemo(() => groupArtifactsByDate(tabArtifacts), [tabArtifacts]);
    // 分批渲染（原版为服务端分页 + 哨兵触底，本地为分批切片 + 哨兵触底）
    const limitedDateGroups = useMemo(() => {
        let remaining = renderLimit;
        const result: Array<{ date: string; items: HistoryArtifact[] }> = [];
        for (const group of dateGroups) {
            if (remaining <= 0) break;
            const slice = group.items.slice(0, remaining);
            remaining -= slice.length;
            result.push({ date: group.date, items: slice });
        }
        return result;
    }, [dateGroups, renderLimit]);
    const renderedCount = limitedDateGroups.reduce((sum, group) => sum + group.items.length, 0);
    const hasMore = renderedCount < tabArtifacts.length;

    // 换筛选/排序/tab 回到第一批（原版各 handler 里重置分页）
    useEffect(() => {
        setRenderLimit(HISTORY_PAGE_SIZE);
    }, [activeTab, sortOrder, onlyCurrentCanvas, ratingFilter]);

    // Escape 关闭（原版：预览打开时不关）
    useEffect(() => {
        if (!open) return;
        const handler = (event: KeyboardEvent) => {
            if (event.key === "Escape" && previewIndex === null) onClose();
        };
        document.addEventListener("keydown", handler);
        return () => document.removeEventListener("keydown", handler);
    }, [open, previewIndex, onClose]);

    // 哨兵触底加载（原版 IntersectionObserver）
    useEffect(() => {
        const sentinel = sentinelRef.current;
        const container = listRef.current;
        if (!sentinel || !container || !hasMore) return;
        const observer = new IntersectionObserver(
            (entries) => {
                if (entries[0]?.isIntersecting) setRenderLimit((limit) => limit + HISTORY_PAGE_SIZE);
            },
            { root: container, threshold: 0.1 },
        );
        observer.observe(sentinel);
        return () => observer.disconnect();
    }, [hasMore, open]);

    const cardSize = Math.round(152 * (ZOOM_SCALE[ZOOM_STEPS[zoomIndex]] / 100)); // tR

    // ===== 回调（对应原版 t$/tq/tW/tZ/t2/t4/t5/t9/t7/…） =====
    const switchTab = useCallback(
        (next: "image" | "video" | "audio") => {
            if (next === activeTab) return;
            if (batchMode && selectedIds.size > 0) {
                AntdModal.confirm({
                    title: T.switchMediaTypeTitle,
                    content: T.switchMediaTypeMessage,
                    okText: T.ok,
                    cancelText: T.cancel,
                    onOk: () => {
                        setActiveTab(next);
                        setSelectedIds(new Set());
                        setBatchMode(false);
                    },
                });
                return;
            }
            setActiveTab(next);
            setSelectedIds(new Set());
        },
        [activeTab, batchMode, selectedIds.size],
    );

    const applyScopeAndRating = useCallback((onlyCurrent: boolean, rating: string | number) => {
        setOnlyCurrentCanvas(onlyCurrent);
        setRatingFilter(rating);
        setSelectedIds(new Set());
    }, []);

    const toggleSortOrder = useCallback(() => {
        setSortOrder((prev) => (prev === "desc" ? "asc" : "desc"));
    }, []);

    const toggleBatchMode = useCallback(() => {
        setBatchMode((prev) => {
            if (prev) setSelectedIds(new Set());
            return !prev;
        });
    }, []);

    const toggleSelected = useCallback((id: string) => {
        setSelectedIds((prev) => {
            const next = new Set(prev);
            if (next.has(id)) next.delete(id);
            else next.add(id);
            return next;
        });
    }, []);

    const setGroupSelection = useCallback((items: HistoryArtifact[]) => {
        const ids = items.map((item) => item.artifactId).filter(Boolean);
        const allSelected = ids.length > 0 && ids.every((id) => selectedIds.has(id));
        setSelectedIds((prev) => {
            const next = new Set(prev);
            if (allSelected) {
                for (const id of ids) next.delete(id);
            } else {
                for (const id of ids) next.add(id);
            }
            return next;
        });
    }, [selectedIds]);

    const selectableIds = useMemo(() => tabArtifacts.map((a) => a.artifactId).filter(Boolean), [tabArtifacts]);
    const allSelected = selectableIds.length > 0 && selectableIds.every((id) => selectedIds.has(id));

    // 评级（会话内存，卡片/详情/预览/批量四处同步——对应原版 tJ/tQ + subscribeArtifactRatingSync）
    const rateArtifacts = useCallback((artifacts: HistoryArtifact[], rating: number) => {
        setRatingMap((prev) => {
            const next = { ...prev };
            for (const artifact of artifacts) {
                if (artifact.previewPath?.trim()) next[artifact.previewPath] = rating;
            }
            return next;
        });
    }, []);

    // 单个删除（原版 aw：confirm → 服务端 → 本地移除）
    const handleDeleteArtifact = useCallback(
        (artifact: HistoryArtifact) => {
            if (!artifact.artifactId) return;
            const [projectId, nodeId] = artifact.artifactId.split(":");
            if (projectId !== currentProjectId) {
                antdMessage.warning("仅本画布的产出可在此删除");
                return;
            }
            AntdModal.confirm({
                title: T.deleteRecordTitle,
                content: T.deleteConfirmIrreversible,
                okText: T.delete,
                okButtonProps: { danger: true },
                cancelText: T.cancel,
                onOk: () => {
                    onDelete(new Set([nodeId]));
                    setDetailArtifact((prev) => (prev?.artifactId === artifact.artifactId ? null : prev));
                    setPreviewIndex(null);
                    antdMessage.success(T.deleted);
                },
            });
        },
        [currentProjectId, onDelete],
    );

    // 批量删除（原版 t9）
    const handleDeleteSelected = useCallback(() => {
        if (selectedIds.size === 0 || deleting) return;
        AntdModal.confirm({
            title: T.batchDeleteTitle,
            content: T.batchDeleteConfirm(selectedIds.size),
            okText: T.delete,
            okButtonProps: { danger: true },
            cancelText: T.cancel,
            onOk: () => {
                setDeleting(true);
                try {
                    const nodeIds = new Set<string>();
                    selectedIds.forEach((key) => {
                        const [projectId, nodeId] = key.split(":");
                        if (projectId === currentProjectId) nodeIds.add(nodeId);
                    });
                    const count = selectedIds.size;
                    if (nodeIds.size) onDelete(nodeIds);
                    setSelectedIds(new Set());
                    antdMessage.success(T.deletedCount(count));
                } finally {
                    setDeleting(false);
                }
            },
        });
    }, [selectedIds, deleting, currentProjectId, onDelete]);

    // 批量下载（原版 t7：>300 禁用；走统一 zip/逐个下载，进度条内嵌按钮）
    const overLimit = selectedIds.size > MAX_BATCH_DOWNLOAD;
    const handleDownloadSelected = useCallback(() => {
        if (selectedIds.size === 0 || overLimit || deleting) return;
        const items: BatchDownloadItem[] = [];
        selectedIds.forEach((key) => {
            const [projectId, nodeId] = key.split(":");
            const node = projects.find((project) => project.id === projectId)?.nodes.find((item) => item.id === nodeId);
            if (!node?.metadata?.content) return;
            items.push({
                id: key,
                label: `canvas-${node.type}-${node.id}.${node.type === CanvasNodeType.Video ? "mp4" : node.type === CanvasNodeType.Audio ? "mp3" : "png"}`,
                url: node.metadata.content,
            });
        });
        if (!items.length) return;
        setDeleting(true);
        setDownloadPercent(0);
        antdMessage.info(T.packagingDownload(items.length));
        void downloadBatchItems(items, "history").then(
            () => {
                antdMessage.success(T.downloadStarted(items.length));
            },
            () => {
                antdMessage.error(T.downloadFailedRetry);
            },
        ).finally(() => {
            setDeleting(false);
            setDownloadPercent(null);
        });
    }, [selectedIds, overLimit, deleting, projects]);

    // 批量评级（原版 tQ：菜单 1-5 + 取消评级）
    const handleRateSelected = useCallback(
        (rating: number) => {
            if (selectedIds.size === 0) return;
            const targets = tabArtifacts.filter((artifact) => selectedIds.has(artifact.artifactId) && artifact.previewPath?.trim());
            if (!targets.length) return;
            rateArtifacts(targets, rating);
            antdMessage.success(T.ratingApplied(targets.length));
        },
        [selectedIds, tabArtifacts, rateArtifacts],
    );

    // 保存到资产（原版 t1 → stash 弹窗；本地直接逐个走 saveNodeAsset）
    const handleSaveSelectedToAsset = useCallback(() => {
        if (selectedIds.size === 0 || deleting) return;
        const nodes = tabArtifacts.filter((artifact) => selectedIds.has(artifact.artifactId)).map((artifact) => artifact.node);
        if (!nodes.length || !onSaveToAsset) return;
        nodes.forEach((node) => onSaveToAsset(node));
    }, [selectedIds, tabArtifacts, deleting, onSaveToAsset]);

    // 批量添加到画布（原版 al：I?.(e, sizes)；本地缺省逐个 onAddToCanvas）
    const handleApplySelected = useCallback(() => {
        if (selectedIds.size === 0 || deleting || applyingRef.current) return;
        const nodes = tabArtifacts.filter((artifact) => selectedIds.has(artifact.artifactId)).map((artifact) => artifact.node);
        if (!nodes.length) return;
        applyingRef.current = true;
        setApplying(true);
        try {
            if (onBatchAddToCanvas) onBatchAddToCanvas(nodes);
            else nodes.forEach((node) => onAddToCanvas(node));
        } finally {
            applyingRef.current = false;
            setApplying(false);
        }
    }, [selectedIds, tabArtifacts, deleting, onBatchAddToCanvas, onAddToCanvas]);

    const applyOverLimit = selectedIds.size > BATCH_APPLY_MAX[activeTab];

    const findNode = useCallback((artifact: HistoryArtifact): CanvasNodeData | null => artifact.node ?? null, []);

    // 详情面板动作
    const handleDetailApply = useCallback((artifact: HistoryArtifact) => {
        if (artifact.projectId !== currentProjectId) return;
        onAddToCanvas(artifact.node);
    }, [currentProjectId, onAddToCanvas]);

    const handleDetailDownload = useCallback(
        (artifact: HistoryArtifact) => {
            onDownload(artifact.node);
        },
        [onDownload],
    );

    const handleDetailSaveToAsset = useCallback(
        (artifact: HistoryArtifact) => {
            onSaveToAsset?.(artifact.node);
        },
        [onSaveToAsset],
    );

    const handleDetailPreviewCover = useCallback(
        (artifact: HistoryArtifact) => {
            const index = tabArtifacts.indexOf(artifact);
            setPreviewIndex(index >= 0 ? index : null);
        },
        [tabArtifacts],
    );

    const handleCardPreview = useCallback((artifact: HistoryArtifact) => {
        setDetailArtifact(artifact);
    }, []);

    const enterBatchSelect = useCallback((artifact: HistoryArtifact) => {
        if (artifact.artifactId) {
            setBatchMode(true);
            setSelectedIds(new Set([artifact.artifactId]));
        }
    }, []);

    const batchApplyMaxHint = T.batchApplyMax(activeTab);

    if (!open) return null;

    // ===== 渲染（对应原版 eu 外壳 → aC 结构） =====
    return createPortal(
        <>
            {/* 背景遮罩（eu：light bg-black/40 / dark bg-black/60） */}
            <div className={cn("fixed inset-0", isLight ? "bg-black/40" : "bg-black/60")} style={{ zIndex: HISTORY_BACKDROP_Z_INDEX }} onClick={onClose} />
            {/* 弹窗主体：h-[calc(100vh-160px)] w-[min(90vw,1600px)] rounded-[24px] */}
            <div className="pointer-events-none fixed inset-0 flex items-center justify-center" style={{ zIndex: HISTORY_DIALOG_Z_INDEX }}>
                <div
                    className="pointer-events-auto flex h-[calc(100vh-160px)] w-[min(90vw,1600px)] max-w-[min(90vw,1600px)] flex-col overflow-hidden rounded-[24px]"
                    style={{ backgroundColor: "var(--canvas-controls-bg)", border: "0.5px solid var(--canvas-controls-border)", backdropFilter: "blur(24px)", boxShadow: "var(--canvas-shadow-menu)" }}
                    onClick={(event) => event.stopPropagation()}
                >
                    {/* 顶栏：标题 + 缩放控件 + 关闭 */}
                    <div className="flex shrink-0 flex-wrap items-center justify-between gap-4 px-6 pb-5 pt-6">
                        <div className="flex min-w-0 items-center gap-6">
                            <span className="text-canvas-controls-text truncate text-[18px] font-[500] leading-[26px]">{T.generationHistory}</span>
                        </div>
                        <div className="flex items-center gap-4">
                            <div className={cn("flex items-center gap-2 rounded-lg p-2", isLight ? "bg-black/[0.04]" : "bg-white/[0.06]")}>
                                <LayoutGrid width={16} height={16} className="text-canvas-controls-text shrink-0" />
                                <input
                                    type="range"
                                    min={0}
                                    max={ZOOM_STEPS.length - 1}
                                    step={1}
                                    value={ZOOM_STEPS.length - 1 - zoomIndex}
                                    onChange={(event) => {
                                        const inverted = ZOOM_STEPS.length - 1 - Number(event.target.value);
                                        setZoomIndex(Math.min(ZOOM_STEPS.length - 1, Math.max(0, inverted)));
                                    }}
                                    className="h-3 w-[100px] cursor-pointer appearance-none bg-transparent [&::-moz-range-thumb]:size-[9px] [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:border-none [&::-moz-range-thumb]:bg-[radial-gradient(circle,rgba(0,0,0,0.9)_0.65px,white_0.65px)] [&::-moz-range-thumb]:shadow-[0_0_2px_rgba(0,0,0,0.35)] [&::-moz-range-track]:h-[2px] [&::-moz-range-track]:rounded-full [&::-moz-range-track]:bg-[#8f8f8f] [&::-webkit-slider-runnable-track]:h-[2px] [&::-webkit-slider-runnable-track]:rounded-full [&::-webkit-slider-runnable-track]:bg-[#8f8f8f] [&::-webkit-slider-thumb]:mt-[-3.5px] [&::-webkit-slider-thumb]:size-[9px] [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-[radial-gradient(circle,rgba(0,0,0,0.9)_0.65px,white_0.65px)] [&::-webkit-slider-thumb]:shadow-[0_0_2px_rgba(0,0,0,0.35)]"
                                />
                                <Grid3x3 width={16} height={16} className="text-canvas-controls-text shrink-0" />
                            </div>
                            <button type="button" onClick={onClose} className="text-fg-default flex size-7 cursor-pointer items-center justify-center rounded-lg hover:bg-canvas-controls-hover">
                                <X width={16} height={16} />
                            </button>
                        </div>
                    </div>
                    <div className="h-px shrink-0 bg-canvas-controls-border" />
                    <div className="flex min-h-0 flex-1">
                        <div className="flex min-w-0 flex-1 flex-col">
                            {/* 工具行：范围 + 媒体 tabs | 评级筛选 + 排序 + 批量操作 */}
                            <div className="flex shrink-0 flex-wrap items-center justify-between gap-3 px-6 py-3">
                                <div className="flex min-w-0 flex-wrap items-center gap-4">
                                    <div role="radiogroup" className={cn("flex shrink-0 items-center gap-0.5 rounded-xl p-0.5", isLight ? "bg-black/[0.04]" : "bg-white/[0.06]")}>
                                        {SCOPE_OPTIONS.map((option) => {
                                            const selected = onlyCurrentCanvas === option.onlyCurrent;
                                            return (
                                                <button
                                                    key={option.label}
                                                    type="button"
                                                    role="radio"
                                                    aria-checked={selected}
                                                    onClick={() => {
                                                        if (!selected) applyScopeAndRating(option.onlyCurrent, ratingFilter);
                                                    }}
                                                    disabled={option.onlyCurrent && !currentProjectId}
                                                    className={cn(
                                                        "relative flex h-8 shrink-0 cursor-pointer items-center justify-center rounded-[10px] border-none bg-transparent px-3 text-[14px] leading-[22px] transition-colors disabled:cursor-default disabled:opacity-40",
                                                        selected ? (isLight ? "text-black/90" : "text-white") : isLight ? "text-black/55 hover:text-black/80" : "text-white/60 hover:text-white/85",
                                                    )}
                                                >
                                                    {selected ? (
                                                        <motion.span
                                                            layoutId="history-canvas-scope-indicator"
                                                            transition={DETAIL_PANEL_TRANSITION}
                                                            className={cn("absolute inset-0 rounded-[10px] border border-solid", isLight ? "border-black/[0.07] bg-white" : "border-white/[0.08] bg-[#161616]")}
                                                        />
                                                    ) : null}
                                                    <span className="relative">{option.label}</span>
                                                </button>
                                            );
                                        })}
                                    </div>
                                    <div className="h-4 w-px bg-canvas-controls-border" />
                                    <div className="flex items-center gap-4 pl-1">
                                        {MEDIA_TABS.map((tab) => {
                                            const active = activeTab === tab.value;
                                            const count = tabCounts[tab.value];
                                            return (
                                                <button
                                                    key={tab.value}
                                                    type="button"
                                                    onClick={() => switchTab(tab.value)}
                                                    className={cn(
                                                        "text-canvas-controls-text flex h-8 shrink-0 cursor-pointer items-center gap-1.5 border-none bg-transparent text-[13px] transition-colors",
                                                        active ? "font-medium opacity-100" : "opacity-40 hover:opacity-60",
                                                    )}
                                                >
                                                    {tab.label}
                                                    {count != null ? (
                                                        <span className={cn("flex h-4 min-w-4 items-center justify-center rounded px-1 text-[11px] font-normal", isLight ? "bg-black/[0.05]" : "bg-white/10")}>{count}</span>
                                                    ) : null}
                                                </button>
                                            );
                                        })}
                                    </div>
                                </div>
                                {/* 右组（原版 aI）：评级筛选 | 排序 | 批量操作 */}
                                <div className="flex items-center gap-2">
                                    <RatingFilterPopover value={ratingFilter} onChange={(value) => applyScopeAndRating(onlyCurrentCanvas, value)} isLight={isLight} />
                                    <div className="h-4 w-px bg-canvas-controls-border" />
                                    <button
                                        type="button"
                                        onClick={toggleSortOrder}
                                        className="text-fg-default flex h-8 cursor-pointer items-center gap-1 rounded-lg border-none bg-transparent px-2 text-[13px] hover:bg-canvas-controls-hover"
                                        title={sortOrder === "desc" ? T.sortNewestFirst : T.sortOldestFirst}
                                    >
                                        <ArrowDownUp width={14} height={14} className="transition-transform duration-200" style={{ transform: sortOrder === "asc" ? "scaleY(-1)" : "none" }} />
                                        {sortOrder === "desc" ? T.timeDesc : T.timeAsc}
                                    </button>
                                    <div className="h-4 w-px bg-canvas-controls-border" />
                                    <Tooltip title={T.marqueeTip} placement="top">
                                        <button
                                            type="button"
                                            onClick={toggleBatchMode}
                                            disabled={deleting}
                                            className={cn(
                                                "text-fg-default flex h-8 cursor-pointer items-center gap-1 rounded-lg border-none px-2 text-[13px] transition-colors disabled:cursor-not-allowed disabled:opacity-40",
                                                batchMode ? (isLight ? "bg-black/[0.08] opacity-100" : "bg-white/[0.12] opacity-100") : "bg-transparent hover:bg-canvas-controls-hover",
                                            )}
                                        >
                                            <List width={16} height={16} />
                                            {T.batchOperation}
                                        </button>
                                    </Tooltip>
                                </div>
                            </div>
                            {/* 滚动列表（原版 UnifiedScrollArea → 本地 overflow 容器，padding 0 40px 24px） */}
                            <div
                                ref={listRef}
                                className="thin-scrollbar min-h-0 flex-1 overflow-y-auto overflow-x-hidden"
                                style={{ padding: "0 40px 24px" }}
                                onPointerDown={batchMode ? marqueePointerDown : undefined}
                            >
                                {tabArtifacts.length === 0 ? (
                                    <div className="text-fg-muted flex h-60 items-center justify-center text-sm">{T.noHistoryRecords}</div>
                                ) : (
                                    <>
                                        {limitedDateGroups.map((group) => {
                                            const groupIds = group.items.map((item) => item.artifactId).filter(Boolean);
                                            const selectedCount = groupIds.reduce((sum, id) => sum + (selectedIds.has(id) ? 1 : 0), 0);
                                            const groupAllSelected = group.items.length > 0 && selectedCount === group.items.length;
                                            return (
                                                <div key={group.date} className="mb-6">
                                                    <div className="mb-3 flex items-center gap-2" data-no-marquee>
                                                        {batchMode ? <BatchCheckbox checked={groupAllSelected} indeterminate={!groupAllSelected && selectedCount > 0} onChange={() => setGroupSelection(group.items)} isLight={isLight} /> : null}
                                                        <h4 className="text-canvas-controls-text mb-0 text-sm font-medium">{group.date}</h4>
                                                    </div>
                                                    <div className="flex flex-wrap gap-3">
                                                        {group.items.map((artifact, index) => (
                                                            <ArtifactCard
                                                                key={artifact.artifactId || `${group.date}-${index}`}
                                                                artifact={artifact}
                                                                size={cardSize}
                                                                batchMode={batchMode}
                                                                selected={selectedIds.has(artifact.artifactId)}
                                                                active={false}
                                                                dimmed={false}
                                                                onToggleSelect={toggleSelected}
                                                                onApply={batchMode ? undefined : (item) => {
                                                                    if (item.projectId !== currentProjectId) {
                                                                        antdMessage.warning("仅本画布的产出可添加");
                                                                        return;
                                                                    }
                                                                    onAddToCanvas(item.node);
                                                                }}
                                                                onPreview={batchMode ? undefined : handleCardPreview}
                                                                onDelete={batchMode ? undefined : handleDeleteArtifact}
                                                                onDownload={batchMode ? undefined : handleDetailDownload}
                                                                onEnterBatchSelect={batchMode ? undefined : enterBatchSelect}
                                                                isLight={isLight}
                                                            />
                                                        ))}
                                                    </div>
                                                </div>
                                            );
                                        })}
                                        {hasMore ? (
                                            <div ref={sentinelRef} aria-hidden className="h-8" />
                                        ) : (
                                            <div className="py-4 text-center text-xs text-fg-muted opacity-60">没有更多了</div>
                                        )}
                                    </>
                                )}
                            </div>
                            {/* 批量操作栏（原版 ep + tf 场景） */}
                            {batchMode ? (
                                <>
                                    <div className="h-px shrink-0 bg-canvas-controls-border" />
                                    <div className="flex shrink-0 flex-wrap items-center justify-between gap-3 p-6">
                                        <div className="text-fg-muted flex shrink-0 items-center gap-1.5 text-[13px]">
                                            <Images width={20} height={20} />
                                            {T.selectedCount(selectedIds.size)}
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <button
                                                type="button"
                                                onClick={handleDeleteSelected}
                                                disabled={selectedIds.size === 0 || deleting}
                                                aria-label={T.delete}
                                                className="flex h-9 min-w-20 cursor-pointer items-center justify-center rounded-[10px] border-none px-3 text-sm text-[#e74c3c] transition-opacity hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-40"
                                                style={{ background: "rgba(231,76,60,0.12)" }}
                                            >
                                                <Trash2 width={18} height={18} className="mr-0.5" />
                                                <span className="px-1">{T.delete}</span>
                                            </button>
                                            <Tooltip title={downloadPercent != null ? "打包中" : T.downloadMaxHint(MAX_BATCH_DOWNLOAD)} open={downloadPercent == null && selectedIds.size > 50 && !overLimit ? undefined : false}>
                                                <div className="inline-flex" style={overLimit ? { cursor: "not-allowed" } : undefined}>
                                                    <button
                                                        type="button"
                                                        onClick={handleDownloadSelected}
                                                        disabled={selectedIds.size === 0 || deleting || overLimit}
                                                        className={cn(
                                                            "text-canvas-controls-text relative flex h-9 min-w-20 cursor-pointer items-center justify-center overflow-hidden rounded-[10px] border-none px-3 text-sm transition-colors disabled:pointer-events-none disabled:opacity-40",
                                                            isLight ? "bg-black/[0.04] hover:bg-black/[0.06]" : "bg-white/[0.06] hover:bg-white/[0.08]",
                                                        )}
                                                    >
                                                        {downloadPercent != null ? (
                                                            <span aria-hidden className={cn("absolute inset-y-0 left-0 transition-[width] duration-200", isLight ? "bg-black/[0.08]" : "bg-white/[0.08]")} style={{ width: `${downloadPercent}%` }} />
                                                        ) : null}
                                                        {downloadPercent != null ? <Loader2 width={14} height={14} className="relative mx-0.5 animate-spin" /> : <Download width={18} height={18} className="relative mr-0.5" />}
                                                        <span className="relative px-1">{downloadPercent != null ? `${downloadPercent}%` : T.download}</span>
                                                    </button>
                                                </div>
                                            </Tooltip>
                                            <Dropdown
                                                menu={{
                                                    items: [
                                                        ...RATING_VALUES.map((value) => ({
                                                            key: String(value),
                                                            label: (
                                                                <span className="flex items-center gap-1">
                                                                    <span className="tabular-nums">{value}</span>
                                                                    <Star width={12} height={12} className="shrink-0" style={{ color: "var(--nt-accent-amber)" }} fill="currentColor" />
                                                                </span>
                                                            ),
                                                        })),
                                                        { key: "clear", label: T.ratingClear },
                                                    ],
                                                    onClick: ({ key }) => handleRateSelected(key === "clear" ? 0 : Number(key)),
                                                }}
                                                placement="topRight" /* 原版 mantine topEnd → antd 等价 topRight */
                                                trigger={["click"]}
                                            >
                                                <button
                                                    type="button"
                                                    disabled={selectedIds.size === 0 || deleting}
                                                    aria-label={T.ratingButton}
                                                    className={cn(
                                                        "text-canvas-controls-text flex h-9 min-w-20 cursor-pointer items-center justify-center rounded-[10px] border-none px-3 text-sm transition-colors disabled:cursor-not-allowed disabled:opacity-40",
                                                        isLight ? "bg-black/[0.04] hover:bg-black/[0.06]" : "bg-white/[0.06] hover:bg-white/[0.08]",
                                                    )}
                                                >
                                                    <Star width={18} height={18} className="mr-0.5" />
                                                    <span className="px-1">{T.ratingButton}</span>
                                                </button>
                                            </Dropdown>
                                            {onSaveToAsset ? (
                                                <button
                                                    type="button"
                                                    onClick={handleSaveSelectedToAsset}
                                                    disabled={selectedIds.size === 0 || deleting}
                                                    className={cn(
                                                        "text-canvas-controls-text flex h-9 min-w-20 cursor-pointer items-center justify-center rounded-[10px] border-none px-3 text-sm transition-colors disabled:cursor-not-allowed disabled:opacity-40",
                                                        isLight ? "bg-black/[0.04] hover:bg-black/[0.06]" : "bg-white/[0.06] hover:bg-white/[0.08]",
                                                    )}
                                                >
                                                    <FolderInput width={18} height={18} className="mr-0.5 shrink-0" />
                                                    <span className="px-1 text-[13px]">{T.saveToAsset}</span>
                                                </button>
                                            ) : null}
                                            <Tooltip title={batchApplyMaxHint} open={applyOverLimit ? undefined : false} placement="top">
                                                <div className="inline-flex" style={applyOverLimit ? { cursor: "not-allowed" } : undefined}>
                                                    <button
                                                        type="button"
                                                        onClick={() => void handleApplySelected()}
                                                        disabled={selectedIds.size === 0 || deleting || applying || applyOverLimit}
                                                        aria-busy={applying}
                                                        className={cn(
                                                            "flex h-9 min-w-20 cursor-pointer items-center justify-center rounded-[10px] border-none px-3 text-sm transition-opacity hover:opacity-90 disabled:pointer-events-none disabled:opacity-40",
                                                            isLight ? "bg-[#2c2c2c] text-white" : "bg-white text-black",
                                                        )}
                                                    >
                                                        {applying ? <Loader2 width={16} height={16} className="mr-0.5 animate-spin" /> : <Plus width={16} height={16} className="mr-0.5 shrink-0" />}
                                                        <span className="px-1 text-[13px]">{T.addToCanvas}</span>
                                                    </button>
                                                </div>
                                            </Tooltip>
                                        </div>
                                    </div>
                                </>
                            ) : null}
                        </div>
                        {/* 右侧详情面板（原版 AnimatePresence motion.div width 300 展开） */}
                        <AnimatePresence>
                            {detailArtifact ? (
                                <motion.div
                                    key="history-detail"
                                    initial={{ width: 0, opacity: 0 }}
                                    animate={{ width: 300, opacity: 1 }}
                                    exit={{ width: 0, opacity: 0 }}
                                    transition={DETAIL_PANEL_TRANSITION}
                                    className="relative h-full shrink-0 overflow-hidden"
                                >
                                    <HistoryDetailPanel
                                        className="absolute inset-y-0 right-0"
                                        artifact={filteredArtifacts.find((a) => a.artifactId === detailArtifact.artifactId) ?? detailArtifact}
                                        creatorName={detailArtifact.projectTitle}
                                        onClose={() => setDetailArtifact(null)}
                                        onPreviewCover={handleDetailPreviewCover}
                                        onApply={handleDetailApply}
                                        onSaveToAsset={onSaveToAsset ? handleDetailSaveToAsset : undefined}
                                        onDownload={handleDetailDownload}
                                        onDelete={handleDeleteArtifact}
                                        onRate={(artifact, rating) => rateArtifacts([artifact], rating)}
                                        isLight={isLight}
                                    />
                                </motion.div>
                            ) : null}
                        </AnimatePresence>
                    </div>
                </div>
            </div>
            {/* 全屏预览（原版 ed） */}
            {previewIndex != null && tabArtifacts[previewIndex] ? (
                <HistoryPreviewOverlay
                    artifacts={tabArtifacts}
                    currentIndex={previewIndex}
                    onNavigate={setPreviewIndex}
                    onClose={() => setPreviewIndex(null)}
                    onRate={(artifact, rating) => rateArtifacts([artifact], rating)}
                    onDownload={handleDetailDownload}
                />
            ) : null}
            {/* 框选橡皮筋（原版 tI） */}
            {rubberStyle ? <div aria-hidden style={rubberStyle} /> : null}
        </>,
        document.body,
    );
}

// 项目主题（原版 useCanvasThemeStore light 判定）
function useLightTheme(): boolean {
    const [isLight, setIsLight] = useState(false);
    useEffect(() => {
        const probe = () => setIsLight(document.documentElement.classList.contains("light"));
        probe();
        const observer = new MutationObserver(probe);
        observer.observe(document.documentElement, { attributes: true, attributeFilter: ["class"] });
        return () => observer.disconnect();
    }, []);
    return isLight;
}
