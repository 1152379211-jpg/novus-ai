"use client";

import { Button, Modal } from "antd";

import { deleteCanvasProjects, deleteCanvasTasks } from "@/services/api/canvas-tasks";
import { useAssetStore } from "@/stores/use-asset-store";
import { useCanvasStore } from "../stores/use-canvas-store";
import { useCanvasUiStore } from "../stores/use-canvas-ui-store";

export function CanvasDeleteProjectsDialog() {
    const ids = useCanvasUiStore((state) => state.deleteProjectIds);
    const setDeleteIds = useCanvasUiStore((state) => state.setDeleteProjectIds);
    const removeSelectedIds = useCanvasUiStore((state) => state.removeSelectedProjectIds);
    const deleteProjects = useCanvasStore((state) => state.deleteProjects);
    const cleanupImages = useAssetStore((state) => state.cleanupImages);
    const confirm = () => {
        void Promise.all([
            deleteCanvasProjects(ids),
            Promise.all(ids.map((id) => deleteCanvasTasks(id))),
        ]).catch(() => undefined);
        deleteProjects(ids);
        cleanupImages();
        removeSelectedIds(ids);
        setDeleteIds([]);
    };

    return (
        <Modal
            title="移入回收站？"
            open={ids.length > 0}
            centered
            onCancel={() => setDeleteIds([])}
            footer={
                <>
                    <Button onClick={() => setDeleteIds([])}>取消</Button>
                    <Button danger type="primary" onClick={confirm}>
                        移入回收站
                    </Button>
                </>
            }
        >
            <p className="text-sm text-stone-500">将 {ids.length} 个画布移入回收站，节点和连线会完整保留，随时可以从回收站还原。</p>
        </Modal>
    );
}
