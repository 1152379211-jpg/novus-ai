"use client";

// 任务rDjmof：「旋转与镜像」变换工具条（样式对齐 LibTV 截图：X/标题/角度/重置/水平镜像/垂直镜像/保存），
// 浮在变换目标节点上方；变换实时反映在节点上（CSS transform 预览），保存时落像素。

import { RotateCcw, RotateCw, Undo2, X } from "lucide-react";

const BAR_CLASS = "border-hair bg-panel-background border-canvas-controls-border flex items-center gap-1.5 rounded-xl px-2 py-1.5";
const BTN_CLASS = "flex h-8 items-center gap-1.5 rounded-lg px-2 text-[13px] text-fg-default transition hover:bg-white/10";
const ICON_BTN_CLASS = "grid size-8 place-items-center rounded-lg text-fg-default transition hover:bg-white/10";
const SAVE_BTN_CLASS = "ml-1 flex h-8 items-center rounded-lg bg-white px-3 text-[13px] font-medium text-black transition hover:opacity-90";

export type NodeTransformState = { angle: number; flipH: boolean; flipV: boolean };

export function transformToCss(state: NodeTransformState) {
    const parts: string[] = [];
    if (state.angle) parts.push(`rotate(${state.angle}deg)`);
    if (state.flipH) parts.push("scaleX(-1)");
    if (state.flipV) parts.push("scaleY(-1)");
    return parts.join(" ");
}

export function CanvasNodeTransformBar({
    state,
    onStateChange,
    onSave,
    onClose,
}: {
    state: NodeTransformState;
    onStateChange: (next: NodeTransformState) => void;
    onSave: () => void;
    onClose: () => void;
}) {
    return (
        <div className={BAR_CLASS} onPointerDown={(event) => event.stopPropagation()} onMouseDown={(event) => event.stopPropagation()}>
            <button type="button" className={ICON_BTN_CLASS} onClick={onClose} aria-label="关闭（放弃变换）" title="关闭（放弃变换）">
                <X className="size-4" />
            </button>
            <span className="pr-1 text-[13px] font-medium">旋转与镜像</span>
            <span className="mx-0.5 h-6 w-px bg-[var(--canvas-controls-border)]" />
            <span className={BTN_CLASS} title="旋转角度（可任意填写，正=顺时针）">
                <svg width="15" height="15" viewBox="0 0 16 16" fill="none" aria-hidden="true">
                    <path d="M13.3 8a5.3 5.3 0 1 1-1.55-3.75" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
                    <path d="M13.5 1.8v2.9h-2.9" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                <input
                    type="number"
                    min={-360}
                    max={360}
                    value={state.angle}
                    onChange={(event) => onStateChange({ ...state, angle: Math.max(-360, Math.min(360, Math.round(Number(event.target.value) || 0))) })}
                    className="w-12 bg-transparent text-right outline-none [appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none"
                    aria-label="旋转角度"
                />
                <span className="opacity-60">°</span>
            </span>
            {/* boss 2026-10-07：逆时针在前面，顺时针在后面（原顺序反了） */}
            <button type="button" className={ICON_BTN_CLASS} onClick={() => onStateChange({ ...state, angle: ((state.angle - 90 + 180) % 360) - 180 })} aria-label="逆时针 90°" title="逆时针 90°">
                <RotateCcw className="size-4" />
            </button>
            <button type="button" className={ICON_BTN_CLASS} onClick={() => onStateChange({ ...state, angle: ((state.angle + 90 + 180) % 360) - 180 })} aria-label="顺时针 90°" title="顺时针 90°">
                <RotateCw className="size-4" />
            </button>
            <button type="button" className={ICON_BTN_CLASS} onClick={() => onStateChange({ angle: 0, flipH: false, flipV: false })} aria-label="重置" title="重置">
                <Undo2 className="size-4" />
            </button>
            <span className="mx-0.5 h-6 w-px bg-[var(--canvas-controls-border)]" />
            <button type="button" className={ICON_BTN_CLASS + (state.flipH ? " bg-white/15" : "")} onClick={() => onStateChange({ ...state, flipH: !state.flipH })} aria-label="水平镜像" title="水平镜像">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
                    <path d="M8 1.5v13" stroke="currentColor" strokeWidth="1.4" strokeDasharray="2 1.6" />
                    <path d="M5.8 4 2 8l3.8 4V4ZM10.2 4 14 8l-3.8 4V4Z" stroke="currentColor" strokeWidth="1.3" strokeLinejoin="round" />
                </svg>
            </button>
            <button type="button" className={ICON_BTN_CLASS + (state.flipV ? " bg-white/15" : "")} onClick={() => onStateChange({ ...state, flipV: !state.flipV })} aria-label="垂直镜像" title="垂直镜像">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
                    <path d="M1.5 8h13" stroke="currentColor" strokeWidth="1.4" strokeDasharray="2 1.6" />
                    <path d="M4 5.8 8 2l4 3.8H4ZM4 10.2 8 14l4-3.8H4Z" stroke="currentColor" strokeWidth="1.3" strokeLinejoin="round" />
                </svg>
            </button>
            {/* boss 2026-10-07：按钮文案=确定；文字色用内联样式（text-black 类曾被压掉显示成纯白块） */}
            <button type="button" className={SAVE_BTN_CLASS} style={{ color: "#141414" }} onClick={onSave}>确定</button>
        </div>
    );
}
