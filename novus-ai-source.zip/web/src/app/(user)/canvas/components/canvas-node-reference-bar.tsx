"use client";

import { useState } from "react";
import { FileText, Image as ImageIcon, Mountain, Music2, Package, Plus, Shapes, Shirt, UserRound, Video, X } from "lucide-react";
import { message, Popover } from "antd";

import { canvasThemes } from "@/lib/canvas-theme";
import { useThemeStore } from "@/stores/use-theme-store";
import { buildAllCanvasResourceReferences, type CanvasResourceReference } from "../utils/canvas-resource-references";
import type { CanvasNodeData } from "../types";

// 030（boss 2026-10-05）：五个分类库按钮 —— 点开「我的资产」对应分类弹窗，选中的素材直接上画布并连线为参考
const CATEGORY_LIBRARIES = [
    { label: "角色库", category: "character", icon: UserRound },
    { label: "场景库", category: "scene", icon: Mountain },
    { label: "服装库", category: "clothing", icon: Shirt },
    { label: "道具库", category: "prop", icon: Package },
    { label: "其他库", category: "other", icon: Shapes },
];

export function CanvasNodeReferenceBar({ nodeId, connectedNodes, onDisconnect, onReorder, onStartSelection, onOpenCategoryLibrary }: { nodeId: string; connectedNodes: CanvasNodeData[]; onDisconnect?: (fromNodeId: string, toNodeId: string) => void; onReorder?: (orderedFromNodeIds: string[]) => void; onStartSelection?: (nodeId: string) => void; onOpenCategoryLibrary?: (nodeId: string, category: string) => void }) {
    const theme = canvasThemes[useThemeStore((state) => state.theme)];
    const [dragNodeId, setDragNodeId] = useState<string | null>(null);
    const references = buildAllCanvasResourceReferences(connectedNodes);
    const handleDropOn = (targetNodeId: string) => {
        if (!dragNodeId || dragNodeId === targetNodeId) return;
        const ids = references.map((reference) => reference.nodeId);
        const from = ids.indexOf(dragNodeId);
        const to = ids.indexOf(targetNodeId);
        setDragNodeId(null);
        if (from < 0 || to < 0) return;
        ids.splice(to, 0, ids.splice(from, 1)[0]);
        // 参考顺序 = 连线顺序，直接重排该节点的连线即可让生成输入顺序跟着变
        onReorder?.(ids);
    };
    return (
        <div className="flex min-w-0 flex-col gap-1">
            <div data-generator-action-chips="" className="canvas-prompt-bar-chips thin-scrollbar flex min-w-0 flex-wrap items-center gap-1 overflow-x-auto">
                {/* v2 源码真值 ActionButton：rounded-full / px-2 py-1 / gap-0.5 / bg white-a5 / text-fg-muted / text-xs(12) / svg 12 / hover white-a10 */}
                <button type="button" className="canvas-prompt-bar-action-button" title="从画布选择参考节点" onClick={() => onStartSelection?.(nodeId)}>
                    <Plus className="size-3" />
                    参考
                </button>
                {/* 第5点：「标记」「特效」「运镜」已删除，只留「参考」 */}
                {/* 030：分类库按钮组（角色/场景/服装/道具/其他），接通「我的资产」分类选素材 */}
                {CATEGORY_LIBRARIES.map((chip) => (
                    <button key={chip.label} type="button" className="canvas-prompt-bar-action-button" title={`从我的资产·${chip.label.replace(/库$/, "")}中选择素材添加为参考`} onClick={() => (onOpenCategoryLibrary ? onOpenCategoryLibrary(nodeId, chip.category) : message.info(`「${chip.label}」功能开发中`))}>
                        <chip.icon className="size-3" />
                        {chip.label}
                    </button>
                ))}
            </div>
            {/* 030（boss 2026-10-05）：参考缩略图从 chips 行拆到独立一行（对齐原版截图：按钮一行、缩略图一行），
               面板高度随连接的图片自动增加，给缩略图留出空间；序号角标 = 生成输入顺序（与拖拽排序一致） */}
            {references.length ? (
                <div className="flex min-w-0 flex-wrap items-center gap-1 px-1">
                    {references.map((reference, index) => (
                        <ReferenceItem
                            key={reference.id}
                            reference={reference}
                            order={index + 1}
                            dragging={dragNodeId === reference.nodeId}
                            onDragStart={() => setDragNodeId(reference.nodeId)}
                            onDragEnd={() => setDragNodeId(null)}
                            onDropOn={() => handleDropOn(reference.nodeId)}
                            onRemove={() => onDisconnect?.(reference.nodeId, nodeId)}
                        />
                    ))}
                </div>
            ) : null}
        </div>
    );
}

function ReferenceItem({ reference, order, dragging, onDragStart, onDragEnd, onDropOn, onRemove }: { reference: CanvasResourceReference; order: number; dragging: boolean; onDragStart: () => void; onDragEnd: () => void; onDropOn: () => void; onRemove: () => void }) {
    const theme = canvasThemes[useThemeStore((state) => state.theme)];
    const Icon = reference.kind === "image" ? ImageIcon : reference.kind === "video" ? Video : reference.kind === "audio" ? Music2 : FileText;
    const isMedia = reference.kind === "image" || reference.kind === "video";
    return (
        <Popover placement="topLeft" mouseEnterDelay={0.15} content={<ReferencePreview reference={reference} />} arrow={!isMedia} destroyOnHidden={reference.kind === "video"} styles={isMedia ? { container: { padding: 0, background: "transparent", boxShadow: "none" } } : undefined}>
            <div
                className="group relative grid size-12 shrink-0 cursor-grab place-items-center rounded-xl border transition-opacity active:cursor-grabbing"
                style={{ background: theme.toolbar.activeBg, borderColor: theme.toolbar.border, opacity: dragging ? 0.4 : 1 }}
                title="拖动调整参考顺序"
                draggable
                onDragStart={(event) => {
                    // 只允许"排序"这一种拖拽：禁掉浏览器原生 img 拖拽（否则会拽出幽灵图、还能拖到画布上生成新节点）
                    event.dataTransfer.effectAllowed = "move";
                    event.dataTransfer.dropEffect = "move";
                    event.dataTransfer.setData("application/x-canvas-ref-order", reference.nodeId);
                    onDragStart();
                }}
                onDragEnd={onDragEnd}
                onDragOver={(event) => event.preventDefault()}
                onDrop={(event) => {
                    event.preventDefault();
                    event.stopPropagation();
                    // 只响应我们自己发起的排序拖拽，外部拖入的文件/内容忽略
                    if (event.dataTransfer.getData("application/x-canvas-ref-order")) onDropOn();
                }}
            >
                <span className="grid size-full place-items-center overflow-hidden rounded-[inherit]">
                    {reference.kind === "image" && reference.previewUrl ? <img src={reference.previewUrl} alt="" draggable={false} style={{ WebkitUserDrag: "none" } as React.CSSProperties} className="size-full select-none object-cover" /> : reference.kind === "video" && reference.previewUrl ? <video src={reference.previewUrl} draggable={false} style={{ WebkitUserDrag: "none" } as React.CSSProperties} className="size-full select-none object-cover" muted /> : <Icon className="size-4 opacity-65" />}
                </span>
                {/* 030：顺序角标（对齐原版左上角 1/2/3/4 小圆徽标） */}
                <span className="absolute left-0 top-0 z-10 grid size-4 -translate-x-1/4 -translate-y-1/4 place-items-center rounded-full text-[10px] font-medium leading-none shadow-sm" style={{ background: theme.toolbar.panel, color: theme.node.text, border: `1px solid ${theme.toolbar.border}` }} aria-label={`参考顺序 ${order}`}>
                    {order}
                </span>
                <button type="button" className="absolute right-0 top-0 grid size-5 place-items-center rounded-full border opacity-0 shadow-sm transition-opacity group-hover:opacity-100 focus-visible:opacity-100" style={{ background: theme.toolbar.panel, borderColor: theme.toolbar.border }} aria-label="断开参考连接" title="断开参考连接" onMouseDown={(event) => event.stopPropagation()} onClick={(event) => { event.stopPropagation(); onRemove(); }}><X className="size-3" /></button>
            </div>
        </Popover>
    );
}

function ReferencePreview({ reference }: { reference: CanvasResourceReference }) {
    if (reference.kind === "image" && reference.previewUrl) return <img src={reference.previewUrl} alt={reference.title} className="block max-h-52 max-w-72 rounded-lg object-contain" />;
    if (reference.kind === "video" && reference.previewUrl) return <video src={reference.previewUrl} className="block max-h-52 max-w-72 rounded-lg" autoPlay muted playsInline preload="metadata" />;
    if (reference.kind === "audio" && reference.previewUrl) return <audio src={reference.previewUrl} className="w-72" controls />;
    return <div className="max-h-52 w-72 overflow-auto whitespace-pre-wrap text-sm">{reference.text || reference.title || "暂无内容"}</div>;
}
