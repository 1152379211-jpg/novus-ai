"use client";

import { type CSSProperties, type PointerEvent as ReactPointerEvent, type ReactNode, useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
    History,
    Bot,
    Clapperboard,
    Copy,
    Cpu,
    Gauge,
    Group,
    ChevronRight,
    Image as ImageIcon,
    ArrowLeftRight,
    Keyboard,
    Minus,
    Moon,
    Focus,
    Music2,
    PanelRight,
    PanelRightClose,
    Pencil,
    Pin,
    PlugZap,
    Plus,
    RotateCcw,
    Settings2,
    Trash2,
    Type,
    Upload,
    Video,
    Wand2,
    X,
} from "lucide-react";
import { App, AutoComplete, Button, Dropdown, Modal, Segmented, Switch, Tooltip } from "antd";
import { motion } from "motion/react";
import { nanoid } from "nanoid";
import ReactMarkdown, { type Components } from "react-markdown";
import remarkGfm from "remark-gfm";

import { ImageGenerationPending } from "@/components/image-generation-pending";
import { useCopyText } from "@/hooks/use-copy-text";
import { canvasThemes } from "@/lib/canvas-theme";
import { cn } from "@/lib/utils";
import { fetchSystemAgentSkillFile } from "@/services/api/agent-skills";
import { imageToDataUrl } from "@/services/image-storage";
import { useAssetStore } from "@/stores/use-asset-store";
import { useAgentSkillStore } from "@/stores/use-agent-skill-store";
import { useConfigStore, useEffectiveConfig } from "@/stores/use-config-store";
import { useThemeStore } from "@/stores/use-theme-store";
import { createCanvasAgentState, runCanvasAgent } from "../agent/canvas-agent-runtime";
import { useCodexAgent } from "../agent/use-codex-agent";
import type { CanvasAgentContext } from "../agent/canvas-agent-context";
import type { CanvasAgentAction, CanvasAgentToolResult } from "../agent/canvas-agent-tools";
import {
    MAX_CANVAS_AGENT_SKILLS,
    CanvasNodeType,
    type CanvasAgentConfig,
    type CanvasAgentSkillSelection,
    type CanvasAgentState,
    type CanvasAssistantMessage,
    type CanvasAssistantReference,
    type CanvasAssistantSession,
    type CanvasNodeData,
} from "../types";
import { isCanvasImageNodeType } from "../utils/canvas-panorama";
import { assistantReferenceContentFromNode, buildAllCanvasResourceReferences, type CanvasResourceReference } from "../utils/canvas-resource-references";
import { assistantToPromptReference, CanvasAssistantComposer } from "./canvas-assistant-composer";
import { AgentSparkleIcon } from "./canvas-toolbar";
import { CanvasCodexConnectView } from "./canvas-codex-connect-view";
import { CanvasPromptChipInput } from "./canvas-prompt-chip-input";

const PANEL_MOTION_MS = 500;
const PANEL_MOTION_SECONDS = PANEL_MOTION_MS / 1000;

/** 欢迎区快捷操作（参考图）：kind=upload 打开上传，其余填入提示词 */
const WELCOME_QUICK_ACTIONS: { label: string; icon: typeof Focus; kind?: "upload"; prompt?: string }[] = [
    { label: "感知画布开始创作", icon: Focus, prompt: "感知当前画布内容，帮我开始创作" },
    { label: "从爆款预设开始", icon: Clapperboard, prompt: "从爆款预设开始，给我推荐一个模板" },
    { label: "上传故事改编", icon: Upload, kind: "upload" },
    { label: "批量优化提示词", icon: Wand2, prompt: "批量优化画布中现有节点的提示词" },
];

/** Agent 悬浮窗：屏幕坐标定位（不随画布平移缩放），位置/大小持久化到 localStorage */
type AgentFloatRect = { x: number; y: number; w: number; h: number };
const AGENT_FLOAT_RECT_KEY = "canvas-agent-float-rect-v1";
const AGENT_FLOAT_MIN_W = 340;
const AGENT_FLOAT_MIN_H = 420;

function clampAgentFloatRect(rect: AgentFloatRect): AgentFloatRect {
    if (typeof window === "undefined") return rect;
    const w = Math.min(Math.max(rect.w, AGENT_FLOAT_MIN_W), Math.max(AGENT_FLOAT_MIN_W, window.innerWidth - 24));
    const h = Math.min(Math.max(rect.h, AGENT_FLOAT_MIN_H), Math.max(AGENT_FLOAT_MIN_H, window.innerHeight - 24));
    const x = Math.min(Math.max(rect.x, 120 - w), Math.max(12, window.innerWidth - 120));
    const y = Math.min(Math.max(rect.y, 8), Math.max(8, window.innerHeight - 56));
    return { x, y, w, h };
}

function defaultAgentFloatRect(): AgentFloatRect {
    if (typeof window === "undefined") return { x: 0, y: 0, w: 420, h: 640 };
    const w = 420;
    const h = Math.min(660, Math.max(AGENT_FLOAT_MIN_H, window.innerHeight - 140));
    return clampAgentFloatRect({ x: window.innerWidth - w - 28, y: Math.round((window.innerHeight - h) / 2) - 30, w, h });
}

function readInitialAgentFloatRect(): AgentFloatRect {
    if (typeof window === "undefined") return { x: 0, y: 0, w: 420, h: 640 };
    let rect: AgentFloatRect | null = null;
    try {
        const raw = window.localStorage.getItem(AGENT_FLOAT_RECT_KEY);
        if (raw) {
            const parsed = JSON.parse(raw) as Partial<AgentFloatRect>;
            if (typeof parsed.x === "number" && typeof parsed.y === "number" && typeof parsed.w === "number" && typeof parsed.h === "number" && parsed.w >= AGENT_FLOAT_MIN_W && parsed.h >= AGENT_FLOAT_MIN_H) rect = { x: parsed.x, y: parsed.y, w: parsed.w, h: parsed.h };
        }
    } catch {}
    return clampAgentFloatRect(rect || defaultAgentFloatRect());
}

function persistAgentFloatRect(rect: AgentFloatRect) {
    try {
        window.localStorage.setItem(AGENT_FLOAT_RECT_KEY, JSON.stringify(rect));
    } catch {}
}

/** 停靠模式：贴右侧全高的侧边栏状态（UI 样式与浮窗一致），状态与宽度持久化 */
const AGENT_DOCKED_KEY = "canvas-agent-docked-v1";
const AGENT_DOCK_WIDTH_KEY = "canvas-agent-dock-width-v1";
const AGENT_DOCK_MIN_W = 340;
const AGENT_DOCK_MAX_W = 620;

function clampDockWidth(width: number) {
    if (typeof window === "undefined") return Math.min(Math.max(width, AGENT_DOCK_MIN_W), AGENT_DOCK_MAX_W);
    return Math.min(Math.max(width, AGENT_DOCK_MIN_W), Math.min(AGENT_DOCK_MAX_W, Math.max(AGENT_DOCK_MIN_W, window.innerWidth - 320)));
}
const ASSISTANT_NODE_TYPE_META = {
    [CanvasNodeType.Image]: { Icon: ImageIcon, label: "图片" },
    [CanvasNodeType.Panorama]: { Icon: ImageIcon, label: "全景图" },
    [CanvasNodeType.Video]: { Icon: Video, label: "视频" },
    [CanvasNodeType.Audio]: { Icon: Music2, label: "音频" },
    [CanvasNodeType.Text]: { Icon: Type, label: "文本" },
    [CanvasNodeType.Config]: { Icon: Settings2, label: "生成配置" },
    [CanvasNodeType.Director]: { Icon: Clapperboard, label: "导演台" },
    [CanvasNodeType.Group]: { Icon: Group, label: "组" },
};
const ASSISTANT_NODE_STATUS_COLOR: Record<string, string> = {
    success: "#22c55e",
    loading: "#f59e0b",
    error: "#ef4444",
};

type CanvasAssistantPanelProps = {
    canvasId: string;
    nodes: CanvasNodeData[];
    selectedNodeIds: Set<string>;
    referenceNodeClick: { nodeId: string | null; version: number };
    sessions: CanvasAssistantSession[];
    activeSessionId: string | null;
    agentConfig: CanvasAgentConfig;
    onFocusNode: (nodeId: string) => void;
    onSessionsChange: (sessions: CanvasAssistantSession[], activeSessionId: string | null) => void;
    onAgentConfigChange: (patch: Partial<CanvasAgentConfig>) => void;
    onPasteImage: (file: File) => void;
    onOpenUpload: () => void;
    onOpenAssets: () => void;
    getAgentContext: (state: CanvasAgentState) => CanvasAgentContext;
    onExecuteAction: (action: CanvasAgentAction, messageReferenceNodeIds: string[]) => Promise<CanvasAgentToolResult>;
    onCollapseStart: () => void;
    onCollapse: () => void;
    initialRequest?: { prompt: string; references: CanvasAssistantReference[]; skills: CanvasAgentSkillSelection[] } | null;
    onInitialRequestConsumed?: () => void;
    /** 底部工具栏“生成历史”信号：数值变化时切到历史记录视图 */
    historySignal?: number;
    /** 双击菜单里的“键盘快捷键” */
    onOpenShortcuts?: () => void;
};

type PendingDeleteConfirmation = {
    title: string;
    resolve: (confirmed: boolean) => void;
};

type PanelCardAction = { label: string; onClick: () => void | Promise<void>; danger?: boolean };
type CodexConfirmation = { id: string; title: string; content: ReactNode; actions: PanelCardAction[] };

export function CanvasAssistantPanel({
    canvasId,
    nodes,
    selectedNodeIds,
    referenceNodeClick,
    sessions,
    activeSessionId,
    agentConfig,
    onFocusNode,
    onSessionsChange,
    onAgentConfigChange,
    onPasteImage,
    onOpenUpload,
    onOpenAssets,
    getAgentContext,
    onExecuteAction,
    onCollapseStart,
    onCollapse,
    initialRequest,
    onInitialRequestConsumed,
    historySignal,
    onOpenShortcuts,
}: CanvasAssistantPanelProps) {
    const theme = canvasThemes[useThemeStore((state) => state.theme)];
    const colorTheme = useThemeStore((state) => state.theme);
    const setTheme = useThemeStore((state) => state.setTheme);
    const effectiveConfig = useEffectiveConfig();
    const isAiConfigReady = useConfigStore((state) => state.isAiConfigReady);
    const cleanupImages = useAssetStore((state) => state.cleanupImages);
    const { message: appMessage } = App.useApp();
    const mode = agentConfig.mode || "api";
    const abortRef = useRef<AbortController | null>(null);
    const consumedInitialRequestRef = useRef<typeof initialRequest>(null);
    const pendingDeleteRef = useRef<PendingDeleteConfirmation | null>(null);
    const messageListRef = useRef<HTMLDivElement>(null);
    const consumedReferenceNodeClickVersionRef = useRef(0);
    const [view, setView] = useState<"chat" | "history" | "connect">("chat");

    // 底部工具栏“生成历史”按钮触发：面板打开并切到历史记录视图
    // 注意：只在信号“发生变化”时切换。面板每次收起会卸载重建，若直接用残留的旧信号值判断，
    // 会导致之后每次点蓝球打开 Agent 都落在历史记录页（欢迎/对话界面消失）。
    const historySignalRef = useRef(historySignal ?? 0);
    useEffect(() => {
        const signal = historySignal ?? 0;
        if (signal === historySignalRef.current) return;
        historySignalRef.current = signal;
        if (signal > 0) setView("history");
    }, [historySignal]);

    const [prompt, setPrompt] = useState("");
    const [isRunning, setIsRunning] = useState(false);
    const [checkedChatIds, setCheckedChatIds] = useState<string[]>([]);
    const [deleteChatIds, setDeleteChatIds] = useState<string[]>([]);
    const [settingsOpen, setSettingsOpen] = useState(false);
    const [pinned, setPinned] = useState(false);
    const [contextMenuOpen, setContextMenuOpen] = useState(false);
    const [docked, setDocked] = useState(() => {
        if (typeof window === "undefined") return false;
        try { return window.localStorage.getItem(AGENT_DOCKED_KEY) === "1"; } catch { return false; }
    });
    const [dockWidth, setDockWidth] = useState(() => {
        if (typeof window === "undefined") return 420;
        try { return clampDockWidth(Number(window.localStorage.getItem(AGENT_DOCK_WIDTH_KEY)) || 420); } catch { return 420; }
    });
    const [closing, setClosing] = useState(false);
    const [floatRect, setFloatRect] = useState<AgentFloatRect>(() => readInitialAgentFloatRect());
    const [resizing, setResizing] = useState(false);
    const floatInteractionRef = useRef<{ mode: "move" | "resize"; startX: number; startY: number; origin: AgentFloatRect } | null>(null);

    // 视口变化时把悬浮窗拉回可视范围
    useEffect(() => {
        const onViewportResize = () => setFloatRect((current) => clampAgentFloatRect(current));
        window.addEventListener("resize", onViewportResize);
        return () => window.removeEventListener("resize", onViewportResize);
    }, []);

    /** 拖动（标题栏）/ 缩放（右下角手柄）：屏幕坐标，不随画布变换 */
    const beginFloatInteraction = (mode: "move" | "resize") => (event: ReactPointerEvent) => {
        if (event.button !== 0) return;
        event.preventDefault();
        floatInteractionRef.current = { mode, startX: event.clientX, startY: event.clientY, origin: floatRect };
        setResizing(true);
        const onMove = (moveEvent: PointerEvent) => {
            const drag = floatInteractionRef.current;
            if (!drag) return;
            const dx = moveEvent.clientX - drag.startX;
            const dy = moveEvent.clientY - drag.startY;
            setFloatRect(clampAgentFloatRect(drag.mode === "move"
                ? { ...drag.origin, x: drag.origin.x + dx, y: drag.origin.y + dy }
                : { ...drag.origin, w: drag.origin.w + dx, h: drag.origin.h + dy }));
        };
        const onUp = () => {
            floatInteractionRef.current = null;
            setResizing(false);
            window.removeEventListener("pointermove", onMove);
            window.removeEventListener("pointerup", onUp);
            setFloatRect((current) => {
                persistAgentFloatRect(current);
                return current;
            });
        };
        window.addEventListener("pointermove", onMove);
        window.addEventListener("pointerup", onUp);
    };

    const onHeaderPointerDown = (event: ReactPointerEvent<HTMLDivElement>) => {
        if ((event.target as HTMLElement).closest("button, a, input, textarea, [data-no-drag]")) return;
        beginFloatInteraction("move")(event);
    };

    /** 停靠模式：拖左边缘只调整宽度 */
    const beginDockResize = (event: ReactPointerEvent) => {
        if (event.button !== 0) return;
        event.preventDefault();
        const startX = event.clientX;
        const originW = dockWidth;
        setResizing(true);
        const onMove = (moveEvent: PointerEvent) => {
            const next = clampDockWidth(originW - (moveEvent.clientX - startX));
            setDockWidth(next);
            try { window.localStorage.setItem(AGENT_DOCK_WIDTH_KEY, String(next)); } catch {}
        };
        const onUp = () => {
            setResizing(false);
            window.removeEventListener("pointermove", onMove);
            window.removeEventListener("pointerup", onUp);
        };
        window.addEventListener("pointermove", onMove);
        window.addEventListener("pointerup", onUp);
    };

    /** 双击标题栏回到默认位置 */
    const resetFloatRect = () => {
        const rect = defaultAgentFloatRect();
        setFloatRect(rect);
        persistAgentFloatRect(rect);
    };
    const [composerReferenceIds, setComposerReferenceIds] = useState<string[]>([]);
    const [selectedSkills, setSelectedSkills] = useState<CanvasAgentSkillSelection[]>([]);
    const [removedReferenceIds, setRemovedReferenceIds] = useState<Set<string>>(new Set());
    const [pendingDelete, setPendingDelete] = useState<PendingDeleteConfirmation | null>(null);
    const [codexConfirmations, setCodexConfirmations] = useState<CodexConfirmation[]>([]);
    const [initialSession] = useState(() => createSession(mode));
    const lastSessionIds = useRef<Partial<Record<"api" | "codex", string>>>({});
    const drafts = useRef<Partial<Record<"api" | "codex", { prompt: string; references: string[]; skills: CanvasAgentSkillSelection[] }>>>({});
    const safeSessions = sessions.length ? sessions : [initialSession];
    const visibleSessions = safeSessions.filter((session) => (session.provider || "api") === mode);
    const rememberedId = lastSessionIds.current[mode] || activeSessionId;
    const resolvedActiveSessionId = visibleSessions.find((session) => session.id === rememberedId)?.id || visibleSessions[0]?.id || null;
    const sessionsRef = useRef<CanvasAssistantSession[]>(safeSessions);
    const activeSessionIdRef = useRef<string | null>(resolvedActiveSessionId);

    useEffect(() => {
        sessionsRef.current = safeSessions;
        activeSessionIdRef.current = resolvedActiveSessionId;
    }, [resolvedActiveSessionId, sessions]);

    useEffect(() => () => {
        abortRef.current?.abort();
        pendingDeleteRef.current?.resolve(false);
        pendingDeleteRef.current = null;
    }, []);

    const activeSession = visibleSessions.find((session) => session.id === resolvedActiveSessionId) || visibleSessions[0] || null;
    const historySessions = visibleSessions.filter((session) => session.messages.length > 0);
    const messages = activeSession?.messages || [];
    const hasMessages = messages.length > 0;
    const selectedNodeKey = useMemo(() => Array.from(selectedNodeIds).sort().join(","), [selectedNodeIds]);

    const resourceReferences = useMemo(() => buildAllCanvasResourceReferences(nodes), [nodes]);
    const resourceReferenceById = useMemo(() => new Map(resourceReferences.map((reference) => [reference.nodeId, reference])), [resourceReferences]);
    const nodeById = useMemo(() => new Map(nodes.map((node) => [node.id, node])), [nodes]);
    const resolveReferences = useCallback((ids: string[]) => ids.flatMap((id) => {
        const node = nodeById.get(id);
        const resource = resourceReferenceById.get(id);
        const reference = node && resource ? nodeToReference(node, resource) : null;
        return reference ? [reference] : [];
    }), [nodeById, resourceReferenceById]);
    const composerReferences = useMemo(() => resolveReferences(composerReferenceIds), [composerReferenceIds, resolveReferences]);
    const pendingReferences = useMemo(() => {
        const pendingClickNodeId = referenceNodeClick.version > consumedReferenceNodeClickVersionRef.current ? referenceNodeClick.nodeId : null;
        return resourceReferences.filter(
            (reference) => selectedNodeIds.has(reference.nodeId) && ((!composerReferenceIds.includes(reference.nodeId) && !removedReferenceIds.has(reference.nodeId)) || reference.nodeId === pendingClickNodeId),
        );
    }, [composerReferenceIds, referenceNodeClick, removedReferenceIds, resourceReferences, selectedNodeIds]);
    const iconButtonStyle = { color: theme.node.muted };
    const settleDeleteConfirmation = (confirmed: boolean) => {
        const pending = pendingDeleteRef.current;
        if (!pending) return;
        pendingDeleteRef.current = null;
        setPendingDelete(null);
        pending.resolve(confirmed);
    };

    useEffect(() => {
        setRemovedReferenceIds(new Set());
    }, [selectedNodeKey]);

    const commitSessions = (nextSessions: CanvasAssistantSession[], nextActiveSessionId = activeSessionIdRef.current) => {
        sessionsRef.current = nextSessions;
        activeSessionIdRef.current = nextActiveSessionId;
        const selected = nextSessions.find((session) => session.id === nextActiveSessionId);
        if (selected) lastSessionIds.current[selected.provider || "api"] = selected.id;
        onSessionsChange(nextSessions, nextActiveSessionId);
    };

    const updateSession = (sessionId: string, updater: (session: CanvasAssistantSession) => CanvasAssistantSession) => {
        commitSessions(sessionsRef.current.map((session) => (session.id === sessionId ? updater(session) : session)));
    };

    const appendMessage = (sessionId: string, message: CanvasAssistantMessage) => {
        updateSession(sessionId, (session) => ({
            ...session,
            title: session.messages.length ? session.title : message.text.slice(0, 18) || "新对话",
            messages: [...session.messages, message],
            updatedAt: new Date().toISOString(),
        }));
    };

    const updateMessage = (sessionId: string, messageId: string, patch: Partial<CanvasAssistantMessage>) => {
        updateSession(sessionId, (session) => ({
            ...session,
            messages: session.messages.map((message) => (message.id === messageId ? { ...message, ...patch } : message)),
            updatedAt: new Date().toISOString(),
        }));
    };

    const startChatSession = () => {
        setSelectedSkills([]);
        if (activeSession && activeSession.messages.length === 0) {
            commitSessions(sessionsRef.current, activeSession.id);
            return;
        }
        const session = createSession(mode);
        commitSessions([session, ...sessionsRef.current], session.id);
    };

    const removeSessions = async (ids: string[]) => {
        const removing = sessionsRef.current.filter((session) => (session.provider || "api") === mode && ids.includes(session.id));
        await Promise.all(removing.filter((session) => session.codexThreadId).map((session) => codex.archive(session.codexThreadId!, session.codexServiceId)));
        const next = sessionsRef.current.filter((session) => !removing.some((item) => item.id === session.id));
        let selected = next.find((session) => session.id === activeSessionIdRef.current)
            || next.find((session) => (session.provider || "api") === mode);
        if (!selected) { selected = createSession(mode); next.unshift(selected); }
        commitSessions(next, selected.id);
        if (!next.some((session) => (session.provider || "api") === mode && session.messages.length)) {
            const draft = drafts.current[mode];
            if (draft?.skills === selectedSkills) draft.skills = [];
            setSelectedSkills((current) => current === selectedSkills ? [] : current);
        }
        cleanupImages({ sessions: next });
        setCheckedChatIds((previous) => previous.filter((id) => !ids.includes(id)));
    };

    const selectComposerSkill = (skill: CanvasAgentSkillSelection) => {
        const existingIndex = selectedSkills.findIndex((selected) => selected.id === skill.id && selected.source === skill.source);
        if (existingIndex >= 0) {
            setSelectedSkills(selectedSkills.map((selected, index) => (index === existingIndex ? skill : selected)));
            return;
        }
        if (selectedSkills.length >= MAX_CANVAS_AGENT_SKILLS) {
            appMessage.warning(`最多选择 ${MAX_CANVAS_AGENT_SKILLS} 个 Skill`);
            return;
        }
        setSelectedSkills([...selectedSkills, skill]);
    };

    const removeComposerSkill = (id: string, source: CanvasAgentSkillSelection["source"]) => {
        setSelectedSkills((current) => current.filter((skill) => skill.id !== id || skill.source !== source));
    };

    const executeCanvasTool = async (action: CanvasAgentAction, messageReferenceNodeIds: string[], activeSkills: CanvasAgentSkillSelection[], provider: "api" | "codex", signal: AbortSignal): Promise<CanvasAgentToolResult> => {
        signal.throwIfAborted();
        // 066-T7：Agent 提交图片/视频生成时先弹窗确认比例与时长，用户可改参数或取消
        if (action.name === "generate_image" || action.name === "generate_video") {
            const kind = action.name === "generate_image" ? "image" : "video";
            const answer = await askMediaParams(kind, action.arguments as Record<string, unknown>, signal);
            if (!answer.confirmed) return { ok: false, code: "user_cancelled", message: "用户取消了本次生成（可在弹窗中调整参数后重试）" };
            action = { ...action, arguments: { ...(action.arguments as Record<string, unknown>), ...answer.overrides } };
        }
        if (action.name === "read_skill_file") {
            const skillId = typeof action.arguments.skillId === "string" ? action.arguments.skillId : "";
            const filePath = typeof action.arguments.path === "string" ? action.arguments.path : "";
            const activeSkill = activeSkills.find((skill) => skill.id === skillId && skill.source === "system");
            if (!activeSkill) return { ok: false, code: "skill_not_active", message: "只能读取当前激活的系统 Skill 文件" };
            try {
                const file = await fetchSystemAgentSkillFile(skillId, filePath);
                return { ok: true, skillId, path: file.path, content: file.content };
            } catch (error) {
                return { ok: false, code: "skill_file_not_found", message: error instanceof Error ? error.message : "Skill 文件读取失败" };
            }
        }
        if (action.name !== "delete_node") return onExecuteAction(action, messageReferenceNodeIds);
        const nodeId = typeof action.arguments.nodeId === "string" ? action.arguments.nodeId : "";
        const node = nodes.find((item) => item.id === nodeId);
        let confirmed: boolean;
        if (provider === "codex") {
            confirmed = await confirmCodex(
                `删除「${node?.title || "未命名节点"}」？`,
                <div className="text-xs opacity-55">相关连线和任务记录将按现有逻辑清理</div>,
                signal, "确认删除", "取消", true,
            );
        } else {
            const cancel = () => settleDeleteConfirmation(false);
            signal.addEventListener("abort", cancel, { once: true });
            confirmed = await new Promise<boolean>((resolve) => {
                pendingDeleteRef.current?.resolve(false);
                const pending = { title: node?.title || "未命名节点", resolve };
                pendingDeleteRef.current = pending;
                setPendingDelete(pending);
            });
            signal.removeEventListener("abort", cancel);
        }
        signal.throwIfAborted();
        return confirmed ? onExecuteAction(action, messageReferenceNodeIds) : { ok: false, code: "delete_cancelled", message: "用户取消删除，原节点已保留" };
    };

    const confirmCodex = (title: string, content: ReactNode, signal: AbortSignal, okText = "允许一次", cancelText = "拒绝", danger = false) => new Promise<boolean>((resolve) => {
        const finish = (allowed: boolean) => { signal.removeEventListener("abort", cancel); setCodexConfirmations((current) => current.filter((item) => item !== confirmation)); resolve(allowed); };
        const cancel = () => finish(false);
        const confirmation = { id: nanoid(), title, content, actions: [{ label: cancelText, onClick: cancel }, { label: okText, danger, onClick: () => finish(true) }] };
        setCodexConfirmations((current) => [...current, confirmation]);
        signal.addEventListener("abort", cancel, { once: true });
        if (signal.aborted) cancel();
    });
    const codex = useCodexAgent({
        canvasId,
        onBootstrap: () => { if (mode === "api") switchMode(); else setView("chat"); },
        executeTool: async (action, signal) => {
            if (action.name === "arrange_nodes" && !(await confirmCodex("允许 Codex 整理画布？", <pre className="whitespace-pre-wrap break-words text-xs">{JSON.stringify(action.arguments, null, 2)}</pre>, signal))) return { ok: false, code: "action_not_requested", message: "未允许整理画布" };
            return executeCanvasTool(action, [], [], "codex", signal);
        },
        onApproval: async ({ method, params }, signal) => {
            if (method === "mcpServer/elicitation/request") {
                appMessage.info("Codex 工具请求了额外信息，本次请求已取消");
                return { action: "decline", content: null };
            }
            const questions = method === "item/tool/requestUserInput"
                ? params.questions as Array<{ id: string; question: string; options?: Array<{ label: string; description?: string }> }> : null;
            const answers: Record<string, { answers: string[] }> = {};
            const accepted = await confirmCodex(
                questions ? "Codex 需要补充信息" : "Codex 请求授权",
                questions ? <div className="space-y-3">{questions.map((question) => <div key={question.id}>
                    <div className="mb-1 text-sm">{question.question}</div>
                    <AutoComplete className="w-full" aria-label={question.question} options={question.options?.map((option) => ({ value: option.label, label: option.description ? `${option.label}：${option.description}` : option.label }))} onChange={(value) => { answers[question.id] = { answers: [value] }; }} />
                </div>)}</div> : <pre className="whitespace-pre-wrap break-words text-xs">{JSON.stringify(params, null, 2)}</pre>,
                signal, questions ? "提交" : "允许一次", questions ? "取消" : "拒绝",
            );
            return questions ? { answers: accepted ? answers : {} } : method === "item/permissions/requestApproval"
                ? { permissions: accepted ? params.permissions || {} : {}, scope: "turn" }
                : { decision: accepted ? "accept" : "decline" };
        },
    });
    const switchMode = () => {
        if (isRunning) return;
        const next = mode === "api" ? "codex" : "api";
        if (activeSessionIdRef.current) lastSessionIds.current[mode] = activeSessionIdRef.current;
        drafts.current[mode] = { prompt, references: composerReferenceIds, skills: selectedSkills };
        const nextSessions = sessionsRef.current.filter((session) => (session.provider || "api") === next);
        commitSessions(sessionsRef.current, nextSessions.find((session) => session.id === lastSessionIds.current[next])?.id || nextSessions[0]?.id || null);
        onAgentConfigChange({ mode: next });
        setView("chat");
        setPrompt(drafts.current[next]?.prompt || "");
        setComposerReferenceIds(drafts.current[next]?.references || []);
        setRemovedReferenceIds(new Set());
        setSelectedSkills(drafts.current[next]?.skills || []);
        setCheckedChatIds([]);
        setDeleteChatIds([]);
    };
    const codexModel = codex.models.find((item) => item.model === agentConfig.codexModel) || codex.models.find((item) => item.isDefault) || codex.models[0];
    const effortLabels: Record<string, string> = { none: "不推理", minimal: "最低", low: "低", medium: "中", high: "高", xhigh: "极高", max: "最大", ultra: "超高" };
    const codexEffort = agentConfig.codexEffort || codexModel?.defaultReasoningEffort;
    const showCodexConnection = mode === "codex" && (view === "connect" || (view === "chat" && codex.status !== "ready"));
    useEffect(() => {
        if (view !== "chat" || showCodexConnection) return;
        const frame = window.requestAnimationFrame(() => {
            const element = messageListRef.current;
            if (element) element.scrollTop = element.scrollHeight;
        });
        return () => window.cancelAnimationFrame(frame);
    }, [messages, view, showCodexConnection]);
    const codexControls = mode === "codex" ? (
        <>
            <Dropdown trigger={["click"]} placement="topLeft" disabled={isRunning || !codex.models.length} menu={{ selectable: true, selectedKeys: codexModel ? [codexModel.model] : [], items: codex.models.map((item) => ({ key: item.model, label: item.displayName })), onClick: ({ key }) => onAgentConfigChange({ codexModel: key, codexEffort: undefined }) }}>
                <Button type="text" className="!h-9 !min-w-8 !shrink-0 !px-2" style={{ color: theme.node.text }} icon={<Cpu className="size-4" />} aria-label="选择 Codex 模型"><span className="hidden max-w-28 truncate @[660px]:inline">{codexModel?.displayName || "选择模型"}</span></Button>
            </Dropdown>
            <Dropdown trigger={["click"]} placement="topLeft" disabled={isRunning || !codexModel?.supportedReasoningEfforts.length} menu={{ selectable: true, selectedKeys: codexEffort ? [codexEffort] : [], items: codexModel?.supportedReasoningEfforts.map((item) => ({ key: item.reasoningEffort, label: effortLabels[item.reasoningEffort] || item.reasoningEffort })), onClick: ({ key }) => onAgentConfigChange({ codexEffort: key }) }}>
                <Button type="text" className="!h-9 !min-w-8 !shrink-0 !px-2" style={{ color: theme.node.text }} icon={<Gauge className="size-4" />} aria-label="选择 Codex 推理强度"><span className="hidden @[660px]:inline">{effortLabels[codexEffort || ""] || codexEffort}</span></Button>
            </Dropdown>
        </>
    ) : undefined;

    const sendMessage = async (text: string, savedReferences?: CanvasAssistantReference[], skillOverride?: CanvasAgentSkillSelection[] | null, showSelectedSkills = skillOverride === undefined && selectedSkills.length > 0) => {
        if (abortRef.current) return;
        if (mode === "codex" && codex.status !== "ready") { setView("connect"); appMessage.info("请先连接本地 Codex 服务"); return; }
        const session = activeSession || createSession(mode);
        const activeSkills = skillOverride !== undefined ? skillOverride || [] : selectedSkills.length ? selectedSkills : session.activeSkills || [];
        let activeSkillContents: Array<{ id: string; source: CanvasAgentSkillSelection["source"]; name: string; content: string; hasFiles?: boolean }> = [];

        if (activeSkills.length) {
            const skillStore = useAgentSkillStore.getState();
            if (!skillStore.systemSkills.length && !skillStore.userSkills.length) {
                try {
                    await skillStore.loadSkills();
                } catch (error) {
                    appMessage.error(error instanceof Error ? error.message : "Skill 加载失败");
                    return;
                }
            }
            const availableSkills = [...useAgentSkillStore.getState().systemSkills, ...useAgentSkillStore.getState().userSkills];
            const latestSkills = activeSkills.map((selected) => availableSkills.find((skill) => skill.id === selected.id && skill.source === selected.source && skill.enabled));
            const unavailableSkill = activeSkills.find((_, index) => !latestSkills[index]);
            if (unavailableSkill) {
                appMessage.error(`Skill「${unavailableSkill.name}」已不可用，请重新选择`);
                return;
            }
            activeSkillContents = latestSkills.map((skill) => ({ id: skill!.id, source: skill!.source, name: skill!.name, content: skill!.content, hasFiles: skill!.hasFiles }));
        }

        if (!activeSession) commitSessions([session, ...sessionsRef.current], session.id);
        updateSession(session.id, (current) => ({
            ...current,
            activeSkills,
            updatedAt: new Date().toISOString(),
        }));

        const references = savedReferences || composerReferences;
        const messageReferenceNodeIds = references.map((reference) => reference.id);
        const userMessage: CanvasAssistantMessage = { id: nanoid(), role: "user", text, references, skills: activeSkills, skillsSelected: showSelectedSkills, status: "success" };
        const assistantId = nanoid();
        appendMessage(session.id, userMessage);
        appendMessage(session.id, { id: assistantId, role: "assistant", text: "", status: "thinking", activity: "正在理解画布和创作目标" });
        setPrompt("");
        setComposerReferenceIds([]);
        setSelectedSkills([]);
        setRemovedReferenceIds(new Set(selectedNodeIds));

        const requestConfig = {
            ...effectiveConfig,
            model: effectiveConfig.textModel || effectiveConfig.model,
            apiMode: agentConfig.textApiMode,
            textStreaming: agentConfig.textStreaming === true,
            textReasoningEnabled: agentConfig.textReasoningEnabled === true,
            activeChannelId: effectiveConfig.textChannelId || effectiveConfig.activeChannelId,
            textChannelId: effectiveConfig.textChannelId,
        };
        const jsonToolFallbackKey = [requestConfig.apiMode || "chat", requestConfig.textChannelId || requestConfig.activeChannelId || requestConfig.baseUrl, requestConfig.model].join("|");
        if (mode === "api" && !isAiConfigReady(requestConfig, requestConfig.model)) {
            updateMessage(session.id, assistantId, {
                text: "全局文本模型尚未配置完成。请先从应用原有的全局配置入口选择文本模型和渠道，然后再继续。",
                status: "error",
                activity: undefined,
            });
            return;
        }

        const controller = new AbortController();
        abortRef.current = controller;
        setIsRunning(true);
        try {
            const modelReferences = await Promise.all(
                references.map(async (reference) => {
                    if (!reference.dataUrl) return reference;
                    try {
                        return { ...reference, dataUrl: await imageToDataUrl(reference) };
                    } catch {
                        return reference;
                    }
                }),
            );
            const run = mode === "codex" ? (input: Parameters<typeof runCanvasAgent>[0]) => codex.run({
                ...input, threadId: session.codexThreadId, serviceId: session.codexServiceId, model: codexModel?.model, effort: codexEffort,
                onThread: (codexThreadId, codexServiceId) => updateSession(session.id, (current) => ({ ...current, codexThreadId, codexServiceId })),
                onText: (text) => updateMessage(session.id, assistantId, { text }),
            }) : runCanvasAgent;
            const result = await run({
                config: requestConfig,
                initialState: session.agentState,
                protocolMessages: session.protocolMessages,
                userText: text,
                references: modelReferences,
                activeSkillContents,
                contextCheckpoint: session.contextCheckpoint,
                preferredJsonMode: session.jsonToolFallbackKey === jsonToolFallbackKey ? session.jsonToolFallbackMode || "structured-json" : undefined,
                getContext: getAgentContext,
                executeAction: (action, signal = controller.signal) => executeCanvasTool(action, messageReferenceNodeIds, activeSkills, mode, signal),
                signal: controller.signal,
                onEvent: (event) => updateMessage(session.id, assistantId, { status: event.status, activity: event.label }),
                onCheckpoint: (checkpoint) =>
                    updateSession(session.id, (current) => ({
                        ...current,
                        agentState: checkpoint.state,
                        protocolMessages: checkpoint.protocolMessages,
                        contextCheckpoint: checkpoint.contextCheckpoint,
                        jsonToolFallbackKey: checkpoint.jsonFallbackMode ? jsonToolFallbackKey : undefined,
                        jsonToolFallbackMode: checkpoint.jsonFallbackMode,
                        updatedAt: new Date().toISOString(),
                    })),
            });
            updateSession(session.id, (current) => ({
                ...current,
                agentState: result.state,
                protocolMessages: result.protocolMessages,
                contextCheckpoint: result.contextCheckpoint,
                jsonToolFallbackKey: result.jsonFallbackMode ? jsonToolFallbackKey : undefined,
                jsonToolFallbackMode: result.jsonFallbackMode,
                messages: current.messages.map((message) =>
                    message.id === assistantId ? { ...message, text: result.reply, status: "success", activity: undefined } : message,
                ),
                updatedAt: new Date().toISOString(),
            }));
        } catch (error) {
            const stopped = error instanceof Error && error.name === "AbortError";
            updateMessage(session.id, assistantId, {
                text: stopped ? "已停止继续执行。已经创建的节点和已经提交的媒体任务会保留。" : error instanceof Error ? error.message : "Agent 执行失败",
                status: stopped ? "waiting" : "error",
                activity: undefined,
            });
        } finally {
            if (abortRef.current === controller) abortRef.current = null;
            setIsRunning(false);
        }
    };

    useEffect(() => {
        if (!initialRequest || consumedInitialRequestRef.current === initialRequest) return;
        consumedInitialRequestRef.current = initialRequest;
        onInitialRequestConsumed?.();
        void sendMessage(initialRequest.prompt, initialRequest.references, initialRequest.skills, initialRequest.skills.length > 0);
    }, [initialRequest, onInitialRequestConsumed]);

    const submit = async (nextPrompt = prompt, referenceIds = composerReferenceIds) => {
        const text = nextPrompt.trim();
        if (!text || isRunning) return;
        await sendMessage(text, resolveReferences(referenceIds));
    };

    const retryMessage = (message: CanvasAssistantMessage) => {
        const index = messages.findIndex((item) => item.id === message.id);
        const user = messages.slice(0, index).findLast((item) => item.role === "user");
        if (user) void sendMessage(user.text, user.references, user.skills || []);
    };

    const collapse = () => {
        setClosing(true);
        onCollapseStart();
        window.setTimeout(onCollapse, PANEL_MOTION_MS);
    };

    // 066-T7：Agent 生成图片/视频时弹窗确认参数（比例/秒数）——替代原底部常驻设置
    const [mediaAsk, setMediaAsk] = useState<null | {
        kind: "image" | "video";
        args: Record<string, unknown>;
        resolve: (result: { confirmed: boolean; overrides: Record<string, unknown> }) => void;
    }>(null);
    const [mediaAskSize, setMediaAskSize] = useState("");
    const [mediaAskSeconds, setMediaAskSeconds] = useState(30);
    const askMediaParams = useCallback((kind: "image" | "video", args: Record<string, unknown>, signal: AbortSignal) => {
        return new Promise<{ confirmed: boolean; overrides: Record<string, unknown> }>((resolve) => {
            const finish = (result: { confirmed: boolean; overrides: Record<string, unknown> }) => {
                setMediaAsk(null);
                resolve(result);
            };
            setMediaAskSize(kind === "video" ? "16:9" : "1:1");
            setMediaAskSeconds(30);
            setMediaAsk({ kind, args, resolve: finish });
            signal.addEventListener("abort", () => finish({ confirmed: false, overrides: {} }), { once: true });
        });
    }, []);
    const IMAGE_ASK_SIZES = ["1:1", "16:9", "9:16", "4:3", "3:4", "3:2", "2:3", "21:9"];
    const VIDEO_ASK_SIZES = ["16:9", "9:16", "1:1", "4:3"];
    const VIDEO_ASK_SECONDS = [5, 10, 15, 30];

    return (
        <>
        <motion.div
            data-canvas-agent-panel
            className="fixed z-[80] flex flex-col overflow-hidden rounded-2xl border shadow-2xl"
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: closing ? 0 : 1, scale: closing ? 0.96 : 1 }}
            transition={{ duration: resizing ? 0 : PANEL_MOTION_SECONDS, ease: [0.22, 1, 0.36, 1] }}
            style={
                docked
                    ? {
                          right: 0,
                          top: 0,
                          bottom: 0,
                          width: dockWidth,
                          borderRadius: 0,
                          pointerEvents: closing ? "none" : undefined,
                          background: "#252525", // 018-3 boss：面板本体背景统一 #252525
                          borderColor: theme.node.stroke,
                          color: theme.node.text,
                          boxShadow: colorTheme === "dark" ? "-18px 0 50px rgba(0,0,0,.35)" : "-18px 0 50px rgba(28,25,23,.14)",
                      }
                    : {
                          left: floatRect.x,
                          top: floatRect.y,
                          width: floatRect.w,
                          height: floatRect.h,
                          pointerEvents: closing ? "none" : undefined,
                          background: "#252525", // 018-3 boss：面板本体背景统一 #252525
                          borderColor: theme.node.stroke,
                          color: theme.node.text,
                          boxShadow: colorTheme === "dark" ? "0 24px 70px rgba(0,0,0,.45)" : "0 24px 70px rgba(28,25,23,.22)",
                      }
            }
        >
            <div
                className="flex flex-wrap items-center justify-between gap-2 border-b px-4 py-3 select-none"
                style={{ borderColor: theme.node.stroke, cursor: docked || pinned ? "default" : "grab" }}
                onPointerDown={(event) => { if (!pinned && !docked) onHeaderPointerDown(event); }}
                onDoubleClick={() => setContextMenuOpen(true)}
                title={pinned ? "窗口已固定，点击别针取消后可拖动；双击打开菜单" : "拖动移动窗口；双击打开菜单"}
            >
                    <div className="flex items-center gap-2 text-sm font-medium">
                        <Bot className="size-4" />
                        {view === "history" ? "历史记录" : mode === "codex" ? "Codex" : "创作 Agent"}
                        <Tooltip title={mode === "codex" ? "切换回创作 Agent" : "切换到 Codex"}>
                            <Button size="small" className="!h-7 !rounded-md !px-2.5 !shadow-none" style={{ font: "inherit", color: theme.node.text, background: "transparent", borderColor: theme.node.stroke }} icon={<ArrowLeftRight className="size-3.5" />} disabled={isRunning} onClick={switchMode}>{mode === "codex" ? "创作 Agent" : "Codex"}</Button>
                        </Tooltip>
                    </div>
                    <div className="flex items-center gap-1">
                        {mode === "codex" ? <Tooltip title="连接教程"><Button type="text" shape="circle" className="!h-8 !w-8 !min-w-8" style={iconButtonStyle} icon={<PlugZap className="size-4" />} aria-label="连接教程" disabled={isRunning} onClick={() => { setView("connect"); messageListRef.current?.scrollTo({ top: 0 }); }} /></Tooltip> : null}
                        {view === "history" ? (
                            <>
                                <Tooltip title="删除选中">
                                    <Button type="text" shape="circle" className="!h-8 !w-8 !min-w-8" style={iconButtonStyle} icon={<Trash2 className="size-4" />} disabled={!checkedChatIds.length} onClick={() => setDeleteChatIds(checkedChatIds)} />
                                </Tooltip>
                                <Tooltip title="删除全部">
                                    <Button type="text" shape="circle" className="!h-8 !w-8 !min-w-8" style={iconButtonStyle} icon={<X className="size-4" />} disabled={!historySessions.length} onClick={() => setDeleteChatIds(historySessions.map((session) => session.id))} />
                                </Tooltip>
                            </>
                        ) : null}
                        <Tooltip title={view === "history" ? "返回对话" : "历史记录"}>
                            <Button type="text" shape="circle" className="!h-8 !w-8 !min-w-8" style={iconButtonStyle} icon={<History className="size-4" />} onClick={() => setView(view === "history" ? "chat" : "history")} />
                        </Tooltip>
                        <Tooltip title="新对话">
                            <Button
                                type="text"
                                shape="circle"
                                className="!h-8 !w-8 !min-w-8"
                                style={iconButtonStyle}
                                icon={<Plus className="size-4" />}
                                disabled={!hasMessages}
                                onClick={() => {
                                    startChatSession();
                                    setView("chat");
                                }}
                            />
                        </Tooltip>
                        <Tooltip title="Agent 设置">
                            <Button type="text" shape="circle" className="!h-8 !w-8 !min-w-8" style={iconButtonStyle} icon={<Settings2 className="size-4" />} onClick={() => setSettingsOpen(true)} />
                        </Tooltip>
                        <Tooltip title={pinned ? "取消固定（恢复拖动）" : "固定窗口位置"}>
                            <Button type="text" shape="circle" className="!h-8 !w-8 !min-w-8" style={{ ...iconButtonStyle, background: pinned ? theme.toolbar.activeBg : undefined }} icon={<Pin className={cn("size-4", pinned && "fill-current")} />} aria-pressed={pinned} onClick={() => setPinned((value) => !value)} />
                        </Tooltip>
                        <Tooltip title={docked ? "切换为浮窗" : "停靠到右侧"}>
                            <Button
                                type="text"
                                shape="circle"
                                className="!h-8 !w-8 !min-w-8"
                                style={{ ...iconButtonStyle, background: docked ? theme.toolbar.activeBg : undefined }}
                                icon={docked ? <PanelRightClose className="size-4" /> : <PanelRight className="size-4" />}
                                aria-pressed={docked}
                                onClick={() => {
                                    setDocked((value) => {
                                        try { window.localStorage.setItem(AGENT_DOCKED_KEY, value ? "0" : "1"); } catch {}
                                        return !value;
                                    });
                                }}
                            />
                        </Tooltip>
                        <Tooltip title="关闭">
                            <Button type="text" shape="circle" className="!h-8 !w-8 !min-w-8" style={iconButtonStyle} icon={<Minus className="size-4" />} onClick={collapse} />
                        </Tooltip>
                    </div>
                </div>

                {/* 双击标题栏弹出的菜单（参考图样式：深色圆角浮层 + 图标行） */}
                {contextMenuOpen ? (
                    <>
                        <div className="fixed inset-0 z-40" onClick={() => setContextMenuOpen(false)} />
                        <div
                            className="absolute left-3 top-[52px] z-50 w-[230px] overflow-hidden rounded-xl border py-1.5 shadow-2xl"
                            style={{ background: theme.node.panel, borderColor: theme.node.stroke }}
                            data-no-drag
                        >
                            {[
                                { key: "settings", icon: <Settings2 className="size-4" />, label: "Agent 设置", onClick: () => setSettingsOpen(true) },
                                { key: "shortcuts", icon: <Keyboard className="size-4" />, label: "键盘快捷键", onClick: () => onOpenShortcuts?.() },
                                { key: "theme", icon: <Moon className="size-4" />, label: colorTheme === "dark" ? "切换亮色主题" : "切换暗色主题", onClick: () => setTheme(colorTheme === "dark" ? "light" : "dark") },
                            ].map((item, index) => (
                                <button
                                    key={item.key}
                                    type="button"
                                    className={cn("mx-1.5 flex h-9 w-[calc(100%-12px)] items-center gap-3 rounded-lg px-3 text-left text-sm transition", index === 0 && "mt-0.5")}
                                    style={{ color: theme.node.text }}
                                    onMouseEnter={(event) => { event.currentTarget.style.background = theme.toolbar.itemHover; }}
                                    onMouseLeave={(event) => { event.currentTarget.style.background = "transparent"; }}
                                    onClick={() => {
                                        setContextMenuOpen(false);
                                        item.onClick();
                                    }}
                                >
                                    {item.icon}
                                    {item.label}
                                </button>
                            ))}
                            <div className="mx-3 my-1.5 h-px" style={{ background: theme.node.stroke }} />
                            <button
                                type="button"
                                className="mx-1.5 flex h-9 w-[calc(100%-12px)] items-center gap-3 rounded-lg px-3 text-left text-sm transition"
                                style={{ color: theme.node.text }}
                                onMouseEnter={(event) => { event.currentTarget.style.background = theme.toolbar.itemHover; }}
                                onMouseLeave={(event) => { event.currentTarget.style.background = "transparent"; }}
                                onClick={() => {
                                    setContextMenuOpen(false);
                                    resetFloatRect();
                                }}
                            >
                                <Focus className="size-4" />
                                回到默认位置
                            </button>
                        </div>
                    </>
                ) : null}

                <div ref={messageListRef} className="thin-scrollbar min-h-0 flex-1 space-y-4 overflow-y-auto px-4 py-4">
                    {showCodexConnection ? <CanvasCodexConnectView agent={codex} onChat={() => setView("chat")} /> : view === "history" ? (
                        <AssistantHistory
                            sessions={historySessions}
                            activeSession={activeSession}
                            checkedIds={checkedChatIds.filter((id) => historySessions.some((session) => session.id === id))}
                            onToggleChecked={(id, checked) => setCheckedChatIds((previous) => (checked ? [...new Set([...previous, id])] : previous.filter((item) => item !== id)))}
                            onOpen={(id) => {
                                commitSessions(sessionsRef.current, id);
                                setSelectedSkills([]);
                                setView("chat");
                            }}
                            onRename={(id, title) => updateSession(id, (session) => ({ ...session, title, updatedAt: new Date().toISOString() }))}
                            onDelete={(id) => setDeleteChatIds([id])}
                        />
                    ) : messages.length ? (
                        <AssistantMessages messages={messages} nodeById={nodeById} onFocusNode={onFocusNode} onRetry={retryMessage} codexMode={mode === "codex"} />
                    ) : (
                        <div className="flex h-full flex-col items-center justify-center px-6 text-center">
                            <div
                                className="grid size-16 place-items-center rounded-full shadow-lg"
                                style={{ background: "linear-gradient(135deg,#63b0ff,#2569ff,#0d4fd8)" }}
                            >
                                <AgentSparkleIcon className="size-7 text-white" />
                            </div>
                            <div className="mt-4 text-base font-medium">让创作 Agent 辅助你的无限创意</div>
                            <div className="mt-1.5 max-w-[280px] text-sm leading-6 opacity-55">描述故事、宣传片或现有素材，Agent 会与你沟通并直接操作当前画布</div>
                            <div className="mt-6 w-full max-w-[300px] space-y-1.5">
                                {WELCOME_QUICK_ACTIONS.map((action) => (
                                    <button
                                        key={action.label}
                                        type="button"
                                        className="flex w-full items-center justify-between gap-3 rounded-xl border px-4 py-2.5 text-left text-sm transition"
                                        style={{ borderColor: theme.node.stroke, background: "#303030" }}
                                        onMouseEnter={(event) => { event.currentTarget.style.background = "#3d3d3d"; }}
                                        onMouseLeave={(event) => { event.currentTarget.style.background = "#303030"; }}
                                        onClick={() => {
                                            if (action.kind === "upload") onOpenUpload();
                                            else if (action.prompt) setPrompt(action.prompt);
                                        }}
                                    >
                                        <span className="flex items-center gap-2.5">
                                            <action.icon className="size-4 opacity-80" />
                                            {action.label}
                                        </span>
                                        <ChevronRight className="size-4 opacity-45" />
                                    </button>
                                ))}
                            </div>
                        </div>
                    )}
                </div>

                {(mode === "api" ? pendingDelete : codexConfirmations.length) ? (
                    <div className="thin-scrollbar max-h-[50%] shrink-0 space-y-2 overflow-y-auto pb-2">
                        {mode === "api" && pendingDelete ? <AssistantPanelCard title={`删除「${pendingDelete.title}」？`} actions={[
                            { label: "取消", onClick: () => settleDeleteConfirmation(false) },
                            { label: "确认删除", danger: true, onClick: () => settleDeleteConfirmation(true) },
                        ]}><div className="text-xs opacity-55">相关连线和任务记录将按现有逻辑清理</div></AssistantPanelCard> : null}
                        {mode === "codex" ? codexConfirmations.map((confirmation) => <AssistantPanelCard key={confirmation.id} title={confirmation.title} actions={confirmation.actions}>{confirmation.content}</AssistantPanelCard>) : null}
                    </div>
                ) : null}
                {view === "chat" && !showCodexConnection ? (
                    <CanvasAssistantComposer
                        prompt={prompt}
                        isRunning={isRunning}
                        codexControls={codexControls}
                        references={composerReferences}
                        availableReferences={resourceReferences}
                        pendingReferences={pendingReferences}
                        selectedSkills={selectedSkills}
                        agentConfig={agentConfig}
                        onAgentConfigChange={onAgentConfigChange}
                        onPromptChange={setPrompt}
                        onSkillSelect={selectComposerSkill}
                        onSkillRemove={removeComposerSkill}
                        onReferenceIdsChange={(ids) => {
                            consumedReferenceNodeClickVersionRef.current = referenceNodeClick.version;
                            const removedSelectedIds = composerReferenceIds.filter((id) => selectedNodeIds.has(id) && !ids.includes(id));
                            if (removedSelectedIds.length) setRemovedReferenceIds((previous) => new Set([...previous, ...removedSelectedIds]));
                            setComposerReferenceIds(ids);
                        }}
                        onSubmit={submit}
                        onStop={() => abortRef.current?.abort()}
                        onOpenUpload={onOpenUpload}
                        onOpenAssets={onOpenAssets}
                        onPasteImage={onPasteImage}
                    />
                ) : null}

                <Modal
                    title="Agent 设置"
                    open={settingsOpen}
                    centered
                    width={520}
                    onCancel={() => setSettingsOpen(false)}
                    footer={<Button type="primary" onClick={() => setSettingsOpen(false)}>完成</Button>}
                >
                    {mode !== "codex" ? <div className="flex items-center justify-between gap-6 py-2">
                        <div className="min-w-0">
                            <div className="text-sm font-medium">文本接口</div>
                            <div className="mt-1 text-xs leading-5 opacity-55">选择使用 Chat Completions 或 Responses 接口</div>
                        </div>
                        <Segmented
                            value={agentConfig.textApiMode}
                            options={[{ label: "Chat", value: "chat" }, { label: "Responses", value: "responses" }]}
                            onChange={(textApiMode) => onAgentConfigChange({ textApiMode: textApiMode as CanvasAgentConfig["textApiMode"] })}
                        />
                    </div> : null}
                    {mode !== "codex" ? <div className="flex items-center justify-between gap-6 py-2">
                        <div className="min-w-0">
                            <div className="text-sm font-medium">流式响应</div>
                            <div className="mt-1 text-xs leading-5 opacity-55">开启后以流式读取文本模型回复</div>
                        </div>
                        <Switch checked={agentConfig.textStreaming === true} onChange={(textStreaming) => onAgentConfigChange({ textStreaming })} />
                    </div> : null}
                    <div className="flex items-center justify-between gap-6 py-2">
                        <div className="min-w-0">
                            <div className="text-sm font-medium">自动生成图片/视频/音频</div>
                            <div className="mt-1 text-xs leading-5 opacity-55">开启后，Agent 可直接提交图片/视频/音频生成，无需再次确认</div>
                        </div>
                        <Switch checked={agentConfig.autoGenerateMedia} onChange={(autoGenerateMedia) => onAgentConfigChange({ autoGenerateMedia })} />
                    </div>
                </Modal>

                <Modal
                    title="删除对话记录？"
                    open={deleteChatIds.length > 0}
                    centered
                    onCancel={() => setDeleteChatIds([])}
                    footer={
                        <>
                            <Button onClick={() => setDeleteChatIds([])}>取消</Button>
                            <Button
                                danger
                                type="primary"
                                onClick={async () => {
                                    try {
                                        await removeSessions(deleteChatIds);
                                        setDeleteChatIds((current) => current === deleteChatIds ? [] : current);
                                    } catch (error) { appMessage.error(error instanceof Error ? error.message : "删除会话失败"); }
                                }}
                            >
                                删除
                            </Button>
                        </>
                    }
                >
                    <p className="text-sm opacity-60">将删除 {deleteChatIds.length} 条对话记录，此操作不可撤销</p>
                </Modal>

            {/* 缩放手柄：浮窗=右下角；停靠=左边缘调宽度 */}
            {docked ? (
                <div
                    className="absolute bottom-0 left-0 z-50 h-20 w-1.5 cursor-ew-resize touch-none transition hover:bg-white/20"
                    onPointerDown={beginDockResize}
                    aria-label="调整停靠宽度"
                    title="拖动调整停靠宽度"
                />
            ) : (
                <div
                    className="absolute bottom-0 right-0 z-50 size-5 cursor-nwse-resize touch-none"
                    onPointerDown={beginFloatInteraction("resize")}
                    onDoubleClick={resetFloatRect}
                    aria-label="调整窗口大小"
                    title="拖动调整大小；双击回到默认"
                />
            )}
        </motion.div>
        {mediaAsk ? (
            <Modal
                open
                title={mediaAsk.kind === "image" ? "Agent 生成图片 · 确认参数" : "Agent 生成视频 · 确认参数"}
                centered
                okText="开始生成"
                cancelText="取消"
                onOk={() => {
                    const overrides: Record<string, unknown> = { size: mediaAskSize };
                    if (mediaAsk.kind === "video") overrides.seconds = mediaAskSeconds;
                    mediaAsk.resolve({ confirmed: true, overrides });
                }}
                onCancel={() => mediaAsk.resolve({ confirmed: false, overrides: {} })}
            >
                <div className="space-y-4 py-2">
                    <div>
                        <div className="mb-2 text-xs opacity-60">画面比例</div>
                        <div className="flex flex-wrap gap-2">
                            {(mediaAsk.kind === "image" ? IMAGE_ASK_SIZES : VIDEO_ASK_SIZES).map((value) => (
                                <button
                                    key={value}
                                    type="button"
                                    onClick={() => setMediaAskSize(value)}
                                    className="rounded-full border px-3 py-1 text-xs transition"
                                    style={mediaAskSize === value ? { borderColor: theme.node.activeStroke, color: theme.node.activeStroke, background: theme.toolbar.activeBg } : { borderColor: theme.node.stroke, color: theme.node.text }}
                                >
                                    {value}
                                </button>
                            ))}
                        </div>
                    </div>
                    {mediaAsk.kind === "video" ? (
                        <div>
                            <div className="mb-2 text-xs opacity-60">视频时长（秒）</div>
                            <div className="flex flex-wrap gap-2">
                                {VIDEO_ASK_SECONDS.map((value) => (
                                    <button
                                        key={value}
                                        type="button"
                                        onClick={() => setMediaAskSeconds(value)}
                                        className="rounded-full border px-3 py-1 text-xs transition"
                                        style={mediaAskSeconds === value ? { borderColor: theme.node.activeStroke, color: theme.node.activeStroke, background: theme.toolbar.activeBg } : { borderColor: theme.node.stroke, color: theme.node.text }}
                                    >
                                        {value}s
                                    </button>
                                ))}
                            </div>
                        </div>
                    ) : null}
                    <div className="text-xs opacity-55">提示词：{String(mediaAsk.args?.prompt || "").slice(0, 120) || "（沿用对话内容）"}</div>
                </div>
            </Modal>
        ) : null}
        </>
    );
}

function AssistantPanelCard({ title, children, actions }: { title: string; children: ReactNode; actions: PanelCardAction[] }) {
    const theme = canvasThemes[useThemeStore((state) => state.theme)];
    return <section className="mx-2 overflow-hidden rounded-xl border" style={{ background: theme.node.fill, borderColor: theme.node.stroke }} aria-label={title}>
        <div className="min-w-0 px-3 py-2.5">
            <div className="break-words text-sm font-medium">{title}</div>
            <div className="mt-1">{children}</div>
        </div>
        <div className="flex border-t" style={{ borderColor: theme.node.stroke }}>
            {actions.map((action, index) => <button key={action.label} type="button" className={cn("h-9 min-w-0 flex-1 cursor-pointer bg-transparent text-sm", index > 0 && "border-l", action.danger && "font-medium")} style={{ borderColor: theme.node.stroke, color: action.danger ? "#ef4444" : theme.node.text }} onClick={action.onClick}>{action.label}</button>)}
        </div>
    </section>;
}

const ASSISTANT_MARKDOWN_COMPONENTS: Components = {
    a: ({ node: _node, ...props }) => <a {...props} target="_blank" rel="noreferrer" className="font-medium underline underline-offset-4" />,
};

function AssistantMarkdown({ children, components }: { children: string; components: Components }) {
    const theme = canvasThemes[useThemeStore((state) => state.theme)];

    return (
        <div
            className={cn(
                "min-w-0 whitespace-normal break-words",
                "[&_p]:my-2 [&_p:first-child]:mt-0 [&_p:last-child]:mb-0",
                "[&_h1]:mb-2 [&_h1]:mt-4 [&_h1]:text-lg [&_h1]:font-semibold [&_h1:first-child]:mt-0",
                "[&_h2]:mb-2 [&_h2]:mt-4 [&_h2]:text-base [&_h2]:font-semibold [&_h2:first-child]:mt-0",
                "[&_h3]:mb-1.5 [&_h3]:mt-3 [&_h3]:font-semibold [&_h3:first-child]:mt-0",
                "[&_h4]:my-2 [&_h4]:font-semibold",
                "[&_ul]:my-2 [&_ul]:list-disc [&_ul]:pl-5 [&_ol]:my-2 [&_ol]:list-decimal [&_ol]:pl-5 [&_li]:my-1",
                "[&_blockquote]:my-2 [&_blockquote]:border-l-2 [&_blockquote]:border-[color:var(--agent-markdown-border)] [&_blockquote]:pl-3 [&_blockquote]:opacity-80",
                "[&_hr]:my-3 [&_hr]:border-0 [&_hr]:border-t [&_hr]:border-[color:var(--agent-markdown-border)]",
                "[&_code]:rounded [&_code]:bg-[var(--agent-markdown-surface)] [&_code]:px-1.5 [&_code]:py-0.5 [&_code]:font-mono [&_code]:text-[0.85em]",
                "[&_pre]:my-2 [&_pre]:overflow-x-auto [&_pre]:rounded-lg [&_pre]:bg-[var(--agent-markdown-surface)] [&_pre]:p-3",
                "[&_pre_code]:bg-transparent [&_pre_code]:p-0",
                "[&_table]:my-2 [&_table]:w-full [&_table]:border-collapse [&_th]:border-b [&_th]:border-[color:var(--agent-markdown-border)] [&_th]:px-2 [&_th]:py-1.5 [&_th]:text-left [&_td]:border-b [&_td]:border-[color:var(--agent-markdown-border)] [&_td]:px-2 [&_td]:py-1.5",
            )}
            style={
                {
                    "--agent-markdown-surface": theme.toolbar.itemHover,
                    "--agent-markdown-border": theme.node.stroke,
                } as CSSProperties
            }
        >
            <ReactMarkdown remarkPlugins={[remarkGfm]} components={components} skipHtml>
                {children}
            </ReactMarkdown>
        </div>
    );
}

function AssistantMessages({ messages, nodeById, onFocusNode, onRetry, codexMode }: { messages: CanvasAssistantMessage[]; nodeById: ReadonlyMap<string, CanvasNodeData>; onFocusNode: (nodeId: string) => void; onRetry: (message: CanvasAssistantMessage) => void; codexMode?: boolean }) {
    const theme = canvasThemes[useThemeStore((state) => state.theme)];
    const copyText = useCopyText();
    const markdownComponents = useMemo<Components>(() => ({
        ...ASSISTANT_MARKDOWN_COMPONENTS,
        code: ({ node, className, children, ...props }) => {
            const canvasNode = nodeById.get(String(children).trim());
            if (node?.position?.start.line === node?.position?.end.line && canvasNode) {
                const { Icon, label: typeLabel } = ASSISTANT_NODE_TYPE_META[canvasNode.type];
                const hasImage = isCanvasImageNodeType(canvasNode.type) && canvasNode.metadata?.content;
                return (
                    <span className="my-1 flex w-full min-w-0 items-center rounded-lg transition-opacity hover:opacity-80" style={{ background: theme.toolbar.itemHover }}>
                        <button type="button" onClick={() => onFocusNode(canvasNode.id)} className="flex min-w-0 flex-1 items-center gap-3 px-2 py-2 text-left outline-none" title={`定位到画布节点：${canvasNode.title || typeLabel}`}>
                            <span className="grid size-10 shrink-0 place-items-center overflow-hidden rounded-md">
                                {hasImage ? <img src={canvasNode.metadata?.content} alt={canvasNode.title || typeLabel} className="size-full object-cover" /> : <Icon className="size-5 opacity-60" />}
                            </span>
                            <span className="min-w-0 flex-1 space-y-0.5">
                                <span className="block truncate text-sm font-medium leading-snug">{canvasNode.title || `${typeLabel}节点`}</span>
                                <span className="block truncate text-xs leading-snug opacity-50">{canvasNode.type === CanvasNodeType.Text ? canvasNode.metadata?.content || canvasNode.metadata?.prompt || "" : typeLabel}</span>
                            </span>
                            {canvasNode.metadata?.status && canvasNode.metadata.status !== "idle" ? <span className="size-1.5 shrink-0 rounded-full" style={{ background: ASSISTANT_NODE_STATUS_COLOR[canvasNode.metadata.status] || "transparent" }} /> : null}
                        </button>
                    </span>
                );
            }
            return <code {...props} className={className}>{children}</code>;
        },
    }), [nodeById, onFocusNode, theme]);
    let previousUserSkills: CanvasAgentSkillSelection[] = [];

    return (
        <>
            {messages.map((message) => {
                const running = message.status === "thinking" || message.status === "running";
                const showSkills = message.skillsSelected ?? Boolean(message.skills?.length && !sameSkillSelections(message.skills, previousUserSkills));
                if (message.role === "user") previousUserSkills = message.skills || [];
                return (
                    <div key={message.id} className={cn("flex flex-col gap-2", message.role === "user" ? "items-end" : "items-start")}>
                        {message.text ? (
                            <div
                                className="max-w-[88%] whitespace-pre-wrap rounded-2xl px-3 py-2 text-sm leading-6"
                                style={
                                    message.role === "user"
                                        ? { background: theme.toolbar.activeBg, color: theme.toolbar.activeText }
                                        : message.status === "error"
                                            ? { background: theme.node.fill, color: theme.node.text }
                                            : { background: theme.node.fill, color: theme.node.text }
                                }
                            >
                                {message.role === "assistant" ? (
                                    <div className="mb-1 flex items-center gap-1.5 text-xs opacity-60">
                                        <Bot className="size-3.5" />
                                        {codexMode ? "Codex" : "Agent"}
                                    </div>
                                ) : null}
                                {message.role === "assistant" ? <AssistantMarkdown components={markdownComponents}>{message.text}</AssistantMarkdown> : <UserMessageContent message={message} showSkills={showSkills} />}
                            </div>
                        ) : null}
                        {running ? <ImageGenerationPending compact label={message.activity || "正在执行"} className="w-[250px] rounded-2xl border" /> : null}
                        {!running && message.text ? (
                            <div className="flex gap-1">
                                <Button shape="circle" size="small" style={{ borderColor: theme.node.stroke }} icon={<Copy className="size-3.5" />} onClick={() => copyText(message.text, "消息已复制")} title="复制" />
                                {message.role === "assistant" ? <Button shape="circle" size="small" style={{ borderColor: theme.node.stroke }} icon={<RotateCcw className="size-3.5" />} onClick={() => onRetry(message)} title="重试" /> : null}
                            </div>
                        ) : null}
                    </div>
                );
            })}
        </>
    );
}

function AssistantHistory({
    sessions,
    activeSession,
    checkedIds,
    onToggleChecked,
    onOpen,
    onRename,
    onDelete,
}: {
    sessions: CanvasAssistantSession[];
    activeSession: CanvasAssistantSession | null;
    checkedIds: string[];
    onToggleChecked: (id: string, checked: boolean) => void;
    onOpen: (id: string) => void;
    onRename: (id: string, title: string) => void;
    onDelete: (id: string) => void;
}) {
    const theme = canvasThemes[useThemeStore((state) => state.theme)];
    const [editingId, setEditingId] = useState<string | null>(null);

    return (
        <div className="space-y-1">
            {sessions.map((session) => (
                <div key={session.id} className="group flex items-center gap-2 rounded-lg px-2 py-1.5 transition" style={session.id === activeSession?.id ? { background: theme.node.fill } : undefined}>
                    <input type="checkbox" className="size-4" style={{ accentColor: theme.node.text }} checked={checkedIds.includes(session.id)} onChange={(event) => onToggleChecked(session.id, event.target.checked)} />
                    <div className="min-w-0 flex-1 text-sm">
                        {editingId === session.id ? (
                            <input
                                autoFocus
                                defaultValue={session.title}
                                onBlur={(event) => {
                                    const title = event.currentTarget.value.trim();
                                    if (title && title !== session.title) onRename(session.id, title);
                                    setEditingId(null);
                                }}
                                onKeyDown={(event) => event.key === "Enter" && event.currentTarget.blur()}
                                className="block w-full rounded-sm bg-transparent outline-none"
                                style={{ color: theme.node.text, boxShadow: `inset 0 0 0 1px ${theme.node.muted}` }}
                            />
                        ) : (
                            <button type="button" className="block w-full text-left" onClick={() => onOpen(session.id)}>
                                <span className="block truncate">{session.title}</span>
                            </button>
                        )}
                        <span className="block text-xs opacity-50">{session.messages.length} 条消息</span>
                    </div>
                    <Button type="text" shape="circle" size="small" className="opacity-0 transition group-hover:opacity-100" icon={<Pencil className="size-3.5" />} onClick={() => setEditingId(session.id)} title="重命名" />
                    <Button type="text" shape="circle" size="small" className="opacity-0 transition group-hover:opacity-100" icon={<Trash2 className="size-3.5" />} onClick={() => onDelete(session.id)} title="删除" />
                </div>
            ))}
        </div>
    );
}

function UserMessageContent({ message, showSkills }: { message: CanvasAssistantMessage; showSkills: boolean }) {
    const references = useMemo(() => message.references?.map(assistantToPromptReference) || [], [message.references]);
    return <CanvasPromptChipInput value={message.text} references={references} skills={showSkills ? message.skills : undefined} onChange={ignorePromptChange} readOnly />;
}

function ignorePromptChange() {}

function sameSkillSelections(left: CanvasAgentSkillSelection[] = [], right: CanvasAgentSkillSelection[] = []) {
    return left.length === right.length && left.every((skill, index) => skill.id === right[index]?.id && skill.source === right[index]?.source);
}

function nodeToReference(node: CanvasNodeData, resource: CanvasResourceReference): CanvasAssistantReference | null {
    const content = assistantReferenceContentFromNode(node);
    return content ? { id: node.id, type: node.type, title: node.title, label: resource.label, ...content } : null;
}

function createSession(provider: "api" | "codex"): CanvasAssistantSession {
    const now = new Date().toISOString();
    return {
        id: nanoid(),
        provider,
        title: "新对话",
        messages: [],
        agentState: createCanvasAgentState(),
        protocolMessages: [],
        createdAt: now,
        updatedAt: now,
    };
}
