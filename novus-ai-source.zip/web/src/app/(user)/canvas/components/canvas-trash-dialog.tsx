"use client";

import { useState } from "react";
import { Button, Empty, Modal } from "antd";
import { RotateCcw, Trash2 } from "lucide-react";

import { useCanvasStore } from "../stores/use-canvas-store";
import { useCanvasUiStore } from "../stores/use-canvas-ui-store";

export function CanvasTrashDialog() {
    const open = useCanvasUiStore((state) => state.trashOpen);
    const setTrashOpen = useCanvasUiStore((state) => state.setTrashOpen);
    const trash = useCanvasStore((state) => state.trash);
    const restoreProjects = useCanvasStore((state) => state.restoreProjects);
    const deleteForever = useCanvasStore((state) => state.deleteForever);
    const emptyTrash = useCanvasStore((state) => state.emptyTrash);
    const [pendingForever, setPendingForever] = useState<string | null>(null);
    const [pendingEmpty, setPendingEmpty] = useState(false);

    const items = [...trash].sort(
        (a, b) => Date.parse(b.deletedAt || b.updatedAt || "") - Date.parse(a.deletedAt || a.updatedAt || ""),
    );

    const close = () => {
        setPendingForever(null);
        setPendingEmpty(false);
        setTrashOpen(false);
    };

    return (
        <Modal
            title={`回收站${trash.length ? `（${trash.length}）` : ""}`}
            open={open}
            centered
            width={640}
            onCancel={close}
            footer={
                <>
                    <Button onClick={close}>关闭</Button>
                    {trash.length ? (
                        pendingEmpty ? (
                            <Button danger type="primary" onClick={() => { emptyTrash(); setPendingEmpty(false); }}>
                                确认清空全部
                            </Button>
                        ) : (
                            <Button danger onClick={() => setPendingEmpty(true)}>清空回收站</Button>
                        )
                    ) : null}
                </>
            }
        >
            {items.length ? (
                <div className="canvas-trash-list">
                    {items.map((project) => {
                        const deleted = project.deletedAt
                            ? new Date(project.deletedAt).toLocaleString("zh-CN", { month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" })
                            : "未知时间";
                        const confirming = pendingForever === project.id;
                        return (
                            <div className="canvas-trash-item" key={project.id}>
                                <div className="canvas-trash-info">
                                    <strong>{project.title || "未命名画布"}</strong>
                                    <span>{project.nodes.length} 个节点 · {project.connections.length} 条连线</span>
                                    <span className="canvas-trash-time">删除于 {deleted}</span>
                                </div>
                                <div className="canvas-trash-actions">
                                    <Button size="small" icon={<RotateCcw className="size-3.5" />} onClick={() => restoreProjects([project.id])}>
                                        还原
                                    </Button>
                                    {confirming ? (
                                        <Button size="small" danger type="primary" onClick={() => { deleteForever([project.id]); setPendingForever(null); }}>
                                            确认删除
                                        </Button>
                                    ) : (
                                        <Button size="small" danger icon={<Trash2 className="size-3.5" />} onClick={() => setPendingForever(project.id)}>
                                            彻底删除
                                        </Button>
                                    )}
                                </div>
                            </div>
                        );
                    })}
                </div>
            ) : (
                <Empty description="回收站是空的" image={Empty.PRESENTED_IMAGE_SIMPLE} />
            )}
        </Modal>
    );
}
