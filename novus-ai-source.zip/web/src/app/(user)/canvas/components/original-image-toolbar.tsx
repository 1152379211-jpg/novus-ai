"use client";

import { CanvasNodeType, type CanvasNodeData, type ViewportTransform } from "../types";
import { isCanvasImageNodeType } from "../utils/canvas-panorama";

/* ============================================================
   任务 03：原版「图片节点上方工具栏」（LibTV 源码 aq + ToolbarButton）
   JSX 结构 / className / 内联 style / SVG path / 文案 逐字抄自
   ui-original-separated/03-图片节点上方工具栏/03-image-node-toolbar.html
   （容器类经 chunk flex-end__aq__1an1x1_484152.js 交叉验证，剔除脚手架类 toolbar-demo）
   样式变量与工具类在 original-canvas-ui.css 的 .original-ui-scope 内钉死
   触发：单选图片节点时显示（03 语义「单击图片节点后的图片工具栏」）。
   现有 CanvasNodeHoverToolbar 代码保留未删，但其在页面 mousedown 处被
   setToolbarNodeId(null) 禁用（功能已迁右键菜单），故两栏不会同屏冲突。
   ============================================================ */

type TbIcon = {
    viewBox: string;
    d: string;
    transform?: string;
};

const ICON_PORTRAIT: TbIcon = {
    viewBox: "0 0 16 16",
    d: "M5.39 0a3.7 3.7 0 0 1 3.7 3.7v4.45c.53.24.97.64 1.3 1.09.55.73.87 1.63.97 2.38.08.68-.49 1.14-1.05 1.14H1.1c-.73 0-1.33-.73-1-1.48.37-.82.87-1.56 1.41-2.19q.9-1.03 1.72-1.63a2.6 2.6 0 0 1-1.54-2.23V3.71A3.7 3.7 0 0 1 5.38 0m2.54 8.94c-1.04 0-1.28.57-2.1 1.21-.4.31-.9.57-1.61.56-.6 0-1.3-.2-2.18-.62a8 8 0 0 0-.98 1.6v.01h9.25a4 4 0 0 0-.76-1.83c-.43-.57-.97-.93-1.62-.93M5.4 1.05q-.58 0-1.07.22A2.56 2.56 0 0 1 6.8 3.83v1.28c0 1.06-.64 1.96-1.56 2.35-.66.3-1.52.83-2.48 1.8.66.3 1.13.4 1.47.4.4 0 .68-.13.95-.34.52-.4 1.23-1.43 2.75-1.43h.11V3.71A2.66 2.66 0 0 0 5.4 1.05M4.24 2.32c-.83 0-1.51.68-1.51 1.51v1.28a1.51 1.51 0 0 0 3.02 0V3.83c0-.83-.67-1.5-1.5-1.5",
    transform: "translate(2.315 1.62)",
};
const ICON_PANORAMA: TbIcon = {
    viewBox: "0 0 19.17 16.38",
    d: "M1.7 8.92c.12-.08.28.01.28.16a.2.2 0 0 1-.07.14q-.64.6-.66 1.3c0 1.42 2.2 2.63 5.31 3.11v-1.25c0-.28.32-.44.54-.27l2.27 1.75c.26.2.25.6-.01.8L7.09 16.3a.33.33 0 0 1-.53-.27v-.8C2.75 14.69 0 13.13 0 11.28c0-.87.63-1.69 1.7-2.36m15.49.16c0-.15.16-.24.28-.16 1.07.67 1.7 1.49 1.7 2.36 0 1.96-3.1 3.6-7.29 4.05a.2.2 0 0 1-.22-.2v-1.2q.01-.16.18-.2c3.5-.39 6.07-1.68 6.08-3.2q-.01-.7-.67-1.3a.2.2 0 0 1-.06-.15M14.36 0a1.9 1.9 0 0 1 1.8 1.11q.24.51.24 1.14V8.4q0 .63-.24 1.14-.25.51-.71.81t-1.09.3a2 2 0 0 1-1.1-.3q-.46-.3-.7-.8a3 3 0 0 1-.24-1.15V2.25q0-.63.25-1.15.25-.5.7-.8.46-.3 1.1-.3M6.18 1.64l-1.53 8.89H3.07l1.56-8.9h-2.3V.1h3.85zM9.15 0q.56 0 .95.18.39.19.63.53t.34.82q.12.48.12 1.06 0 .7-.22 1.52-.2.81-.55 1.66A20 20 0 0 1 8.8 9.01h2.43v1.52H7.06V9a26 26 0 0 0 1.78-3.24q.37-.84.6-1.63.22-.8.22-1.45 0-.47-.1-.87t-.41-.4-.42.4-.1.87v.72H7.12v-.7q0-.62.1-1.12.12-.5.36-.85T8.2.18Q8.58 0 9.15 0m5.21 1.49a.4.4 0 0 0-.39.24q-.12.23-.12.52V8.4q0 .3.12.53a.4.4 0 0 0 .4.23.4.4 0 0 0 .38-.23q.12-.23.12-.53V2.25q0-.3-.12-.54a.4.4 0 0 0-.39-.22",
};
const ICON_MULTI_ANGLE: TbIcon = {
    viewBox: "0 0 21.6 21.8",
    d: "M10.9 0c1.35 0 2.5.77 3.36 1.87.79.99 1.41 2.31 1.84 3.82q.8.23 1.51.52c1.82.75 3.33 1.88 3.92 3.35a.9.9 0 0 1-1.66.68c-.33-.81-1.3-1.69-2.95-2.36a18 18 0 0 0-9.75-.7 18 18 0 0 0-.37 3.72 18 18 0 0 0 .38 3.72 18 18 0 0 0 8.47-.25l-1.95-.95a.9.9 0 1 1 .79-1.62l3.81 1.86a.9.9 0 0 1 .42 1.2l-1.86 3.82a.9.9 0 1 1-1.62-.8l.87-1.77a20 20 0 0 1-8.38.45q.2.55.44 1C9.03 19.29 10.04 20 10.9 20q.33 0 .66-.13a.9.9 0 0 1 .68 1.66q-.64.27-1.34.27c-1.9 0-3.39-1.52-4.34-3.43a13 13 0 0 1-.87-2.26 13 13 0 0 1-2.26-.87C1.53 14.3 0 12.81 0 10.9s1.52-3.39 3.43-4.34a13 13 0 0 1 2.26-.87q.36-1.24.87-2.26C7.51 1.53 9 0 10.9 0M5.25 7.73q-.55.2-1.02.44c-1.71.86-2.43 1.87-2.43 2.73s.72 1.87 2.43 2.73q.47.23 1.02.44a20 20 0 0 1 0-6.34M10.9 1.8c-.86 0-1.87.72-2.73 2.43q-.24.47-.44 1.02a20 20 0 0 1 6.33 0 8 8 0 0 0-1.2-2.26c-.68-.85-1.36-1.19-1.96-1.19",
};
const ICON_RELIGHT: TbIcon = {
    viewBox: "0 0 16 16",
    d: "M8 11.73c.33 0 .6.27.6.6V14a.6.6 0 0 1-1.2 0v-1.67c0-.33.27-.6.6-.6m-4.02-1.55a.6.6 0 0 1 .85.84l-.94.94a.6.6 0 0 1-.85-.85zm7.2 0a.6.6 0 0 1 .85 0l.93.93a.6.6 0 0 1-.85.85l-.93-.94a.6.6 0 0 1 0-.84m-.51-3.78c.33 0 .6.27.6.6a3.27 3.27 0 0 1-6.54 0 .6.6 0 1 1 1.2 0 2.07 2.07 0 1 0 4.14 0c0-.33.27-.6.6-.6m-8 0a.6.6 0 0 1 0 1.2H1.33a.6.6 0 0 1 0-1.2zm12 0a.6.6 0 0 1 0 1.2h-1.34a.6.6 0 0 1 0-1.2zm0-2.67a.6.6 0 0 1 0 1.2H1.33a.6.6 0 0 1 0-1.2zM12 1.4a.6.6 0 0 1 0 1.2H4a.6.6 0 0 1 0-1.2z",
};
const ICON_NINE_GRID: TbIcon = {
    viewBox: "0 0 19.8 19.8",
    d: "M16.9 0c1.6 0 2.9 1.3 2.9 2.9v14c0 1.6-1.3 2.9-2.9 2.9h-14A2.9 2.9 0 0 1 0 16.9v-14C0 1.3 1.3 0 2.9 0zM1.8 16.9c0 .6.5 1.1 1.1 1.1H6v-4.2H1.8zm6 1.1H12v-4.2H7.8zm6 0h3.1c.6 0 1.1-.5 1.1-1.1v-3.1h-4.2zm-12-6H6V7.8H1.8zm6 0H12V7.8H7.8zm6 0H18V7.8h-4.2zM2.9 1.8c-.6 0-1.1.5-1.1 1.1V6H6V1.8zM7.8 6H12V1.8H7.8zm6 0H18V2.9c0-.6-.5-1.1-1.1-1.1h-3.1z",
};
const ICON_HD: TbIcon = {
    viewBox: "0 0 20 20",
    d: "M16.75 0C18.55 0 20 1.45 20 3.25v13.5c0 1.8-1.45 3.25-3.25 3.25H3.08A3.25 3.25 0 0 1 0 16.75V3.25A3.25 3.25 0 0 1 3.08 0zM3.25 1.5c-.97 0-1.75.78-1.75 1.75v13.5c0 .97.78 1.75 1.75 1.75h13.5c.97 0 1.75-.78 1.75-1.75V3.25c0-.97-.78-1.75-1.75-1.75zm1.87 7.75h2.8V6.08h1.5v8h-1.5v-3.33h-2.8v3.33h-1.5v-8h1.5zm8.16-3.17c1.5.06 3.76.6 3.76 4.04s-2.33 3.9-3.78 3.95H11v-8h2zm-.79 6.5h.5c.65 0 1.3-.08 1.75-.37.33-.2.8-.67.8-2.09 0-1.43-.47-1.93-.8-2.15-.45-.3-1.1-.4-1.75-.4h-.5z",
};
const ICON_ELEMENT_EDIT: TbIcon = {
    viewBox: "0 0 16 16",
    d: "M6.15.12c.32-.16.7-.16 1.03 0l5.5 2.74c.87.43.87 1.67 0 2.1L10.6 6l2.1 1.04c.86.43.86 1.67 0 2.1l-5.5 2.74c-.33.16-.72.16-1.04 0L.65 9.14a1.17 1.17 0 0 1 0-2.1L2.75 6 .64 4.96a1.17 1.17 0 0 1 0-2.1zM7.18 7.7c-.32.17-.7.17-1.03 0L3.86 6.56 1.1 7.94a.17.17 0 0 0 0 .3l5.5 2.74q.07.04.15 0l5.5-2.73a.17.17 0 0 0 0-.31L9.47 6.56zm-.44-6.67a.2.2 0 0 0-.15 0L1.1 3.75a.17.17 0 0 0 0 .31L6.6 6.8q.07.03.15 0l5.5-2.74a.17.17 0 0 0 0-.3z",
    transform: "translate(1.335 2)",
};
const ICON_LAYER_SPLIT: TbIcon = {
    viewBox: "0 0 16 16",
    d: "M9.99 0c.93.05 1.68.82 1.68 1.77v8.22c-.05.9-.78 1.63-1.68 1.67H1.77A1.75 1.75 0 0 1 0 10V1.77C0 .79.8 0 1.77 0zM1.77 1.05c-.4 0-.72.32-.72.72V9.9c0 .4.32.72.72.72H9.9c.4 0 .72-.32.72-.72V1.77c0-.4-.32-.72-.72-.72zm6.51 7.43a.53.53 0 0 1 0 1.04H3.56a.53.53 0 0 1 0-1.04zM5.9 2.07c.27 0 .5.2.52.47v1.85h1.81l.05.01a.53.53 0 0 1 0 1.05H6.43v1.8a.53.53 0 0 1-1.06 0v-1.8h-1.8a.53.53 0 0 1 0-1.05h1.8V2.54a.53.53 0 0 1 .53-.47",
    transform: "translate(1 1) translate(0.9617 1.1667)",
};
const ICON_GRID_CUT: TbIcon = {
    viewBox: "0 0 16 16",
    d: "M4.76 2c.22 0 .4.18.4.4v1.72h5.71V2.4c0-.22.18-.4.4-.4h.24c.22 0 .4.18.4.4v1.72h1.69c.22 0 .4.17.4.4v.24a.4.4 0 0 1-.4.4h-1.69v5.71h1.69c.22 0 .4.18.4.4v.24a.4.4 0 0 1-.4.4h-1.69v1.69a.4.4 0 0 1-.4.4h-.24a.4.4 0 0 1-.4-.4v-1.69H5.16v1.69a.4.4 0 0 1-.4.4h-.24a.4.4 0 0 1-.4-.4v-1.69H2.4a.4.4 0 0 1-.4-.4v-.24c0-.22.18-.4.4-.4h1.72V5.16H2.4a.4.4 0 0 1-.4-.4v-.24c0-.23.18-.4.4-.4h1.72V2.4c0-.22.17-.4.4-.4zm.4 8.87h5.71V5.16H5.16z",
};
const ICON_ANNOTATE: TbIcon = {
    viewBox: "0 0 16.71 17.34",
    d: "M9.29.23q.75-.29 1.5-.21.77.1 1.32.73c.41.5.46 1.1.34 1.65-.13.54-.42 1.1-.78 1.63a31 31 0 0 1-2.9 3.45A29 29 0 0 0 6 10.78q-.47.75-.57 1.2c-.06.3 0 .45.1.56q.14.2.42.18.35-.02.98-.37c.84-.48 1.83-1.34 2.85-2.3 1-.94 2.04-1.96 2.92-2.66.43-.35.87-.66 1.28-.84.36-.16.88-.29 1.35 0l.09.06.16.14q.53.48.65 1.15c.08.49-.02.98-.19 1.42-.32.88-.99 1.83-1.6 2.7-.64.9-1.23 1.72-1.55 2.45-.31.73-.24 1.09 0 1.34q.26.23.49.23.26.02.66-.15a8 8 0 0 0 1.8-1.32l.44.48.43.48a9 9 0 0 1-2.14 1.54c-.39.18-.83.3-1.29.27a2 2 0 0 1-1.3-.6c-.83-.84-.66-1.9-.28-2.79.38-.88 1.07-1.83 1.68-2.69.64-.9 1.19-1.7 1.44-2.39q.18-.5.13-.75a.7.7 0 0 0-.28-.43l-.17.05q-.37.16-.99.66c-.82.66-1.8 1.62-2.84 2.6a19 19 0 0 1-3.1 2.48c-.49.28-1.02.5-1.54.53-.56.04-1.1-.15-1.5-.62-.42-.5-.49-1.1-.37-1.66a5 5 0 0 1 .75-1.66C5.62 9 6.74 7.78 7.81 6.6a30 30 0 0 0 2.78-3.3q.49-.72.59-1.19c.07-.29.01-.43-.07-.52a.7.7 0 0 0-.5-.28q-.31-.06-.88.14c-.77.28-1.7.9-2.75 1.73C4.89 4.86 2.66 7.2.88 8.86L0 7.9c1.68-1.58 4.03-4.03 6.17-5.74A12 12 0 0 1 9.29.23",
};
const ICON_ROTATE: TbIcon = {
    viewBox: "0 0 16 16",
    d: "M8.6 14.67H7.4V12h1.2zM6.84 5.01 5.62 7.39l-1.07-.55.3-.57q-.75.17-1.34.4-.84.35-1.24.73c-.26.25-.34.45-.34.6s.08.36.34.6q.4.38 1.24.73c1.12.45 2.7.74 4.49.74 1.78 0 3.37-.29 4.5-.74q.83-.34 1.23-.72c.26-.25.34-.46.34-.6 0-.16-.08-.36-.34-.61q-.4-.38-1.24-.73c-.83-.33-1.92-.57-3.16-.68V4.8c1.38.1 2.62.38 3.6.77q.99.39 1.63.97c.4.39.7.89.7 1.47 0 .59-.3 1.09-.7 1.48q-.65.57-1.62.97c-1.3.51-3.04.82-4.94.82s-3.64-.3-4.94-.82a5 5 0 0 1-1.62-.97A2 2 0 0 1 .74 8c0-.58.3-1.08.7-1.47q.64-.58 1.62-.97.76-.3 1.68-.5l-.58-.38.66-1zM8.6 9.34H7.4v-8h1.2z",
};
const ICON_DOWNLOAD: TbIcon = {
    viewBox: "0 0 19.8 19.9",
    d: "M1.8 17a1.1 1.1 0 0 0 1.1 1.1h14A1.1 1.1 0 0 0 18 17v-4h1.8v4a2.9 2.9 0 0 1-2.9 2.9h-14A2.9 2.9 0 0 1 0 17v-4h1.8zm9-5.17 3.46-3.47 1.28 1.28-5 5a.9.9 0 0 1-1.28 0l-5-5 1.28-1.28L9 11.83V0h1.8z",
};
const ICON_PREVIEW: TbIcon = {
    viewBox: "0 0 24 24",
    d: "M4.15 12c.22 0 .4.18.4.4v5.54l5.26-5.26a.4.4 0 0 1 .57 0l.7.7a.4.4 0 0 1 0 .58L5.94 19.1h5.3c.23 0 .4.18.4.4v1a.4.4 0 0 1-.4.4h-7.7a.8.8 0 0 1-.8-.8v-7.7c0-.22.19-.4.4-.4zm15.6-8.9c.44 0 .8.36.8.8v7.7a.4.4 0 0 1-.4.4h-1a.4.4 0 0 1-.4-.4V6.24l-5.2 5.19a.4.4 0 0 1-.56 0l-.7-.7a.4.4 0 0 1 0-.57l5.25-5.26h-5.5a.4.4 0 0 1-.4-.4v-1c0-.22.19-.4.4-.4z",
};

/* className 逐字抄快照 */
const TEXT_BTN_CLASS = "text-canvas-controls-text inline-flex h-8 select-none items-center justify-center gap-1 rounded-lg px-2 py-2 transition-colors hover:bg-canvas-controls-hover active:bg-canvas-controls-active cursor-pointer";
/* boss 2026-10-04：箭头指的 7 个功能置灰=暂不可用（不禁 hover 背景以外的交互，点击无效） */
const GREYED_CLASS = " opacity-40 cursor-not-allowed hover:bg-transparent active:bg-transparent pointer-events-none";
const ICON_BTN_CLASS = "text-canvas-controls-text inline-flex h-8 w-8 min-w-8 items-center justify-center rounded-lg p-2 hover:bg-canvas-controls-hover";
const LABEL_CLASS = "whitespace-nowrap text-[13px]";
const NEW_BADGE_CLASS = "ml-0.5 flex h-5 w-[42px] shrink-0 items-center justify-center rounded-full bg-[#3CB5CC40] text-[12px] font-bold uppercase leading-none text-[#5DDCFF]";
const DIVIDER_CLASS = "mx-0.5 min-h-8 w-px shrink-0 self-stretch bg-[var(--canvas-controls-border)]";

function TbSvg({ icon }: { icon: TbIcon }) {
    return (
        <svg width="16" height="16" viewBox={icon.viewBox} fill="none" xmlns="http://www.w3.org/2000/svg" className="" aria-hidden="true">
            <path d={icon.d} fill="currentColor" transform={icon.transform} />
        </svg>
    );
}

/* 下拉箭头 12×12（快照两种：人像=上箭头 rotate-180，九宫格/高清/宫格切分=下箭头） */
function ChevronSvg({ up }: { up?: boolean }) {
    return (
        <svg width="12" height="12" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" className={up ? "rotate-180 opacity-80" : "opacity-80"} aria-hidden="true">
            {up ? (
                <path d="M3.16.2a.7.7 0 0 1 .99 0l3.04 3.05a.4.4 0 0 1 0 .56l-.43.43a.4.4 0 0 1-.56 0L3.65 1.69 1.11 4.24a.4.4 0 0 1-.57 0L.12 3.8a.4.4 0 0 1 0-.56z" fill="currentColor" transform="translate(4.345 5.825)" />
            ) : (
                <path d="M6.2.12a.4.4 0 0 1 .56 0l.43.42a.4.4 0 0 1 0 .57L4.15 4.15a.7.7 0 0 1-1 0L.13 1.1a.4.4 0 0 1 0-.57L.54.12a.4.4 0 0 1 .57 0l2.54 2.54z" fill="currentColor" transform="translate(4.345 5.825)" />
            )}
        </svg>
    );
}

export function OriginalImageToolbar({
    node,
    viewport,
    onUpscale,
    onSplit,
    onAngle,
    onTransform,
    onViewImage,
    onDownload,
    onAnnotate,
}: {
    node: CanvasNodeData | null;
    viewport: ViewportTransform;
    onUpscale: (node: CanvasNodeData) => void;
    onSplit: (node: CanvasNodeData) => void;
    onAngle: (node: CanvasNodeData) => void;
    /** 任务rDjmof：旋转与镜像——拎出独立新节点并进入变换模式 */
    onTransform: (node: CanvasNodeData) => void;
    onViewImage: (node: CanvasNodeData) => void;
    onDownload: (node: CanvasNodeData) => void;
    onAnnotate: (node: CanvasNodeData) => void;
}) {
    if (!node || !isCanvasImageNodeType(node.type) || !node.metadata?.content) return null;

    /* 与现有悬停栏同一坐标公式（贴节点上方 14px）；驱动来源为「单选图片节点」。
       注：现有悬停栏在 mousedown 处被 setToolbarNodeId(null) 禁用（功能已迁右键菜单），
       故原版栏不再需要为其让位，直接放在原版语义位置。 */
    const left = viewport.x + (node.position.x + node.width / 2) * viewport.k;
    const top = viewport.y + node.position.y * viewport.k - 14;

    return (
        <div className="original-ui-scope absolute z-[71] -translate-x-1/2 -translate-y-full" style={{ left, top }}>
            <div
                data-guide-surface="toolbar"
                className="border-hair bg-panel-background border-canvas-controls-border box-border flex w-fit items-center justify-center gap-2 rounded-xl p-2"
                style={{ boxShadow: "var(--canvas-shadow-dropdown)" }}
            >
                <button className={TEXT_BTN_CLASS + GREYED_CLASS} type="button" data-unwired="true" aria-disabled="true" title="暂不可用">
                    <TbSvg icon={ICON_PORTRAIT} />
                    <span className={LABEL_CLASS}>人像质感调节</span>
                    <span className={NEW_BADGE_CLASS}>NEW</span>
                    <ChevronSvg up />
                </button>
                <button className={TEXT_BTN_CLASS + GREYED_CLASS} type="button" data-unwired="true" aria-disabled="true" title="暂不可用">
                    <TbSvg icon={ICON_PANORAMA} />
                    <span className={LABEL_CLASS}>全景</span>
                </button>
                <button className={TEXT_BTN_CLASS + GREYED_CLASS} type="button" aria-disabled="true" title="暂不可用">
                    <TbSvg icon={ICON_MULTI_ANGLE} />
                    <span className={LABEL_CLASS}>多角度</span>
                </button>
                <button className={TEXT_BTN_CLASS + GREYED_CLASS} type="button" data-unwired="true" aria-disabled="true" title="暂不可用">
                    <TbSvg icon={ICON_RELIGHT} />
                    <span className={LABEL_CLASS}>打光</span>
                </button>
                <div className={DIVIDER_CLASS} />
                <button className={TEXT_BTN_CLASS + GREYED_CLASS} type="button" data-unwired="true" aria-disabled="true" title="暂不可用">
                    <TbSvg icon={ICON_NINE_GRID} />
                    <span className={LABEL_CLASS}>九宫格</span>
                    <ChevronSvg />
                </button>
                <button className={TEXT_BTN_CLASS} type="button" onClick={() => onUpscale(node)}>
                    <TbSvg icon={ICON_HD} />
                    <span className={LABEL_CLASS}>高清</span>
                    <ChevronSvg />
                </button>
                <button className={TEXT_BTN_CLASS + GREYED_CLASS} type="button" data-unwired="true" aria-disabled="true" title="暂不可用">
                    <TbSvg icon={ICON_ELEMENT_EDIT} />
                    <span className={LABEL_CLASS}>元素编辑</span>
                </button>
                <button className={TEXT_BTN_CLASS + GREYED_CLASS} type="button" data-unwired="true" aria-disabled="true" title="暂不可用">
                    <TbSvg icon={ICON_LAYER_SPLIT} />
                    <span className={LABEL_CLASS}>图层分离</span>
                </button>
                <button className={TEXT_BTN_CLASS} type="button" onClick={() => onSplit(node)}>
                    <TbSvg icon={ICON_GRID_CUT} />
                    <span className={LABEL_CLASS}>宫格切分</span>
                    <ChevronSvg />
                </button>
                <div className={DIVIDER_CLASS} />
                {/* 078：标注接线——进入照片内涂鸦模式（非破坏性笔迹层，可换色/粗细/撤销/清空） */}
                <button className={ICON_BTN_CLASS} type="button" onClick={() => onAnnotate(node)} aria-label="标注" title="涂鸦标注">
                    <TbSvg icon={ICON_ANNOTATE} />
                </button>
                <button className={ICON_BTN_CLASS} type="button" onClick={() => onTransform(node)} aria-label="旋转与镜像" title="旋转与镜像">
                    <TbSvg icon={ICON_ROTATE} />
                </button>
                <button className={ICON_BTN_CLASS} type="button" onClick={() => onDownload(node)} aria-label="下载" data-testid="image-toolbar-download">
                    <TbSvg icon={ICON_DOWNLOAD} />
                </button>
                <button className={ICON_BTN_CLASS} type="button" onClick={() => onViewImage(node)} aria-label="预览">
                    <TbSvg icon={ICON_PREVIEW} />
                </button>
            </div>
        </div>
    );
}
