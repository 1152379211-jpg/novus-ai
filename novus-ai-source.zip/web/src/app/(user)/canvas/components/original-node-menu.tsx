"use client";

import { useEffect, useRef } from "react";
import type { ReactNode } from "react";
import { Globe2, Settings2 } from "lucide-react";
import { CanvasNodeType } from "../types";

/* ============================================================
   任务 02：原版「双击添加节点菜单」（LibTV 源码模块 859654 / node-type-menu）
   JSX 结构 / className / 内联 style / SVG path / 文案 逐字抄自
   ui-original-separated/02-双击添加节点菜单/02-add-node-menu.html
   样式变量与工具类在 original-canvas-ui.css 的 .original-ui-scope 内钉死
   挂载逻辑复用现有菜单（fixed 锚点 + 点外关闭），009 Portal 控制器原版未提供
   ============================================================ */

type MenuIconDef = {
    viewBox: string;
    d: string;
    transform?: string;
    fillOpacity?: number;
};

/* 图标 path 全部逐字抄自快照（svg width=16 height=16 fill=none class="" aria-hidden） */
const ICON_TEXT: MenuIconDef = {
    viewBox: "0 0 16 16",
    d: "M13.6 14c.22 0 .4.18.4.4v.7a.4.4 0 0 1-.4.4H.4a.4.4 0 0 1-.4-.4v-.7c0-.22.18-.4.4-.4zm0-6.92c.22 0 .4.18.4.4v.7a.4.4 0 0 1-.4.4H.4a.4.4 0 0 1-.4-.4v-.7c0-.22.18-.4.4-.4zm6-7.08c.22 0 .4.18.4.4v.7a.4.4 0 0 1-.4.4H.4a.4.4 0 0 1-.4-.4V.4C0 .18.18 0 .4 0z",
    transform: "translate(0 1.8) scale(0.8)",
};
const ICON_IMAGE: MenuIconDef = {
    viewBox: "0 0 16 16",
    d: "M7.6.97c.22 0 .4.18.4.4v.5a.4.4 0 0 1-.4.4H2.27a.97.97 0 0 0-.97.97V13.7l.01.15 6.73-5.23a3.65 3.65 0 0 1 4.82.3l.84.84V8.8c0-.22.18-.4.4-.4h.5c.22 0 .4.18.4.4v4.9l-.01.23a2.3 2.3 0 0 1-2.03 2.03l-.23.01H2.27c-1.17 0-2.14-.9-2.26-2.04L0 13.7V3.24A2.27 2.27 0 0 1 2.27.97zm4.34 8.87a2.35 2.35 0 0 0-3.1-.2l-6.46 5.03h10.35c.53 0 .97-.44.97-.97v-2.1zM5 4.47a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3M12.4.15c.07-.2.35-.2.42 0l.81 2.19 2.2.81c.19.07.19.35 0 .42l-2.2.8-.81 2.2c-.07.2-.35.2-.42 0l-.8-2.2-2.2-.8a.22.22 0 0 1 0-.42l2.2-.81z",
    transform: "translate(0.015 0.015)",
};
const ICON_VIDEO: MenuIconDef = {
    viewBox: "0 0 16 16",
    d: "M7.6.97c.22 0 .4.18.4.4v.5a.4.4 0 0 1-.4.4H2.27a.97.97 0 0 0-.97.97V13.7c0 .53.44.97.97.97h10.46c.53 0 .97-.44.97-.97V9.26c0-.22.18-.4.4-.4h.5c.22 0 .4.18.4.4v4.44l-.01.23a2.3 2.3 0 0 1-2.03 2.03l-.23.01H2.27c-1.17 0-2.14-.9-2.26-2.04L0 13.7V3.24A2.27 2.27 0 0 1 2.27.97zM4.85 5.51c0-.97 1.12-1.5 1.86-.87l3.74 3.12.1.09c.42.45.4 1.16-.03 1.6l-.1.08-3.75 2.86c-.74.57-1.82.04-1.82-.9zm1.3 5.64 3.31-2.53-3.31-2.76zm5.92-11c.07-.2.34-.2.42 0l.8 2.19 2.2.81c.2.07.2.35 0 .42l-2.2.8-.8 2.2c-.08.2-.35.2-.42 0l-.81-2.2-2.2-.8a.22.22 0 0 1 0-.42l2.2-.81z",
    transform: "translate(0.18 0.015)",
};
const ICON_SMART_CLIP: MenuIconDef = {
    viewBox: "0 0 20 20",
    d: "M10 14.17c.35 0 .63.28.63.62v2.92a.62.62 0 1 1-1.26 0v-2.92c0-.34.28-.62.63-.62M4.1 4.1a.63.63 0 0 1 .9 0l5.44 5.45c.25.24.25.64 0 .88L5 15.9a.63.63 0 0 1-.88-.88l4.38-4.38H2.3a.62.62 0 1 1 0-1.26h6.2L4.11 5a.6.6 0 0 1 0-.88m8.85 8.84a.63.63 0 0 1 .88 0L15.9 15a.63.63 0 0 1-.88.88l-2.06-2.06a.6.6 0 0 1 0-.88m4.76-3.57a.62.62 0 1 1 0 1.24H14.8a.62.62 0 1 1 0-1.24zM15 4.1a.63.63 0 0 1 .88.88l-2.06 2.06a.63.63 0 0 1-.88-.88zm-5-2.43c.35 0 .63.28.63.62v2.92a.62.62 0 1 1-1.26 0V2.29c0-.34.28-.62.63-.62",
};
const ICON_DIRECTOR: MenuIconDef = {
    viewBox: "0 0 20 20",
    d: "M15.83 2.5c1.15 0 2.09.93 2.09 2.08v2.09c0 .8-.66 1.46-1.46 1.46H15v7.5c0 1.03-.84 1.87-1.87 1.87H3.95a2.3 2.3 0 0 1-2.3-2.3v-.82c0-.81.66-1.46 1.47-1.46h1.04v-1.67a.62.62 0 1 1 1.25 0v1.67h5.62c.8 0 1.46.65 1.46 1.46v1.24a.62.62 0 1 0 1.25 0V4.59q0-.45.18-.83H8.75a.62.62 0 1 1 0-1.25zM3.13 14.17a.2.2 0 0 0-.21.2v.84c0 .57.46 1.04 1.04 1.04h7.4q-.1-.3-.11-.62v-1.26a.2.2 0 0 0-.2-.2zM5 2.5c.2 0 .38.12.45.31l.45 1.17c.17.44.52.78.96.95l1.16.45a.49.49 0 0 1 0 .9l-1.16.45c-.44.17-.79.52-.96.96l-.45 1.17a.49.49 0 0 1-.9 0L4.1 7.69a1.7 1.7 0 0 0-.96-.96L1.98 6.3a.49.49 0 0 1 0-.91l1.16-.45c.44-.17.79-.51.96-.95l.45-1.17A.5.5 0 0 1 5 2.5m10.83 1.25a.83.83 0 0 0-.83.83v2.3h1.46c.11 0 .2-.1.2-.21V4.58a.83.83 0 0 0-.83-.83",
    fillOpacity: 0.9,
};
const ICON_FRAME_RIP: MenuIconDef = {
    viewBox: "0 0 19.17 16.38",
    d: "M1.7 8.92c.12-.08.28.01.28.16a.2.2 0 0 1-.07.14q-.64.6-.66 1.3c0 1.42 2.2 2.63 5.31 3.11v-1.25c0-.28.32-.44.54-.27l2.27 1.75c.26.2.25.6-.01.8L7.09 16.3a.33.33 0 0 1-.53-.27v-.8C2.75 14.69 0 13.13 0 11.28c0-.87.63-1.69 1.7-2.36m15.49.16c0-.15.16-.24.28-.16 1.07.67 1.7 1.49 1.7 2.36 0 1.96-3.1 3.6-7.29 4.05a.2.2 0 0 1-.22-.2v-1.2q.01-.16.18-.2c3.5-.39 6.07-1.68 6.08-3.2q-.01-.7-.67-1.3a.2.2 0 0 1-.06-.15M14.36 0a1.9 1.9 0 0 1 1.8 1.11q.24.51.24 1.14V8.4q0 .63-.24 1.14-.25.51-.71.81t-1.09.3a2 2 0 0 1-1.1-.3q-.46-.3-.7-.8a3 3 0 0 1-.24-1.15V2.25q0-.63.25-1.15.25-.5.7-.8.46-.3 1.1-.3M6.18 1.64l-1.53 8.89H3.07l1.56-8.9h-2.3V.1h3.85zM9.15 0q.56 0 .95.18.39.19.63.53t.34.82q.12.48.12 1.06 0 .7-.22 1.52-.2.81-.55 1.66A20 20 0 0 1 8.8 9.01h2.43v1.52H7.06V9a26 26 0 0 0 1.78-3.24q.37-.84.6-1.63.22-.8.22-1.45 0-.47-.1-.87t-.41-.4-.42.4-.1.87v.72H7.12v-.7q0-.62.1-1.12.12-.5.36-.85T8.2.18Q8.58 0 9.15 0m5.21 1.49a.4.4 0 0 0-.39.24q-.12.23-.12.52V8.4q0 .3.12.53a.4.4 0 0 0 .4.23.4.4 0 0 0 .38-.23q.12-.23.12-.53V2.25q0-.3-.12-.54a.4.4 0 0 0-.39-.22",
};
const ICON_AUDIO: MenuIconDef = {
    viewBox: "0 0 20 20",
    d: "M8.33 1.75c.42 0 .75.34.75.75v15a.75.75 0 0 1-1.5 0v-15c0-.41.34-.75.75-.75M15 8.83c.41 0 .75.34.75.75V15a.75.75 0 0 1-1.5 0V9.58c0-.41.34-.75.75-.75M5 4.25c.41 0 .75.34.75.75v9.17a.75.75 0 0 1-1.5 0V5c0-.41.34-.75.75-.75m6.67 1.67c.41 0 .75.33.75.75v5.83a.75.75 0 0 1-1.5 0V6.67c0-.42.33-.75.75-.75m-10 1.66c.41 0 .75.34.75.75v2.5a.75.75 0 0 1-1.5 0v-2.5c0-.41.33-.75.75-.75m16.66 0c.42 0 .75.34.75.75v2.5a.75.75 0 0 1-1.5 0v-2.5c0-.41.33-.75.75-.75M15.53.84c.1-.29.5-.29.62 0l.76 2.06q.05.14.2.2l2.05.75c.29.11.29.52 0 .63l-2.06.76q-.14.05-.2.2l-.75 2.05a.33.33 0 0 1-.63 0l-.76-2.05a.3.3 0 0 0-.2-.2l-2.05-.76a.33.33 0 0 1 0-.63l2.05-.76q.15-.05.2-.2z",
};
/* 脚本：快照里图标 path 与导演台完全一致（照抄，不"优化"） */
const ICON_SCRIPT: MenuIconDef = { ...ICON_DIRECTOR };
const ICON_LIBRARY: MenuIconDef = {
    viewBox: "0 0 20 20",
    d: "M9.9 0a3 3 0 0 1 2 .91l1.46 1.51a.5.5 0 0 0 .26.15H17a3 3 0 0 1 3 3v11.58A3 3 0 0 1 17.15 20H2.85A3 3 0 0 1 0 17.15V3a3 3 0 0 1 2.85-3zM1.8 17c0 .66.54 1.2 1.2 1.2h14c.66 0 1.2-.54 1.2-1.2V9.79H1.8zM3 1.8c-.66 0-1.2.54-1.2 1.2v4.99h16.4V5.58c0-.67-.54-1.2-1.2-1.2h-3.28a2.3 2.3 0 0 1-1.65-.7L10.6 2.16a1.2 1.2 0 0 0-.86-.36z",
};
const ICON_UPLOAD: MenuIconDef = {
    viewBox: "0 0 19.8 19.8",
    d: "M1.8 16.9A1.1 1.1 0 0 0 2.9 18h14a1.1 1.1 0 0 0 1.1-1.1V12h1.8v4.9a2.9 2.9 0 0 1-2.9 2.9h-14A2.9 2.9 0 0 1 0 16.9V12h1.8zM9.33.2a.9.9 0 0 1 1.2.06l5.64 5.64-1.27 1.27-4.1-4.1V13.8H9V3.07l-4.1 4.1L3.63 5.9 9.26.26z",
};
const ICON_HISTORY: MenuIconDef = {
    viewBox: "0 0 20 20",
    d: "M17.08 10a7.08 7.08 0 1 0-14.16 0 7.08 7.08 0 0 0 14.16 0m-7.7-3.54a.62.62 0 1 1 1.24 0v3.28l2.11 2.11a.63.63 0 0 1-.88.88l-2.3-2.29a.6.6 0 0 1-.18-.44zM18.33 10a8.33 8.33 0 1 1-16.66 0 8.33 8.33 0 0 1 16.66 0",
    fillOpacity: 0.9,
};

/* className 逐字抄快照 */
const ITEM_CLASS = "flex h-9 w-full items-center rounded-[10px] px-2 text-left transition-none hover:bg-canvas-controls-hover";
const ICON_WRAP_CLASS = "mr-2 flex size-5 shrink-0 items-center justify-center rounded-lg bg-canvas-controls-hover";
const LABEL_CLASS = "min-w-0 flex-1 truncate text-[13px]";
const BADGE_BETA_CLASS = "ml-1 rounded px-1 text-[10px] bg-white/15 text-white/55";
const BADGE_CYAN_CLASS = "ml-1 rounded px-1 text-[10px] bg-[#1cc8f0]/25 text-[#5ddcff]";

type MenuAction =
    | { kind: "create"; nodeType: CanvasNodeType }
    | { kind: "upload" }
    | { kind: "assetLibrary" }
    | { kind: "history" }
    | { kind: "unwired" };

type NodeMenuItem = {
    label: string;
    /** 原版快照图标（fill path 逐字）；自研新增项无原版依据时用 lucide */
    icon?: MenuIconDef;
    lucide?: ReactNode;
    badge?: { text: string; className: string };
    action: MenuAction;
    /** 功能未实现：置灰不可点（boss 2026-10-04：不删除先置灰） */
    greyed?: boolean;
};

const NODE_ITEMS: NodeMenuItem[] = [
    { label: "文本", icon: ICON_TEXT, action: { kind: "create", nodeType: CanvasNodeType.Text } },
    { label: "图片", icon: ICON_IMAGE, action: { kind: "create", nodeType: CanvasNodeType.Image } },
    { label: "视频", icon: ICON_VIDEO, action: { kind: "create", nodeType: CanvasNodeType.Video } },
    { label: "智能剪辑", icon: ICON_SMART_CLIP, badge: { text: "Beta", className: BADGE_BETA_CLASS }, action: { kind: "unwired" }, greyed: true },
    { label: "导演台", icon: ICON_DIRECTOR, badge: { text: "NEW", className: BADGE_CYAN_CLASS }, action: { kind: "create", nodeType: CanvasNodeType.Director } },
    { label: "逐帧拉片", icon: ICON_FRAME_RIP, badge: { text: "SD 2.5", className: BADGE_CYAN_CLASS }, action: { kind: "unwired" }, greyed: true },
    { label: "音频", icon: ICON_AUDIO, action: { kind: "create", nodeType: CanvasNodeType.Audio } },
    // 自研功能项（双击空白菜单并入，boss 2026-10-04 确认）：原版菜单无此两项，图标沿用原双击菜单 lucide 语义
    { label: "全景图", lucide: <Globe2 size={16} />, action: { kind: "create", nodeType: CanvasNodeType.Panorama }, greyed: true },
    { label: "配置节点", lucide: <Settings2 size={16} />, action: { kind: "create", nodeType: CanvasNodeType.Config } },
    { label: "脚本", icon: ICON_SCRIPT, badge: { text: "›", className: BADGE_CYAN_CLASS }, action: { kind: "unwired" }, greyed: true },
    { label: "素材库", icon: ICON_LIBRARY, badge: { text: "›", className: BADGE_CYAN_CLASS }, action: { kind: "assetLibrary" } },
];

const RESOURCE_ITEMS: NodeMenuItem[] = [
    { label: "上传", icon: ICON_UPLOAD, action: { kind: "upload" } },
    { label: "从生成历史选择", icon: ICON_HISTORY, action: { kind: "history" } },
];

export function OriginalNodeMenu({
    screenAnchor,
    position,
    onCreate,
    onUpload,
    onOpenAssetLibrary,
    onOpenHistory,
    onClose,
}: {
    /** 屏幕固定锚点（fixed 定位、底部对齐、水平居中于导航＋按钮）；与 position 二选一 */
    screenAnchor?: { left: number; bottom: number };
    /** 世界坐标锚点（双击空白触发：absolute 定位在世界容器内、随缩放反缩放保持屏幕尺寸） */
    position?: { x: number; y: number };
    onCreate: (type: CanvasNodeType) => void;
    onUpload: () => void;
    onOpenAssetLibrary: () => void;
    onOpenHistory: () => void;
    onClose: () => void;
}) {
    const menuRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handlePointerDown = (event: PointerEvent) => {
            // 点在触发按钮（底栏＋）上时不走外点关闭——交给按钮自身的 toggle 关掉，避免「先外点关、后 onClick 又开」
            if ((event.target as HTMLElement | null)?.closest?.('[data-sidebar-btn="add-node"]')) return;
            if (menuRef.current && !menuRef.current.contains(event.target as Node)) onClose();
        };
        document.addEventListener("pointerdown", handlePointerDown, true);
        return () => document.removeEventListener("pointerdown", handlePointerDown, true);
    }, [onClose]);

    const runAction = (action: MenuAction) => {
        switch (action.kind) {
            case "create":
                onCreate(action.nodeType);
                break;
            case "upload":
                onUpload();
                break;
            case "assetLibrary":
                onOpenAssetLibrary();
                break;
            case "history":
                onOpenHistory();
                break;
            case "unwired":
                break;
        }
    };

    const renderItem = (item: NodeMenuItem) => (
        <button
            key={item.label}
            type="button"
            className={item.greyed
                ? `${ITEM_CLASS.replace("hover:bg-canvas-controls-hover", "hover:bg-transparent")} opacity-40 cursor-not-allowed pointer-events-none`
                : ITEM_CLASS}
            style={{ color: "var(--canvas-controls-text)" }}
            data-unwired={item.action.kind === "unwired" || item.greyed ? "true" : undefined}
            aria-disabled={item.greyed ? true : undefined}
            onClick={() => runAction(item.action)}
        >
            <span className={ICON_WRAP_CLASS}>
                {item.lucide ?? (
                    <svg width="16" height="16" viewBox={item.icon!.viewBox} fill="none" xmlns="http://www.w3.org/2000/svg" className="" aria-hidden="true">
                        <path d={item.icon!.d} fill="currentColor" transform={item.icon!.transform} fillOpacity={item.icon!.fillOpacity} />
                    </svg>
                )}
            </span>
            <span className={LABEL_CLASS}>{item.label}</span>
            {item.badge ? <span className={item.badge.className}>{item.badge.text}</span> : null}
        </button>
    );

    const rootStyle = position
        ? { position: "absolute" as const, left: position.x, top: position.y, transform: "scale(var(--canvas-inverse-scale, 1))", transformOrigin: "top left", zIndex: 120 }
        : { position: "fixed" as const, left: screenAnchor!.left, bottom: screenAnchor!.bottom, transform: "translateX(-50%)", zIndex: 120 };

    return (
        <div
            ref={menuRef}
            className="original-ui-scope"
            data-canvas-no-zoom
            style={rootStyle}
            onPointerDown={(event) => event.stopPropagation()}
        >
            <div
                className="border-canvas-controls-border flex min-w-[220px] w-max flex-col rounded-2xl border p-1.5"
                style={{ backgroundColor: "var(--canvas-controls-bg)", boxShadow: "var(--canvas-shadow-menu)" }}
            >
                <div className="flex items-center justify-between px-2 py-1">
                    <span className="text-canvas-controls-text text-[13px] font-medium">添加节点</span>
                    <svg width="16" height="16" viewBox="0 0 20.5 20.91" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-canvas-controls-icon opacity-80" aria-hidden="true">
                        <path d="M9.04 0a9.04 9.04 0 0 1 6.86 14.92l4.6 4.58-1.42 1.41-4.64-4.63A9.04 9.04 0 1 1 9.04 0m0 2a7.04 7.04 0 1 0 0 14.08A7.04 7.04 0 0 0 9.04 2" fill="currentColor" />
                    </svg>
                </div>
                {NODE_ITEMS.map(renderItem)}
                <div className="px-2 pb-1 pt-2 text-[12px] text-canvas-controls-text opacity-50">添加资源</div>
                {RESOURCE_ITEMS.map(renderItem)}
            </div>
        </div>
    );
}
