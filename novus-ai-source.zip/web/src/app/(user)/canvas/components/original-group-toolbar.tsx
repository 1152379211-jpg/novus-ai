"use client";

import "./original-canvas-ui.css";
import { useState, useRef, useEffect, useCallback } from "react";

/**
 * 原版组节点工具栏（选中单个 Group 时显示在组框正上方）
 *
 * 结构 / className / 内联 style / 文案 / SVG 逐字抄自
 *   group-toolbar.html（= 013 chunk GroupNodeToolbar 的渲染结果，boss 给定正常态真值）
 *   + 013__GroupNodeToolbar_run-group-hand-cue__1an1x1akb2vnr_832426.js（弹层状态机 / 菜单层级 / 样式常量）
 *
 * 样式真值（GROUP_TOOLBAR_ROW_STYLE / 组工具栏容器 C / 按钮 k / 颜色数组 N，快照+boss 给定）：
 *   y = padding:8px; gap:8px; borderRadius:12; border:0.5px solid var(--canvas-controls-border);
 *       background:var(--canvas-controls-bg); box-shadow:0 4px 10px rgba(0,0,0,.08); backdrop-filter:blur(16px)
 *   组工具栏容器 C = {...y, padding:4px, gap:4px, borderRadius:14}
 *   按钮 k = "flex h-9 items-center justify-center rounded-[10px] transition-colors hover:bg-canvas-controls-hover
 *            text-[13px] select-none cursor-pointer text-canvas-controls-text px-2 gap-1.5"
 *   颜色数组 N = #7A7A7A #E74C3C #F28A2E #F4B740 #2ECC71 #08B6DD #3B82F6 #8B5CF6 #F63B97 #E6E6E6
 *   默认无色 = #B8B8B8；分隔线 I = "mx-0.5 h-6 w-px shrink-0 self-center bg-[var(--canvas-controls-border)]"
 *   颜色面板 padding:12px; width:max-content；grid-cols-5 gap-3；外层 h-9 w-9；内层 h-7 w-7；选中 outline 2px solid + offset 2
 *   排版菜单 padding:4px; width:max-content; minWidth:120px；项 px-3 py-2 rounded-md text-sm
 *   弹层 portal 到 body、fixed、translateY(-100%) translateY(-8px)（颜色）/ translate(-50%,-100%) translateY(-8px)（排版）、zIndex var(--z-sticky)、outside mousedown 关闭
 *
 * 替换项（仅依赖差异，结构/样式/文案/图标不动）：
 *   1. i18n hook t(key) → 渲染稿中文文案硬编码（整组执行 / 添加到工具箱 / 转分镜组 / 解组 / 网格布局 / 水平布局 / 垂直布局）
 *   2. Mantine Icons.Icon* → 渲染稿内联 SVG（path 逐字）：IconAutoArrange/chevronDown/IconPlay/IconToolBox/
 *      IconGroupStoryboard/IconUngroup/IconDownload/layoutGrid/workflow/list
 *   3. Mantine Tooltip（包裹按钮的 hover 提示）→ 不实现（渲染稿 DOM 无 tooltip 层；仅 hover 提示，无结构影响）
 *   4. useCanvasThemeStore 主题 + canvas-light 类 → 弹层包 original-ui-scope（本项目 CSS 变量作用域），不引入主题 store
 *   5. run-group-hand-cue 手势提示 SVG（w 组件）→ 不渲染（仅 isGroupRunning/storyboardV2 时出现，本项目无等价运行态）
 *   6. React Flow nodrag/nopan/nowheel + 视口 transform 订阅 → 外层包 original-ui-scope + 世界坐标定位 +
 *      --canvas-inverse-scale 反缩放（与 original-multi-selection-toolbar 同款）；内层 onMouseDown/onPointerDown stopPropagation
 *
 * 数据适配（仅边界，结构/样式/文案不动）：
 *   - 组颜色：原版 groupColor prop（null 时显式 #B8B8B8）→ 本项目 metadata.groupColor（null 时同样 #B8B8B8）
 *   - 解组：原版 onUngroup(L) → 本项目 ungroupSelection()
 *   - 排版：原版 onLayoutChange(_) → 本项目 layoutGroupChildren(mode)（012 chunk 算法 + 常量 36/36/66，grid 列数 min(5,max(1,ceil(sqrt(n))))）
 *   - 整组执行 / 添加到工具箱 / 转分镜组 / 批量下载 / 批量生成视频：项目无等价业务 →
 *     ① 批量生成视频：原版按 showBatchGenerateVideo 条件不渲染 → 本项目不传该 prop，按钮不渲染（与渲染稿一致）
 *     ② 转分镜组、批量下载：渲染稿中即禁用态（opacity-45 cursor-not-allowed）→ 保留禁用态，点击无效，标 data-unwired
 *     ③ 整组执行、添加到工具箱：渲染稿正常态（有等价按钮位但无业务）→ 保留可视，点击无效，标 data-unwired
 *     以上全部列入交付「缺失功能清单」
 */

type GroupLayoutMode = "grid" | "horizontal" | "vertical";

const GROUP_TOOLBAR_ROW_STYLE: React.CSSProperties = {
    padding: "8px",
    gap: "8px",
    borderRadius: 12,
    border: "0.5px solid var(--canvas-controls-border)",
    background: "var(--canvas-controls-bg)",
    boxShadow: "0px 4px 10px 0px rgba(0, 0, 0, 0.08)",
    backdropFilter: "blur(16px)",
};

const GROUP_TOOLBAR_CONTAINER_STYLE: React.CSSProperties = {
    ...GROUP_TOOLBAR_ROW_STYLE,
    padding: "4px",
    gap: "4px",
    borderRadius: 14,
};

const GROUP_TOOLBAR_BUTTON_CLASS =
    "flex h-9 items-center justify-center rounded-[10px] transition-colors hover:bg-canvas-controls-hover text-[13px] select-none cursor-pointer text-canvas-controls-text px-2 gap-1.5";

const GROUP_COLORS = [
    "#7A7A7A",
    "#E74C3C",
    "#F28A2E",
    "#F4B740",
    "#2ECC71",
    "#08B6DD",
    "#3B82F6",
    "#8B5CF6",
    "#F63B97",
    "#E6E6E6",
];

const DEFAULT_GROUP_COLOR = "#B8B8B8";

function GroupToolbarDivider() {
    return (
        <div
            className="mx-0.5 h-6 w-px shrink-0 self-center bg-[var(--canvas-controls-border)]"
            aria-hidden="true"
        />
    );
}

function GroupColorPanel({
    currentColor,
    onSelect,
}: {
    currentColor: string | null;
    onSelect: (color: string | null) => void;
}) {
    return (
        <div
            style={{
                ...GROUP_TOOLBAR_ROW_STYLE,
                padding: "12px",
                width: "max-content",
            }}
        >
            <div className="grid grid-cols-5 gap-3">
                {GROUP_COLORS.map((color) => {
                    const selected = color === currentColor;
                    return (
                        <div
                            key={color}
                            className="flex h-9 w-9 cursor-pointer items-center justify-center rounded-full transition-transform hover:scale-110"
                            style={{
                                outline: selected ? `2px solid ${color}` : "none",
                                outlineOffset: 2,
                            }}
                            onClick={(event) => {
                                event.stopPropagation();
                                onSelect(selected ? null : color);
                            }}
                        >
                            <div
                                className="h-7 w-7 rounded-full"
                                style={{ background: color }}
                            />
                        </div>
                    );
                })}
            </div>
        </div>
    );
}

function GroupLayoutMenu({
    onSelect,
    onClose,
}: {
    onSelect: (mode: GroupLayoutMode) => void;
    onClose: () => void;
}) {
    const itemClass =
        "text-canvas-controls-text hover:bg-canvas-controls-hover flex cursor-pointer items-center gap-2 rounded-md px-3 py-2 text-sm transition-colors";
    return (
        <div
            className="flex flex-col gap-1"
            style={{
                ...GROUP_TOOLBAR_ROW_STYLE,
                padding: "4px",
                width: "max-content",
                minWidth: "120px",
            }}
        >
            <div
                className={itemClass}
                onClick={(event) => {
                    event.stopPropagation();
                    onSelect("grid");
                }}
            >
                <svg width="16" height="16" viewBox="0 0 19.8 19.8" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                    <path d="M6.9 11c1.05 0 1.9.85 1.9 1.9v5a1.9 1.9 0 0 1-1.9 1.9h-5A1.9 1.9 0 0 1 0 17.9v-5C0 11.85.85 11 1.9 11zm11 0c1.05 0 1.9.85 1.9 1.9v5a1.9 1.9 0 0 1-1.9 1.9h-5a1.9 1.9 0 0 1-1.9-1.9v-5c0-1.05.85-1.9 1.9-1.9zm-16 1.8a.1.1 0 0 0-.1.1v5q.01.1.1.1h5a.1.1 0 0 0 .1-.1v-5a.1.1 0 0 0-.1-.1zm11 0a.1.1 0 0 0-.1.1v5q.01.1.1.1h5a.1.1 0 0 0 .1-.1v-5a.1.1 0 0 0-.1-.1zM6.9 0c1.05 0 1.9.85 1.9 1.9v5a1.9 1.9 0 0 1-1.9 1.9h-5A1.9 1.9 0 0 1 0 6.9v-5C0 .85.85 0 1.9 0zm11 0c1.05 0 1.9.85 1.9 1.9v5a1.9 1.9 0 0 1-1.9 1.9h-5A1.9 1.9 0 0 1 11 6.9v-5c0-1.05.85-1.9 1.9-1.9zm-16 1.8a.1.1 0 0 0-.1.1v5q.01.1.1.1h5a.1.1 0 0 0 .1-.1v-5a.1.1 0 0 0-.1-.1zm11 0a.1.1 0 0 0-.1.1v5q.01.1.1.1h5a.1.1 0 0 0 .1-.1v-5a.1.1 0 0 0-.1-.1z" fill="currentColor" />
                </svg>
                <span>网格布局</span>
            </div>
            <div
                className={itemClass}
                onClick={(event) => {
                    event.stopPropagation();
                    onSelect("horizontal");
                }}
            >
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                    <path d="M12.25 11.03a1.22 1.22 0 1 0-2.45 0 1.22 1.22 0 0 0 2.45 0M6.9 2.33q1.32-.01 2.09.05.4.03.7.1.31.1.58.32c.42.4.6.99.5 1.56q-.09.34-.3.58-.2.25-.5.5-.6.49-1.69 1.24L5.91 8.35q-1.09.77-1.6 1.19-.27.22-.37.35l-.08.13q-.06.34.19.6l.14.06q.16.04.5.07.67.05 2 .04h.54a.53.53 0 0 1 0 1.05H6.7q-1.31.01-2.09-.04-.39-.03-.7-.11t-.58-.31a1.7 1.7 0 0 1-.5-1.56q.09-.34.3-.59t.5-.5q.6-.48 1.69-1.23l2.37-1.68q1.08-.76 1.6-1.18.27-.23.37-.36l.08-.13a.6.6 0 0 0-.18-.6L9.4 3.5a3 3 0 0 0-.5-.08q-.67-.05-2-.04h-.25a.53.53 0 0 1 0-1.05zm-2.82.53a1.22 1.22 0 1 0-2.45 0 1.22 1.22 0 0 0 2.45 0m9.22 8.17a2.28 2.28 0 1 1-4.55 0 2.28 2.28 0 0 1 4.55 0M5.13 2.86a2.28 2.28 0 1 1-4.55 0 2.28 2.28 0 0 1 4.55 0" fill="currentColor" transform="translate(1 1)" />
                </svg>
                <span>水平布局</span>
            </div>
            <div
                className={itemClass}
                onClick={(event) => {
                    event.stopPropagation();
                    onSelect("vertical");
                }}
            >
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                    <path d="M.81 11.81a.8.8 0 0 1 0 1.6H.8a.8.8 0 1 1 0-1.6zm17.71 0a.8.8 0 0 1 0 1.6H5.72a.8.8 0 1 1 0-1.6zM.81 5.91a.8.8 0 0 1 0 1.6H.8a.8.8 0 1 1 0-1.6zm17.71 0a.8.8 0 0 1 0 1.6H5.72a.8.8 0 1 1 0-1.6zM.81 0a.8.8 0 1 1 0 1.6H.8A.8.8 0 1 1 .8 0zm17.71 0a.8.8 0 1 1 0 1.6H5.72a.8.8 0 1 1 0-1.6z" fill="currentColor" transform="translate(0 2.4472) scale(0.828157)" />
                </svg>
                <span>垂直布局</span>
            </div>
        </div>
    );
}

export type OriginalGroupToolbarProps = {
    /** 世界坐标：组框顶边中点 */
    left: number;
    top: number;
    groupId: string;
    groupColor: string | null;
    onColorChange: (color: string | null) => void;
    onUngroup: () => void;
    onLayoutChange: (mode: GroupLayoutMode) => void;
    /** 024：批量下载整组（阈值逻辑在外部统一处理） */
    onDownloadAll: () => void;
};

export function OriginalGroupToolbar({
    left,
    top,
    groupId,
    groupColor,
    onColorChange,
    onUngroup,
    onLayoutChange,
    onDownloadAll,
}: OriginalGroupToolbarProps) {
    const [colorOpen, setColorOpen] = useState(false);
    const [layoutOpen, setLayoutOpen] = useState(false);
    const [colorBelow, setColorBelow] = useState(false);

    const colorAnchorRef = useRef<HTMLDivElement>(null);
    const layoutAnchorRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handler = (event: MouseEvent) => {
            const target = event.target as Node | null;
            if (colorOpen && !colorAnchorRef.current?.contains(target)) {
                setColorOpen(false);
            }
            if (layoutOpen && !layoutAnchorRef.current?.contains(target)) {
                setLayoutOpen(false);
            }
        };
        if (colorOpen || layoutOpen) {
            document.addEventListener("mousedown", handler);
        }
        return () => document.removeEventListener("mousedown", handler);
    }, [colorOpen, layoutOpen]);

    const openColor = useCallback((event: React.MouseEvent) => {
        event.stopPropagation();
        const el = colorAnchorRef.current;
        // 上方空间不足（<160px）则向下弹出，避免跑出视口
        setColorBelow(el ? el.getBoundingClientRect().top < 160 : false);
        setColorOpen((prev) => !prev);
        setLayoutOpen(false);
    }, []);
    const openLayout = useCallback((event: React.MouseEvent) => {
        event.stopPropagation();
        // 排版菜单只往上弹（原版行为），不做向下翻转
        setLayoutOpen((prev) => !prev);
        setColorOpen(false);
    }, []);
    const handleColorSelect = useCallback(
        (color: string | null) => {
            onColorChange(color);
            setColorOpen(false);
        },
        [onColorChange],
    );
    const handleLayoutSelect = useCallback(
        (mode: GroupLayoutMode) => {
            onLayoutChange(mode);
            setLayoutOpen(false);
        },
        [onLayoutChange],
    );

    return (
        <div className="original-ui-scope">
            <div
                className="nodrag z-(--z-sticky) absolute flex w-max max-w-none flex-nowrap items-center whitespace-nowrap"
                style={{
                    ...GROUP_TOOLBAR_CONTAINER_STYLE,
                    left,
                    top,
                    transform:
                        "translate(-50%, -100%) translateY(calc(-14px * var(--canvas-inverse-scale, 1))) scale(var(--canvas-inverse-scale, 1))",
                    transformOrigin: "center bottom",
                }}
                onMouseDown={(event) => event.stopPropagation()}
                onPointerDown={(event) => event.stopPropagation()}
            >
                {/* 颜色按钮 */}
                <div ref={colorAnchorRef} className="relative">
                    <div
                        className="hover:bg-canvas-controls-hover flex size-10 cursor-pointer items-center justify-center rounded-[10px] transition-colors"
                        onClick={openColor}
                    >
                        <div
                            className="size-5 rounded-full border-[0.5px] border-solid border-[rgba(0,0,0,0.15)]"
                            style={{ background: groupColor ?? DEFAULT_GROUP_COLOR }}
                        />
                    </div>
                    {colorOpen ? (
                        <div
                            className="original-ui-scope nodrag nopan nowheel absolute"
                            style={{
                                left: 0,
                                [colorBelow ? "top" : "bottom"]: "calc(100% + 8px)",
                                zIndex: "var(--z-sticky)",
                            }}
                            onMouseDown={(event) => event.stopPropagation()}
                        >
                            <GroupColorPanel currentColor={groupColor} onSelect={handleColorSelect} />
                        </div>
                    ) : null}
                </div>
                {/* 排版按钮 */}
                <div ref={layoutAnchorRef} className="relative">
                    <div
                        className="hover:bg-canvas-controls-hover flex h-9 cursor-pointer items-center justify-center gap-1 rounded-[10px] px-2"
                        onClick={openLayout}
                    >
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                            <g transform="translate(-8 -8)">
                                <path d="M13.17 21.58c.69 0 1.25.56 1.25 1.25v1.67c0 .69-.56 1.25-1.25 1.25H11.5c-.69 0-1.25-.56-1.25-1.25v-1.67c0-.69.56-1.25 1.25-1.25zm5.66 0c.7 0 1.25.56 1.25 1.25v1.67c0 .69-.56 1.25-1.25 1.25h-1.66c-.7 0-1.25-.56-1.25-1.25v-1.67c0-.69.56-1.25 1.25-1.25zm5.67 0c.69 0 1.25.56 1.25 1.25v1.67c0 .69-.56 1.25-1.25 1.25h-1.67c-.69 0-1.25-.56-1.25-1.25v-1.67c0-.69.56-1.25 1.25-1.25zM13.17 10.25c.69 0 1.25.56 1.25 1.25v1.67c0 .69-.56 1.25-1.25 1.25H11.5c-.69 0-1.25-.56-1.25-1.25V11.5c0-.69.56-1.25 1.25-1.25zm5.66 0c.7 0 1.25.56 1.25 1.25v1.67c0 .69-.56 1.25-1.25 1.25h-1.66c-.7 0-1.25-.56-1.25-1.25V11.5c0-.69.56-1.25 1.25-1.25zm5.67 0c.69 0 1.25.56 1.25 1.25v1.67c0 .69-.56 1.25-1.25 1.25h-1.67c-.69 0-1.25-.56-1.25-1.25V11.5c0-.69.56-1.25 1.25-1.25z" fill="currentColor" fillOpacity=".3" />
                                <path d="M14.42 17.17c0-.7-.56-1.25-1.25-1.25H11.5c-.69 0-1.25.56-1.25 1.25v1.66c0 .7.56 1.25 1.25 1.25h1.67c.69 0 1.25-.56 1.25-1.25zM20.08 17.17c0-.7-.56-1.25-1.25-1.25h-1.66c-.7 0-1.25.56-1.25 1.25v1.66c0 .7.56 1.25 1.25 1.25h1.66c.7 0 1.25-.56 1.25-1.25zM25.75 17.17c0-.7-.56-1.25-1.25-1.25h-1.67c-.69 0-1.25.56-1.25 1.25v1.66c0 .7.56 1.25 1.25 1.25h1.67c.69 0 1.25-.56 1.25-1.25z" fill="currentColor" fillOpacity=".9" />
                            </g>
                        </svg>
                        <svg width="12" height="12" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" className="opacity-60" aria-hidden="true">
                            <path d="M6.2.12a.4.4 0 0 1 .56 0l.43.42a.4.4 0 0 1 0 .57L4.15 4.15a.7.7 0 0 1-1 0L.13 1.1a.4.4 0 0 1 0-.57L.54.12a.4.4 0 0 1 .57 0l2.54 2.54z" fill="currentColor" transform="translate(4.345 5.825)" />
                        </svg>
                    </div>
                    {layoutOpen ? (
                        <div
                            className="original-ui-scope nodrag nopan nowheel absolute"
                            style={{
                                left: "50%",
                                transform: "translateX(-50%)",
                                bottom: "calc(100% + 8px)",
                                zIndex: "var(--z-sticky)",
                            }}
                            onMouseDown={(event) => event.stopPropagation()}
                        >
                            <GroupLayoutMenu onSelect={handleLayoutSelect} onClose={() => setLayoutOpen(false)} />
                        </div>
                    ) : null}
                </div>
                <GroupToolbarDivider />
                {/* 整组执行：项目无等价 pipeline → 保留可视，点击无效 */}
                <div
                    className={GROUP_TOOLBAR_BUTTON_CLASS}
                    data-unwired="true"
                    onClick={(event) => event.stopPropagation()}
                >
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                        <path d="M4.38 5.05a3.13 3.13 0 0 1 4.84-2.61l7.53 4.95a3.13 3.13 0 0 1 .17 5.1l-.17.12-7.53 4.95a3.13 3.13 0 0 1-4.85-2.61zm1.25 9.9c0 1.5 1.65 2.39 2.9 1.57l7.53-4.95a1.88 1.88 0 0 0 0-3.14L8.53 3.48a1.87 1.87 0 0 0-2.9 1.57z" fill="currentColor" fillOpacity=".9" />
                    </svg>
                    <span>整组执行</span>
                </div>
                {/* 024（boss 2026-10-04）：「添加到工具箱」按需求隐藏（打组态不再显示） */}
                {/* 转分镜组：项目无等价业务，渲染稿即禁用态 → 保留禁用，点击无效 */}
                <div
                    className={`${GROUP_TOOLBAR_BUTTON_CLASS} cursor-not-allowed opacity-45`}
                    data-unwired="true"
                    onClick={(event) => event.stopPropagation()}
                >
                    <svg width="20" height="20" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                        <path d="M.63 10c.34 0 .62.28.62.63v1.24c0 1.04.84 1.88 1.88 1.88h1.25a.62.62 0 1 1 0 1.25H3.13A3.1 3.1 0 0 1 0 11.88v-1.26c0-.34.28-.62.63-.62m13.75 0c.34 0 .62.28.62.63v1.24C15 13.6 13.6 15 11.88 15h-1.26a.62.62 0 1 1 0-1.25h1.26c1.03 0 1.87-.84 1.87-1.87v-1.26c0-.34.28-.62.63-.62M7.95 3.33c.55 0 1.07.22 1.45.6l.07.07q.16.16.4.17c.99 0 1.8.8 1.8 1.8v2.57a2.3 2.3 0 0 1-2.3 2.3H5.64a2.3 2.3 0 0 1-2.3-2.3V5.97c0-1 .81-1.8 1.8-1.8q.24 0 .4-.17l.07-.07c.38-.38.9-.6 1.45-.6zm-.9 1.25a.8.8 0 0 0-.57.24l-.07.07c-.34.34-.8.53-1.27.53-.3 0-.56.24-.56.55v2.57c0 .58.47 1.04 1.05 1.04h3.75c.57 0 1.04-.46 1.04-1.04V5.97c0-.3-.25-.55-.56-.55a1.8 1.8 0 0 1-1.27-.53l-.07-.07a.8.8 0 0 0-.57-.24zm.45 1.54a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5M4.38 0a.62.62 0 1 1 0 1.25H3.13c-1.04 0-1.88.84-1.88 1.88v1.25a.62.62 0 1 1-1.25 0V3.13C0 1.4 1.4 0 3.13 0zm7.5 0C13.6 0 15 1.4 15 3.13v1.25a.62.62 0 1 1-1.25 0V3.13c0-1.04-.84-1.88-1.87-1.88h-1.26a.62.62 0 1 1 0-1.25z" fill="currentColor" transform="translate(0.5 0.5)" />
                    </svg>
                    <span>转分镜组</span>
                </div>
                {/* 解组：接 ungroupSelection */}
                <div className={GROUP_TOOLBAR_BUTTON_CLASS} onClick={(event) => { event.stopPropagation(); onUngroup(); }}>
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                        <path d="M17.47 1.64a.62.62 0 1 1 .89.89L2.53 18.36a.63.63 0 0 1-.89-.89z" fill="currentColor" fillOpacity=".9" />
                        <path d="M11.46 16.25a.62.62 0 1 1 0 1.25H8.54a.62.62 0 1 1 0-1.25zm4.79-1.04a.63.63 0 0 1 1.25 0 2.3 2.3 0 0 1-2.3 2.29.63.63 0 0 1 0-1.25c.58 0 1.05-.47 1.05-1.04M2.5 11.46V8.54a.62.62 0 1 1 1.25 0v2.92a.62.62 0 1 1-1.25 0m13.75 0V8.54a.62.62 0 1 1 1.25 0v2.92a.62.62 0 1 1-1.25 0M2.5 4.79v-.04c0-1.24 1-2.25 2.25-2.25a.63.63 0 0 1 0 1.25 1 1 0 0 0-1 1v.04a.63.63 0 0 1-1.25 0m8.96-2.29a.62.62 0 1 1 0 1.25H8.54a.62.62 0 1 1 0-1.25z" fill="currentColor" fillOpacity=".9" />
                    </svg>
                    <span>解组</span>
                </div>
                <GroupToolbarDivider />
                {/* 024（boss 2026-10-04）：批量下载改为真正生效 —— ≤5 个逐个下载、>5 个直接打包 zip */}
                <div
                    className="text-canvas-controls-text hover:bg-canvas-controls-hover flex size-9 cursor-pointer select-none items-center justify-center rounded-[10px] transition-colors"
                    title="下载组内文件（5 个以内逐个下载，超过 5 个打包为 zip）"
                    onClick={(event) => { event.stopPropagation(); onDownloadAll(); }}
                >
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                        <path d="M2.5 14.38v-2.09a.62.62 0 1 1 1.25 0v2.09c0 1.03.84 1.87 1.88 1.87h8.75c1.03 0 1.87-.84 1.87-1.87v-2.09a.62.62 0 1 1 1.25 0v2.09c0 1.72-1.4 3.12-3.12 3.12H5.62a3.1 3.1 0 0 1-3.12-3.12M9.38 3.13a.62.62 0 1 1 1.24 0v7.86l1.85-1.85a.62.62 0 1 1 .89.89l-2.92 2.91a.6.6 0 0 1-.88 0l-2.92-2.91a.62.62 0 1 1 .89-.89L9.37 11z" fill="currentColor" fillOpacity=".9" />
                    </svg>
                </div>
            </div>
        </div>
    );
}
