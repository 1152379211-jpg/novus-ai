"use client";

/**
 * LibTV 原版「快捷键面板」逐字搬运（任务 05）
 * 出处：
 *   - 面板/键帽/图标/combo 归并：chunk 1an1x1akb2vnr.js 模块 981493（c/u/p/g/x/v/b/y/w/C/k/N/S/I/j/E/T/M/R/P/A/D）
 *   - BottomBarPopover/Arrow/clamp/BOTTOM_BAR_POPOVER_GAP：chunk 1blddhgxss0mm.js 模块 16240
 *   - 快捷键 defs：chunk 3-mou5v69wxmq.js 061 注册处（visible:!0 的 17 项，useVisibleShortcutsByGroup 的运行时数据等价物）
 *   - getIsMac：chunk 3u3ydab86zoxk.js 模块 722851
 *   - Close 图标：liblib.tv/icons/libtv.json（libtv:close，viewBox 17.19）
 *   - 文案：词典 chunk 3xjlk8cm1g3m9.js（zh-CN 渲染值）
 * 依赖替换：framer-motion AnimatePresence/BottomBarPopover motion → CSS 入场动画（退出动画未接，直接卸载）；
 *   他们的运行时快捷键注册表 → 静态 defs（061 chunk 提取）；i18n hook → 文案常量表。
 */
import { Fragment, forwardRef, memo, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import type { CSSProperties, ReactNode } from "react";

/* ================= 键工具（模块 981493：d/c/u/p 逐字） ================= */
const MODIFIER_KEYS = new Set(["meta", "ctrl", "shift", "alt"]); // d

// c：键名归一
function normalizeKeyName(e: string): string {
    return "delete" === e || "backspace" === e ? "delete" : "=" === e || "equal" === e || "+" === e || "plus" === e ? "plus" : "-" === e || "minus" === e ? "minus" : e;
}
// u：组合的主键（非修饰键归一后 join |）
function comboKeyOf(e: string[]): string {
    return e.filter((k) => !MODIFIER_KEYS.has(k)).map(normalizeKeyName).join("|");
}
// p：组合的修饰键集合
function comboModsOf(e: string[]): Set<string> {
    return new Set(e.filter((k) => MODIFIER_KEYS.has(k)));
}

/* ================= getIsMac（模块 722851 逐字） ================= */
function getIsMac(): boolean {
    if (typeof navigator === "undefined") return false;
    const uaDataPlatform = (navigator as Navigator & { userAgentData?: { platform?: string } }).userAgentData?.platform ?? "";
    const platform = navigator.platform ?? uaDataPlatform;
    const ua = navigator.userAgent ?? "";
    const isIos = /iPad|iPhone|iPod/i.test(ua);
    const hasTouch = typeof window !== "undefined" && "ontouchend" in window;
    const isMac = /Mac/i.test(platform) || /Mac/i.test(uaDataPlatform);
    return isMac && !isIos && !(isMac && hasTouch);
}

/* ================= 颜色常量（模块 981493：h/f 逐字） ================= */
const ICON_COLOR = "var(--canvas-controls-icon)"; // h
const ACCENT = "#5DDCFF"; // f

/* ================= 图标（模块 981493：g/x/v/b/y/w/C/k/N 逐字） ================= */
// g：Command ⌘
function CommandIcon({ size = 16 }: { size?: number }) {
    return (
        <svg width={size} height={size} viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M10 4V12C10 12.3956 10.1173 12.7822 10.3371 13.1111C10.5568 13.44 10.8692 13.6964 11.2346 13.8478C11.6001 13.9991 12.0022 14.0387 12.3902 13.9616C12.7781 13.8844 13.1345 13.6939 13.4142 13.4142C13.6939 13.1345 13.8844 12.7781 13.9616 12.3902C14.0387 12.0022 13.9991 11.6001 13.8478 11.2346C13.6964 10.8692 13.44 10.5568 13.1111 10.3371C12.7822 10.1173 12.3956 10 12 10H4C3.60444 10 3.21776 10.1173 2.88886 10.3371C2.55996 10.5568 2.30362 10.8692 2.15224 11.2346C2.00087 11.6001 1.96126 12.0022 2.03843 12.3902C2.1156 12.7781 2.30608 13.1345 2.58579 13.4142C2.86549 13.6939 3.22186 13.8844 3.60982 13.9616C3.99778 14.0387 4.39992 13.9991 4.76537 13.8478C5.13082 13.6964 5.44318 13.44 5.66294 13.1111C5.8827 12.7822 6 12.3956 6 12V4C6 3.60444 5.8827 3.21776 5.66294 2.88886C5.44318 2.55996 5.13082 2.30362 4.76537 2.15224C4.39992 2.00087 3.99778 1.96126 3.60982 2.03843C3.22186 2.1156 2.86549 2.30608 2.58579 2.58579C2.30608 2.86549 2.1156 3.22186 2.03843 3.60982C1.96126 3.99778 2.00087 4.39992 2.15224 4.76537C2.30362 5.13082 2.55996 5.44318 2.88886 5.66294C3.21776 5.8827 3.60444 6 4 6H12C12.3956 6 12.7822 5.8827 13.1111 5.66294C13.44 5.44318 13.6964 5.13082 13.8478 4.76537C13.9991 4.39992 14.0387 3.99778 13.9616 3.60982C13.8844 3.22186 13.6939 2.86549 13.4142 2.58579C13.1345 2.30608 12.7781 2.1156 12.3902 2.03843C12.0022 1.96126 11.6001 2.00087 11.2346 2.15224C10.8692 2.30362 10.5568 2.55996 10.3371 2.88886C10.1173 3.21776 10 3.60444 10 4Z" stroke={ICON_COLOR} strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
    );
}
// x：＋（缩放-放大键帽图标）
function PlusKeyIcon({ size = 16 }: { size?: number }) {
    return (
        <svg width={size} height={size} viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g clipPath="url(#clip0_plus)">
                <path d="M7.59985 0.667969C7.45261 0.668004 7.33325 0.787316 7.33325 0.93457V7.33789H0.932861C0.785765 7.3381 0.66626 7.45735 0.66626 7.60449V8.4043C0.66626 8.55144 0.785765 8.67069 0.932861 8.6709H7.33325V15.0684C7.33351 15.2154 7.45276 15.3349 7.59985 15.335H8.39966C8.54678 15.335 8.66601 15.2154 8.66626 15.0684V8.6709H15.0667C15.2139 8.67086 15.3333 8.55155 15.3333 8.4043V7.60449C15.3333 7.45724 15.2139 7.33793 15.0667 7.33789H8.66626V0.93457C8.66626 0.787294 8.54693 0.667969 8.39966 0.667969H7.59985Z" fill={ICON_COLOR} />
            </g>
            <defs>
                <clipPath id="clip0_plus">
                    <rect width={size} height={size} fill="white" transform="matrix(-1 0 0 1 16 0)" />
                </clipPath>
            </defs>
        </svg>
    );
}
// v：－（缩放-缩小键帽图标）
function MinusKeyIcon({ size = 16 }: { size?: number }) {
    return (
        <svg width={size} height={size} viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M1.96582 7.39844C1.89218 7.39844 1.83203 7.45859 1.83203 7.53223V8.46582C1.83214 8.53937 1.89225 8.59863 1.96582 8.59863H13.5654C13.639 8.59863 13.6991 8.53937 13.6992 8.46582V7.53223C13.6992 7.45859 13.6391 7.39844 13.5654 7.39844H1.96582Z" fill={ICON_COLOR} />
        </svg>
    );
}
// b：Delete（退格键帽图标）
function DeleteKeyIcon({ size = 16 }: { size?: number }) {
    return (
        <svg width={size} height={size} viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M7.33325 5.9987L11.3333 9.9987M11.3333 5.9987L7.33325 9.9987M5.33321 3.33203C5.00194 3.33205 4.68253 3.45539 4.43721 3.67803L1.55188 7.5047C1.48303 7.56719 1.42801 7.64339 1.39035 7.72841C1.3527 7.81343 1.33325 7.90538 1.33325 7.99836C1.33325 8.09135 1.3527 8.1833 1.39035 8.26832C1.42801 8.35334 1.48303 8.42954 1.55188 8.49203L4.43721 12.3194C4.68253 12.542 5.00194 12.6653 5.33321 12.6654H13.3332C13.6868 12.6654 14.026 12.5249 14.276 12.2748C14.5261 12.0248 14.6665 11.6857 14.6665 11.332V4.66536C14.6665 4.31174 14.5261 3.9726 14.276 3.72256C14.026 3.47251 13.6868 3.33203 13.3332 3.33203H5.33321Z" stroke={ICON_COLOR} strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
    );
}
// y：触控板捏合（缩放-触控板行）
function TrackpadPinchIcon() {
    return (
        <svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12.3333 6.77778V16.8182L11.626 16.0947C10.9414 15.3946 10.0036 15 9.02447 15H8.90712C8.28401 15 7.71535 15.355 7.44167 15.9148C7.17089 16.4686 7.23552 17.1279 7.60873 17.6186L12.1461 23.5849C12.8241 24.4765 13.8799 25 15 25H16.82C20.2331 25 23 22.2331 23 18.82V16.9179C23 15.7407 22.3405 14.6628 21.2924 14.1268L15.8889 11.3636V6.77778C15.8889 5.79594 15.093 5 14.1111 5C13.1293 5 12.3333 5.79594 12.3333 6.77778Z" stroke={ICON_COLOR} strokeWidth="1.2" />
            <path d="M9.10811 0.999999L11 2.79487M11 2.79487L9.10811 4.58974M11 2.79487C11 2.79487 9.64921 2.53835 8.2973 2.79487C6.94539 3.05139 5.60306 3.66457 4.51351 4.84615C3.42397 6.02774 3.05275 7.3294 2.89189 8.4359C2.73103 9.54239 2.89189 11 2.89189 11M4.78378 9.20513L2.89189 11M2.89189 11L1 9.20513" stroke={ACCENT} strokeWidth="1.16667" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
    );
}
// w：鼠标滚轮（缩放-鼠标行）
function MouseWheelIcon() {
    return (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 6V10" stroke={ACCENT} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M19 9C19 5.13401 15.866 2 12 2C8.13401 2 5 5.13401 5 9V15C5 18.866 8.13401 22 12 22C15.866 22 19 18.866 19 15V9Z" stroke={ICON_COLOR} strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
    );
}
// k：触控板移动（已随移动画布「触控板」行删除，boss 2026-10-04）
// N：鼠标中键平移（移动画布-鼠标行）
function MousePanIcon() {
    return (
        <svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g clipPath="url(#clip0_mousepan)">
                <path d="M23 11C23 7.13401 19.866 4 16 4C12.134 4 9 7.13401 9 11V17C9 20.866 12.134 24 16 24C19.866 24 23 20.866 23 17V11Z" stroke={ICON_COLOR} strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M16 9V11" stroke={ACCENT} strokeOpacity="0.3" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M16 9V11" stroke={ACCENT} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M5.00024 1.00391L5.00024 9.00391" stroke={ACCENT} strokeLinecap="round" />
                <path d="M3.5 2L5 0.5L6.5 2" stroke={ACCENT} />
                <path d="M8 3.5L9.5 5.00378L8 6.5" stroke={ACCENT} />
                <path d="M1.99988 3.5L0.5 4.99988L1.99988 6.5" stroke={ACCENT} />
                <path d="M3.5 8L5.00024 9.50391L6.5 8" stroke={ACCENT} />
                <path d="M9.00513 4.99609L1.00513 4.99609" stroke={ACCENT} strokeLinecap="round" />
            </g>
            <defs>
                <clipPath id="clip0_mousepan">
                    <rect width="28" height="28" fill="white" />
                </clipPath>
            </defs>
        </svg>
    );
}
// Close 图标（libtv:close，viewBox 17.19，fill currentColor）
function CloseIcon({ width = 17.19, height = 17.19, color = "currentColor" }: { width?: number; height?: number; color?: string }) {
    return (
        <svg width={width} height={height} viewBox="0 0 17.19 17.19" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ color }}>
            <path d="M15.8.12a.4.4 0 0 1 .56 0l.7.7a.4.4 0 0 1 0 .57l-7.2 7.2 7.2 7.2a.4.4 0 0 1 0 .57l-.7.7a.4.4 0 0 1-.56 0l-7.2-7.2-7.2 7.2a.4.4 0 0 1-.57 0l-.71-.7a.4.4 0 0 1 0-.57l7.2-7.2-7.2-7.2a.4.4 0 0 1 0-.57l.7-.7a.4.4 0 0 1 .57 0l7.2 7.2z" fill="currentColor" />
        </svg>
    );
}

/* ================= 键帽（模块 981493：S/I/j/E 逐字） ================= */
// S：图标键帽
function KeyIconChip({ children }: { children: ReactNode }) {
    return (
        <span className="flex shrink-0 items-center justify-center" style={{ width: 28, height: 28, borderRadius: 8, border: "1px solid var(--canvas-controls-border)" }}>
            {children}
        </span>
    );
}
// I：文字键帽
function KeyTextChip({ children }: { children: ReactNode }) {
    return (
        <span className="text-canvas-controls-text flex h-7 min-w-7 shrink-0 items-center justify-center px-1 font-sans text-sm" style={{ borderRadius: 8, border: "0.5px solid var(--canvas-controls-border)" }}>
            {children}
        </span>
    );
}
// j：Mod 键帽（mac=⌘ 图标 / 非 mac=Ctrl）
function ModKeyChip({ mac }: { mac: boolean }) {
    return mac ? (
        <KeyIconChip>
            <CommandIcon />
        </KeyIconChip>
    ) : (
        <KeyTextChip>Ctrl</KeyTextChip>
    );
}
// E：Alt 键帽
function AltKeyChip({ mac }: { mac: boolean }) {
    return <KeyTextChip>{mac ? "Option" : "Alt"}</KeyTextChip>;
}

/* ================= 行 / 组 / 竖分隔线（模块 981493：T/M/R 逐字） ================= */
function ShortcutRow({ label, children }: { label: ReactNode; children: ReactNode }) {
    return (
        <div className="flex w-full flex-col gap-2 md:flex-row md:items-center md:justify-between md:gap-4">
            <span className="text-fg-muted text-left text-sm leading-snug md:min-w-0 md:flex-1 md:pr-2">{label}</span>
            <div className="text-canvas-controls-text flex flex-wrap items-center gap-2 text-sm md:shrink-0 md:justify-end">{children}</div>
        </div>
    );
}
function ShortcutGroup({ title, children }: { title: ReactNode; children: ReactNode }) {
    return (
        <section className="border-canvas-controls-border flex w-full min-w-0 flex-col gap-3 border-b pb-5 last:border-b-0 last:pb-0 md:shrink-0 md:border-b-0 md:pb-0 md:w-52 lg:w-[239px]">
            <h3 className="text-sm font-medium text-[#09CAF5]">{title}</h3>
            <div className="flex flex-col gap-3">{children}</div>
        </section>
    );
}
function GroupDivider() {
    return <div className="bg-canvas-controls-border hidden w-px shrink-0 self-stretch md:block" aria-hidden={true} />;
}

/* ================= combo 归并渲染（模块 981493：P 逐字） ================= */
function ComboKeys({ combo, mac }: { combo: string | string[]; mac: boolean }) {
    const groups = useMemo(() => {
        // 解析：拆 +、去空、mod→平台键
        const parsed = (Array.isArray(combo) ? combo : [combo])
            .map((c) => c.toLowerCase().split("+").map((s) => s.trim()).filter(Boolean))
            .filter((c) => c.length > 0)
            .map((c) => c.map((k) => ("mod" === k ? (mac ? "meta" : "ctrl") : k)));
        // 平台过滤（仅 mac 生效）
        const forPlatform = ((list: string[][]) => {
            if (!mac || list.length <= 1) return list;
            const metaKeys = new Set(list.filter((c) => c.includes("meta")).map(comboKeyOf));
            const kept = list.filter((c) => !!c.includes("meta") || !(c.includes("alt") && metaKeys.has(comboKeyOf(c))));
            return kept.length === 0 ? list : kept;
        })(parsed);
        // 同主键组合去重：修饰为子集的删大、相等的删后
        const filtered = ((list: string[][]) => {
            const out: string[][] = [];
            const removed = new Set<number>();
            for (let a = 0; a < list.length; a++) {
                if (removed.has(a)) continue;
                const keyA = comboKeyOf(list[a]);
                const modsA = comboModsOf(list[a]);
                let keep = true;
                for (let t = 0; t < list.length; t++) {
                    if (a === t || removed.has(t) || comboKeyOf(list[t]) !== keyA) continue;
                    const modsT = comboModsOf(list[t]);
                    if (modsT.size < modsA.size && [...modsT].every((m) => modsA.has(m))) {
                        keep = false;
                        break;
                    }
                    if (modsA.size === modsT.size && [...modsA].every((m) => modsT.has(m))) {
                        if (t < a) {
                            keep = false;
                            break;
                        } else removed.add(t);
                    }
                }
                if (keep) out.push(list[a]);
            }
            return out;
        })(forPlatform);
        // ctrl/alt 归并（仅非 mac，两组等长且仅一位 ctrl/alt 不同）
        const merged = ((list: string[][]): string[] | null => {
            if (mac || list.length < 2) return null;
            const len = list[0]?.length ?? 0;
            if (!len || !list.every((c) => c.length === len)) return null;
            let diff = -1;
            for (let t = 0; t < len; t++) {
                if (new Set(list.map((c) => c[t])).size > 1) {
                    if (diff !== -1) return null;
                    diff = t;
                }
            }
            if (diff === -1) return list[0] ?? null;
            const at = Array.from(new Set(list.map((c) => c[diff])));
            return at.length === 2 && at.includes("ctrl") && at.includes("alt") ? list[0].map((k, t) => (t === diff ? "ctrl/alt" : k)) : null;
        })(filtered);
        return merged ? [merged] : filtered;
    }, [combo, mac]);

    return (
        <>
            {groups.map((g, gi) => (
                <Fragment key={`combo-group-${gi}`}>
                    {gi > 0 ? <span className="text-fg-subtle px-1 text-sm">/</span> : null}
                    {g.map((k, ki) => {
                        let cap: ReactNode;
                        if ("meta" === k) cap = mac ? <KeyIconChip><CommandIcon /></KeyIconChip> : <KeyTextChip>Meta</KeyTextChip>;
                        else if ("ctrl" === k) cap = <KeyTextChip>Ctrl</KeyTextChip>;
                        else if ("ctrl/alt" === k) cap = <KeyTextChip>Ctrl/Alt</KeyTextChip>;
                        else if ("shift" === k) cap = <KeyTextChip>{mac ? "⇧" : "Shift"}</KeyTextChip>;
                        else if ("alt" === k) cap = <KeyTextChip>{mac ? "⌥" : "Alt"}</KeyTextChip>;
                        else if ("=" === k || "equal" === k) cap = <KeyIconChip><PlusKeyIcon /></KeyIconChip>;
                        else if ("-" === k || "minus" === k) cap = <KeyIconChip><MinusKeyIcon /></KeyIconChip>;
                        else if ("delete" === k || "backspace" === k) cap = <KeyIconChip><DeleteKeyIcon /></KeyIconChip>;
                        else if ("enter" === k) cap = <KeyTextChip>Enter</KeyTextChip>;
                        else if ("tab" === k) cap = <KeyTextChip>Tab</KeyTextChip>;
                        else if (k.length > 1) cap = <KeyTextChip>{k.charAt(0).toUpperCase() + k.slice(1)}</KeyTextChip>;
                        else cap = <KeyTextChip>{k.toUpperCase()}</KeyTextChip>;
                        return (
                            <Fragment key={`${k}-${ki}`}>
                                {ki > 0 && !mac ? <span className="text-fg-subtle text-sm">+</span> : null}
                                {cap}
                            </Fragment>
                        );
                    })}
                </Fragment>
            ))}
        </>
    );
}

/* ================= BottomBarPopover（模块 16240 逐字，framer-motion → CSS 动画等价） ================= */
const BOTTOM_BAR_POPOVER_GAP = 12;
function clampAnchorOffsetX(e: number, t: number): number {
    return !Number.isFinite(t) || t <= 32 ? e : Math.min(Math.max(16, e), t - 16);
}
// i：锚点小箭头
function BottomBarPopoverArrow({ anchorOffsetX }: { anchorOffsetX: number | string }) {
    const left = typeof anchorOffsetX === "number" ? `${anchorOffsetX}px` : anchorOffsetX;
    const fill = "var(--bottom-bar-popover-arrow-fill, var(--canvas-controls-bg))";
    return (
        <span aria-hidden={true} className="pointer-events-none absolute" style={{ left, bottom: -8, transform: "translateX(-50%)" }}>
            <svg width="16" height="10" viewBox="0 0 16 10" fill="none">
                <path d="M0 2 L6.6 8.4 a2 2 0 0 0 2.8 0 L16 2" fill={fill} stroke="var(--bottom-bar-popover-arrow-stroke, var(--canvas-controls-border))" strokeWidth="1" strokeLinecap="round" />
                <rect x="0" y="0" width="16" height="2" fill={fill} />
            </svg>
        </span>
    );
}
// u：弹层容器（motion.div → div + CSS 入场动画；x:"-50%" → transform）
const BottomBarPopover = forwardRef(function BottomBarPopover(
    { centeredX = false, anchorOffsetX, style, children, className }: { centeredX?: boolean; anchorOffsetX?: number; style?: CSSProperties; children: ReactNode; className?: string },
    ref: React.Ref<HTMLDivElement>,
) {
    const off = typeof anchorOffsetX === "number" ? anchorOffsetX : undefined;
    return (
        <div ref={ref} className={`${className ?? ""} original-popover-in`} style={{ ...style, ...(centeredX ? { transform: "translateX(-50%)" } : {}) }}>
            {children}
            {off != null ? <BottomBarPopoverArrow anchorOffsetX={off} /> : null}
        </div>
    );
});

/* ================= 快捷键 defs（061 chunk 注册处提取，visible:!0；boss 2026-10-04 指令精简：
   删合并分镜组/连线(Ctrl+L)/复制节点和连线(Ctrl+D)/生成(Ctrl+Enter)/适应画布(Ctrl+0)/重做(Ctrl+Shift+Z)；
   新建节点改为鼠标双击，不再占 Tab） ================= */
type ShortcutDef = { id: string; combo: string | string[]; group: "creation" | "zoom" | "move" | "other"; labelKey?: string; label?: string };
const SHORTCUT_DEFS: ShortcutDef[] = [
    { id: "canvas.group", combo: ["mod+g", "alt+g"], group: "creation", labelKey: "canvas:shortcutLabelGroup" },
    { id: "canvas.ungroup", combo: ["mod+shift+g", "alt+shift+g"], group: "creation", labelKey: "canvas:shortcutLabelUngroup" },
    { id: "canvas.zoom-in", combo: ["mod+=", "mod+shift+plus"], group: "zoom", labelKey: "canvas:zoomIn" },
    { id: "canvas.zoom-out", combo: "mod+-", group: "zoom", labelKey: "canvas:zoomOut" },
    { id: "canvas.tool-move", combo: "v", group: "move", labelKey: "canvas:toolModeMove" },
    { id: "canvas.tool-hand", combo: "h", group: "move", labelKey: "canvas:toolModeHand" },
    { id: "canvas.format-layout", combo: "alt+shift+f", group: "move", labelKey: "canvas:tidyCanvas" },
    { id: "canvas.search-nodes", combo: "mod+f", group: "other", labelKey: "canvas:shortcutLabelSearchNodes" },
    { id: "canvas.delete-selection", combo: ["delete", "backspace"], group: "other", labelKey: "canvas:shortcutLabelDelete" },
    { id: "canvas.undo", combo: "mod+z", group: "other", label: "撤销" },
];
// i18n labelKey → zh-CN（词典 3xjlk8cm1g3m9.js；boss 2026-10-04 精简后仅保留在用项）
const SHORTCUT_LABELS: Record<string, string> = {
    "canvas:shortcutLabelGroup": "成组",
    "canvas:shortcutLabelUngroup": "解组",
    "canvas:zoomIn": "放大",
    "canvas:zoomOut": "缩小",
    "canvas:toolModeMove": "移动",
    "canvas:toolModeHand": "抓手工具",
    "canvas:tidyCanvas": "整理画布",
    "canvas:shortcutLabelSearchNodes": "画布节点搜索",
    "canvas:shortcutLabelDelete": "删除",
};

/* ================= D：面板本体（模块 981493 逐字） ================= */
export type OriginalShortcutsPanelProps = {
    open: boolean;
    onClose: () => void;
    hiddenShortcutIds?: Set<string>;
};

export const OriginalShortcutsPanel = memo(function OriginalShortcutsPanel({ open, onClose, hiddenShortcutIds }: OriginalShortcutsPanelProps) {
    const [mac, setMac] = useState(false);
    useEffect(() => {
        setMac(getIsMac());
    }, []);
    const [bottom, setBottom] = useState(76);
    const popoverRef = useRef<HTMLDivElement | null>(null);
    const [anchorOffsetX, setAnchorOffsetX] = useState<number | undefined>(undefined);

    // 锚定底栏（模块 D 的 useIsomorphicLayoutEffect 逐字：bottom/anchorOffsetX + resize/rAF/RO/MO 跟踪）
    useLayoutEffect(() => {
        let rafId: number | undefined;
        if (!open) return;
        const container = document.querySelector("[data-sidebar-container]");
        if (!container) return;
        const update = () => {
            const rect = container.getBoundingClientRect();
            setBottom(window.innerHeight - rect.top + BOTTOM_BAR_POPOVER_GAP);
            const el = popoverRef.current;
            const btn = container.querySelector('[data-sidebar-btn="keyboard"]');
            if (el && btn) {
                const br = btn.getBoundingClientRect();
                const center = br.left + br.width / 2;
                const op = el.offsetParent as HTMLElement | null;
                const base = op
                    ? op.getBoundingClientRect().left + op.clientLeft - op.scrollLeft + el.offsetLeft - el.offsetWidth / 2
                    : window.innerWidth / 2 - el.offsetWidth / 2;
                setAnchorOffsetX(clampAnchorOffsetX(center - base, el.offsetWidth));
            }
        };
        update();
        window.addEventListener("resize", update);
        const loop = () => {
            update();
            rafId = requestAnimationFrame(loop);
        };
        const onRun = (e: Event) => {
            const te = e as TransitionEvent;
            if (te.target === container && te.propertyName === "left" && rafId == null) rafId = requestAnimationFrame(loop);
        };
        const onEnd = (e: Event) => {
            const te = e as TransitionEvent;
            if (te.target === container && te.propertyName === "left") {
                if (rafId != null) {
                    cancelAnimationFrame(rafId);
                    rafId = undefined;
                }
                update();
            }
        };
        container.addEventListener("transitionrun", onRun);
        container.addEventListener("transitionend", onEnd);
        container.addEventListener("transitioncancel", onEnd);
        if (typeof container.getAnimations === "function" && container.getAnimations().some((a) => a.playState === "running")) rafId = requestAnimationFrame(loop);
        const offsetParent = popoverRef.current?.offsetParent as HTMLElement | null;
        const ro = typeof ResizeObserver !== "undefined" && offsetParent ? new ResizeObserver(update) : null;
        if (offsetParent && ro) ro.observe(offsetParent);
        const mo = typeof MutationObserver !== "undefined" ? new MutationObserver(update) : null;
        mo?.observe(container, { attributes: true, attributeFilter: ["style"] });
        return () => {
            window.removeEventListener("resize", update);
            container.removeEventListener("transitionrun", onRun);
            container.removeEventListener("transitionend", onEnd);
            container.removeEventListener("transitioncancel", onEnd);
            if (rafId != null) cancelAnimationFrame(rafId);
            ro?.disconnect();
            mo?.disconnect();
        };
    }, [open]);

    // useVisibleShortcutsByGroup 等价：静态 defs 按组聚合（visible:!0 已过滤）
    const groups = useMemo(() => {
        const m = new Map<string, ShortcutDef[]>();
        for (const def of SHORTCUT_DEFS) {
            const g = def.group ?? "other";
            if (!m.has(g)) m.set(g, []);
            m.get(g)!.push(def);
        }
        return m;
    }, []);
    const filterHidden = (list: ShortcutDef[]) => (hiddenShortcutIds ? list.filter((e) => !hiddenShortcutIds.has(e.id)) : list);
    const labelOf = (e: ShortcutDef) => (e.labelKey ? SHORTCUT_LABELS[e.labelKey] ?? "" : e.label ?? "");
    const creation = filterHidden(groups.get("creation") ?? []);
    const zoom = filterHidden(groups.get("zoom") ?? []);
    const move = filterHidden(groups.get("move") ?? []);
    const other = filterHidden(groups.get("other") ?? []);

    if (!open) return null;

    return (
        <BottomBarPopover
            ref={popoverRef}
            centeredX={true}
            anchorOffsetX={anchorOffsetX}
            style={{ bottom }}
            className="z-(--z-dropdown) absolute left-1/2 w-[min(100%,calc(100vw-1.5rem))] max-w-[1152px]"
        >
            <div className="bg-panel-background/95 border-canvas-controls-border border-hair relative box-border rounded-2xl p-4 backdrop-blur-lg md:p-6" style={{ boxShadow: "var(--canvas-shadow-dropdown)" }}>
                <header className="absolute right-3 top-3">
                    <button
                        type="button"
                        onClick={onClose}
                        className="hover:bg-canvas-controls-hover flex size-7 shrink-0 items-center justify-center rounded-lg transition-colors"
                        aria-label="关闭快捷键面板"
                    >
                        <CloseIcon width={13} height={13} color="var(--canvas-controls-icon)" />
                    </button>
                </header>
                <div className="flex max-h-[80vh] flex-col gap-0 overflow-y-auto overscroll-y-contain [-webkit-overflow-scrolling:touch] md:max-h-none md:flex-row md:items-stretch md:gap-5 md:overflow-visible lg:gap-6">
                    <ShortcutGroup title="创作">
                        {creation.map((e) => (
                            <ShortcutRow key={e.id} label={labelOf(e)}>
                                <ComboKeys combo={e.combo} mac={mac} />
                            </ShortcutRow>
                        ))}
                        {/* boss 2026-10-04：新建节点改为鼠标双击（原 Tab 快捷键关闭） */}
                        <ShortcutRow label="新建节点">
                            <KeyTextChip>鼠标双击</KeyTextChip>
                        </ShortcutRow>
                        <ShortcutRow label="节点复制">
                            <AltKeyChip mac={mac} />
                            {"+拖动节点"}
                        </ShortcutRow>
                    </ShortcutGroup>
                    <GroupDivider />
                    <ShortcutGroup title="缩放">
                        {zoom.map((e) => (
                            <ShortcutRow key={e.id} label={labelOf(e)}>
                                <ComboKeys combo={e.combo} mac={mac} />
                            </ShortcutRow>
                        ))}
                        <ShortcutRow label="触控板">
                            <TrackpadPinchIcon />
                        </ShortcutRow>
                        <ShortcutRow label="鼠标">
                            <ModKeyChip mac={mac} />
                            <MouseWheelIcon />
                        </ShortcutRow>
                    </ShortcutGroup>
                    <GroupDivider />
                    <ShortcutGroup title="移动画布">
                        {/* boss 2026-10-04：删「键盘」「触控板」两行，保留鼠标中键平移 */}
                        <ShortcutRow label="鼠标">
                            <MousePanIcon />
                        </ShortcutRow>
                        {move.map((e) => (
                            <ShortcutRow key={e.id} label={labelOf(e)}>
                                <ComboKeys combo={e.combo} mac={mac} />
                            </ShortcutRow>
                        ))}
                    </ShortcutGroup>
                    <GroupDivider />
                    <ShortcutGroup title="其他">
                        {other.map((e) => (
                            <ShortcutRow key={e.id} label={labelOf(e)}>
                                <ComboKeys combo={e.combo} mac={mac} />
                            </ShortcutRow>
                        ))}
                    </ShortcutGroup>
                </div>
            </div>
        </BottomBarPopover>
    );
});
