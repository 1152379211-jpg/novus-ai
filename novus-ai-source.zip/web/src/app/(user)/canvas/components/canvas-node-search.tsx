"use client";

/**
 * 画布节点搜索浮层（boss 2026-10-04：其他栏「画布节点搜索」Ctrl+F，此前只有面板行没有功能，补齐）。
 * 样式沿用画布深色面板同款（theme.node.panel/stroke/fill + rounded-2xl + p-1.5，与右键菜单一致）。
 * 匹配规则与 agent 的 query_canvas_nodes 一致：title + 文本 content + prompt 包含关键词（大小写不敏感）。
 * 点击结果：focusNode（选中 + 视口动画定位）并关闭浮层。
 */
import { useEffect, useMemo, useRef, useState } from "react";
import { Search } from "lucide-react";

import { canvasThemes } from "@/lib/canvas-theme";
import { useThemeStore } from "@/stores/use-theme-store";

import { CanvasNodeType, type CanvasNodeData } from "../types";

const TYPE_LABELS: Record<string, string> = {
    [CanvasNodeType.Image]: "图片",
    [CanvasNodeType.Video]: "视频",
    [CanvasNodeType.Audio]: "音频",
    [CanvasNodeType.Text]: "文本",
    [CanvasNodeType.Group]: "分组",
    [CanvasNodeType.Panorama]: "全景图",
    [CanvasNodeType.Director]: "导演台",
    [CanvasNodeType.Config]: "配置",
};

export function CanvasNodeSearchPanel({
    open,
    nodes,
    onPick,
    onClose,
}: {
    open: boolean;
    nodes: CanvasNodeData[];
    onPick: (nodeId: string) => void;
    onClose: () => void;
}) {
    const theme = canvasThemes[useThemeStore((state) => state.theme)];
    const [keyword, setKeyword] = useState("");
    const inputRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
        if (open) {
            setKeyword("");
            const timer = window.setTimeout(() => inputRef.current?.focus(), 50);
            return () => window.clearTimeout(timer);
        }
    }, [open]);

    const results = useMemo(() => {
        const kw = keyword.trim().toLowerCase();
        const matched = nodes.filter((node) => {
            if (node.type === CanvasNodeType.Group) return false;
            if (!kw) return true;
            const content = node.metadata?.content || "";
            return `${node.title} ${content} ${node.metadata?.prompt || ""}`.toLowerCase().includes(kw);
        });
        return matched.slice(0, 20);
    }, [keyword, nodes]);

    if (!open) return null;

    return (
        <div
            className="original-ui-scope fixed left-1/2 top-14 z-[140] w-[380px] -translate-x-1/2"
            data-canvas-node-search
            data-canvas-no-zoom
            onMouseDown={(event) => event.stopPropagation()}
            onPointerDown={(event) => event.stopPropagation()}
        >
            <div className="rounded-2xl border p-1.5 shadow-2xl backdrop-blur" style={{ background: theme.node.panel, borderColor: theme.node.stroke, color: theme.node.text, boxShadow: "var(--canvas-shadow-menu, 0 12px 40px rgba(0,0,0,.4))" }}>
                <div className="flex h-9 items-center gap-2 px-2">
                    <Search className="size-4 shrink-0" style={{ color: theme.node.faint }} />
                    <input
                        ref={inputRef}
                        value={keyword}
                        onChange={(event) => setKeyword(event.target.value)}
                        onKeyDown={(event) => {
                            if (event.key === "Escape") {
                                event.preventDefault();
                                event.stopPropagation();
                                onClose();
                            }
                            if (event.key === "Enter" && results.length) {
                                event.preventDefault();
                                onPick(results[0].id);
                            }
                        }}
                        placeholder="搜索节点（标题、内容、提示词）"
                        className="min-w-0 flex-1 bg-transparent text-[13px] outline-none placeholder:opacity-45"
                        style={{ color: theme.node.text }}
                        aria-label="搜索节点"
                    />
                </div>
                {results.length ? (
                    <div className="mt-1 max-h-[320px] overflow-y-auto thin-scrollbar border-t pt-1" style={{ borderColor: theme.node.stroke }}>
                        {results.map((node) => (
                            <button
                                key={node.id}
                                type="button"
                                className="flex h-9 w-full cursor-pointer items-center gap-2.5 rounded-[10px] px-2 text-left"
                                style={{ color: theme.node.text }}
                                onClick={() => onPick(node.id)}
                                onMouseEnter={(event) => (event.currentTarget.style.background = theme.node.fill)}
                                onMouseLeave={(event) => (event.currentTarget.style.background = "transparent")}
                            >
                                <span className="shrink-0 rounded-md px-1.5 py-0.5 text-[11px] leading-4" style={{ background: theme.node.fill, color: theme.node.muted }}>
                                    {TYPE_LABELS[node.type] || node.type}
                                </span>
                                <span className="min-w-0 flex-1 truncate text-[13px] leading-4">{node.title || "未命名节点"}</span>
                            </button>
                        ))}
                    </div>
                ) : (
                    <div className="mt-1 border-t px-2 py-3 text-center text-xs" style={{ borderColor: theme.node.stroke, color: theme.node.faint }}>
                        {keyword.trim() ? "没有匹配的节点" : "画布上还没有节点"}
                    </div>
                )}
            </div>
        </div>
    );
}
