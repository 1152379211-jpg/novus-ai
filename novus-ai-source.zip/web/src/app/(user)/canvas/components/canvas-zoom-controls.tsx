import { Eye, EyeOff, Grid2x2, LayoutGrid, Map as MapIcon, PanelLeft } from "lucide-react";
import { Button, Tooltip } from "antd";

import { canvasThemes } from "@/lib/canvas-theme";
import { useThemeStore } from "@/stores/use-theme-store";

type CanvasZoomControlsProps = {
    scale: number;
    onScaleChange: (scale: number) => void;
    onReset: () => void;
    isMiniMapOpen: boolean;
    onToggleMiniMap: () => void;
    onOrganize: () => void;
    hideConnections: boolean;
    onToggleConnections: () => void;
    snapToGrid: boolean;
    onToggleSnap: () => void;
    assetPanelOpen: boolean;
    onToggleAssetPanel: () => void;
};

export function CanvasZoomControls({ scale, onScaleChange, onReset, isMiniMapOpen, onToggleMiniMap, onOrganize, hideConnections, onToggleConnections, snapToGrid, onToggleSnap, assetPanelOpen, onToggleAssetPanel }: CanvasZoomControlsProps) {
    const colorTheme = useThemeStore((state) => state.theme);
    const theme = canvasThemes[colorTheme];
    const activeStyle = { background: theme.toolbar.activeBg, color: theme.toolbar.activeText };

    const viewTools = [
        { key: "organize", label: "画布整理：按连线层级自动排布节点", icon: <LayoutGrid className="size-4" />, active: false, onClick: onOrganize },
        { key: "minimap", label: "画布小地图", icon: <MapIcon className="size-4" />, active: isMiniMapOpen, onClick: onToggleMiniMap },
        { key: "connections", label: "隐藏连线", icon: hideConnections ? <EyeOff className="size-4" /> : <Eye className="size-4" />, active: hideConnections, onClick: onToggleConnections },
        { key: "snap", label: "网格吸附", icon: <Grid2x2 className="size-4" />, active: snapToGrid, onClick: onToggleSnap },
    ];

    return (
        <div className="absolute bottom-5 left-5 z-50 flex items-center gap-0.5" onMouseDown={(event) => event.stopPropagation()} onPointerDown={(event) => event.stopPropagation()}>
            {/* 资产管理：开关左侧覆盖的资产/提示词面板（boss 要求：去掉外框，只保留图标） */}
            <button
                type="button"
                onClick={onToggleAssetPanel}
                className="flex h-8 w-8 items-center justify-center rounded-lg transition"
                style={assetPanelOpen ? activeStyle : { color: theme.toolbar.item }}
                aria-label="资产管理"
                title="资产管理"
            >
                <PanelLeft className="size-4" />
            </button>
            {viewTools.map((tool) => (
                <Tooltip key={tool.key} title={tool.label}>
                    <Button
                        type="text"
                        className="!h-8 !w-8 !min-w-8 !p-0"
                        style={tool.active ? activeStyle : { color: theme.toolbar.item }}
                        icon={tool.icon}
                        onClick={tool.onClick}
                        aria-label={tool.label}
                    />
                </Tooltip>
            ))}
        </div>
    );
}
