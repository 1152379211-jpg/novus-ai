"use client";

/**
 * LibTV 原版「右键空白处菜单」逐字搬运
 * 出处：LibTV-Canvas-Teardown/source/node-source/components/ImageNode/
 *   data-guide-lockable-portal__aj_aT_aR_aM__3-mou5_117057.js（chunk 3-mou5v69wxmq.js 模块）
 *   - 样式对象 ad(遮罩)/au(容器)/ap(菜单项)/am(hover)/ah(禁用)/af(快捷键)/ag(分隔线) 逐字符复制
 *   - aN(菜单项)/a_(分隔线)/aj(pane 菜单序列)/aM(portal 容器+clamp 定位) 逻辑逐字重写
 * 差异：onWheel={ao.forwardWheelToCanvas} 滚轮转发未接（依赖其画布 store，无等价物）；
 *       文案为其 i18n key 的中文渲染值（快照 04 实测）；主题类 canvas-light 不适用（我们固定深色）。
 */
import { memo, useCallback, useEffect, useLayoutEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import type { CSSProperties, MouseEvent as ReactMouseEvent } from "react";

/* eslint-disable */
// ---- 样式对象（chunk 逐字）----
const ad: CSSProperties = {
    position: "fixed",
    inset: 0,
    zIndex: "var(--z-panel)",
};
const au: CSSProperties = {
    position: "fixed",
    zIndex: "calc(var(--z-panel) + 1)",
    display: "flex",
    flexDirection: "column",
    gap: "4px",
    minWidth: 196,
    padding: "8px",
    borderRadius: 16,
    background: "var(--canvas-controls-bg, #262626)",
    border: "0.5px solid var(--canvas-controls-border, #363636)",
    boxShadow: "var(--canvas-shadow-menu, 0 8px 32px rgba(0,0,0,0.15))",
};
const ap: CSSProperties = {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    width: "100%",
    height: 32,
    flexShrink: 0,
    padding: "0 8px",
    fontSize: 13,
    color: "var(--canvas-controls-text)",
    background: "transparent",
    border: "none",
    borderRadius: 8,
    cursor: "pointer",
    transition: "background 120ms ease",
    outline: "none",
};
const am: CSSProperties = {
    background: "var(--canvas-controls-hover)",
};
const ah: CSSProperties = {
    color: "var(--canvas-controls-text)",
    opacity: 0.3,
    cursor: "default",
};
const af: CSSProperties = {
    fontSize: 12,
    color: "var(--canvas-controls-text)",
    opacity: 0.4,
    marginLeft: 24,
    whiteSpace: "nowrap",
};
const ag: CSSProperties = {
    height: 0.5,
    flexShrink: 0,
    margin: "0 8px",
    background: "var(--canvas-controls-border)",
};

// ---- aN：菜单项（chunk 逐字）----
const PaneMenuItem = memo(function PaneMenuItem({
    label,
    featureId,
    shortcut,
    disabled,
    highlight,
    onClick,
}: {
    label: string;
    featureId: string;
    shortcut?: string;
    disabled?: boolean;
    highlight?: boolean;
    onClick: () => void;
}) {
    const handleClick = useCallback(() => {
        disabled || onClick();
    }, [disabled, onClick]);
    const bg = highlight ? "rgba(255, 255, 255, 0.06)" : "transparent";
    return (
        <button
            type="button"
            data-feature-id={featureId}
            onClick={handleClick}
            disabled={disabled}
            style={{ ...ap, background: bg, ...(disabled ? ah : {}) }}
            onMouseEnter={(e) => {
                disabled || Object.assign(e.currentTarget.style, am);
            }}
            onMouseLeave={(e) => {
                e.currentTarget.style.background = bg;
            }}
        >
            <span>{label}</span>
            {shortcut ? <span style={af}>{shortcut}</span> : null}
        </button>
    );
});

// ---- a_：分隔线（chunk 逐字）----
function PaneMenuDivider() {
    return <div style={ag} />;
}

export type OriginalPaneContextMenuActions = {
    canUndo: boolean;
    canRedo: boolean;
    onUpload: () => void;
    onAddAsset: () => void;
    onAddNode: () => void;
    onUndo: () => void;
    onRedo: () => void;
    onPaste: () => void;
};

export type OriginalPaneContextMenuProps = {
    x: number;
    y: number;
    actions: OriginalPaneContextMenuActions;
    onClose: () => void;
};

// ---- aM：portal 容器 + clamp 定位（chunk 逐字，pane 分支）----
export const OriginalPaneContextMenu = memo(function OriginalPaneContextMenu({ x, y, actions, onClose }: OriginalPaneContextMenuProps) {
    const menuRef = useRef<HTMLDivElement | null>(null);
    const offsetRef = useRef<{ x: number; y: number; maxHeight?: number } | null>(null);
    const [pos, setPos] = useState<{ left: number; top: number; maxHeight?: number }>(() => ({ left: x, top: y }));

    // Escape 关闭（capture，chunk 逐字）
    useEffect(() => {
        const handler = (e: KeyboardEvent) => {
            if (e.key === "Escape") {
                e.preventDefault();
                onClose();
            }
        };
        document.addEventListener("keydown", handler, { capture: true });
        return () => document.removeEventListener("keydown", handler, { capture: true });
    }, [onClose]);

    // clamp 定位（chunk aM 中 i=true 分支逐字）
    useLayoutEffect(() => {
        const el = menuRef.current;
        if (!el) {
            setPos({ left: x, top: y });
            return;
        }
        if (offsetRef.current === null) {
            let maxHeight: number | undefined;
            const r = el.getBoundingClientRect();
            if (!r.height) return;
            const vw = window.innerWidth;
            const vh = window.innerHeight;
            const w = r.width || 196;
            const h = r.height;
            const avail = Math.max(0, vh - 16);
            let u = x;
            let p = y;
            if (h > avail && avail > 0) {
                maxHeight = avail;
                p = 8;
            } else {
                if (p + h > vh - 8) p = Math.max(8, vh - h - 8);
                if (p < 8) p = 8;
            }
            if (u + w > vw - 8) u = Math.max(8, vw - w - 8);
            if (u < 8) u = 8;
            offsetRef.current = { x: u - x, y: p - y, maxHeight };
            setPos({ left: u, top: p, maxHeight });
        } else {
            setPos({ left: x + offsetRef.current.x, top: y + offsetRef.current.y, maxHeight: offsetRef.current.maxHeight });
        }
    }, [x, y]);

    const menuStyle: CSSProperties = {
        ...au,
        left: pos.left,
        top: pos.top,
        ...(pos.maxHeight != null ? { maxHeight: pos.maxHeight, overflowY: "auto" } : {}),
    };

    return createPortal(
        <div data-guide-lockable-portal="true" className="original-ui-scope">
            <div
                style={ad}
                onClick={onClose}
                onContextMenu={(e: ReactMouseEvent) => {
                    e.preventDefault();
                    onClose();
                }}
            />
            <div ref={menuRef} style={menuStyle}>
                {/* aj：pane 菜单序列（chunk 逐字，文案为其 i18n 中文渲染值）*/}
                <PaneMenuItem
                    featureId="context-menu:upload"
                    label="上传"
                    onClick={() => {
                        actions.onUpload();
                        onClose();
                    }}
                />
                <PaneMenuItem featureId="context-menu:addAsset" label="保存到我的资产" disabled onClick={actions.onAddAsset} />
                <PaneMenuItem
                    featureId="context-menu:addNode"
                    label="添加节点"
                    onClick={() => {
                        actions.onAddNode();
                        onClose();
                    }}
                />
                <PaneMenuDivider />
                <PaneMenuItem
                    featureId="context-menu:undo"
                    label="撤销"
                    shortcut="⌘Z"
                    disabled={!actions.canUndo}
                    onClick={() => {
                        actions.onUndo();
                        onClose();
                    }}
                />
                <PaneMenuItem
                    featureId="context-menu:redo"
                    label="重做"
                    shortcut="⇧⌘Z"
                    disabled={!actions.canRedo}
                    onClick={() => {
                        actions.onRedo();
                        onClose();
                    }}
                />
                <PaneMenuDivider />
                <PaneMenuItem
                    featureId="context-menu:paste"
                    label="粘贴"
                    shortcut="⌘V"
                    onClick={() => {
                        actions.onPaste();
                        onClose();
                    }}
                />
            </div>
        </div>,
        document.body,
    );
});
