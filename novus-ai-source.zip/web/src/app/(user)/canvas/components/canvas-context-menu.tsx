"use client";

import { useEffect, useState } from "react";
import type { ReactNode } from "react";
import { BetweenHorizontalStart, ChevronRight, Download, GalleryHorizontal, GalleryHorizontalEnd, Images, Info, LayoutGrid, Mountain, Music2, Package, Plus, RefreshCw, Rows3, Scissors, Shapes, ShieldAlert, Shirt, Columns3, Trash2, Upload, UserRound, Video, Wand2 } from "lucide-react";

import type { ContextMenuState } from "../types";
import { CanvasNodeType, type CanvasNodeData } from "../types";
import type { VideoFramePosition } from "../utils/canvas-video-frame";

// 031：存入素材库子菜单的五个分类（value 与宿主 assets.json 的 kind 字段一致）
const SAVE_ASSET_CATEGORIES = [
    { label: "角色", category: "character", icon: UserRound },
    { label: "场景", category: "scene", icon: Mountain },
    { label: "服装", category: "clothing", icon: Shirt },
    { label: "道具", category: "prop", icon: Package },
    { label: "其他", category: "other", icon: Shapes },
] as const;

// 两个右键菜单（单节点 CanvasNodeContextMenu / 多选 CanvasSelectionContextMenu）共用样式，boss 2026-10-04：与截图原版菜单同款深色
// 三个类逐字复制自 original-node-menu.tsx（ITEM_CLASS/ICON_WRAP_CLASS/LABEL_CLASS）
const MENU_ITEM_CLASS = "flex h-9 w-full items-center rounded-[10px] px-2 text-left transition-none hover:bg-canvas-controls-hover";
const MENU_ICON_WRAP_CLASS = "mr-2 flex size-5 shrink-0 items-center justify-center rounded-lg bg-canvas-controls-hover";
const MENU_LABEL_CLASS = "min-w-0 flex-1 truncate text-[13px]";

export function CanvasNodeContextMenu({ menu, node, canCaptureVideoFrame, showSaintBridgeTest, onClose, onCaptureVideoFrame, onInfo, onExpandBatch, onRetry, onEdit, onUpload, onExtractAudio, onTrimAudio, onDownload, onSaveAsset, onUploadMediaToCloud, onUploadImageToCloud, onSimulateFailure, onDuplicate, onDelete }: {
    menu: ContextMenuState;
    node?: CanvasNodeData | null;
    canCaptureVideoFrame: boolean;
    showSaintBridgeTest?: boolean;
    onClose: () => void;
    onCaptureVideoFrame: (position: VideoFramePosition) => void;
    onInfo?: () => void;
    onRetry?: () => void;
    onEdit?: () => void;
    onUpload?: () => void;
    onExtractAudio?: () => void;
    onTrimAudio?: () => void;
    onDownload?: () => void;
    /** 031：存入素材库改为子菜单直选分类（角色/场景/服装/道具/其他），不再弹二级对话框 */
    onSaveAsset?: (category: string) => void;
    onUploadMediaToCloud?: () => void;
    onUploadImageToCloud?: () => void;
    onSimulateFailure?: () => void;
    /** 097：右键「展开节点」——堆叠批次拆成独立普通图片节点（仅 isBatchRoot 且有子图时显示） */
    onExpandBatch?: () => void;
    onDuplicate: () => void;
    onDelete: () => void;
}) {
    const [frameMenuOpen, setFrameMenuOpen] = useState(false);
    // 031：存入素材库子菜单展开态
    const [saveAssetMenuOpen, setSaveAssetMenuOpen] = useState(false);

    useEffect(() => {
        const close = (event: PointerEvent) => {
            const target = event.target;
            if (target instanceof Element && target.closest(".ant-popover")) return;
            onClose();
        };
        window.addEventListener("pointerdown", close);
        return () => window.removeEventListener("pointerdown", close);
    }, [onClose]);

    return (
        <div
            className="original-ui-scope fixed z-[80]"
            style={{ left: menu.x, top: menu.y }}
            onPointerDown={(event) => event.stopPropagation()}
        >
            <div
                className="border-canvas-controls-border flex min-w-[220px] w-max flex-col rounded-2xl border p-1.5"
                style={{ backgroundColor: "var(--canvas-controls-bg)", boxShadow: "var(--canvas-shadow-menu)" }}
            >
            {menu.type === "node" && node ? (
                <>
                    <MenuButton icon={<Info className="size-4" />} label={node.type === CanvasNodeType.Video ? "生成信息" : "节点信息"} onClick={onInfo} />
                    {/* 097：堆叠批次根节点 → 展开节点（每张图拆成独立节点） */}
                    {onExpandBatch && node.metadata?.isBatchRoot && Array.isArray(node.metadata?.batchChildIds) && (node.metadata.batchChildIds as string[]).length > 0 ? (
                        <MenuButton icon={<Images className="size-4" />} label="展开节点" onClick={onExpandBatch} />
                    ) : null}
                    {node.metadata?.status === "error" ? <MenuButton icon={<RefreshCw className="size-4" />} label="重新生成" onClick={onRetry} /> : null}
                    {onUpload ? <MenuButton icon={node.type === CanvasNodeType.Video ? <Video className="size-4" /> : <Upload className="size-4" />} label={node.type === CanvasNodeType.Video && node.metadata?.content ? "替换视频" : "上传素材"} onClick={onUpload} /> : null}
                    {/* 031（boss 2026-10-05）：存入素材库 → hover 子菜单直选分类（加入角色库/场景库/服装库/道具库/其他库），免二次弹窗 */}
                    {onSaveAsset && node.metadata?.content ? (
                        <div className="relative" onMouseEnter={() => setSaveAssetMenuOpen(true)} onFocus={() => setSaveAssetMenuOpen(true)} onMouseLeave={() => setSaveAssetMenuOpen(false)}>
                            <button type="button" className={MENU_ITEM_CLASS} style={{ color: "var(--canvas-controls-text)" }} aria-haspopup="menu" aria-expanded={saveAssetMenuOpen}>
                                <span className={MENU_ICON_WRAP_CLASS}>
                                    <Plus className="size-4" />
                                </span>
                                <span className={MENU_LABEL_CLASS}>存入素材库</span>
                                <ChevronRight className="size-3.5 opacity-60" />
                            </button>
                            {saveAssetMenuOpen ? (
                                <div className="border-canvas-controls-border absolute left-full top-0 z-[81] ml-1 flex min-w-[220px] w-max flex-col rounded-2xl border p-1.5" style={{ backgroundColor: "var(--canvas-controls-bg)", boxShadow: "var(--canvas-shadow-menu)" }} role="menu">
                                    {SAVE_ASSET_CATEGORIES.map((item) => (
                                        <MenuButton key={item.category} icon={<item.icon className="size-4" />} label={`加入${item.label}库`} onClick={() => onSaveAsset(item.category)} />
                                    ))}
                                </div>
                            ) : null}
                        </div>
                    ) : null}
                    {onDownload && node.metadata?.content ? <MenuButton icon={<Download className="size-4" />} label="下载" onClick={onDownload} /> : null}
                    {onExtractAudio && node.type === CanvasNodeType.Video && node.metadata?.content ? <MenuButton icon={<Music2 className="size-4" />} label="分离音频" onClick={onExtractAudio} /> : null}
                    {onTrimAudio && node.type === CanvasNodeType.Audio && node.metadata?.content ? <MenuButton icon={<Scissors className="size-4" />} label="截取音频" onClick={onTrimAudio} /> : null}
                    {showSaintBridgeTest && node.type === CanvasNodeType.Video ? <MenuButton icon={<ShieldAlert className="size-4" />} label="测试失败回传" onClick={onSimulateFailure} danger /> : null}
                    <div className="border-canvas-controls-border my-1 border-t" />
                </>
            ) : null}
            {canCaptureVideoFrame ? (
                <>
                    <div className="relative" onMouseEnter={() => setFrameMenuOpen(true)} onFocus={() => setFrameMenuOpen(true)} onMouseLeave={() => setFrameMenuOpen(false)}>
                        <button type="button" className={MENU_ITEM_CLASS} style={{ color: "var(--canvas-controls-text)" }} aria-haspopup="menu" aria-expanded={frameMenuOpen}>
                            <span className={MENU_ICON_WRAP_CLASS}>
                                <BetweenHorizontalStart size={16} />
                            </span>
                            <span className={MENU_LABEL_CLASS}>截取视频帧</span>
                            <ChevronRight className="size-3.5 opacity-60" />
                        </button>
                        {frameMenuOpen ? (
                            <div className="border-canvas-controls-border absolute left-full top-0 z-[81] ml-1 flex min-w-[220px] w-max flex-col rounded-2xl border p-1.5" style={{ backgroundColor: "var(--canvas-controls-bg)", boxShadow: "var(--canvas-shadow-menu)" }} role="menu">
                                <MenuButton icon={<BetweenHorizontalStart className="size-4" />} label="截取首帧" onClick={() => onCaptureVideoFrame("first")} />
                                <MenuButton icon={<GalleryHorizontalEnd className="size-4" />} label="截取尾帧" onClick={() => onCaptureVideoFrame("last")} />
                                <MenuButton icon={<GalleryHorizontal className="size-4" />} label="截取当前帧" onClick={() => onCaptureVideoFrame("current")} />
                            </div>
                        ) : null}
                    </div>
                    <div className="border-canvas-controls-border my-1 border-t" />
                </>
            ) : null}
            {menu.type === "node" ? <MenuButton icon={<Plus className="size-4" />} label="创建副本" onClick={onDuplicate} /> : null}
            <MenuButton icon={<Trash2 className="size-4" />} label="删除" onClick={onDelete} danger />
            </div>
        </div>
    );
}

// 多选（框选）后的右键菜单：整理 / 宫格排序 / 垂直排序 / 水平排序 / 存入素材库（五分类子菜单）/ 下载 / 删除
// 033（boss 2026-10-05）：框选右键也要有单节点右键同款能力（存入素材库子菜单、批量下载）
export function CanvasSelectionContextMenu({ menu, onClose, onOrganize, onGridSort, onVerticalSort, onHorizontalSort, onSaveAsset, onDownload, onDelete }: {
    menu: ContextMenuState;
    onClose: () => void;
    onOrganize: () => void;
    onGridSort: () => void;
    onVerticalSort: () => void;
    onHorizontalSort: () => void;
    /** 033：把选中的全部节点按所选分类存入素材库 */
    onSaveAsset?: (category: string) => void;
    /** 033：选中节点批量下载（≤5 逐个、>5 打包 zip） */
    onDownload?: () => void;
    onDelete: () => void;
}) {
    // 033：存入素材库子菜单展开态（与单节点菜单同款交互）
    const [saveAssetMenuOpen, setSaveAssetMenuOpen] = useState(false);

    useEffect(() => {
        const close = (event: PointerEvent) => {
            const target = event.target;
            if (target instanceof Element && target.closest(".ant-popover")) return;
            onClose();
        };
        window.addEventListener("pointerdown", close);
        return () => window.removeEventListener("pointerdown", close);
    }, [onClose]);

    const renderItem = (icon: ReactNode, label: string, onClick: () => void, danger = false) => (
        // boss 2026-10-04：删除项图标与文字都不用红色，整菜单统一白（danger 仅留作语义标记，不再改色）
        <button type="button" className={MENU_ITEM_CLASS} style={{ color: "var(--canvas-controls-text)" }} onClick={onClick}>
            <span className={MENU_ICON_WRAP_CLASS}>{icon}</span>
            <span className={MENU_LABEL_CLASS}>{label}</span>
        </button>
    );

    return (
        <div
            className="original-ui-scope fixed z-[80]"
            style={{ left: menu.x, top: menu.y }}
            onPointerDown={(event) => event.stopPropagation()}
        >
            <div
                className="border-canvas-controls-border flex min-w-[220px] w-max flex-col rounded-2xl border p-1.5"
                style={{ backgroundColor: "var(--canvas-controls-bg)", boxShadow: "var(--canvas-shadow-menu)" }}
            >
                {renderItem(<Wand2 size={16} />, "整理", onOrganize)}
                {renderItem(<LayoutGrid size={16} />, "宫格排序", onGridSort)}
                {renderItem(<Rows3 size={16} />, "垂直排序", onVerticalSort)}
                {renderItem(<Columns3 size={16} />, "水平排序", onHorizontalSort)}
                {onSaveAsset ? (
                    <>
                        <div className="border-canvas-controls-border my-1 border-t" />
                        <div className="relative" onMouseEnter={() => setSaveAssetMenuOpen(true)} onFocus={() => setSaveAssetMenuOpen(true)} onMouseLeave={() => setSaveAssetMenuOpen(false)}>
                            <button type="button" className={MENU_ITEM_CLASS} style={{ color: "var(--canvas-controls-text)" }} aria-haspopup="menu" aria-expanded={saveAssetMenuOpen}>
                                <span className={MENU_ICON_WRAP_CLASS}>
                                    <Plus className="size-4" />
                                </span>
                                <span className={MENU_LABEL_CLASS}>存入素材库</span>
                                <ChevronRight className="size-3.5 opacity-60" />
                            </button>
                            {saveAssetMenuOpen ? (
                                <div className="border-canvas-controls-border absolute left-full top-0 z-[81] ml-1 flex min-w-[220px] w-max flex-col rounded-2xl border p-1.5" style={{ backgroundColor: "var(--canvas-controls-bg)", boxShadow: "var(--canvas-shadow-menu)" }} role="menu">
                                    {SAVE_ASSET_CATEGORIES.map((item) => (
                                        <MenuButton key={item.category} icon={<item.icon className="size-4" />} label={`加入${item.label}库`} onClick={() => onSaveAsset(item.category)} />
                                    ))}
                                </div>
                            ) : null}
                        </div>
                    </>
                ) : null}
                {onDownload ? renderItem(<Download size={16} />, "下载", onDownload) : null}
                <div className="border-canvas-controls-border my-1 border-t" />
                {renderItem(<Trash2 size={16} />, "删除", onDelete, true)}
            </div>
        </div>
    );
}

function MenuButton({ icon, label, onClick, danger = false }: { icon: ReactNode; label: string; onClick?: () => void; danger?: boolean }) {
    // danger 保留签名兼容调用处；颜色一律白（boss 2026-10-04：删除文字也不要红色）
    return (
        <button type="button" className={MENU_ITEM_CLASS} style={{ color: "var(--canvas-controls-text)" }} onClick={onClick}>
            <span className={MENU_ICON_WRAP_CLASS}>{icon}</span>
            <span className={MENU_LABEL_CLASS}>{label}</span>
        </button>
    );
}
