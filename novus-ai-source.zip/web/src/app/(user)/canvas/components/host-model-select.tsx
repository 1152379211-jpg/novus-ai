"use client";
// 053：按 LibTV 原版 ModelSelect（model-selector-original/source/ModelSelect__mod855847.js）复刻的
// 视频模型选择器。boss 2026-10-05 拍板：视频面板模型 UI 以原版为准（简洁名 + 右侧预计耗时徽标）。
// 数据来自宿主模型库推送（use-config-store 的 hostModels），不做静态写死清单。
// 054 修正：下拉用 portal 渲染到 body（提示面板容器 overflow 会裁掉面板内 absolute 定位的菜单）。
import { memo, useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { useConfigStore } from "@/stores/use-config-store";

type HostEntry = {
    modelKey: string;
    modelName: string;
    estimatedTime?: string;
    description?: string;
    iconKind: "bars" | "dot" | "plus";
};

// boss 例子：dola-seedance-2.5 → 「Dola 2.5」。视频 dola 系按此表精简；图片等其它模型显示模型中心原名。
const DOLA_SHORT_NAMES: Record<string, string> = {
    "dola-seedance-web": "Dola 2.0",
    "dola-seedance-web-2.5": "Dola 2.5",
    "dola-seedance-2.5": "Dola 2.5",
    "dola-seedance-2.0-fast": "Dola 2.0",
};

function estimateFor(name: string): string | undefined {
    const value = name.toLowerCase();
    if (value.includes("minimax")) return value.includes("max") ? "30s" : "2min";
    if (value.includes("wan")) return value.includes("prime") ? "1min" : "3min";
    if (value.includes("pro")) return "2min";
    if (value.includes("2.5")) return "1min";
    if (value.includes("2.0")) return "2min";
    return undefined;
}

function iconFor(name: string): HostEntry["iconKind"] {
    const value = name.toLowerCase();
    if (value.includes("minimax")) return "dot";
    if (value.includes("wan")) return "plus";
    return "bars";
}

function shortenFallback(model: string) {
    const parts = String(model || "").split("/").filter(Boolean);
    return parts.slice(-2).join("/") || model;
}

function HostIcon({ kind, model }: { kind: HostEntry["iconKind"]; model: string }) {
    if (kind === "dot") {
        return (
            <svg className="size-4 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true">
                <circle cx="12" cy="12" r="7" />
                <circle cx="12" cy="12" r="2.5" fill="currentColor" stroke="none" />
            </svg>
        );
    }
    if (kind === "plus") {
        return (
            <svg className="size-4 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" aria-hidden="true">
                <path d="M12 5v14M5 12h14" />
            </svg>
        );
    }
    // bars：LibTV 柱状（画布 spark 紫 #b39dff，与底栏模型图标一致）
    return (
        <svg className="size-4 shrink-0" style={{ color: "#b39dff" }} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
            <rect x="4" y="11" width="3" height="9" rx="1" />
            <rect x="10.5" y="6" width="3" height="14" rx="1" />
            <rect x="17" y="3" width="3" height="17" rx="1" />
        </svg>
    );
}

export const HostModelSelect = memo(function HostModelSelect({
    value,
    onChange,
    capability = "video",
    disabled,
}: {
    value: string;
    onChange: (modelKey: string) => void;
    /** 054：能力过滤（video/image/text），决定显示宿主库里哪类模型；Seedance 2.5 账号池仅 video 注入 */
    capability?: "video" | "image" | "text";
    disabled?: boolean;
}) {
    const hostModels = useConfigStore((state) => state.hostModels);
    const [open, setOpen] = useState(false);
    const [menuPosition, setMenuPosition] = useState<{ left: number; bottom: number } | null>(null);
    const rootRef = useRef<HTMLDivElement>(null);
    const menuRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (!open) return;
        const onDocClick = (event: MouseEvent) => {
            // 任务rTOplz：中键（button=1）用于拖动画布——不触发"点击外部关闭"，让菜单保持打开并跟随锚点
            if (event.button === 1) return;
            const target = event.target as Node;
            if (!rootRef.current?.contains(target) && !menuRef.current?.contains(target)) setOpen(false);
        };
        const onKey = (event: KeyboardEvent) => {
            if (event.key === "Escape") setOpen(false);
        };
        document.addEventListener("mousedown", onDocClick);
        document.addEventListener("keydown", onKey);
        return () => {
            document.removeEventListener("mousedown", onDocClick);
            document.removeEventListener("keydown", onKey);
        };
    }, [open]);

    // 任务rTOplz：中键拖动/缩放画布时，菜单持续跟随触发器（锚点）的屏幕位置。
    // 用 rAF 直接改 DOM style（不走 React state），避免每帧 re-render 造成抖动；
    // 位置基于 rootRef（触发器按钮）实时 getBoundingClientRect，画布怎么动都跟着。
    useEffect(() => {
        if (!open) return;
        let raf = 0;
        let lastLeft = -1;
        let lastBottom = -1;
        const follow = () => {
            const root = rootRef.current;
            const menu = menuRef.current;
            if (root && menu) {
                const rect = root.getBoundingClientRect();
                const left = Math.max(8, Math.min(rect.left, window.innerWidth - 376));
                const bottom = window.innerHeight - rect.top + 6;
                if (Math.abs(left - lastLeft) > 0.5 || Math.abs(bottom - lastBottom) > 0.5) {
                    lastLeft = left;
                    lastBottom = bottom;
                    menu.style.left = `${left}px`;
                    menu.style.bottom = `${bottom}px`;
                }
            }
            raf = requestAnimationFrame(follow);
        };
        raf = requestAnimationFrame(follow);
        return () => cancelAnimationFrame(raf);
    }, [open]);

    // portal 定位：菜单挂在 body 上（fixed），贴触发器上方，避免提示面板 overflow 裁剪
    const openMenu = () => {
        const rect = rootRef.current?.getBoundingClientRect();
        if (rect) setMenuPosition({ left: Math.max(8, Math.min(rect.left, window.innerWidth - 376)), bottom: window.innerHeight - rect.top + 6 });
        setOpen(true);
    };

    const entries = useMemo<HostEntry[]>(() => {
        const list: HostEntry[] = [];
        const seen = new Set<string>();
        const push = (modelKey: string, modelName: string, display: string, provider: string) => {
            if (!modelKey || seen.has(modelKey)) return;
            seen.add(modelKey);
            list.push({
                modelKey,
                modelName,
                estimatedTime: estimateFor(modelName),
                description: display !== modelName ? display : undefined,
                iconKind: iconFor(modelName),
            });
        };
        // 056：文本能力只放宿主文本任务支持的模型（Dola text / ChatGPT text 账号池）；saint-api LLM 不支持宿主文本任务，不注入
        const TEXT_HOST_MODELS: Record<string, string> = { "dola-expert-web": "Dola 文本", "chatgpt-text": "ChatGPT 文本" };
        for (const item of hostModels) {
            if (!item.enabled) continue;
            if (capability === "text") {
                if (!TEXT_HOST_MODELS[item.model]) continue;
            } else {
                // video 能力下 dola 账号池模型不在宿主 type 里也能用（isSaintDolaPoolModel 通道）；image 严格按 type
                const matches = item.type === capability || (capability === "video" && item.model.includes("dola-seedance"));
                if (!matches) continue;
            }
            const display = item.displayName || item.model;
            const primary = display.split(" · ")[0]?.trim() || display;
            const channel = display.includes(" · ") ? display.split(" · ").slice(1).join(" · ") : item.provider === "dola" ? "Dola 账号池" : "";
            const modelName = DOLA_SHORT_NAMES[item.model] || (capability === "text" && TEXT_HOST_MODELS[item.model]) || primary;
            const label = channel && !modelName.toLowerCase().includes(channel.toLowerCase()) ? `${modelName}` : modelName;
            push(item.model, label, display !== modelName ? `${modelName}${channel ? ` · ${channel}` : ""}` : modelName, item.provider);
        }
        // 保留画布原有的 Seedance 2.5 账号池入口（仅视频面板）
        if (capability === "video" && !seen.has("dola-seedance-2.5")) {
            push("dola-seedance-2.5", "Seedance 2.5 账号池", "Seedance 2.5 账号池", "dola");
        }
        // 当前选中模型不在宿主库（本地渠道模型等）时追加，避免选择丢失
        if (value && !seen.has(value)) {
            list.unshift({ modelKey: value, modelName: shortenFallback(value), iconKind: "bars" });
        }
        return list;
    }, [hostModels, value]);

    const current = entries.find((entry) => entry.modelKey === value) || null;

    return (
        <div ref={rootRef} className="relative" onMouseDown={(event) => event.stopPropagation()} onPointerDown={(event) => event.stopPropagation()}>
            <button
                type="button"
                disabled={disabled}
                onClick={() => (open ? setOpen(false) : openMenu())}
                className="flex h-8 w-auto min-w-[88px] max-w-[240px] shrink-[2] items-center gap-1 rounded-lg px-2 py-1 transition-colors hover:bg-white/5 disabled:cursor-not-allowed disabled:opacity-50"
                title={current?.description || current?.modelName || value}
            >
                <HostIcon kind={current?.iconKind || "bars"} model={current?.modelKey || value} />
                <span className="max-w-[180px] truncate text-left text-[13px] text-stone-200">{current?.modelName || shortenFallback(value)}</span>
                <svg className={`size-3.5 shrink-0 text-stone-400 transition-transform ${open ? "rotate-180" : ""}`} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                    <path d="m6 9 6 6 6-6" />
                </svg>
            </button>
            {open && menuPosition && typeof document !== "undefined"
                ? createPortal(
                    <div
                        ref={menuRef}
                        className="fixed z-[1300] w-[360px] max-w-[calc(100vw-16px)] overflow-hidden rounded-2xl border p-1 shadow-2xl"
                        style={{ background: "rgba(23,23,25,0.97)", borderColor: "rgba(255,255,255,0.08)", backdropFilter: "blur(32px)", left: menuPosition.left, bottom: menuPosition.bottom }}
                        onMouseDown={(event) => event.stopPropagation()}
                    >
                    <div className="flex max-h-[400px] flex-col gap-1 overflow-y-auto">
                        {entries.length ? (
                            entries.map((entry) => {
                                const selected = entry.modelKey === value;
                                return (
                                    <button
                                        key={entry.modelKey}
                                        type="button"
                                        data-selected={selected || undefined}
                                        onClick={() => {
                                            onChange(entry.modelKey);
                                            setOpen(false);
                                        }}
                                        className="group flex h-[52px] w-full items-center gap-1 rounded-xl p-2 text-left transition-colors duration-200 hover:bg-white/5 data-[selected=true]:bg-white/10"
                                    >
                                        <div className="flex h-[34px] w-[34px] shrink-0 items-center justify-center rounded-lg bg-white/5 text-stone-400">
                                            <HostIcon kind={entry.iconKind} model={entry.modelKey} />
                                        </div>
                                        <div className="h-full flex-1 overflow-hidden pr-1">
                                            <div className="flex w-full min-w-0 items-center justify-between gap-2">
                                                <span className="truncate text-sm font-medium leading-5 text-stone-100">{entry.modelName}</span>
                                                {entry.estimatedTime ? (
                                                    <span className="shrink-0 rounded-full px-2 py-1 text-xs leading-3 text-stone-400" style={{ background: "rgba(255,255,255,0.06)" }}>
                                                        {entry.estimatedTime}
                                                    </span>
                                                ) : null}
                                            </div>
                                            {entry.description ? (
                                                <p className="truncate text-xs leading-4 text-stone-500 opacity-0 transition-opacity duration-200 group-hover:opacity-100 group-data-[selected=true]:opacity-100" data-selected={selected || undefined}>
                                                    {entry.description}
                                                </p>
                                            ) : null}
                                        </div>
                                        {selected ? (
                                            <svg className="size-4 shrink-0 text-stone-300" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                                                <path d="m5 12 5 5L20 7" />
                                            </svg>
                                        ) : null}
                                    </button>
                                );
                            })
                        ) : (
                            <div className="px-3 py-4 text-center text-sm text-stone-500">暂无可用模型</div>
                        )}
                    </div>
                </div>,
                    document.body,
                )
                : null}
        </div>
    );
});
