"use client";

import { useEffect, useRef, useState } from "react";
import { ArrowUp, LoaderCircle, Maximize2 } from "lucide-react";
import { Button, Modal, Tooltip } from "antd";

import { ModelPicker } from "@/components/model-picker";
import { HostModelSelect } from "@/app/(user)/canvas/components/host-model-select";
import { useAutoDLWorkflow } from "@/hooks/use-autodl-workflow";
import { getAutoDLCapabilities, isAutoDLConfig } from "@/lib/autodl";
import { defaultConfig, resolveModelForCapability, useConfigStore, useEffectiveConfig, type AiConfig } from "@/stores/use-config-store";
import { isSeedanceVideoModel, seedancePixelLabel } from "@/lib/seedance-video";
import { CreditSymbol, requestCreditCost } from "@/constant/credits";
import { canvasThemes } from "@/lib/canvas-theme";
import { useThemeStore } from "@/stores/use-theme-store";
import { CanvasImageSettingsPopover } from "./canvas-image-settings-popover";
import { CanvasAudioSettingsPopover, type CanvasAudioSettingKey } from "./canvas-audio-settings-popover";
import { CanvasPromptChipInput } from "./canvas-prompt-chip-input";
import { CanvasNodeReferenceBar } from "./canvas-node-reference-bar";
import { CanvasVideoSettingsPopover, type CanvasVideoFrameOption, type CanvasVideoResourceOption } from "./canvas-video-settings-popover";
import { CanvasNodeType, type CanvasGenerationMode, type CanvasNodeData, type CanvasNodeMetadata } from "../types";
import { PANORAMA_IMAGE_SIZE, isCanvasImageNodeType, isPanoramaNodeType } from "../utils/canvas-panorama";
import type { CanvasResourceReference } from "../utils/canvas-resource-references";
import "./canvas-prompt-bar.css";

export type { CanvasVideoFrameOption };

export type CanvasNodeGenerationMode = CanvasGenerationMode;

type CanvasNodePromptPanelProps = {
    node: CanvasNodeData;
    isRunning: boolean;
    onPromptChange: (nodeId: string, prompt: string) => void;
    onConfigChange: (nodeId: string, patch: Partial<CanvasNodeData["metadata"]>) => void;
    onGenerate: (nodeId: string, mode: CanvasNodeGenerationMode, prompt: string) => void;
    mentionReferences?: CanvasResourceReference[];
    connectedNodes?: CanvasNodeData[];
    onDisconnectReference?: (fromNodeId: string, toNodeId: string) => void;
    onReorderReference?: (orderedFromNodeIds: string[]) => void;
    onStartReferenceSelection?: (nodeId: string) => void;
    videoFrameOptions?: CanvasVideoFrameOption[];
    videoResourceOptions?: CanvasVideoResourceOption[];
    onImageSettingsOpenChange?: (open: boolean) => void;
    /** 030：分类库（角色/场景/服装/道具/其他）点开 → 画布页弹「我的资产」分类选素材并连线为参考 */
    onOpenCategoryLibrary?: (nodeId: string, category: string) => void;
};

function PromptBarDivider() {
    return <span aria-hidden className="canvas-prompt-bar-divider" />;
}

/** 模型 id → 触发器短名（boss 2026-10-03 15:23 要求简略；15:31 确认要「后两段」形式：dola-seedance-2.5 → seedance-2.5） */
function shortModelLabel(model: string) {
    const parts = String(model || "").split("-").filter(Boolean);
    if (parts.length <= 2) return parts.join("-");
    return parts.slice(-2).join("-");
}

export function CanvasNodePromptPanel({ node, isRunning, onPromptChange, onConfigChange, onGenerate, mentionReferences = [], connectedNodes = [], videoFrameOptions = [], videoResourceOptions = [], onDisconnectReference, onReorderReference, onStartReferenceSelection, onImageSettingsOpenChange, onOpenCategoryLibrary }: CanvasNodePromptPanelProps) {
    const globalConfig = useEffectiveConfig();
    const modelCosts = useConfigStore((state) => state.publicSettings?.modelChannel.modelCosts);
    const openConfigDialog = useConfigStore((state) => state.openConfigDialog);
    const theme = canvasThemes[useThemeStore((state) => state.theme)];
    const mode = defaultMode(node.type);
    const config = buildNodeConfig(globalConfig, node, mode);
    const { data: autodlWorkflow } = useAutoDLWorkflow(config, mode === "video" ? config.model : "");
    const isPanorama = isPanoramaNodeType(node.type);
    const hasTextContent = node.type === CanvasNodeType.Text && Boolean(node.metadata?.content?.trim());
    const hasImageContent = isCanvasImageNodeType(node.type) && Boolean(node.metadata?.content);
    const sourcePrompt = isPanorama ? node.metadata?.panoramaSourcePrompt || "" : node.metadata?.prompt || "";
    const [prompt, setPrompt] = useState(sourcePrompt);
    const [expanded, setExpanded] = useState(false);
    const workflowRef = node.metadata?.workflowRef;
    const billingModel = workflowRef
        ? `workflow:${workflowRef.scope}:${workflowRef.channelId}:${workflowRef.kind}:${workflowRef.workflowId}`
        : config.model;
    const credits = requestCreditCost({ channelMode: config.channelMode, modelCosts, model: billingModel, count: mode === "image" ? config.count : 1, seconds: mode === "video" ? config.videoSeconds : undefined });

    useEffect(() => {
        setPrompt(sourcePrompt);
    }, [node.id, sourcePrompt]);

    // 生成中的紫色粒子流（对齐旧版 PromptBar 的 sparks canvas，只在生成时运行）
    const sparkRef = useRef<HTMLCanvasElement>(null);
    useEffect(() => {
        if (!isRunning) return;
        const canvas = sparkRef.current;
        const ctx = canvas?.getContext("2d");
        if (!canvas || !ctx) return;
        const sparkColor = "#b39dff";
        type Spark = { x: number; y: number; r: number; vy: number; sway: number; phase: number; life: number; span: number };
        const parts: Spark[] = [];
        let raf = 0;
        let w = 0;
        let h = 0;
        let last = performance.now();
        let due = 0;
        const resize = () => {
            const rect = canvas.getBoundingClientRect();
            const dpr = Math.min(2, window.devicePixelRatio || 1);
            w = rect.width;
            h = rect.height;
            canvas.width = Math.round(w * dpr);
            canvas.height = Math.round(h * dpr);
            ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        };
        const spawn = (burst: boolean) => {
            parts.push({
                x: Math.random() * w,
                y: burst ? h * (0.2 + Math.random() * 0.8) : h + 3,
                r: 0.9 + Math.random() * 1.1,
                vy: -(7 + Math.random() * 9),
                sway: (Math.random() - 0.5) * 10,
                phase: Math.random() * Math.PI * 2,
                life: burst ? Math.random() * 1.2 : 0,
                span: 2.4 + Math.random() * 2.4,
            });
        };
        const tick = (now: number) => {
            const dt = Math.min(0.05, (now - last) / 1000);
            last = now;
            due += dt;
            while (due > 0.14) {
                due -= 0.14;
                if (parts.length < 30) spawn(false);
            }
            ctx.clearRect(0, 0, w, h);
            ctx.fillStyle = sparkColor;
            ctx.shadowColor = sparkColor;
            ctx.shadowBlur = 8;
            for (let i = parts.length - 1; i >= 0; i -= 1) {
                const part = parts[i];
                part.life += dt;
                if (part.life > part.span) {
                    parts.splice(i, 1);
                    continue;
                }
                const k = part.life / part.span;
                const twinkle = 0.7 + 0.3 * Math.sin(now / 160 + part.phase);
                part.y += part.vy * dt;
                if (part.y < -4) {
                    part.y = h + 3;
                    part.x = Math.random() * w;
                }
                const edge = Math.min(1, Math.max(0, part.y / 14), Math.max(0, (h - part.y) / 14));
                ctx.globalAlpha = Math.min(1, Math.sin(k * Math.PI) * twinkle) * edge;
                ctx.beginPath();
                ctx.arc(part.x + Math.sin(now / 900 + part.phase) * part.sway, part.y, part.r * twinkle, 0, Math.PI * 2);
                ctx.fill();
            }
            raf = requestAnimationFrame(tick);
        };
        resize();
        for (let i = 0; i < 26; i += 1) spawn(true);
        const observer = new ResizeObserver(resize);
        observer.observe(canvas);
        raf = requestAnimationFrame(tick);
        return () => {
            cancelAnimationFrame(raf);
            observer.disconnect();
            ctx.clearRect(0, 0, w, h);
        };
    }, [isRunning]);

    const updatePrompt = (value: string) => {
        setPrompt(value);
        onPromptChange(node.id, value);
    };

    const canSubmit = Boolean(prompt.trim()) || (mode !== "text" && Boolean(node.metadata?.workflowRef)) || (mode === "video" && isAutoDLConfig(config) && getAutoDLCapabilities(autodlWorkflow)?.promptRequired === false) || (isPanorama && (hasImageContent || mentionReferences.length > 0));

    const submit = () => {
        const text = prompt.trim();
        if (!canSubmit || isRunning) return;
        onGenerate(node.id, mode, text);
        // 027（用户反馈 2026-10-04）：点击生成后不再清空提示词——文字保留在输入框里（提示词本身已实时持久化到 node.metadata.prompt）
    };

    return (
        <div
            data-canvas-no-zoom
            /* 真值（报告 B1）：bg-panel-background relative flex w-full flex-col gap-0
               overflow-hidden rounded-2xl(16) border-hair(.5px)
               shadow-[0px_4px_10px_0px_rgba(0,0,0,0.12)] —— gap-0 + 无 padding，
               padding/gap 全在下面那层 .canvas-prompt-bar-main（= GeneratorMainColumn） */
            className={"canvas-prompt-bar-host relative flex w-full flex-col overflow-hidden rounded-2xl" + (isRunning ? " canvas-prompt-bar-generating" : "")}
            /* 不传内联 color：真值 fg-default 暗色 = #f7f7f7，由 CSS 统一给 */
            onMouseDown={(event) => event.stopPropagation()}
            onPointerDown={(event) => event.stopPropagation()}
            onWheel={(event) => event.stopPropagation()}
        >
            {isRunning ? <canvas ref={sparkRef} className="canvas-prompt-bar-sparks" aria-hidden="true" /> : null}
            {/* 真值（真实渲染模块实测）：放大按钮是面板根直接子元素 absolute right-2 top-2 z-10
               size-7(28) rounded-lg(8) bg-panel-background(#262626 不透明，盖住下面 chips) */}
            <Tooltip title="放大编辑">
                <button type="button" className="absolute right-2 top-2 z-10 grid size-7 shrink-0 place-items-center p-0 transition-colors hover:bg-btn-ghost-hover" style={{ background: "#262626", color: "#f7f7f7", borderRadius: "8px" }} onClick={() => setExpanded(true)} aria-label="放大编辑">
                    <Maximize2 className="size-4" />
                </button>
            </Tooltip>
            {/* 真值（报告 B1）：内层 = "flex min-h-0 w-full flex-col"，
               再套 GeneratorMainColumn className="gap-2 p-2" */}
            <div className="flex min-h-0 w-full flex-col">
            <div className="canvas-prompt-bar-main">
            {/* 真值（真实渲染模块实测）：chips 行是主列直接子元素，无包装层 */}
            <CanvasNodeReferenceBar nodeId={node.id} connectedNodes={connectedNodes} onDisconnect={onDisconnectReference} onReorder={onReorderReference} onStartSelection={onStartReferenceSelection} onOpenCategoryLibrary={onOpenCategoryLibrary} />
            <CanvasPromptChipInput
                value={prompt}
                references={mentionReferences}
                onChange={updatePrompt}
                onSubmit={submit}
                className="thin-scrollbar canvas-prompt-bar-editor w-full resize-none outline-none"
                style={{ background: "transparent", color: theme.node.text }}
                placeholder={isPanorama ? "描述想生成的全景，或上传/连接图片作为参考" : mentionReferences.length > 0 || connectedNodes.length > 0 ? (mode === "video" ? "描述你想要生成的画面内容，@引用素材" : promptPlaceholder(mode, hasImageContent, hasTextContent)) : promptPlaceholder(mode, hasImageContent, hasTextContent)}
            />

            <div data-generator-control-bar="" className="canvas-prompt-bar-bottom">
                <div className="canvas-prompt-bar-controls">
                    {mode === "image" ? (
                        <>
                            {/* 054：图片面板也换 LibTV 原版模型选择 UI（boss：以原版为准）；宿主模型（Dola 账号池生图/ChatGPT image2/saint-api 渠道）走宿主任务 */}
                            <HostModelSelect capability="image" value={node.metadata?.model || config.model} onChange={(model) => onConfigChange(node.id, { model })} />
                            <CanvasImageSettingsPopover
                                config={node.metadata?.workflowRef ? { ...config, model: "" } : config}
                                placement="topLeft"
                                buttonClassName="!h-8 !w-[120px] !shrink-0 !justify-start !rounded-full !px-2"
                                onConfigChange={(key, value) => onConfigChange(node.id, key === "count" ? { count: Number(value) || 1 } : { [key]: value })}
                                onMissingConfig={() => openConfigDialog(true)}
                                onOpenChange={onImageSettingsOpenChange}
                                showSize={!isPanorama}
                            />
                        </>
                    ) : mode === "video" ? (
                        <>
                            {/* 053：视频模型选择器按 LibTV 原版 ModelSelect UI 重做（boss 2026-10-05：以原版为准）——简洁名 + 右侧预计耗时徽标 */}
                            <HostModelSelect value={node.metadata?.model || config.model} onChange={(model) => onConfigChange(node.id, { model, ...(String(model).toLowerCase().includes("dola-seedance") ? { vquality: "720", size: seedancePixelLabel("720p", "21:9") } : {}) })} />
                            {/* 第3点：「文生视频/图生视频」模式选择器已删除 */}
                            <PromptBarDivider />
                            <CanvasVideoSettingsPopover config={config} wideScreenLabel="宽荧幕" buttonClassName="canvas-prompt-bar-settings" frameOptions={videoFrameOptions} resourceOptions={videoResourceOptions} metadata={node.metadata} firstFrameNodeId={node.metadata?.firstFrameNodeId} lastFrameNodeId={node.metadata?.lastFrameNodeId} onFrameChange={(patch) => onConfigChange(node.id, patch)} onMetadataChange={(patch) => onConfigChange(node.id, patch)} onConfigChange={(key, value) => onConfigChange(node.id, videoConfigPatch(key, value))} />
                        </>
                    ) : mode === "audio" ? (
                        <>
                            <ModelPicker menuClassName="canvas-prompt-bar-menu" className="!w-[150px] !min-w-0 !shrink-0" config={config} value={config.model} channelId={config.audioChannelId || config.activeChannelId} workflowRef={node.metadata?.workflowRef} onWorkflowChange={(workflowRef) => onConfigChange(node.id, { workflowRef })} onChange={(model, channelId) => onConfigChange(node.id, { model, channelId })} capability="audio" onMissingConfig={() => openConfigDialog(true)} />
                            <PromptBarDivider />
                            <CanvasAudioSettingsPopover config={config} resourceOptions={videoResourceOptions} metadata={node.metadata} onMetadataChange={(patch) => onConfigChange(node.id, patch)} buttonClassName="!h-8 !w-[120px] !shrink-0 !justify-start !rounded-full !px-2" onConfigChange={(key, value) => onConfigChange(node.id, audioConfigPatch(key, value))} />
                        </>
                    ) : (
                        <>
                            {/* 056：文本面板也换原版 UI；Dola text / ChatGPT text 走宿主账号池 */}
                            <HostModelSelect capability="text" value={node.metadata?.model || config.model} onChange={(model) => onConfigChange(node.id, { model })} />
                        </>
                    )}
                </div>
                {/* 真值（报告 B5/C1）：右组 "flex shrink-0 items-start gap-1" ← 顶对齐 */}
                <div className="flex shrink-0 items-start gap-1">
                    {/* 第4点：智能分镜 / 翻译 / 高级设置 三个图标按钮已全部删除 */}
                    {/* 真值（报告 B9）：.gen = min-w-[85px] justify-end + h-8 items-center gap-2，无 margin */}
                    <div className="canvas-prompt-bar-generate">
                        <span className="canvas-prompt-bar-power">
                            <span className="inline-flex" style={{ color: "#F2A93A" }}>
                                <CreditSymbol />
                            </span>
                            {/* 真值：min-w-5(20) text-center text-[12px] leading-[15px] font-normal */}
                            <span className="canvas-prompt-bar-power-value">{credits.toLocaleString()}</span>
                        </span>
                        {/* 真值（报告 B9）：size-8(32) rounded-xl(12) bg #f7f7f7 icon #141414 size-3(12) */}
                        <Button
                            type="primary"
                            className="canvas-prompt-bar-send"
                            disabled={isRunning || !canSubmit}
                            onClick={submit}
                            aria-label="生成"
                        >
                            {isRunning ? <LoaderCircle className="size-3 animate-spin" /> : <ArrowUp className="size-3" />}
                        </Button>
                    </div>
                </div>
            </div>
            </div>
            </div>
            <Modal title="编辑提示词" open={expanded} centered width={760} footer={null} onCancel={() => setExpanded(false)} destroyOnHidden transitionName="" maskTransitionName="">
                <div data-canvas-no-zoom className="h-[52dvh] pt-2" onWheelCapture={(event) => event.stopPropagation()}>
                    <CanvasNodeReferenceBar nodeId={node.id} connectedNodes={connectedNodes} onDisconnect={onDisconnectReference} onReorder={onReorderReference} onStartSelection={(nodeId) => { setExpanded(false); onStartReferenceSelection?.(nodeId); }} onOpenCategoryLibrary={(libraryNodeId, category) => { setExpanded(false); onOpenCategoryLibrary?.(libraryNodeId, category); }} />
                    <CanvasPromptChipInput
                        value={prompt}
                        references={mentionReferences}
                        onChange={updatePrompt}
                        className="thin-scrollbar canvas-prompt-bar-editor canvas-prompt-bar-editor-expanded w-full cursor-text resize-none outline-none"
                        style={{ background: "transparent", borderColor: theme.toolbar.border, color: theme.node.text }}
                        placeholder={isPanorama ? "描述想生成的全景，或上传/连接图片作为参考" : mentionReferences.length > 0 || connectedNodes.length > 0 ? (mode === "video" ? "描述你想要生成的画面内容，@引用素材" : promptPlaceholder(mode, hasImageContent, hasTextContent)) : promptPlaceholder(mode, hasImageContent, hasTextContent)}
                    />
                </div>
            </Modal>
        </div>
    );
}

function defaultMode(type: CanvasNodeData["type"]): CanvasNodeGenerationMode {
    return type === CanvasNodeType.Text ? "text" : type === CanvasNodeType.Video ? "video" : type === CanvasNodeType.Audio ? "audio" : "image";
}

function buildNodeConfig(globalConfig: AiConfig, node: CanvasNodeData, mode: CanvasNodeGenerationMode): AiConfig {
    const defaultModel = mode === "image" ? globalConfig.imageModel : mode === "video" ? (!globalConfig.videoModel || globalConfig.videoModel === "grok-imagine-video" ? "dola-seedance-2.5" : globalConfig.videoModel) : mode === "audio" ? globalConfig.audioModel : globalConfig.textModel;
    const isDolaSeedanceVideo = mode === "video" && isSeedanceVideoModel(node.metadata?.model || defaultModel || "") && String(node.metadata?.model || defaultModel || "").toLowerCase().includes("dola");
    const channelId = node.metadata?.channelId || "";
    const imageChannelId = mode === "image" ? channelId || globalConfig.imageChannelId : globalConfig.imageChannelId;
    const videoChannelId = mode === "video" ? channelId || globalConfig.videoChannelId : globalConfig.videoChannelId;
    const textChannelId = mode === "text" ? channelId || globalConfig.textChannelId : globalConfig.textChannelId;
    const audioChannelId = mode === "audio" ? channelId || globalConfig.audioChannelId : globalConfig.audioChannelId;
    const activeChannelId = mode === "image" ? imageChannelId : mode === "video" ? videoChannelId : mode === "text" ? textChannelId : mode === "audio" ? audioChannelId || globalConfig.activeChannelId : globalConfig.activeChannelId;
    return {
        ...globalConfig,
        model: mode === "text" ? resolveModelForCapability(globalConfig, node.metadata?.model, "text") : node.metadata?.model || defaultModel || (mode === "audio" ? defaultConfig.audioModel : globalConfig.model || defaultConfig.model),
        activeChannelId,
        imageChannelId,
        videoChannelId,
        textChannelId,
        audioChannelId,
        quality: node.metadata?.quality || globalConfig.quality || defaultConfig.quality,
        size: isPanoramaNodeType(node.type) ? PANORAMA_IMAGE_SIZE : node.metadata?.size || (isDolaSeedanceVideo ? seedancePixelLabel("720p", "21:9") : mode === "video" ? globalConfig.videoSize || defaultConfig.videoSize : globalConfig.size || defaultConfig.size),
        videoSeconds: isAutoDLConfig({ ...globalConfig, activeChannelId, videoChannelId }, node.metadata?.model || defaultModel) ? node.metadata?.seconds ?? globalConfig.videoSeconds : node.metadata?.seconds || (defaultModel === "dola-seedance-2.5" ? "30" : globalConfig.videoSeconds || defaultConfig.videoSeconds),
        vquality: node.metadata?.vquality || globalConfig.vquality || defaultConfig.vquality,
        videoMode: node.metadata?.mode || globalConfig.videoMode || defaultConfig.videoMode,
        videoNegativePrompt: node.metadata?.negativePrompt || globalConfig.videoNegativePrompt || defaultConfig.videoNegativePrompt,
        videoMultiShot: node.metadata?.multiShot || globalConfig.videoMultiShot || defaultConfig.videoMultiShot,
        videoShotType: node.metadata?.shotType || globalConfig.videoShotType || defaultConfig.videoShotType,
        videoGenerateAudio: node.metadata?.generateAudio || globalConfig.videoGenerateAudio || defaultConfig.videoGenerateAudio,
        videoCharacterOrientation: node.metadata?.characterOrientation || globalConfig.videoCharacterOrientation || defaultConfig.videoCharacterOrientation,
        videoWatermark: node.metadata?.watermark || globalConfig.videoWatermark || defaultConfig.videoWatermark,
        audioVoice: node.metadata?.audioVoice || globalConfig.audioVoice || defaultConfig.audioVoice,
        audioFormat: node.metadata?.audioFormat || globalConfig.audioFormat || defaultConfig.audioFormat,
        audioSpeed: node.metadata?.audioSpeed || globalConfig.audioSpeed || defaultConfig.audioSpeed,
        audioInstructions: node.metadata?.audioInstructions || globalConfig.audioInstructions || defaultConfig.audioInstructions,
        grokTtsVoice: node.metadata?.grokTtsVoice || globalConfig.grokTtsVoice || defaultConfig.grokTtsVoice,
        grokTtsLanguage: node.metadata?.grokTtsLanguage || globalConfig.grokTtsLanguage || defaultConfig.grokTtsLanguage,
        grokTtsFormat: node.metadata?.grokTtsFormat || globalConfig.grokTtsFormat || defaultConfig.grokTtsFormat,
        grokTtsSpeed: node.metadata?.grokTtsSpeed || globalConfig.grokTtsSpeed || defaultConfig.grokTtsSpeed,
        glmTtsVoice: node.metadata?.glmTtsVoice || globalConfig.glmTtsVoice || defaultConfig.glmTtsVoice,
        glmTtsFormat: node.metadata?.glmTtsFormat || globalConfig.glmTtsFormat || defaultConfig.glmTtsFormat,
        glmTtsSpeed: node.metadata?.glmTtsSpeed || globalConfig.glmTtsSpeed || defaultConfig.glmTtsSpeed,
        mimoTtsVoice: node.metadata?.mimoTtsVoice || globalConfig.mimoTtsVoice || defaultConfig.mimoTtsVoice,
        mimoTtsFormat: node.metadata?.mimoTtsFormat || globalConfig.mimoTtsFormat || defaultConfig.mimoTtsFormat,
        mimoVoiceDesignPrompt: node.metadata?.mimoVoiceDesignPrompt || globalConfig.mimoVoiceDesignPrompt || defaultConfig.mimoVoiceDesignPrompt,
        geminiTtsVoice: node.metadata?.geminiTtsVoice || globalConfig.geminiTtsVoice || defaultConfig.geminiTtsVoice,
        count: String(node.metadata?.count || (mode === "image" ? globalConfig.canvasImageCount || globalConfig.count : globalConfig.count) || defaultConfig.count),
    };
}

function isEmbeddedCanvas() {
    return typeof window !== "undefined" && window.parent !== window;
}

function promptPlaceholder(mode: CanvasNodeGenerationMode, hasImageContent: boolean, hasTextContent: boolean) {
    // video 模式用 LibTV 源码 i18n key `common:promptPlaceholderVideoWithMention` 的中文原文
    if (mode === "video") return "描述你想要生成的画面内容，@引用素材";
    if (mode === "audio") return "描述要生成的音频内容";
    if (mode === "image") return hasImageContent ? "请输入你想要把这张图修改成什么" : "描述要生成的图片内容";
    return hasTextContent ? "请输入你想要将本段文本修改成什么" : "请输入你想要生成的文本内容";
}

function videoConfigPatch(key: keyof AiConfig, value: string) {
    if (key === "count") return { count: Number(value) || 1 };
    if (key === "videoSeconds") return { seconds: value };
    if (key === "videoMode") return { mode: value };
    if (key === "videoNegativePrompt") return { negativePrompt: value };
    if (key === "videoMultiShot") return { multiShot: value };
    if (key === "videoShotType") return { shotType: value };
    if (key === "videoGenerateAudio") return { generateAudio: value };
    if (key === "videoCharacterOrientation") return { characterOrientation: value };
    if (key === "videoWatermark") return { watermark: value };
    return { [key]: value };
}

function audioConfigPatch(key: CanvasAudioSettingKey, value: string): Partial<CanvasNodeMetadata> {
    return { [key]: value } as Partial<CanvasNodeMetadata>;
}
