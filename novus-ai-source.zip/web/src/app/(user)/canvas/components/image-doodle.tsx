"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import type { PointerEvent as ReactPointerEvent, MouseEvent as ReactMouseEvent, CSSProperties } from "react";
import type { CanvasNodeData, ViewportTransform } from "../types";

/* ============================================================
   078→rvgR9q（2026-10-07 用户定案重做）：图片节点涂鸦标注
   行为：涂鸦跟着图走——编辑期间笔迹只存父组件会话状态（annotateStrokes），
   **绝不写入原节点 metadata**；点「完成」由父组件把「原图+笔迹」合成为
   一张新图、生成全新独立节点（原图一丝不动）；点「取消」/Esc 直接丢弃。
   笔迹坐标为 0..1 归一化（相对节点盒），父组件按 object-contain 显示区
   映射到原图像素做合成。
   （旧版把笔迹存 node.metadata.doodleStrokes 导致漂浮残留 + 跨图串笔迹，
   已废弃该写入路径；metadata 字段仅为兼容旧数据保留。）
   ============================================================ */

export type DoodleStroke = { color: string; size: number; points: number[] };

const DOODLE_COLORS = ["#ef4444", "#f59e0b", "#22c55e", "#3b82f6", "#ffffff", "#111827"];
const DOODLE_SIZES = [3, 6, 12];

function strokeToPath(points: number[]) {
    if (points.length < 4) return "";
    let d = `M ${points[0].toFixed(4)} ${points[1].toFixed(4)}`;
    for (let i = 2; i + 1 < points.length; i += 2) d += ` L ${points[i].toFixed(4)} ${points[i + 1].toFixed(4)}`;
    return d;
}

function StrokePath({ stroke, opacity = 1 }: { stroke: DoodleStroke; opacity?: number }) {
    return (
        <path
            d={strokeToPath(stroke.points)}
            fill="none"
            stroke={stroke.color}
            strokeWidth={stroke.size}
            strokeLinecap="round"
            strokeLinejoin="round"
            opacity={opacity}
            vectorEffect="non-scaling-stroke"
        />
    );
}

/** 非编辑态的笔迹显示层（pointer-events-none，纯展示）
 *  任务rvgR9q 修复：本层渲染在画布变换层**内部**（与 CanvasNode 同容器），
 *  必须用画布坐标（node.position/width/height）——此前按屏幕坐标
 *  （viewport.x + position*k）计算导致 viewport 被应用两次，拖动画布后笔迹
 *  错位漂移、悬浮在固定位置不归位。 */
export function DoodleStrokesOverlay({ node }: { node: CanvasNodeData }) {
    const strokes = (node.metadata?.doodleStrokes || []) as DoodleStroke[];
    if (!strokes.length) return null;
    return (
        <svg
            className="pointer-events-none absolute"
            style={{ left: node.position.x, top: node.position.y, width: node.width, height: node.height, zIndex: 55, overflow: "visible" }}
            viewBox="0 0 1 1"
            preserveAspectRatio="none"
            aria-hidden="true"
        >
            {strokes.map((stroke, index) => (
                <StrokePath key={index} stroke={stroke} />
            ))}
        </svg>
    );
}

const PALETTE_STYLE: CSSProperties = {
    background: "rgba(24,24,27,0.96)",
    border: "1px solid rgba(255,255,255,0.12)",
    borderRadius: 12,
    boxShadow: "0 8px 24px rgba(0,0,0,0.45)",
};

/** 编辑态：覆盖在节点上的手绘画布 + 调色盘（颜色/粗细/撤销/清空/完成）
 *  rvgR9q：笔迹只走会话状态（strokes/onChange 由父组件持有，不落节点 metadata）；
 *  「完成」= onFinish（父组件合成原图+笔迹出新独立节点）；Esc = onClose（取消，全部丢弃）。 */
export function ImageDoodleEditor({
    node,
    viewport,
    strokes,
    onChange,
    onFinish,
    onClose,
}: {
    node: CanvasNodeData;
    viewport: ViewportTransform;
    strokes: DoodleStroke[];
    onChange: (strokes: DoodleStroke[]) => void;
    onFinish: () => void;
    onClose: () => void;
}) {
    const [color, setColor] = useState(DOODLE_COLORS[0]);
    const [size, setSize] = useState(DOODLE_SIZES[1]);
    const [draft, setDraft] = useState<number[] | null>(null);
    const drawingRef = useRef(false);

    const left = viewport.x + node.position.x * viewport.k;
    const top = viewport.y + node.position.y * viewport.k;
    const width = Math.max(2, node.width * viewport.k);
    const height = Math.max(2, node.height * viewport.k);

    useEffect(() => {
        const handler = (event: KeyboardEvent) => {
            if (event.key !== "Escape") return;
            event.stopPropagation();
            onClose();
        };
        window.addEventListener("keydown", handler, true);
        return () => window.removeEventListener("keydown", handler, true);
    }, [onClose]);

    const stopEvent = useCallback((event: ReactMouseEvent<SVGSVGElement>) => {
        event.stopPropagation();
    }, []);

    const handlePointerDown = useCallback((event: ReactPointerEvent<SVGSVGElement>) => {
        if (event.pointerType === "mouse" && event.button !== 0) return;
        event.stopPropagation();
        event.preventDefault();
        try { event.currentTarget.setPointerCapture(event.pointerId); } catch (_) {}
        drawingRef.current = true;
        const rect = event.currentTarget.getBoundingClientRect();
        const x = Math.min(1, Math.max(0, (event.clientX - rect.left) / rect.width));
        const y = Math.min(1, Math.max(0, (event.clientY - rect.top) / rect.height));
        setDraft([x, y]);
    }, []);

    const handlePointerMove = useCallback((event: ReactPointerEvent<SVGSVGElement>) => {
        if (!drawingRef.current) return;
        event.stopPropagation();
        const rect = event.currentTarget.getBoundingClientRect();
        const x = Math.min(1, Math.max(0, (event.clientX - rect.left) / rect.width));
        const y = Math.min(1, Math.max(0, (event.clientY - rect.top) / rect.height));
        setDraft((prev) => {
            if (!prev) return prev;
            const lastX = prev[prev.length - 2];
            const lastY = prev[prev.length - 1];
            if (Math.hypot(x - lastX, y - lastY) < 0.0025) return prev;
            return [...prev, x, y];
        });
    }, []);

    const commitDraft = useCallback(() => {
        drawingRef.current = false;
        setDraft((prev) => {
            if (prev && prev.length >= 4) onChange([...strokes, { color, size, points: prev }]);
            return null;
        });
    }, [color, size, strokes, onChange]);

    const handlePointerUp = useCallback((event: ReactPointerEvent<SVGSVGElement>) => {
        if (!drawingRef.current) return;
        event.stopPropagation();
        try { event.currentTarget.releasePointerCapture(event.pointerId); } catch (_) {}
        commitDraft();
    }, [commitDraft]);

    return (
        <>
            <svg
                className="absolute"
                style={{ left, top, width, height, zIndex: 72, cursor: "crosshair", touchAction: "none" }}
                viewBox="0 0 1 1"
                preserveAspectRatio="none"
                onPointerDown={handlePointerDown}
                onPointerMove={handlePointerMove}
                onPointerUp={handlePointerUp}
                onPointerCancel={handlePointerUp}
                onMouseDown={stopEvent}
                onContextMenu={(event) => { event.preventDefault(); event.stopPropagation(); }}
            >
                {strokes.map((stroke, index) => (
                    <StrokePath key={index} stroke={stroke} />
                ))}
                {draft && draft.length >= 2 ? <StrokePath stroke={{ color, size, points: draft }} opacity={0.85} /> : null}
            </svg>
            <div
                className="absolute flex -translate-x-1/2 -translate-y-full items-center gap-2 rounded-xl px-2.5 py-2"
                style={{ ...PALETTE_STYLE, left: left + width / 2, top: top - 12, zIndex: 73 }}
                onMouseDown={(event) => event.stopPropagation()}
                onPointerDown={(event) => event.stopPropagation()}
            >
                {DOODLE_COLORS.map((item) => (
                    <button
                        key={item}
                        type="button"
                        aria-label={`颜色 ${item}`}
                        onClick={() => setColor(item)}
                        className="h-6 w-6 rounded-full transition-transform hover:scale-110"
                        style={{
                            background: item,
                            border: "1px solid rgba(255,255,255,0.35)",
                            outline: color === item ? "2px solid #60a5fa" : "none",
                            outlineOffset: 2,
                        }}
                    />
                ))}
                <span className="mx-1 h-6 w-px shrink-0" style={{ background: "rgba(255,255,255,0.15)" }} />
                {DOODLE_SIZES.map((item) => (
                    <button
                        key={item}
                        type="button"
                        aria-label={`粗细 ${item}`}
                        onClick={() => setSize(item)}
                        className="flex h-7 w-7 items-center justify-center rounded-lg transition-colors hover:bg-white/10"
                        style={{ outline: size === item ? "1.5px solid #60a5fa" : "none" }}
                    >
                        <span className="rounded-full bg-white" style={{ width: Math.min(14, item + 2), height: Math.min(14, item + 2) }} />
                    </button>
                ))}
                <span className="mx-1 h-6 w-px shrink-0" style={{ background: "rgba(255,255,255,0.15)" }} />
                <button type="button" onClick={() => onChange(strokes.slice(0, -1))} disabled={!strokes.length}
                    className="rounded-lg px-2 py-1 text-[12px] text-zinc-200 transition-colors hover:bg-white/10 disabled:opacity-40">撤销</button>
                <button type="button" onClick={() => onChange([])} disabled={!strokes.length}
                    className="rounded-lg px-2 py-1 text-[12px] text-zinc-200 transition-colors hover:bg-white/10 disabled:opacity-40">清空</button>
                <button type="button" onClick={onClose}
                    className="rounded-lg px-2 py-1 text-[12px] text-zinc-400 transition-colors hover:bg-white/10">取消</button>
                <button type="button" onClick={onFinish} disabled={!strokes.length}
                    className="rounded-lg bg-[#2569ff] px-2.5 py-1 text-[12px] font-medium text-white transition-colors hover:bg-[#1d5ae0] disabled:opacity-40">完成</button>
            </div>
        </>
    );
}
