"use client";

import { FileText, ImagePlus, Music, MousePointerClick, Scissors, Video } from "lucide-react";

import { canvasThemes } from "@/lib/canvas-theme";
import { useThemeStore } from "@/stores/use-theme-store";

export type CanvasEmptyStateAction = "image" | "video" | "audio" | "script" | "clip";

/** 空画布欢迎态：居中提示 + 快捷创建 chips（参考竞品空画布样式） */
export function CanvasEmptyState({ onPick }: { onPick: (action: CanvasEmptyStateAction) => void }) {
    const theme = canvasThemes[useThemeStore((state) => state.theme)];
    const chips: Array<{ key: CanvasEmptyStateAction; label: string; icon: typeof ImagePlus }> = [
        { key: "image", label: "图片生成", icon: ImagePlus },
        { key: "video", label: "视频生成", icon: Video },
        { key: "audio", label: "音频生成", icon: Music },
        { key: "script", label: "剧本生成", icon: FileText },
        { key: "clip", label: "智能剪辑", icon: Scissors },
    ];
    return (
        <div className="pointer-events-none absolute inset-0 z-20 flex flex-col items-center justify-center gap-6">
            <div className="flex items-center gap-2 text-[13px]" style={{ color: theme.node.muted }}>
                <MousePointerClick className="size-4" />
                双击画布 自由生成节点
            </div>
            <div className="pointer-events-auto flex flex-wrap items-center justify-center gap-3 px-6">
                {chips.map((chip) => (
                    <button
                        key={chip.key}
                        type="button"
                        className="flex h-11 items-center gap-2.5 rounded-lg border px-4 text-[13px] font-medium transition hover:brightness-125"
                        style={{ background: theme.node.fill, borderColor: theme.node.stroke, color: theme.node.text }}
                        onClick={() => onPick(chip.key)}
                    >
                        <span className="flex size-6 items-center justify-center rounded-md border" style={{ borderColor: theme.node.stroke, color: theme.node.muted }}>
                            <chip.icon className="size-3.5" />
                        </span>
                        {chip.label}
                    </button>
                ))}
            </div>
        </div>
    );
}
