"use client";

import React, { useCallback, useEffect, useRef, useState } from "react";
import type { ReactNode } from "react";
import dynamic from "next/dynamic";
import { ChevronRight, Layers, Maximize2, Music2, Pause, Play, RefreshCw, Star, Video } from "lucide-react";

import { canvasThemes } from "@/lib/canvas-theme";
import { formatBytes, formatDuration } from "@/lib/image-utils";
import { useThemeStore } from "@/stores/use-theme-store";
import { CanvasResourceMentionTextarea } from "./canvas-resource-mention-textarea";
import { CanvasNodeType, type CanvasNodeData, type ConnectionHandle, type Position } from "../types";
import { isCanvasImageNodeType } from "../utils/canvas-panorama";
import type { CanvasResourceReference } from "../utils/canvas-resource-references";

type ResizeCorner = "top-left" | "top-right" | "bottom-left" | "bottom-right";
const selectionHighlight = "#a8a29e";
// boss 2026-10-07 批次 128：生成光环 loader 中央文字 = 软件名
const GEN_LOADER_TEXT = "Novus AI";
const CanvasPanoramaViewer = dynamic(() => import("./canvas-panorama-viewer"), { ssr: false, loading: () => null });

type CanvasNodeProps = {
    data: CanvasNodeData;
    scale: number;
    /** 屏幕对齐描边（世界坐标、相对节点原点）：四边恒定 1 物理像素，见 canvas-client-page.nodeScreenBorder */
    screenBorder?: { left: number; top: number; width: number; height: number; color: string };
    isSelected: boolean;
    isRelated: boolean;
    isFocusRelated: boolean;
    isConnectionTarget: boolean;
    isConnecting: boolean;
    isConnectingFrom: ConnectionHandle | null;
    referenceSelectionState?: "target" | "disabled" | "available";
    showPanel: boolean;
    showImageInfo: boolean;
    mentionReferences?: CanvasResourceReference[];
    now?: number;
    renderPanel?: (node: CanvasNodeData) => ReactNode;
    renderNodeContent?: (node: CanvasNodeData) => ReactNode;
    batchCount?: number;
    groupChildCount?: number;
    isGroupDropTarget?: boolean;
    batchExpanded?: boolean;
    batchClosing?: boolean;
    batchOpening?: boolean;
    batchRecovering?: boolean;
    batchMotion?: { x: number; y: number; index: number };
    onMouseDown: (event: React.MouseEvent, nodeId: string) => void;
    onHoverStart: (nodeId: string) => void;
    onHoverEnd: (nodeId: string) => void;
    onConnectStart: (event: React.MouseEvent, nodeId: string, handleType: "source" | "target") => void;
    onResize: (nodeId: string, width: number, height: number, position?: Position) => void;
    onContentChange: (nodeId: string, content: string) => void;
    onTitleChange: (nodeId: string, title: string) => void;
    onToggleBatch?: (nodeId: string) => void;
    onSetBatchPrimary?: (node: CanvasNodeData) => void;
    onRetry?: (node: CanvasNodeData) => void;
    onViewImage?: (node: CanvasNodeData) => void;
    onSelectReference?: (nodeId: string) => void;
    onContextMenu: (event: React.MouseEvent, nodeId: string) => void;
};

type NodeContentRendererProps = {
    node: CanvasNodeData;
    theme: (typeof canvasThemes)[keyof typeof canvasThemes];
    scale: number;
    isSelected: boolean;
    isEditingContent: boolean;
    textareaRef: React.RefObject<HTMLTextAreaElement | null>;
    isBatchRoot: boolean;
    batchCount: number;
    batchExpanded: boolean;
    batchOpening: boolean;
    batchRecovering: boolean;
    now?: number;
    renderNodeContent?: (node: CanvasNodeData) => ReactNode;
    onContentChange: (nodeId: string, content: string) => void;
    onStopEditing: () => void;
    mentionReferences: CanvasResourceReference[];
    onRetry?: (node: CanvasNodeData) => void;
    onViewImage?: (node: CanvasNodeData) => void;
    onToggleBatch?: () => void;
    onSetBatchPrimary?: () => void;
    onMoveStart?: (event: React.MouseEvent<HTMLButtonElement>) => void;
};

export const CanvasNode = React.memo(function CanvasNode({
    data,
    scale,
    screenBorder,
    isSelected,
    isRelated,
    isFocusRelated,
    isConnectionTarget,
    isConnecting,
    isConnectingFrom,
    referenceSelectionState,
    showPanel,
    showImageInfo,
    mentionReferences = [],
    now,
    renderPanel,
    renderNodeContent,
    batchCount = 0,
    groupChildCount = 0,
    isGroupDropTarget = false,
    batchExpanded = false,
    batchClosing = false,
    batchOpening = false,
    batchRecovering = false,
    batchMotion,
    onMouseDown,
    onHoverStart,
    onHoverEnd,
    onConnectStart,
    onResize,
    onContentChange,
    onTitleChange,
    onToggleBatch,
    onSetBatchPrimary,
    onRetry,
    onViewImage,
    onSelectReference,
    onContextMenu,
}: CanvasNodeProps) {
    const theme = canvasThemes[useThemeStore((state) => state.theme)];
    const [hovered, setHovered] = useState(false);
    const [isEditingContent, setIsEditingContent] = useState(false);
    const [isEditingTitle, setIsEditingTitle] = useState(false);
    const [titleDraft, setTitleDraft] = useState(data.title || "");
    const isGroup = data.type === CanvasNodeType.Group;
    // 原版组体着色真值（LiBTV bundle）：有组色 → background `${e}1A`、border `${e}33`；无组色 → 变量兜底
    const groupColor = data.metadata?.groupColor;

    // 组标题徽章动态缩放上限（boss 2026-10-04）：默认屏幕恒定，缩到文字即将撑爆组时转跟随。
    // badgeMax = 组世界宽 / 徽章世界宽；badgeScale = min(1/k, badgeMax)。
    const badgeRef = useRef<HTMLDivElement>(null);
    const [badgeMax, setBadgeMax] = useState(3);
    useEffect(() => {
        if (!isGroup) return;
        const el = badgeRef.current;
        if (!el) return;
        const measure = () => {
            const parent = el.parentElement;
            const Wg = parent ? parent.offsetWidth : 0;
            const Wb = el.offsetWidth;
            if (Wg > 0 && Wb > 0) setBadgeMax(Math.max(0.2, Math.min(Wg / Wb, 12)));
        };
        measure();
        const ro = new ResizeObserver(measure);
        if (el.parentElement) ro.observe(el.parentElement);
        ro.observe(el);
        return () => ro.disconnect();
    }, [isGroup, data.title, groupColor]);
    const hasImageContent = isCanvasImageNodeType(data.type) && Boolean(data.metadata?.content);
    const hasVideoContent = data.type === CanvasNodeType.Video && Boolean(data.metadata?.content);
    const hasAudioContent = data.type === CanvasNodeType.Audio && Boolean(data.metadata?.content);
    const isBatchRoot = isCanvasImageNodeType(data.type) && Boolean(data.metadata?.isBatchRoot) && batchCount > 1;
    const isBatchChild = isCanvasImageNodeType(data.type) && Boolean(data.metadata?.batchRootId);
    const isActive = isConnectionTarget || isSelected;
    // 节点主体的静态描边已移到屏幕坐标覆盖层（canvas-client-page 的 nodeBorderOverlay）：
    // 在缩放层内画边框会被 scale(k) 摊到非整数物理像素上，四条边浓度随子像素位置漂移（两边粗两边细）。
    // 这里只保留状态环：选中 / 组拖放 / 相邻高亮 / 参考选择。
    const strokeUnit = 1 / Math.max(scale, 0.05);
    const nodeRings = [
        isGroupDropTarget ? `0 0 0 ${strokeUnit * 2}px ${selectionHighlight}66` : "",
        isGroup && isSelected ? `0 0 0 ${strokeUnit}px ${selectionHighlight}55` : "",
        isActive ? `0 0 0 ${strokeUnit * (scale >= 1 ? 1.25 : 1)}px ${selectionHighlight}` : "",
        isRelated && !isBatchChild ? `0 0 0 ${strokeUnit}px ${theme.node.muted}55, 0 18px 48px rgba(0,0,0,.14)` : "",
    ].filter(Boolean).join(", ") || undefined;
    const textareaRef = useRef<HTMLTextAreaElement>(null);
    const titleInputRef = useRef<HTMLInputElement>(null);
    const resizeRef = useRef({
        isResizing: false,
        corner: "bottom-right" as ResizeCorner,
        startX: 0,
        startY: 0,
        startLeft: 0,
        startTop: 0,
        startWidth: 0,
        startHeight: 0,
        keepRatio: false,
        ratio: 1,
    });

    useEffect(() => {
        setTitleDraft(data.title || "");
    }, [data.title]);

    useEffect(() => {
        if (!isEditingTitle) return;
        titleInputRef.current?.focus();
        titleInputRef.current?.select();
    }, [isEditingTitle]);

    const finishTitleEditing = useCallback(() => {
        const title = titleDraft.trim() || data.title || "未命名节点";
        setTitleDraft(title);
        setIsEditingTitle(false);
        if (title !== data.title) onTitleChange(data.id, title);
    }, [data.id, data.title, onTitleChange, titleDraft]);

    useEffect(() => {
        if (!isEditingTitle) return;
        const handleOutsidePointerDown = (event: PointerEvent) => {
            const target = event.target;
            if (target instanceof Node && titleInputRef.current?.contains(target)) return;
            finishTitleEditing();
        };
        window.addEventListener("pointerdown", handleOutsidePointerDown, true);
        return () => window.removeEventListener("pointerdown", handleOutsidePointerDown, true);
    }, [finishTitleEditing, isEditingTitle]);

    useEffect(() => {
        const textarea = textareaRef.current;
        if (!textarea) return;
        const handleWheel = (event: WheelEvent) => event.stopPropagation();
        textarea.addEventListener("wheel", handleWheel, { passive: false });
        return () => textarea.removeEventListener("wheel", handleWheel);
    }, [data.type, isEditingContent]);

    useEffect(() => {
        if (!isEditingContent) return;
        const textarea = textareaRef.current;
        textarea?.focus();
        textarea?.setSelectionRange(textarea.value.length, textarea.value.length);
    }, [isEditingContent]);

    useEffect(() => {
        if (!isEditingContent) return;

        const handleOutsidePointerDown = (event: PointerEvent) => {
            const target = event.target;
            if (!(target instanceof Node)) return;
            if (isEditingContent && textareaRef.current?.contains(target)) return;

            setIsEditingContent(false);
        };

        window.addEventListener("pointerdown", handleOutsidePointerDown, true);
        return () => window.removeEventListener("pointerdown", handleOutsidePointerDown, true);
    }, [isEditingContent]);

    const handleResizeMove = useCallback(
        (event: MouseEvent) => {
            if (!resizeRef.current.isResizing) return;

            const dx = (event.clientX - resizeRef.current.startX) / scale;
            const dy = (event.clientY - resizeRef.current.startY) / scale;
            const minWidth = 220;
            const minHeight = 160;
            const startRight = resizeRef.current.startLeft + resizeRef.current.startWidth;
            const startBottom = resizeRef.current.startTop + resizeRef.current.startHeight;
            const fromLeft = resizeRef.current.corner.includes("left");
            const fromTop = resizeRef.current.corner.includes("top");
            const rawWidth = Math.max(minWidth, resizeRef.current.startWidth + (fromLeft ? -dx : dx));
            const rawHeight = Math.max(minHeight, resizeRef.current.startHeight + (fromTop ? -dy : dy));
            let width = rawWidth;
            let height = rawHeight;
            if (resizeRef.current.keepRatio) {
                const ratio = resizeRef.current.ratio;
                if (Math.abs(dx) >= Math.abs(dy)) {
                    height = width / ratio;
                } else {
                    width = height * ratio;
                }
                if (height < minHeight) {
                    height = minHeight;
                    width = height * ratio;
                }
                if (width < minWidth) {
                    width = minWidth;
                    height = width / ratio;
                }
            }

            onResize(data.id, width, height, {
                x: fromLeft ? startRight - width : resizeRef.current.startLeft,
                y: fromTop ? startBottom - height : resizeRef.current.startTop,
            });
        },
        [data.id, onResize, scale],
    );

    const handleResizeUp = useCallback(() => {
        resizeRef.current.isResizing = false;
        window.removeEventListener("mousemove", handleResizeMove);
        window.removeEventListener("mouseup", handleResizeUp);
    }, [handleResizeMove]);

    const handleResizeMouseDown = (event: React.MouseEvent, corner: ResizeCorner) => {
        event.stopPropagation();
        event.preventDefault();
        resizeRef.current = {
            isResizing: true,
            corner,
            startX: event.clientX,
            startY: event.clientY,
            startLeft: data.position.x,
            startTop: data.position.y,
            startWidth: data.width,
            startHeight: data.height,
            keepRatio: (isCanvasImageNodeType(data.type) && !data.metadata?.freeResize) || data.type === CanvasNodeType.Video,
            ratio: (data.metadata?.naturalWidth || data.width) / (data.metadata?.naturalHeight || data.height || 1),
        };
        window.addEventListener("mousemove", handleResizeMove);
        window.addEventListener("mouseup", handleResizeUp);
    };

    useEffect(() => {
        return () => {
            window.removeEventListener("mousemove", handleResizeMove);
            window.removeEventListener("mouseup", handleResizeUp);
        };
    }, [handleResizeMove, handleResizeUp]);

    return (
        <div
            data-node-id={data.id}
            className={`node-element absolute flex select-none flex-col transition-shadow duration-200 ${isGroup ? "z-[5]" : isSelected ? "z-50" : "z-10"} ${referenceSelectionState === "available" ? "cursor-pointer" : referenceSelectionState ? "cursor-not-allowed" : ""}`}
            style={{
                transform: `translate(${data.position.x}px, ${data.position.y}px)${data.metadata?.previewTransform ? ` ${data.metadata.previewTransform}` : ""}`,
                width: data.width,
                height: data.height,
                transition: "box-shadow 200ms ease",
                contain: "layout style",
            }}
            onMouseEnter={() => {
                setHovered(true);
                onHoverStart(data.id);
            }}
            onMouseLeave={() => {
                setHovered(false);
                onHoverEnd(data.id);
            }}
            onMouseDownCapture={(event) => {
                if (!referenceSelectionState) return;
                event.preventDefault();
                event.stopPropagation();
                if (event.button === 0 && referenceSelectionState === "available") onSelectReference?.(data.id);
            }}
            onContextMenu={(event) => {
                if (referenceSelectionState) event.preventDefault();
                else onContextMenu(event, data.id);
            }}
        >
            {!referenceSelectionState ? <div
                ref={badgeRef}
                className={`absolute z-[65] ${isGroup ? "" : "left-3 top-[-28px]"} max-w-[calc(100%-24px)]`}
                style={
                    isGroup
                        ? {
                              // 动态缩放（boss 2026-10-04 修正）：默认屏幕恒定，缩到文字即将撑爆组时转跟随。
                              // --badge-scale = min(1/k, 组宽/文字宽)：k 正常取 1/k ⇒ 文字恒屏幕大小（缩小后仍清晰）；
                              // 缩到 1/k > 组宽/文字宽 时取后者 ⇒ 徽章==组宽并随组一起缩小，永不越界。
                              "--badge-max": badgeMax,
                              "--badge-scale": "min(var(--canvas-inverse-scale, 1), var(--badge-max, 3))",
                              // 对齐（boss 2026-10-04）：徽章块左缘=组左边框；底边悬在组上边框上方 4px（留一点距离不贴死）。
                              left: "0px",
                              bottom: "calc(100% + 4px * var(--badge-scale))",
                              transform: "scale(var(--badge-scale))",
                              transformOrigin: "bottom left",
                              // 宽度上限 = 组宽（100%/badge-scale），超长走 truncate 省略号兜底（正常不会触发）
                              maxWidth: "calc(100% / var(--badge-scale))",
                          } as React.CSSProperties
                        : undefined
                }
                onMouseDown={(event) => event.stopPropagation()}
                onPointerDown={(event) => event.stopPropagation()}
            >
                {isEditingTitle ? (
                    <input
                        ref={titleInputRef}
                        value={titleDraft}
                        maxLength={64}
                        className="h-6 max-w-full border-0 border-b border-dashed bg-transparent px-0 text-left text-xs font-medium outline-none"
                        style={{ borderColor: theme.node.muted, color: theme.node.text, ...(isGroup && groupColor ? { background: `${groupColor}33`, borderRadius: 4, padding: "1px 6px" } : {}) }}
                        onChange={(event) => setTitleDraft(event.target.value)}
                        onBlur={finishTitleEditing}
                        onKeyDown={(event) => {
                            if (event.key === "Enter") finishTitleEditing();
                            if (event.key === "Escape") {
                                setTitleDraft(data.title || "");
                                setIsEditingTitle(false);
                            }
                        }}
                    />
                ) : (
                    <button
                        type="button"
                        className="block max-w-full truncate border-b border-dashed border-transparent px-0 py-0.5 text-left text-xs font-medium opacity-75 transition hover:border-current hover:opacity-100"
                        style={{ color: theme.node.text, ...(isGroup && groupColor ? { background: `${groupColor}33`, borderRadius: 4, padding: "2px 6px", opacity: 1 } : {}) }}
                        title="双击修改节点名称"
                        onDoubleClick={(event) => {
                            event.stopPropagation();
                            setIsEditingTitle(true);
                        }}
                    >
                        {data.title || "未命名节点"}
                    </button>
                )}
            </div> : null}
            {isGroup && !referenceSelectionState ? (
                <div className="pointer-events-none absolute right-3 top-[-28px] z-[65] text-xs opacity-75" style={{ color: theme.node.text }}>
                    {groupChildCount} 个节点
                </div>
            ) : null}

            <div
                className={`relative h-full w-full overflow-visible ${isGroup ? "rounded-lg" : "rounded-[6px]"}`}
                style={{
                    background: isGroup
                        ? (groupColor ? `${groupColor}1A` : theme.node.panel)
                        : hasImageContent || hasVideoContent ? "transparent" : theme.node.fill,
                    boxShadow: nodeRings,
                }}
                onMouseDown={(event) => onMouseDown(event, data.id)}
                onDoubleClick={(event) => {
                    if (referenceSelectionState) {
                        event.preventDefault();
                        event.stopPropagation();
                        return;
                    }
                    if (isBatchRoot) {
                        event.stopPropagation();
                        onToggleBatch?.(data.id);
                        return;
                    }
                    if ((isCanvasImageNodeType(data.type) && hasImageContent) || (data.type === CanvasNodeType.Video && hasVideoContent)) {
                        event.preventDefault();
                        event.stopPropagation();
                        if (data.type === CanvasNodeType.Video && event.target instanceof HTMLVideoElement) event.target.pause();
                        onViewImage?.(data);
                        return;
                    }
                    if (data.type !== CanvasNodeType.Text) return;
                    event.stopPropagation();
                    setIsEditingContent(true);
                }}
            >
                {screenBorder ? (
                    <div
                        aria-hidden
                        className="pointer-events-none absolute rounded-[inherit]"
                        style={{
                            left: screenBorder.left,
                            top: screenBorder.top,
                            width: screenBorder.width,
                            height: screenBorder.height,
                            // 1/k 画布px × 缩放 k = 恒定 1 物理像素；坐标已按整设备像素对齐，四边浓度一致
                            border: `${1 / Math.max(scale, 0.05)}px solid ${screenBorder.color}`,
                            zIndex: 50,
                        }}
                    />
                ) : null}
                <div
                    className={`relative flex h-full w-full items-center justify-center rounded-[inherit] ${isBatchRoot ? "overflow-visible" : "overflow-hidden"}`}
                    style={
                        {
                            background: isGroup ? "transparent" : hasImageContent || hasVideoContent ? "transparent" : theme.node.fill,
                            "--batch-from-x": `${batchMotion?.x || 0}px`,
                            "--batch-from-y": `${batchMotion?.y || 0}px`,
                            // 092：对齐 LibTV 原版 ImageNode 折叠态——第 t 层 rotate = 2.5 * t（首图 t=0 为主节点，子层 t = index+1）
                            "--batch-from-rotate": `${2.5 * ((batchMotion?.index || 0) + 1)}deg`,
                            animation: data.metadata?.batchRootId ? (batchClosing ? "canvas-batch-child-out 260ms cubic-bezier(.4,0,.2,1) both" : "canvas-batch-child-in 340ms cubic-bezier(.2,.85,.18,1) both") : undefined,
                            animationDelay: data.metadata?.batchRootId ? `${batchClosing ? 0 : 45 + (batchMotion?.index || 0) * 24}ms` : undefined,
                        } as React.CSSProperties
                    }
                >
                    {!isGroup ? (
                        <NodeContent
                            node={data}
                            theme={theme}
                            scale={scale}
                            isSelected={isSelected}
                            now={now}
                            isEditingContent={isEditingContent}
                            textareaRef={textareaRef}
                            isBatchRoot={isBatchRoot}
                            batchCount={batchCount}
                            batchExpanded={batchExpanded}
                            batchOpening={batchOpening}
                            batchRecovering={batchRecovering}
                            renderNodeContent={renderNodeContent}
                            mentionReferences={mentionReferences}
                            onContentChange={onContentChange}
                            onStopEditing={() => setIsEditingContent(false)}
                            onRetry={onRetry}
                            onViewImage={onViewImage}
                            onToggleBatch={() => onToggleBatch?.(data.id)}
                            onSetBatchPrimary={() => onSetBatchPrimary?.(data)}
                            onMoveStart={(event) => onMouseDown(event, data.id)}
                        />
                    ) : null}
                </div>

                {showImageInfo && hasImageContent ? <ImageInfoBar node={data} /> : null}

                {!isGroup && !hasImageContent && !hasVideoContent && !hasAudioContent ? <div className="pointer-events-none absolute inset-x-0 bottom-0 h-12" style={{ background: `linear-gradient(to top, ${theme.canvas.background}66, transparent)` }} /> : null}

                {referenceSelectionState && (referenceSelectionState !== "available" || hovered) ? (
                    <div className="pointer-events-none absolute inset-0 z-[60] grid place-items-center rounded-[inherit]" style={{ background: `color-mix(in srgb, ${theme.canvas.background} ${referenceSelectionState === "target" ? 78 : referenceSelectionState === "disabled" ? 60 : 34}%, transparent)`, boxShadow: referenceSelectionState === "available" ? `inset 0 0 0 2px ${selectionHighlight}` : undefined }}>
                        {referenceSelectionState !== "disabled" ? <span className="rounded-lg px-3 py-2 text-sm font-medium shadow-sm" style={{ background: theme.toolbar.panel, color: theme.node.text }}>{referenceSelectionState === "target" ? "正在添加参考" : "选择"}</span> : null}
                    </div>
                ) : null}

            </div>

            {!referenceSelectionState && !isGroup ? (
                <>
                    <ConnectionHandleDot side="left" visible={(hovered || isSelected || isConnecting) && !(isConnectingFrom?.nodeId === data.id && isConnectingFrom.handleType === "target")} scale={scale} onMouseDown={(event) => onConnectStart(event, data.id, "target")} />
                    <ConnectionHandleDot side="right" visible={data.type !== CanvasNodeType.Config && (hovered || isSelected || isConnecting) && !(isConnectingFrom?.nodeId === data.id && isConnectingFrom.handleType === "source")} scale={scale} onMouseDown={(event) => onConnectStart(event, data.id, "source")} />
                </>
            ) : null}

            {/* 打组框：四个角可自由拖动调整框体大小 */}
            {isGroup && !referenceSelectionState && (hovered || isSelected) ? (
                <>
                    {(["top-left", "top-right", "bottom-left", "bottom-right"] as const).map((corner) => (
                        <GroupResizeHandle key={corner} corner={corner} onMouseDown={(event) => handleResizeMouseDown(event, corner)} />
                    ))}
                </>
            ) : null}

            {!referenceSelectionState && showPanel && !isGroup && renderPanel ? (
                <div
                    className={"absolute left-1/2 top-full z-[70] max-w-[calc(100vw-24px)] pt-5 " + (isCanvasImageNodeType(data.type) || data.type === CanvasNodeType.Video || data.type === CanvasNodeType.Audio ? "w-[540px]" : "w-[440px]")}
                    data-canvas-no-zoom
                    style={{
                        // 面板固定屏幕尺寸（媒体 540 / 其他 440），scale(1/k) 抵消画布缩放——任何缩放级别外观恒定
                        transform: `translateX(-50%) scale(${1 / Math.max(scale, 0.05)})`,
                        transformOrigin: "top center",
                    }}
                >
                    {renderPanel(data)}
                </div>
            ) : null}
        </div>
    );
});

function NodeContent(props: NodeContentRendererProps) {
    if (props.node.type === CanvasNodeType.Group) return null;
    if ((props.node.type === CanvasNodeType.Config || props.node.type === CanvasNodeType.Director) && props.renderNodeContent) return props.renderNodeContent(props.node);
    if (props.isBatchRoot) return props.node.type === CanvasNodeType.Panorama ? <PanoramaNodeContent {...props} /> : <ImageNodeContent {...props} />;
    if (props.node.metadata?.status === "loading" && (props.node.type !== CanvasNodeType.Text || !props.node.metadata.content)) return <LoadingContent node={props.node} theme={props.theme} now={props.now} />;
    if (props.node.metadata?.status === "error") return <ErrorContent node={props.node} theme={props.theme} onRetry={props.onRetry} />;

    const Renderer = nodeContentRenderers[props.node.type];
    return Renderer ? <Renderer {...props} /> : <UnknownNodeContent theme={props.theme} />;
}

const nodeContentRenderers = {
    [CanvasNodeType.Text]: TextContent,
    [CanvasNodeType.Image]: ImageNodeContent,
    [CanvasNodeType.Panorama]: PanoramaNodeContent,
    [CanvasNodeType.Config]: EmptyImageContent,
    [CanvasNodeType.Video]: VideoNodeContent,
    [CanvasNodeType.Audio]: AudioNodeContent,
    [CanvasNodeType.Director]: EmptyImageContent,
} satisfies Partial<Record<CanvasNodeType, (props: NodeContentRendererProps) => ReactNode>>;

function LoadingContent({ node, theme, now }: Pick<NodeContentRendererProps, "node" | "theme" | "now">) {
    const startTimeRef = useRef(Date.now());
    const [localNow, setLocalNow] = useState(Date.now());
    useEffect(() => {
        if (now !== undefined) return;
        const timer = window.setInterval(() => setLocalNow(Date.now()), 1000);
        return () => window.clearInterval(timer);
    }, [now]);
    const currentNow = now ?? localNow;
    const startedAt = typeof node.metadata?.startedAt === "number" ? node.metadata.startedAt : startTimeRef.current;
    const elapsedMs = Math.max(0, currentNow - startedAt);
    const progress = Math.max(0, Math.min(100, Math.round(node.metadata?.progress || 0)));
    const statusMessage = node.metadata?.stageLabel || node.metadata?.statusMessage || node.metadata?.generationMessage || "";

    if (node.type === CanvasNodeType.Video) {
        return (
            <div className="flex h-full w-full flex-col justify-between overflow-hidden p-4" style={{ color: theme.node.text }}>
                <div className="flex min-h-0 flex-1 flex-col items-center justify-center gap-3">
                    {/* boss 2026-10-07 批次 128：生成动画换成旋转渐变光环 loader（Uiverse dexter-st 移植），文字=软件名 Novus AI；进度信息保留在下方进度条 */}
                    <div className="canvas-gen-loader" aria-hidden>
                        {GEN_LOADER_TEXT.split("").map((letter, index) => (
                            <span key={index} className="canvas-gen-loader-letter" style={{ animationDelay: `${(index * 0.1).toFixed(2)}s` }}>
                                {letter === " " ? "\u00A0" : letter}
                            </span>
                        ))}
                        <div className="canvas-gen-loader-ring" />
                    </div>
                    {statusMessage ? <div className="text-[13px] font-medium" style={{ color: "#076fe5" }}>{statusMessage}</div> : null}
                    <span className="rounded-full px-2 py-1 text-xs" style={{ background: theme.toolbar.panel, color: theme.node.text }}>
                        {formatDuration(elapsedMs)}
                    </span>
                </div>
                <div className="space-y-1">
                    <div className="flex items-center justify-between text-[11px]" style={{ color: theme.node.muted }}>
                        <span>当前创作进度</span>
                        <span>{progress}%</span>
                    </div>
                    <div className="h-1.5 overflow-hidden rounded-full" style={{ background: theme.node.stroke }}>
                        <div className="h-full rounded-full transition-all" style={{ width: `${progress}%`, background: selectionHighlight }} />
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="flex h-full w-full flex-col items-center justify-center gap-3" style={{ color: theme.node.activeStroke }}>
            <div className="canvas-node-spinner size-10 rounded-full border-2" style={{ borderColor: theme.node.stroke, borderTopColor: theme.node.activeStroke }} />
            <span className="text-[10px] tracking-[0.2em]">{statusMessage || (progress > 0 ? `生成中 ${progress}%` : "生成中")}</span>
            <span className="rounded-full border px-2 py-1 text-xs tracking-normal" style={{ borderColor: theme.node.stroke, color: theme.node.text }}>
                {formatDuration(elapsedMs)}
            </span>
            {progress > 0 ? (
                <div className="h-1.5 w-28 overflow-hidden rounded-full" style={{ background: theme.node.stroke }}>
                    <div className="h-full rounded-full transition-all" style={{ width: `${progress}%`, background: theme.node.activeStroke }} />
                </div>
            ) : null}
        </div>
    );
}

function ErrorContent({ node, theme, onRetry }: Pick<NodeContentRendererProps, "node" | "theme" | "onRetry">) {
    return (
        <div className="flex max-w-[260px] flex-col items-center gap-3 px-5 text-center">
            <div className="text-xs leading-5 text-red-300">{node.metadata?.errorDetails || "生成失败"}</div>
            <button
                type="button"
                className="inline-flex h-8 items-center gap-1.5 rounded-full border px-3 text-xs font-medium transition hover:scale-[1.02]"
                style={{ background: theme.toolbar.panel, borderColor: theme.toolbar.border, color: theme.node.text }}
                onClick={(event) => {
                    event.stopPropagation();
                    onRetry?.(node);
                }}
                onMouseDown={(event) => event.stopPropagation()}
            >
                <RefreshCw className="size-3.5" />
                重试
            </button>
        </div>
    );
}

function UnknownNodeContent({ theme }: Pick<NodeContentRendererProps, "theme">) {
    return (
        <div className="flex h-full w-full items-center justify-center text-sm" style={{ color: theme.node.placeholder }}>
            未知节点
        </div>
    );
}

function TextContent({ node, theme, isEditingContent, textareaRef, mentionReferences, onContentChange, onStopEditing }: NodeContentRendererProps) {
    const fontSize = node.metadata?.fontSize || 14;
    const textStyle = { fontSize: `${fontSize}px`, lineHeight: `${Math.round(fontSize * 1.65)}px`, color: theme.node.text, boxSizing: "border-box" } as React.CSSProperties;

    return (
        <div className="flex h-full w-full flex-col overflow-hidden">
            {isEditingContent ? (
                <CanvasResourceMentionTextarea
                    ref={textareaRef}
                    className="thin-scrollbar block h-full w-full resize-none overflow-y-auto whitespace-pre-wrap break-words border-none bg-transparent p-4 m-0 font-mono outline-none select-text appearance-none"
                    style={textStyle}
                    value={node.metadata?.content || ""}
                    references={mentionReferences}
                    highlightLabels={false}
                    onChange={(value) => onContentChange(node.id, value)}
                    onBlur={onStopEditing}
                    onKeyDown={(event) => {
                        if (event.key === "Escape") onStopEditing();
                    }}
                    onMouseDown={(event) => event.stopPropagation()}
                    onPointerDown={(event) => event.stopPropagation()}
                    onWheel={(event) => event.stopPropagation()}
                />
            ) : (
                <div
                    className="thin-scrollbar block h-full w-full overflow-y-auto whitespace-pre-wrap break-words bg-transparent p-4 font-mono"
                    style={textStyle}
                    onWheelCapture={(event) => event.stopPropagation()}
                >
                    {node.metadata?.content || <span style={{ color: theme.node.placeholder }}>双击编辑文字</span>}
                </div>
            )}
        </div>
    );
}

function ImageNodeContent(props: NodeContentRendererProps) {
    if (!props.node.metadata?.content && props.isBatchRoot) {
        const content =
            props.node.metadata?.status === "loading" ? (
                <LoadingContent node={props.node} theme={props.theme} now={props.now} />
            ) : props.node.metadata?.status === "error" ? (
                <ErrorContent node={props.node} theme={props.theme} onRetry={props.onRetry} />
            ) : (
                <EmptyImageContent {...props} isBatchRoot={false} />
            );
        return (
            <BatchFrame batchCount={props.batchCount} batchExpanded={props.batchExpanded} batchOpening={props.batchOpening} batchRecovering={props.batchRecovering} scale={props.scale} onToggleBatch={props.onToggleBatch}>
                {content}
            </BatchFrame>
        );
    }
    if (!props.node.metadata?.content) return <EmptyImageContent {...props} />;

    return (
        <ImageContent
            node={props.node}
            isBatchRoot={props.isBatchRoot}
            batchCount={props.batchCount}
            batchExpanded={props.batchExpanded}
            batchOpening={props.batchOpening}
            batchRecovering={props.batchRecovering}
            onToggleBatch={props.onToggleBatch}
            onSetBatchPrimary={props.onSetBatchPrimary}
            scale={props.scale}
        />
    );
}

function PanoramaNodeContent(props: NodeContentRendererProps) {
    const src = props.node.metadata?.content;
    if (!src) return <ImageNodeContent {...props} />;
    const proxyGeneratedPanorama = Boolean(props.node.metadata?.imageTaskId || props.node.metadata?.imageTaskResultId) && !props.node.metadata?.storageKey;

    return (
        <ImageContent
            node={props.node}
            isBatchRoot={props.isBatchRoot}
            batchCount={props.batchCount}
            batchExpanded={props.batchExpanded}
            batchOpening={props.batchOpening}
            batchRecovering={props.batchRecovering}
            onToggleBatch={props.onToggleBatch}
            onSetBatchPrimary={props.onSetBatchPrimary}
            media={<CanvasPanoramaViewer src={src} alt={props.node.title} proxyGeneratedPanorama={proxyGeneratedPanorama} expandOnDoubleClick={!props.isBatchRoot} onMoveStart={props.onMoveStart} onOpen={props.onViewImage ? () => props.onViewImage?.(props.node) : undefined} />}
            scale={props.scale}
        />
    );
}

// 空节点占位图标（boss 2026-10-04 发图指定，按原版实心样式：山形+圆点 / 实心播放三角 / 实心八分音符）
function PlaceholderImageGlyph({ className }: { className?: string }) {
    return (
        <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
            <circle cx="17" cy="6.6" r="2.3" />
            <path d="M6.1 9.9c.5-.68 1.53-.68 2.03 0l1.4 1.87 2.53-3.37c.5-.68 1.53-.68 2.03 0l5.9 7.87c.62.82.03 1.99-1 1.99H3.2c-1.03 0-1.62-1.17-1-1.99l3.9-5.37z" />
        </svg>
    );
}

function PlaceholderVideoGlyph({ className }: { className?: string }) {
    return (
        <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
            <path d="M7.5 5.62v12.76c0 1.23 1.35 1.98 2.4 1.33l10.03-6.38a1.57 1.57 0 0 0 0-2.66L9.9 4.29c-1.05-.65-2.4.1-2.4 1.33z" />
        </svg>
    );
}

function PlaceholderAudioGlyph({ className }: { className?: string }) {
    return (
        <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
            <path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z" />
        </svg>
    );
}

function EmptyImageContent({ node, theme, scale, isBatchRoot, batchCount, batchExpanded, batchOpening, batchRecovering, onToggleBatch }: NodeContentRendererProps) {
    const content = (
        <div className="flex h-full w-full items-center justify-center" style={{ color: theme.node.placeholder }}>
            <PlaceholderImageGlyph className="size-10 opacity-30" />
        </div>
    );
    if (isBatchRoot)
        return (
            <BatchFrame batchCount={batchCount} batchExpanded={batchExpanded} batchOpening={batchOpening} batchRecovering={batchRecovering} scale={scale} onToggleBatch={onToggleBatch}>
                {content}
            </BatchFrame>
        );
    return content;
}

// rfkvm9：以下三段按 LibTV 真源码 1:1 移植（bundle.js TURBOPACK chunk，字节偏移 2698719 附近的 VideoPlayerBar 体系）
// eD（formatTimeCompact）：秒 → "m:ss"，(0,1) 区间取 1
function libtvTime(seconds: number) {
    if (seconds > 0 && seconds < 1) seconds = 1;
    const minutes = Math.floor(seconds / 60);
    const sec = Math.floor(seconds % 60);
    return `${minutes}:${String(sec).padStart(2, "0")}`;
}

// eB（SeekBar）：3px 白轨 + 3px 已播 + 10px 白色拖点，容器高 14，window 级 mousemove/mouseup 拖拽
function LibtvSeekBar({ currentTime, duration, onSeek }: { currentTime: number; duration: number; onSeek: (seconds: number) => void }) {
    const trackRef = useRef<HTMLDivElement>(null);
    const [dragging, setDragging] = useState(false);
    const ratio = duration > 0 ? currentTime / duration : 0;
    const seekTo = useCallback(
        (clientX: number) => {
            const el = trackRef.current;
            if (!el || duration <= 0) return;
            const rect = el.getBoundingClientRect();
            onSeek(Math.max(0, Math.min(clientX - rect.left, rect.width)) / rect.width * duration);
        },
        [duration, onSeek],
    );
    const onMouseDown = useCallback(
        (event: React.MouseEvent) => {
            event.stopPropagation();
            setDragging(true);
            seekTo(event.clientX);
        },
        [seekTo],
    );
    useEffect(() => {
        if (!dragging) return;
        const move = (event: MouseEvent) => seekTo(event.clientX);
        const up = () => setDragging(false);
        window.addEventListener("mousemove", move);
        window.addEventListener("mouseup", up);
        return () => {
            window.removeEventListener("mousemove", move);
            window.removeEventListener("mouseup", up);
        };
    }, [dragging, seekTo]);
    const onClick = useCallback(
        (event: React.MouseEvent) => {
            event.stopPropagation();
            seekTo(event.clientX);
        },
        [seekTo],
    );
    return (
        <div ref={trackRef} className="nodrag relative flex-1 cursor-pointer" style={{ height: 14, display: "flex", alignItems: "center" }} onMouseDown={onMouseDown} onClick={onClick}>
            <div className="absolute left-0 right-0 rounded-full" style={{ height: 3, background: "rgba(255, 255, 255, 0.3)", top: "50%", transform: "translateY(-50%)", pointerEvents: "none" }} />
            <div className="absolute left-0 rounded-full" style={{ height: 3, background: "#fff", width: `${100 * ratio}%`, top: "50%", transform: "translateY(-50%)", pointerEvents: "none" }} />
            <div className="absolute rounded-full" style={{ width: 10, height: 10, background: "#fff", top: "50%", left: `${100 * ratio}%`, transform: "translate(-50%, -50%)", boxShadow: "0 1px 3px rgba(0, 0, 0, 0.3)", pointerEvents: "none" }} />
        </div>
    );
}

function VideoNodeContent({ node, theme, isSelected, onViewImage }: NodeContentRendererProps) {
    const videoRef = useRef<HTMLVideoElement>(null);
    const [isPlaying, setIsPlaying] = useState(false);
    const [mediaDurationMs, setMediaDurationMs] = useState(0);
    const [videoTime, setVideoTime] = useState(0);
    const videoDuration = mediaDurationMs / 1000;
    const togglePlayback = () => {
        const video = videoRef.current;
        if (!video) return;
        if (video.paused) void video.play();
        else video.pause();
    };
    useEffect(() => {
        if (!isSelected) videoRef.current?.pause();
        if (isSelected) videoRef.current?.focus({ preventScroll: true });
        else if (document.activeElement === videoRef.current) videoRef.current?.blur();
    }, [isSelected, node.metadata?.content]);
    if (!node.metadata?.content)
        return (
            <div className="flex h-full w-full items-center justify-center" style={{ color: theme.node.placeholder }}>
                <PlaceholderVideoGlyph className="size-9 opacity-30" />
            </div>
        );
    const keepVideoFocus = (event: React.MouseEvent<HTMLButtonElement>) => {
        event.preventDefault();
        event.stopPropagation();
        if (isSelected) videoRef.current?.focus({ preventScroll: true });
    };
    return (
        // rfkvm9：LibTV 视频卡 —— group/video 容器 + object-contain 居中视频 + 悬停浮现底部播放条
        <div className="group/video relative h-full w-full overflow-hidden rounded-[inherit]">
            <video
                ref={videoRef}
                src={node.metadata.content}
                tabIndex={-1}
                playsInline
                className="max-h-full max-w-full cursor-pointer object-contain outline-none"
                onClick={(event) => {
                    event.stopPropagation();
                    togglePlayback();
                }}
                onLoadStart={() => {
                    setVideoTime(0);
                    setMediaDurationMs(0);
                }}
                onLoadedMetadata={(event) => setMediaDurationMs(Number.isFinite(event.currentTarget.duration) ? event.currentTarget.duration * 1000 : 0)}
                onTimeUpdate={(event) => setVideoTime(event.currentTarget.currentTime)}
                onPlay={() => setIsPlaying(true)}
                onPause={() => setIsPlaying(false)}
                onKeyDown={(event) => {
                    if (isSelected && event.code === "Space") {
                        event.preventDefault();
                        event.stopPropagation();
                        togglePlayback();
                    }
                }}
            />
            {/* 状态标签：LibTV 徽标风格（bg-black/65 backdrop-blur-sm text-[10px]，同素材卡时长角标样式）；130 补记 7（boss 2026-10-07）：状态与耗时并排一排，不再堆两行 */}
            {(node.metadata?.statusMessage || (node.metadata?.status === "success" && typeof node.metadata?.durationMs === "number" && node.metadata.durationMs > 0)) ? (
                <div className="pointer-events-none absolute left-2 top-2 z-20 flex items-center gap-1">
                    {node.metadata?.statusMessage ? <div className="flex h-5 items-center rounded bg-black/65 px-1.5 text-[10px] leading-none text-white backdrop-blur-sm">{node.metadata.statusMessage}</div> : null}
                    {/* reYs5C：生成完成的视频节点显示本次生成总耗时（durationMs 在任务更新完成时写入；仅 success 且有值时显示） */}
                    {node.metadata?.status === "success" && typeof node.metadata?.durationMs === "number" && node.metadata.durationMs > 0 ? (
                        <span className="flex h-5 items-center rounded bg-black/65 px-1.5 text-[10px] leading-none text-white backdrop-blur-sm">耗时 {formatDuration(node.metadata.durationMs)}</span>
                    ) : null}
                </div>
            ) : null}
            {/* 时长角标：LibTV 素材卡样式（bottom-2 left-2）；悬停播放条浮现时让位隐藏（播放条里有完整时间） */}
            {mediaDurationMs > 0 ? <span className="pointer-events-none absolute bottom-2 left-2 z-20 flex h-5 items-center rounded bg-black/65 px-1.5 text-[10px] leading-none text-white opacity-100 backdrop-blur-sm transition-opacity duration-200 group-hover/video:opacity-0">{libtvTime(videoDuration)}</span> : null}
            {/* 播放条：LibTV VideoPlayerBar 1:1 —— 80px 底部渐变 + 播放按钮(28px圆) + 时间(tabular-nums) + 3px 进度条，悬停浮现 */}
            <div className="pointer-events-none absolute bottom-0 left-0 right-0 z-30 opacity-0 transition-opacity duration-200 group-hover/video:pointer-events-auto group-hover/video:opacity-100">
                <div className="pointer-events-none absolute bottom-0 left-0 right-0" style={{ height: 80, background: "linear-gradient(to bottom, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.5))" }} />
                <div className="relative flex items-center gap-2 px-3 pb-2.5 pt-8">
                    <button
                        type="button"
                        title={isPlaying ? "暂停" : "播放"}
                        aria-label={isPlaying ? "暂停" : "播放"}
                        className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full transition-colors hover:bg-black/50"
                        onClick={(event) => {
                            event.stopPropagation();
                            togglePlayback();
                        }}
                        onMouseDown={keepVideoFocus}
                        onDoubleClick={(event) => event.stopPropagation()}
                    >
                        {isPlaying ? <Pause className="size-4 text-white" /> : <Play className="size-4 text-white" />}
                    </button>
                    <span className="shrink-0 text-xs tabular-nums text-white">{libtvTime(videoTime)}</span>
                    <LibtvSeekBar
                        currentTime={videoTime}
                        duration={videoDuration}
                        onSeek={(seconds) => {
                            if (!videoRef.current) return;
                            videoRef.current.currentTime = seconds;
                            setVideoTime(seconds);
                        }}
                    />
                    <span className="shrink-0 text-xs tabular-nums text-white">{videoDuration > 0 ? libtvTime(videoDuration) : "--:--"}</span>
                </div>
            </div>
            {/* 放大预览：LibTV hover 操作按钮样式（size-6 bg-black/65 backdrop-blur-[2px]，右下） */}
            <button
                type="button"
                title="放大预览"
                aria-label="放大预览"
                className="absolute bottom-2 right-2 z-30 flex size-6 items-center justify-center rounded bg-black/65 opacity-0 backdrop-blur-[2px] transition-opacity group-hover/video:opacity-100"
                onClick={(event) => {
                    event.stopPropagation();
                    videoRef.current?.pause();
                    onViewImage?.(node);
                }}
                onMouseDown={keepVideoFocus}
                onDoubleClick={(event) => event.stopPropagation()}
            >
                <Maximize2 className="size-3 text-white" />
            </button>
        </div>
    );
}

function AudioNodeContent({ node, theme }: NodeContentRendererProps) {
    if (!node.metadata?.content)
        return (
            <div className="flex h-full w-full items-center justify-center" style={{ color: theme.node.placeholder }}>
                <PlaceholderAudioGlyph className="size-9 opacity-30" />
            </div>
        );
    return (
        <div className="flex h-full w-full flex-col justify-center gap-3 px-4" style={{ background: theme.node.fill, color: theme.node.text }}>
            <div className="flex min-w-0 items-center gap-2 text-sm opacity-70">
                <Music2 className="size-4 shrink-0" />
                <span className="truncate">{node.title || "音频"}</span>
            </div>
            <audio src={node.metadata.content} controls className="w-full" data-canvas-no-zoom />
        </div>
    );
}

function ImageContent({
    node,
    isBatchRoot,
    batchCount,
    batchExpanded,
    batchOpening,
    batchRecovering,
    onToggleBatch,
    onSetBatchPrimary,
    media,
    scale,
}: {
    node: CanvasNodeData;
    isBatchRoot: boolean;
    batchCount: number;
    batchExpanded: boolean;
    batchOpening: boolean;
    batchRecovering: boolean;
    onToggleBatch?: () => void;
    onSetBatchPrimary?: () => void;
    media?: ReactNode;
    scale: number;
}) {
    const theme = canvasThemes[useThemeStore((state) => state.theme)];
    const isBatchChild = Boolean(node.metadata?.batchRootId);

    return (
        <BatchFrame batchCount={isBatchRoot ? batchCount : 0} batchExpanded={batchExpanded} batchOpening={batchOpening} batchRecovering={batchRecovering} scale={scale} onToggleBatch={onToggleBatch} stackImageSrc={typeof node.metadata?.content === "string" ? node.metadata.content : undefined}>
            <div className="h-full w-full overflow-hidden rounded-[inherit]">
                {media ?? (
                    <img
                        src={node.metadata!.content!}
                        alt={node.title}
                        draggable={false}
                        onDragStart={(event) => event.preventDefault()}
                        className={`pointer-events-none block h-full w-full select-none ${node.metadata?.freeResize ? "object-fill" : "object-contain"}`}
                    />
                )}
            </div>
            {isBatchRoot ? (
                <button
                    type="button"
                    className="absolute right-2.5 top-2.5 z-30 flex h-7 items-center justify-center gap-1 rounded-lg bg-black/65 px-2 text-[11px] font-medium text-white shadow-[0_4px_14px_rgba(0,0,0,.28)] backdrop-blur-sm transition hover:scale-[1.04] hover:bg-black/75"
                    aria-label={batchExpanded ? "图片组已展开，点击收起" : "图片组已收起，点击展开"}
                    onClick={(event) => {
                        event.stopPropagation();
                        onToggleBatch?.();
                    }}
                    onMouseDown={(event) => event.stopPropagation()}
                    onPointerDown={(event) => event.stopPropagation()}
                >
                    <Layers className="size-3.5" />
                    <span className="leading-none tabular-nums">{batchCount + 1}张</span>
                    <ChevronRight className={`size-3 transition-transform ${batchExpanded ? "rotate-90" : ""}`} />
                </button>
            ) : null}
            {isBatchChild ? (
                <button
                    type="button"
                    className="absolute right-3 top-3 z-30 flex h-9 items-center gap-1.5 rounded-xl border px-2.5 text-xs font-medium opacity-0 shadow-[0_8px_20px_rgba(68,64,60,.13)] backdrop-blur-md transition group-hover/batch:opacity-100 hover:scale-[1.02]"
                    style={{ background: theme.toolbar.panel, borderColor: theme.toolbar.border, color: theme.node.text }}
                    onClick={(event) => {
                        event.stopPropagation();
                        onSetBatchPrimary?.();
                    }}
                    onMouseDown={(event) => event.stopPropagation()}
                    onPointerDown={(event) => event.stopPropagation()}
                >
                    <Star className="size-3.5 text-[#2569ff]" />
                    设为主图
                </button>
            ) : null}
        </BatchFrame>
    );
}

function ImageInfoBar({ node }: { node: CanvasNodeData }) {
    const width = Math.round(node.metadata?.naturalWidth || node.width);
    const height = Math.round(node.metadata?.naturalHeight || node.height);
    const size = formatBytes(node.metadata?.bytes || 0);
    return (
        <div className="pointer-events-none absolute bottom-3 right-3 z-40 max-w-[calc(100%-24px)]">
            <span className="max-w-full truncate rounded-md bg-black/55 px-2 py-1 text-[11px] font-medium leading-none text-white backdrop-blur-sm">
                {width} x {height}
                {size ? ` · ${size}` : ""}
            </span>
        </div>
    );
}

function BatchFrame({ batchCount, batchExpanded, batchOpening, batchRecovering, scale, onToggleBatch, stackImageSrc, children }: { batchCount: number; batchExpanded: boolean; batchOpening: boolean; batchRecovering: boolean; scale: number; onToggleBatch?: () => void; stackImageSrc?: string; children: ReactNode }) {
    const theme = canvasThemes[useThemeStore((state) => state.theme)];
    const isBatchRoot = batchCount > 1;
    return (
        <div
            className="group/batch relative h-full w-full overflow-visible"
            onDoubleClick={
                isBatchRoot
                    ? (event) => {
                        event.stopPropagation();
                        onToggleBatch?.();
                    }
                    : undefined
            }
        >
            {isBatchRoot ? (
                <div className="pointer-events-none absolute inset-0 overflow-visible">
                    {/* 092：LibTV 原版最多可见 4 张（oL = min(len,4)，t>=4 hidden）→ 主图 1 + 背层 3 */}
                    {Array.from({ length: Math.min(batchCount - 1, 3) }).map((_, index) => (
                        <div
                            key={index}
                            className="absolute overflow-hidden rounded-[inherit] border shadow-[0_14px_32px_rgba(0,0,0,0.38)] transition-all duration-300 group-hover/batch:translate-x-2"
                            style={{
                                inset: 0,
                                background: `linear-gradient(135deg, ${theme.node.panel}, ${theme.node.fill})`,
                                borderColor: theme.node.stroke,
                                borderWidth: (scale >= 1 ? 1 : Math.max(0.55, scale)) / Math.max(scale, 0.05),
                                opacity: batchExpanded && !batchOpening ? 0.34 : 1,
                                // 092：LibTV ImageNode 真值——层 t：left 12*t / top 4*t / rotate 2.5*t / scale 1-0.035*t；展开态 rotate 0、scale 1
                                transform:
                                    batchOpening || batchRecovering
                                        ? `translate(${12 * (index + 1)}px, ${4 * (index + 1)}px) rotate(0deg) scale(1)`
                                        : `translate(${12 * (index + 1)}px, ${4 * (index + 1)}px) rotate(${2.5 * (index + 1)}deg) scale(${1 - 0.035 * (index + 1)})`,
                                zIndex: -index - 1,
                            }}
                        >
                            {/* 075：堆叠卡露出子图内容边（对齐 LibTV 原版——背后卡片能看到图片边缘而非纯色块） */}
                            {stackImageSrc ? <img src={stackImageSrc} alt="" draggable={false} className="absolute inset-0 h-full w-full select-none object-cover opacity-90" /> : null}
                        </div>
                    ))}
                </div>
            ) : null}
            {children}
        </div>
    );
}
function ResizeHandle({ corner, onMouseDown }: { corner: ResizeCorner; onMouseDown: (event: React.MouseEvent, corner: ResizeCorner) => void }) {    const positionClass = {
        "top-left": "-left-[14px] -top-[14px] cursor-nwse-resize",
        "top-right": "-right-[14px] -top-[14px] cursor-nesw-resize",
        "bottom-left": "-bottom-[14px] -left-[14px] cursor-nesw-resize",
        "bottom-right": "-bottom-[14px] -right-[14px] cursor-nwse-resize",
    }[corner];

    return <div className={`absolute z-50 size-7 ${positionClass}`} onMouseDown={(event) => onMouseDown(event, corner)} />;
}

// 打组框四角的可见角点：小圆点 + 更大的隐形命中区，拖动自由调整组框大小
function GroupResizeHandle({ corner, onMouseDown }: { corner: ResizeCorner; onMouseDown: (event: React.MouseEvent, corner: ResizeCorner) => void }) {
    const positionClass = {
        "top-left": "-left-[8px] -top-[8px] cursor-nwse-resize",
        "top-right": "-right-[8px] -top-[8px] cursor-nesw-resize",
        "bottom-left": "-bottom-[8px] -left-[8px] cursor-nesw-resize",
        "bottom-right": "-bottom-[8px] -right-[8px] cursor-nwse-resize",
    }[corner];

    return (
        <div className={`absolute z-[60] flex size-6 items-center justify-center ${positionClass}`} onMouseDown={(event) => onMouseDown(event, corner)}>
            <span
                className="size-[9px] rounded-full border"
                style={{ background: "#ffffff", borderColor: selectionHighlight, boxShadow: `0 0 0 2px ${selectionHighlight}33` }}
            />
        </div>
    );
}

function ConnectionHandleDot({ side, visible, scale, onMouseDown }: { side: "left" | "right"; visible: boolean; scale: number; onMouseDown: (event: React.MouseEvent) => void }) {
    const theme = canvasThemes[useThemeStore((state) => state.theme)];
    const areaRef = useRef<HTMLDivElement>(null);
    const [offset, setOffset] = useState<{ x: number; y: number } | null>(null);
    const maxDist = 34;

    // 手柄屏幕尺寸：≥100% 恒定 16px；<100% 随缩放自然变小，下限 10px（不再显得比节点还大）
    const handleScreenScale = scale >= 1 ? 1 / scale : Math.max(1, 10 / (16 * scale));

    const track = (event: React.MouseEvent) => {
        const area = areaRef.current;
        if (!area) return;
        const rect = area.getBoundingClientRect();
        // ⊕ 静止点在节点边缘外侧 10px：命中区完全在节点外侧，右侧手柄在命中区左起 10px 处，左侧手柄在右起 10px 处
        const restX = side === "right" ? rect.left + 10 : rect.right - 10;
        let dy = event.clientY - (rect.top + rect.height / 2);
        const outSign = side === "right" ? 1 : -1;
        let du = (event.clientX - restX) * outSign; // 以“向外”为正方向
        if (du < 0) du = 0; // 只能往外移，不能往里
        const dist = Math.hypot(du, dy);
        if (dist > maxDist) {
            du = (du / dist) * maxDist;
            dy = (dy / dist) * maxDist;
        }
        setOffset({ x: (du * outSign) / Math.max(scale, 0.05), y: dy / Math.max(scale, 0.05) });
    };

    // 手柄移到极限位置后保持不动（不回弹），只有节点不再 hover/选中时才归位。
    useEffect(() => {
        if (!visible) setOffset(null);
    }, [visible]);

    // 缩放到 30% 以下隐藏手柄：那个尺寸下无法瞄准连线，想连线先放大（hooks 之后才能提前 return）
    if (scale < 0.3) return null;

    return (
        <div
            ref={areaRef}
            className={`group/connection absolute z-30 cursor-crosshair transition-opacity duration-150 pointer-events-auto ${visible ? "opacity-100" : "opacity-0 hover:opacity-100"}`}
            style={{ ...(side === "right" ? { right: -72 } : { left: -72 }), top: "50%", width: 72, height: 150, transform: "translateY(-50%)" }}
            onMouseDown={onMouseDown}
            onMouseMove={track}
            onMouseLeave={() => setOffset(null)}
            title="拖动以创建连接"
        >
            <div
                className="absolute flex size-4 items-center justify-center rounded-full border transition-transform duration-150 ease-out"
                style={{
                    ...(side === "right" ? { left: "calc(10px / var(--canvas-inverse-scale, 1) - 8px)" } : { right: "calc(10px / var(--canvas-inverse-scale, 1) - 8px)" }),
                    top: "50%",
                    marginTop: -8,
                    background: theme.node.panel,
                    borderColor: visible ? theme.node.label : theme.node.muted,
                    color: visible ? theme.node.label : theme.node.muted,
                    transform: `translate(${offset?.x ?? 0}px, ${offset?.y ?? 0}px) scale(${handleScreenScale})`,
                }}
            >
                <svg viewBox="0 0 10 10" className="size-2.5">
                    <path d="M5 2.4 V7.6 M2.4 5 H7.6" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" fill="none" />
                </svg>
            </div>
        </div>
    );
}
