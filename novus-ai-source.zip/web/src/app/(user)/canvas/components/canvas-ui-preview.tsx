"use client";

import { useEffect, type ChangeEvent, type MouseEvent, type ReactNode, type RefObject } from "react";
import { useRouter } from "next/navigation";
import { Check, Download, FileUp, Pencil, Plus, Trash2, X } from "lucide-react";
import { Input } from "antd";

import { useCanvasStore, type CanvasProject } from "../stores/use-canvas-store";
import { useCanvasUiStore } from "../stores/use-canvas-ui-store";
import { exportCanvasProjects } from "../utils/canvas-export";
import { disabledNavSlugs } from "@/constant/navigation-tools";
import GhostFibers from "./preview/GhostFibers";
import LightRays from "./preview/LightRays";

export function CanvasPreviewNav({ active, embedded = false }: { active: "start" | "library"; embedded?: boolean }) {
    const router = useRouter();
    const navigate = (event: MouseEvent<HTMLAnchorElement>, href: string) => {
        event.preventDefault();
        router.push(href);
    };
    const items = [
        { label: "开始", href: embedded ? "/canvas?embedded=1" : "/", key: "start" as const, slug: "canvas" },
        { label: "我的画布", href: embedded ? "/canvas?embedded=1&view=library" : "/canvas", key: "library" as const, slug: "canvas" },
        { label: "生图工作台", href: "/image", key: "other" as const, slug: "image" },
        { label: "视频创作", href: "/video", key: "other" as const, slug: "video" },
        { label: "提示词库", href: "/prompts", key: "other" as const, slug: "prompts" },
        { label: "我的素材", href: "/assets", key: "other" as const, slug: "assets" },
    ];
    return (
        <header className="canvas-ui-topbar">
            <div className="canvas-ui-nav-shell">
                <div className="canvas-ui-nav-center">
                    <a className="canvas-ui-brand" href={embedded ? "/canvas?embedded=1" : "/"} onClick={(event) => navigate(event, embedded ? "/canvas?embedded=1" : "/")}>
                        {/* boss 2026-10-07 批次 127：顶栏品牌 logo 换 Novus AI logo（此前误换的是蓝钮/页签，boss 澄清指的是这里） */}
                        <span className="canvas-ui-brand-mark"><img src="/novus-ai-logo.png" alt="Novus AI" /></span>
                        <span>Novus AI</span>
                    </a>
                    <nav className="canvas-ui-main-nav" aria-label="Novus AI导航">
                        {items.map((item) => {
                            // 功能未上线项置灰禁点（boss 2026-10-04），清单同 constant/navigation-tools.ts
                            const disabled = disabledNavSlugs.has(item.slug);
                            return (
                                <a
                                    key={item.label}
                                    href={item.href}
                                    onClick={disabled ? (event) => event.preventDefault() : (event) => navigate(event, item.href)}
                                    title={disabled ? "即将上线" : undefined}
                                    aria-disabled={disabled || undefined}
                                    className={`canvas-ui-nav-item ${item.key === active ? "is-active" : ""}`}
                                    style={disabled ? { color: "#57534e", cursor: "not-allowed" } : undefined}
                                >
                                    {item.label}
                                </a>
                            );
                        })}
                    </nav>
                </div>
            </div>
        </header>
    );
}

export function CanvasPreviewHome({
    onCreateBlank,
    embedded = false,
}: {
    /** 保留兼容旧调用（composer 弹窗已移除，点击“新建画布”直接创建并进入画布） */
    composer?: ReactNode;
    composerOpen?: boolean;
    onOpenComposer?: () => void;
    onCloseComposer?: () => void;
    onCreateBlank: () => void;
    embedded?: boolean;
}) {
    const router = useRouter();
    useEffect(() => {
        if (window.parent !== window) window.parent.postMessage({ type: "canvas-ready" }, "*");
    }, []);
    return (
        <div className="canvas-ui-shell canvas-ui-home-shell">
            <CanvasPreviewNav active="start" embedded={embedded} />
            <main className="canvas-ui-home">
                <div className="canvas-ui-fiber-bg" aria-hidden="true">
                    <GhostFibers lineColor="#140E35" glowColor="#3437A0" speed={0.35} scale={2} rotation={0} rotationSpeed={0.4} layers={4} waveAmplitude={0.02} waveFrequency={3} waveSpeed={0.3} layerSpeed={0.16} twist={0.1} twistFrequency={5} twistSpeed={1.2} lineFrequency={5} lineSpacing={2} lineSharpness={16} glowFalloff={10} glowIntensity={1.6} brightness={2} blueBoost={1.25} vignette={0.8} grain={0.05} dpr={1} />
                </div>
                <div className="canvas-ui-grid-overlay" aria-hidden="true" />
                <div className="canvas-ui-ambient canvas-ui-ambient-one" aria-hidden="true" />
                <div className="canvas-ui-ambient canvas-ui-ambient-two" aria-hidden="true" />
                <section className="canvas-ui-hero-content">
                    <div className="canvas-ui-announcement"><span>NEW</span><strong>Dola</strong></div>
                    <h1>让灵感从安静的<br /><em>空白里长出来。</em></h1>
                    <p>从一个想法开始，展开你的故事、画面与镜头。Novus AI让每一次创作都保持自由。</p>
                    {/* 034（boss 2026-10-05）：主 CTA 旁加「我的画布」，直接跳第二个界面（画布库/全部项目） */}
                    <div className="flex items-center justify-center gap-3">
                        <button type="button" className="canvas-ui-primary-cta" onClick={onCreateBlank}>新建画布 <span>↗</span></button>
                        <button type="button" className="canvas-ui-secondary-cta" onClick={() => router.push(embedded ? "/canvas?embedded=1&view=library" : "/canvas")}>我的画布</button>
                    </div>
                </section>
            </main>
        </div>
    );
}

export function CanvasPreviewLibrary({
    projects,
    hydrated,
    inputRef,
    importCanvas,
    createAndEnter,
    embedded = false,
}: {
    projects: CanvasProject[];
    hydrated: boolean;
    inputRef: RefObject<HTMLInputElement | null>;
    importCanvas: (file?: File) => Promise<void>;
    createAndEnter: () => void;
    embedded?: boolean;
}) {
    useEffect(() => {
        if (window.parent !== window) window.parent.postMessage({ type: "canvas-ready" }, "*");
    }, []);
    const selectedIds = useCanvasUiStore((state) => state.selectedProjectIds);
    const setDeleteIds = useCanvasUiStore((state) => state.setDeleteProjectIds);
    const trashCount = useCanvasStore((state) => state.trash.length);
    const setTrashOpen = useCanvasUiStore((state) => state.setTrashOpen);
    const deleteAll = () => setDeleteIds(projects.map((project) => project.id));
    return (
        <div className="canvas-ui-shell">
            <CanvasPreviewNav active="library" embedded={embedded} />
            <main className="canvas-ui-library">
                <div className="canvas-ui-library-rays" aria-hidden="true"><LightRays raysOrigin="top-center" raysColor="#3d4ad6" raysSpeed={0.35} lightSpread={1.15} rayLength={1.5} pulsating={false} fadeDistance={1.1} saturation={1} followMouse={false} mouseInfluence={0} noiseAmount={0.02} distortion={0} /></div>
                <section className="canvas-ui-library-shell">
                    <div className="canvas-ui-library-heading"><div><div className="canvas-ui-eyebrow">画布库</div><h1>全部项目</h1></div><div className="canvas-ui-library-actions">
                        {selectedIds.length ? <><button type="button" className="canvas-ui-library-button" onClick={() => void exportCanvasProjects(projects.filter((project) => selectedIds.includes(project.id)), `Novus AI-${selectedIds.length}个项目`)}><Download className="size-3.5" /> 导出选中</button><button type="button" className="canvas-ui-library-button" onClick={() => setDeleteIds(selectedIds)}>删除选中</button></> : null}
                        {projects.length ? <button type="button" className="canvas-ui-library-button" onClick={deleteAll}>删除全部</button> : null}
                        <button type="button" className="canvas-ui-library-button" onClick={() => setTrashOpen(true)}><Trash2 className="size-3.5" /> 回收站{trashCount ? <span className="canvas-ui-library-badge">{trashCount}</span> : null}</button>
                        <button type="button" className="canvas-ui-library-button"><label className="canvas-ui-file-button"><FileUp className="size-3.5" /> 导入画布<input ref={inputRef} type="file" accept="application/zip,.zip" hidden onChange={(event: ChangeEvent<HTMLInputElement>) => void importCanvas(event.target.files?.[0])} /></label></button>
                        <button type="button" className="canvas-ui-library-button canvas-ui-library-button-primary" onClick={createAndEnter}><Plus className="size-3.5" /> 新建画布</button>
                    </div></div>
                    <div className="canvas-ui-library-divider" />
                    {!hydrated ? <div className="canvas-ui-library-empty">正在加载画布...</div> : projects.length ? <div className="canvas-ui-card-grid">{projects.map((project) => <CanvasPreviewProjectCard key={project.id} project={project} />)}</div> : <div className="canvas-ui-library-empty"><strong>还没有画布</strong><span>新建一个画布后，就可以独立保存节点、连线和画布外观。</span><button type="button" className="canvas-ui-library-button canvas-ui-library-button-primary" onClick={createAndEnter}><Plus className="size-3.5" /> 新建画布</button></div>}
                </section>
            </main>
        </div>
    );
}

function CanvasPreviewProjectCard({ project }: { project: CanvasProject }) {
    const router = useRouter();
    const renameProject = useCanvasStore((state) => state.renameProject);
    const selectedIds = useCanvasUiStore((state) => state.selectedProjectIds);
    const editingId = useCanvasUiStore((state) => state.editingProjectId);
    const editingTitle = useCanvasUiStore((state) => state.editingProjectTitle);
    const startEditing = useCanvasUiStore((state) => state.startEditingProject);
    const setEditingTitle = useCanvasUiStore((state) => state.setEditingProjectTitle);
    const stopEditing = useCanvasUiStore((state) => state.stopEditingProject);
    const toggleSelected = useCanvasUiStore((state) => state.toggleSelectedProjectId);
    const setDeleteIds = useCanvasUiStore((state) => state.setDeleteProjectIds);
    const editing = editingId === project.id;
    const selected = selectedIds.includes(project.id);
    const saveTitle = () => { renameProject(project.id, editingTitle); stopEditing(); };
    const updated = new Date(project.updatedAt).toLocaleString("zh-CN", { month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" });
    return <article className="canvas-ui-card" tabIndex={0} onClick={() => !editing && router.push(`/canvas/${project.id}`)}>
        <div className="canvas-ui-card-top"><input type="checkbox" checked={selected} onClick={(event) => event.stopPropagation()} onChange={(event) => toggleSelected(project.id, event.target.checked)} aria-label={`选择 ${project.title}`} />{editing ? <Input className="canvas-ui-card-input" value={editingTitle} onClick={(event) => event.stopPropagation()} onChange={(event) => setEditingTitle(event.target.value)} onKeyDown={(event) => event.key === "Enter" && saveTitle()} autoFocus /> : <button type="button" className="canvas-ui-card-title-button" onClick={(event) => { event.stopPropagation(); router.push(`/canvas/${project.id}`); }}><h2>{project.title}</h2><span className="canvas-ui-card-status">最近编辑</span></button>}</div>
        <p className="canvas-ui-card-meta">{project.nodes.length} 个节点 · {project.connections.length} 条连线</p>
        <div className="canvas-ui-card-footer"><span className="canvas-ui-card-updated"><i /> 更新于 {updated}</span><div className="canvas-ui-card-actions" onClick={(event) => event.stopPropagation()}>{editing ? <><button type="button" onClick={saveTitle} aria-label="保存名称"><Check className="size-3.5" /></button><button type="button" onClick={stopEditing} aria-label="取消重命名"><X className="size-3.5" /></button></> : <><button type="button" onClick={() => void exportCanvasProjects([project], project.title || "Novus AI")} aria-label="导出"><Download className="size-3.5" /></button><button type="button" onClick={() => startEditing(project.id, project.title)} aria-label="重命名"><Pencil className="size-3.5" /></button><button type="button" onClick={() => setDeleteIds([project.id])} aria-label="删除"><Trash2 className="size-3.5" /></button></>}</div></div>
    </article>;
}
