"use client";

import { useEffect, useRef, useState, type ReactNode, type RefObject } from "react";
import { createPortal } from "react-dom";
import { Settings2 } from "lucide-react";
import { Button, Switch } from "antd";

import { imageQualityLabel, imageSizeLabel } from "@/components/image-settings-panel";
import { canvasThemes } from "@/lib/canvas-theme";
import { imageModelCapability } from "@/lib/image-model-capability-map";
import { isKIESeedreamLayerDecompositionModel } from "@/lib/kie-models";
import { useThemeStore } from "@/stores/use-theme-store";
import type { AiConfig } from "@/stores/use-config-store";
import { PromptBarSettingsSection, RatioFrameIcon } from "./canvas-video-settings-popover";

type CanvasImageSettingsPopoverProps = {
    config: AiConfig;
    onConfigChange: (key: keyof AiConfig, value: string) => void;
    onMissingConfig?: () => void;
    onOpenChange?: (open: boolean) => void;
    buttonClassName?: string;
    getPopupContainer?: (triggerNode: HTMLElement) => HTMLElement;
    placement?: "topLeft" | "top" | "topRight" | "bottomLeft" | "bottom" | "bottomRight";
    autoAdjustOverflow?: boolean;
    showSize?: boolean;
    showCount?: boolean;
    buttonIcon?: ReactNode;
};

/* 图像比例选项（数据与 src/components/image-settings-panel.tsx 的 aspectOptions 一致；
   ratio = RatioFrameIcon 的形状键，2k/4k 变体复用基础比例形状） */
const ASPECT_OPTIONS: { value: string; label: string; size?: string; width: number; height: number; ratio: string }[] = [
    { value: "1:1", label: "1:1", width: 1024, height: 1024, ratio: "1:1" },
    { value: "3:2", label: "3:2", width: 1536, height: 1024, ratio: "3:2" },
    { value: "2:3", label: "2:3", width: 1024, height: 1536, ratio: "2:3" },
    { value: "4:3", label: "4:3", width: 1024, height: 768, ratio: "4:3" },
    { value: "3:4", label: "3:4", width: 768, height: 1024, ratio: "3:4" },
    { value: "16:9", label: "16:9", width: 1920, height: 1080, ratio: "16:9" },
    { value: "9:16", label: "9:16", width: 1080, height: 1920, ratio: "9:16" },
    { value: "21:9", label: "21:9", width: 1568, height: 672, ratio: "21:9" },
    { value: "1:1-2k", label: "1:1(2k)", size: "2048x2048", width: 2048, height: 2048, ratio: "1:1" },
    { value: "16:9-2k", label: "16:9(2k)", size: "2048x1152", width: 2048, height: 1152, ratio: "16:9" },
    { value: "9:16-2k", label: "9:16(2k)", size: "1152x2048", width: 1152, height: 2048, ratio: "9:16" },
    { value: "21:9-2k", label: "21:9(2k)", size: "3136x1344", width: 3136, height: 1344, ratio: "21:9" },
    { value: "16:9-4k", label: "16:9(4k)", size: "3840x2160", width: 3840, height: 2160, ratio: "16:9" },
    { value: "9:16-4k", label: "9:16(4k)", size: "2160x3840", width: 2160, height: 3840, ratio: "9:16" },
    { value: "21:9-4k", label: "21:9(4k)", size: "6272x2688", width: 6272, height: 2688, ratio: "21:9" },
    { value: "auto", label: "auto", width: 0, height: 0, ratio: "auto" },
];

const QUALITY_OPTIONS = [
    { value: "auto", label: "自动" },
    { value: "high", label: "高" },
    { value: "medium", label: "中" },
    { value: "low", label: "低" },
];
const DIMENSION_STEP = 16;

export function CanvasImageSettingsPopover({ config, onConfigChange, onOpenChange, buttonClassName, placement = "topLeft", showSize = true, showCount = true, buttonIcon }: CanvasImageSettingsPopoverProps) {
    const theme = canvasThemes[useThemeStore((state) => state.theme)];
    const buttonRef = useRef<HTMLSpanElement>(null);
    const panelRef = useRef<HTMLDivElement>(null);
    const [open, setOpen] = useState(false);
    const [buttonRect, setButtonRect] = useState<DOMRect | null>(null);
    const quality = config.quality || "auto";
    const count = Math.max(1, Math.min(15, Math.floor(Math.abs(Number(config.count)) || 1)));
    const activeSize = config.size || "auto";
    const layerDecomposition = isKIESeedreamLayerDecompositionModel(config.model);
    // 任务rUrQgS：按模型能力适配——dola5.0 等不支持质量/张数的模型不显示对应项
    const capability = imageModelCapability(config.model);
    const effectiveShowSize = showSize && !layerDecomposition;
    const effectiveShowCount = showCount && !layerDecomposition && capability.supportsCount;
    const effectiveShowQuality = capability.supportsQuality;
    const updateOpen = (nextOpen: boolean) => {
        setOpen(nextOpen);
        onOpenChange?.(nextOpen);
    };

    useEffect(() => {
        if (!open) return;
        const syncPosition = () => setButtonRect(buttonRef.current?.getBoundingClientRect() || null);
        const closeOnOutsidePointer = (event: PointerEvent) => {
            const target = event.target;
            if (!(target instanceof Node)) return;
            if (buttonRef.current?.contains(target) || panelRef.current?.contains(target)) return;
            if (document.activeElement instanceof HTMLElement && panelRef.current?.contains(document.activeElement)) document.activeElement.blur();
            setOpen(false);
            onOpenChange?.(false);
        };

        syncPosition();
        window.addEventListener("resize", syncPosition);
        window.addEventListener("scroll", syncPosition, true);
        window.addEventListener("pointerdown", closeOnOutsidePointer, true);
        return () => {
            window.removeEventListener("resize", syncPosition);
            window.removeEventListener("scroll", syncPosition, true);
            window.removeEventListener("pointerdown", closeOnOutsidePointer, true);
        };
    }, [onOpenChange, open]);

    const panel = open && buttonRect ? <ImageSettingsPortal buttonRect={buttonRect} panelRef={panelRef} placement={placement} config={config} onConfigChange={onConfigChange} showSize={effectiveShowSize} showCount={effectiveShowCount} /> : null;

    return (
        <>
            <span ref={buttonRef} className="inline-flex min-w-0">
                <Button size="small" type="text" className={buttonClassName || "!h-8 !max-w-[180px] !justify-start !rounded-full !px-2.5"} style={{ background: theme.node.fill, color: theme.node.text }} icon={buttonIcon || <Settings2 className="size-3.5" />} onClick={() => updateOpen(!open)}>
                    <span className="truncate">
                        {effectiveShowSize ? (
                            <>
                                {effectiveShowQuality ? <>{imageQualityLabel(quality)} · </> : null}
                                {imageSizeLabel(activeSize)}
                                {effectiveShowCount ? <> · {count} 张</> : null}
                            </>
                        ) : (
                            <>
                                {effectiveShowQuality ? imageQualityLabel(quality) : null}
                                {effectiveShowCount ? <> · {count} 张</> : null}
                            </>
                        )}
                    </span>
                </Button>
            </span>
            {panel}
        </>
    );
}

function ImageSettingsPortal({
    buttonRect,
    panelRef,
    placement,
    config,
    onConfigChange,
    showSize,
    showCount,
}: {
    buttonRect: DOMRect;
    panelRef: RefObject<HTMLDivElement | null>;
    placement: CanvasImageSettingsPopoverProps["placement"];
    config: AiConfig;
    onConfigChange: (key: keyof AiConfig, value: string) => void;
    showSize: boolean;
    showCount: boolean;
}) {
    /* boss 2026-10-04：图像设置弹层换成与视频参数弹层同款新 UI（promptBarMode 真值）：
       w 340 / bg rgba(38,38,38,.95) / rounded-2xl(16) / p-3(12) / border 0.5px #363636
       / backdrop-blur 32px / shadow-dropdown */
    const width = 340;
    const gap = 8;
    const margin = 12;
    const alignRight = placement?.endsWith("Right");
    const alignCenter = placement === "top" || placement === "bottom";
    const left = alignCenter ? buttonRect.left + buttonRect.width / 2 - width / 2 : alignRight ? buttonRect.right - width : buttonRect.left;
    const topPlacement = placement?.startsWith("top");
    const style = {
        position: "fixed",
        zIndex: 1200,
        width,
        left: Math.max(margin, Math.min(window.innerWidth - width - margin, left)),
        ...(topPlacement ? { bottom: window.innerHeight - buttonRect.top + gap, maxHeight: Math.max(260, buttonRect.top - margin * 2) } : { top: buttonRect.bottom + gap, maxHeight: Math.max(260, window.innerHeight - buttonRect.bottom - margin * 2) }),
        background: "rgba(38, 38, 38, 0.95)",
        borderRadius: 16,
        boxShadow: "0px 4px 10px rgba(0,0,0,0.25), 0px 2px 4px rgba(0,0,0,0.3)",
        padding: 12,
        overflowY: "auto",
        color: "#f7f7f7",
        border: "0.5px solid #363636",
        backdropFilter: "blur(32px)",
        WebkitBackdropFilter: "blur(32px)",
    } as const;

    return createPortal(
        <div
            ref={panelRef}
            className="canvas-image-settings-popover"
            style={style}
            onPointerDown={(event) => event.stopPropagation()}
            onMouseDown={(event) => event.stopPropagation()}
            onClick={(event) => event.stopPropagation()}
        >
            <PromptBarImageSettingsPanel config={config} onConfigChange={onConfigChange} showSize={showSize} showCount={showCount} />
        </div>,
        document.body,
    );
}

/** 与视频 PromptBarVideoSettingsPanel 同套结构的图像参数面板：比例/质量/尺寸/生成张数（按模型能力适配） */
function PromptBarImageSettingsPanel({ config, onConfigChange, showSize, showCount }: { config: AiConfig; onConfigChange: (key: keyof AiConfig, value: string) => void; showSize: boolean; showCount: boolean }) {
    const [snapDimensionToStep, setSnapDimensionToStep] = useState(true);
    const quality = config.quality || "auto";
    const count = Math.max(1, Math.min(15, Math.floor(Math.abs(Number(config.count)) || 1)));
    const activeSize = config.size || "auto";
    // 任务rUrQgS：按模型能力过滤比例选项（如 Dola 只开基础比例，无 2k/4k 变体）
    const capability = imageModelCapability(config.model);
    const aspectOptions = capability.ratios ? ASPECT_OPTIONS.filter((item) => capability.ratios!.includes(item.value)) : ASPECT_OPTIONS;
    const selectedAspect = aspectOptions.find((item) => (item.size || item.value) === activeSize || item.value === activeSize);
    const dimensions = readSizeDimensions(activeSize, selectedAspect || aspectOptions[0] || ASPECT_OPTIONS[0]);
    const selectAspect = (value: string) => {
        const option = ASPECT_OPTIONS.find((item) => item.value === value);
        onConfigChange("size", option?.size || option?.value || "auto");
    };
    const updateDimension = (key: "width" | "height", value: number | null) => {
        const next = Math.max(1, Math.floor(value || dimensions[key] || 1024));
        const width = key === "width" ? next : dimensions.width;
        const height = key === "height" ? next : dimensions.height;
        onConfigChange("size", `${alignDimension(width, snapDimensionToStep)}x${alignDimension(height, snapDimensionToStep)}`);
    };

    return (
        <div className="canvas-prompt-video-settings">
            {showSize ? (
                <PromptBarSettingsSection title="比例">
                    <div className="canvas-prompt-settings-ratio-grid">
                        {aspectOptions.map((item) => (
                            <button key={item.value} type="button" className={selectedAspect?.value === item.value ? "is-active" : ""} onMouseDown={(event) => event.stopPropagation()} onClick={() => selectAspect(item.value)}>
                                <RatioFrameIcon ratio={item.ratio} />
                                <span className="canvas-prompt-settings-ratio-label">{item.label}</span>
                            </button>
                        ))}
                    </div>
                </PromptBarSettingsSection>
            ) : null}
            {capability.supportsQuality ? (
                <PromptBarSettingsSection title="质量">
                    <div className="canvas-prompt-settings-quality-grid">
                        {QUALITY_OPTIONS.map((item) => (
                            <button key={item.value} type="button" className={quality === item.value ? "is-active" : ""} onMouseDown={(event) => event.stopPropagation()} onClick={() => onConfigChange("quality", item.value)}>
                                {item.label}
                            </button>
                        ))}
                    </div>
                </PromptBarSettingsSection>
            ) : null}
            {showSize && capability.supportsCustomSize ? (
                <PromptBarSettingsSection title="尺寸">
                    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8, marginTop: -4, marginBottom: 2 }}>
                        <span style={{ color: "#919191", fontSize: 12 }}>16倍数对齐</span>
                        <span title="输入完成后自动向上补成 16 的倍数" onMouseDown={(event) => event.stopPropagation()}>
                            <Switch size="small" checked={snapDimensionToStep} onChange={setSnapDimensionToStep} />
                        </span>
                    </div>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr auto 1fr", alignItems: "center", gap: 8 }}>
                        <DimensionField prefix="W" value={dimensions.width} disabled={activeSize === "auto"} alignToStep={snapDimensionToStep} onChange={(value) => updateDimension("width", value)} />
                        <span style={{ color: "#919191", fontSize: 14, opacity: 0.6 }}>↔</span>
                        <DimensionField prefix="H" value={dimensions.height} disabled={activeSize === "auto"} alignToStep={snapDimensionToStep} onChange={(value) => updateDimension("height", value)} />
                    </div>
                </PromptBarSettingsSection>
            ) : null}
            {showCount && capability.supportsCount ? (
                <PromptBarSettingsSection title="生成张数">
                    <div className="canvas-prompt-settings-count-grid">
                        {Array.from({ length: 10 }, (_, index) => index + 1).map((value) => (
                            <button key={value} type="button" className={count === value ? "is-active" : ""} onMouseDown={(event) => event.stopPropagation()} onClick={() => onConfigChange("count", String(value))}>
                                {value}张
                            </button>
                        ))}
                        <CountField value={count} max={15} onChange={(value) => onConfigChange("count", String(value || 1))} />
                    </div>
                </PromptBarSettingsSection>
            ) : null}
            {capability.note ? <p className="canvas-prompt-settings-note" style={{ marginTop: 4 }}>{capability.note}</p> : null}
        </div>
    );
}

/** W/H 输入框：视觉对齐 count cell（h-8 / 0.5px #525252 / rounded-lg），逻辑同老 DimensionInput */
function DimensionField({ prefix, value, disabled, alignToStep, onChange }: { prefix: string; value: number; disabled: boolean; alignToStep: boolean; onChange: (value: number | null) => void }) {
    const commit = (input: HTMLInputElement) => {
        const next = alignDimension(Math.max(1, Math.floor(Number(input.value) || value || 1024)), alignToStep);
        input.value = String(next);
        onChange(next);
    };
    return (
        <label style={{ display: "flex", height: 32, alignItems: "center", overflow: "hidden", border: "0.5px solid #525252", borderRadius: 8, color: "#f7f7f7", opacity: disabled ? 0.35 : 1 }}>
            <span style={{ width: 28, flex: "none", textAlign: "center", color: "#919191", fontSize: 13 }}>{prefix}</span>
            <input
                type="number"
                min={1}
                disabled={disabled}
                defaultValue={value || ""}
                key={`${prefix}-${value}`}
                className="[appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none"
                style={{ minWidth: 0, flex: 1, background: "transparent", border: 0, outline: "none", color: "#f7f7f7", fontSize: 13, padding: "0 8px 0 0" }}
                onBlur={(event) => commit(event.currentTarget)}
                onKeyDown={(event) => {
                    if (event.key === "Enter") event.currentTarget.blur();
                }}
                onMouseDown={(event) => event.stopPropagation()}
            />
        </label>
    );
}

/** 张数自定义输入：占 count-grid 一格，视觉同 count cell */
function CountField({ value, max, onChange }: { value: number; max: number; onChange: (value: number | null) => void }) {
    return (
        <label style={{ display: "flex", height: 32, alignItems: "center", overflow: "hidden", border: "0.5px solid #525252", borderRadius: 8, color: "#f7f7f7" }}>
            <input
                type="number"
                min={1}
                max={max}
                value={value || ""}
                className="[appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none"
                style={{ minWidth: 0, flex: 1, background: "transparent", border: 0, outline: "none", color: "#f7f7f7", fontSize: 13, textAlign: "center" }}
                onChange={(event) => onChange(Number(event.target.value) || null)}
                onMouseDown={(event) => event.stopPropagation()}
            />
        </label>
    );
}

function readSizeDimensions(size: string, fallback: { width: number; height: number }) {
    const match = size?.match(/^(\d+)x(\d+)$/);
    return {
        width: match ? Number(match[1]) : fallback.width,
        height: match ? Number(match[2]) : fallback.height,
    };
}

function alignDimension(value: number, enabled: boolean) {
    return enabled ? Math.ceil(value / DIMENSION_STEP) * DIMENSION_STEP : value;
}
