import { type MouseEvent as ReactMouseEvent } from "react";

import { canvasThemes } from "@/lib/canvas-theme";
import { useThemeStore } from "@/stores/use-theme-store";
import type { CanvasConnection, CanvasNodeData, ConnectionHandle, Position } from "../types";

// 角度自适应曲率：水平连接弯度最大，越接近垂直越直（只留两端小钩），斜向取中等弯度
export function buildConnectionPath(startX: number, startY: number, endX: number, endY: number): string {
    const dx = endX - startX;
    const dy = endY - startY;
    const dist = Math.hypot(dx, dy) || 1;
    const angleFactor = Math.abs(dx) / dist; // 1=水平 0=垂直
    const cp = Math.max(dist * 0.35 * angleFactor, 14);
    return `M ${startX} ${startY} C ${startX + cp} ${startY}, ${endX - cp} ${endY}, ${endX} ${endY}`;
}

// 沿连线真实曲线等距采样（与 buildConnectionPath 同一套控制点），供命中判定/框选取点使用
export function connectionCurvePoints(startX: number, startY: number, endX: number, endY: number, steps: number): Position[] {
    const dx = endX - startX;
    const dy = endY - startY;
    const dist = Math.hypot(dx, dy) || 1;
    const angleFactor = Math.abs(dx) / dist;
    const cp = Math.max(dist * 0.35 * angleFactor, 14);
    const c1x = startX + cp;
    const c2x = endX - cp;
    const points: Position[] = [];
    for (let i = 0; i <= steps; i += 1) {
        const t = i / steps;
        const mt = 1 - t;
        const a = mt * mt * mt;
        const b = 3 * mt * mt * t;
        const c = 3 * mt * t * t;
        const d = t * t * t;
        points.push({
            x: a * startX + b * c1x + c * c2x + d * endX,
            y: a * startY + b * startY + c * endY + d * endY,
        });
    }
    return points;
}


export function ConnectionPath({
    connection,
    from,
    to,
    active,
    onSelect,
    onContextMenu,
}: {
    connection: CanvasConnection;
    from: CanvasNodeData;
    to: CanvasNodeData;
    active: boolean;
    onSelect: () => void;
    onContextMenu?: (event: ReactMouseEvent<SVGPathElement>) => void;
}) {
    const theme = canvasThemes[useThemeStore((state) => state.theme)];
    const startX = from.position.x + from.width;
    const startY = from.position.y + from.height / 2;
    const endX = to.position.x;
    const endY = to.position.y + to.height / 2;
    const pathD = buildConnectionPath(startX, startY, endX, endY);

    return (
        <g>
            <path
                data-connection-id={connection.id}
                d={pathD}
                stroke="transparent"
                strokeWidth="16"
                fill="none"
                style={{ cursor: "pointer", pointerEvents: "stroke" }}
                onClick={(event) => {
                    event.stopPropagation();
                    onSelect();
                }}
                onContextMenu={(event) => {
                    event.preventDefault();
                    event.stopPropagation();
                    onContextMenu?.(event);
                }}
            />
            {/* 主连线：全灰静态（boss 2026-10-03 定：禁蓝色、禁动画、禁 drop-shadow 滤镜） */}
            {active ? <path d={pathD} stroke={theme.node.label} strokeWidth={5} strokeOpacity={0.2} fill="none" strokeLinecap="round" style={{ pointerEvents: "none" }} /> : null}
            <path d={pathD} stroke={active ? theme.node.label : theme.node.faint} strokeWidth={active ? 2 : 1.5} fill="none" strokeLinecap="round" style={{ pointerEvents: "none" }} />
        </g>
    );
}

export function ActiveConnectionPath({ node, handle, mouseWorld, target }: { node?: CanvasNodeData; handle: ConnectionHandle; mouseWorld: Position; target?: CanvasNodeData }) {
    const theme = canvasThemes[useThemeStore((state) => state.theme)];
    if (!node) return null;

    const startX = handle.handleType === "source" ? node.position.x + node.width : mouseWorld.x;
    const startY = handle.handleType === "source" ? node.position.y + node.height / 2 : mouseWorld.y;
    const endX = handle.handleType === "source" ? mouseWorld.x : node.position.x;
    const endY = handle.handleType === "source" ? mouseWorld.y : node.position.y + node.height / 2;
    const snappedStartX = handle.handleType === "target" && target ? target.position.x + target.width : startX;
    const snappedStartY = handle.handleType === "target" && target ? target.position.y + target.height / 2 : startY;
    const snappedEndX = handle.handleType === "source" && target ? target.position.x : endX;
    const snappedEndY = handle.handleType === "source" && target ? target.position.y + target.height / 2 : endY;
    const pathD = buildConnectionPath(snappedStartX, snappedStartY, snappedEndX, snappedEndY);

    return (
        <g>
            {/* 拖拽拉线预览：与默认连线同款哑光灰（全灰静态，无辉光无动画） */}
            <path d={pathD} stroke={theme.node.faint} strokeWidth={1.5} fill="none" strokeLinecap="round" style={{ pointerEvents: "none" }} />
        </g>
    );
}
