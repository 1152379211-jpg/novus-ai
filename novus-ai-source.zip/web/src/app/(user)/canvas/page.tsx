"use client";

import { Suspense, useEffect, useRef } from "react";
import { useSearchParams } from "next/navigation";
import { useRouter } from "next/navigation";
import { App, Button } from "antd";
import { Download, FileUp, Plus } from "lucide-react";

import { readZip } from "@/lib/zip";
import { setMediaBlob } from "@/services/file-storage";
import { setImageBlob } from "@/services/image-storage";
import { CanvasDeleteProjectsDialog } from "./components/canvas-delete-projects-dialog";
import { CanvasTrashDialog } from "./components/canvas-trash-dialog";
import { CanvasProjectCard } from "./components/canvas-project-card";
import type { CanvasExportFile } from "./export-types";
import { useCanvasStore } from "./stores/use-canvas-store";
import { useCanvasUiStore } from "./stores/use-canvas-ui-store";
import { exportCanvasProjects } from "./utils/canvas-export";
import { CanvasPreviewHome, CanvasPreviewLibrary } from "./components/canvas-ui-preview";

export default function CanvasPage() {
    return <Suspense fallback={<div className="canvas-ui-library-empty">正在加载画布...</div>}><CanvasPageContent /></Suspense>;
}

function CanvasPageContent() {
    const { message } = App.useApp();
    const router = useRouter();
    const inputRef = useRef<HTMLInputElement>(null);
    const hydrated = useCanvasStore((state) => state.hydrated);
    const projects = useCanvasStore((state) => state.projects);
    const createProject = useCanvasStore((state) => state.createProject);
    const importProject = useCanvasStore((state) => state.importProject);
    const selectedIds = useCanvasUiStore((state) => state.selectedProjectIds);
    const setDeleteIds = useCanvasUiStore((state) => state.setDeleteProjectIds);

    const enterProject = (id: string) => {
        router.push(`/canvas/${id}`);
    };
    const doCreateAndEnter = () => enterProject(createProject(`Novus AI ${useCanvasStore.getState().projects.length + 1}`));
    const pendingCreateRef = useRef(false);
    const createAndEnter = () => {
        // 数据未水合时创建会被水合竞态冲掉：先挂起，水合完成自动创建并进入
        if (!hydrated) {
            pendingCreateRef.current = true;
            message.loading({ content: "画布数据正在加载，完成后自动进入新画布...", key: "canvas-create", duration: 0 });
            return;
        }
        doCreateAndEnter();
    };
    useEffect(() => {
        if (hydrated && pendingCreateRef.current) {
            pendingCreateRef.current = false;
            message.destroy("canvas-create");
            doCreateAndEnter();
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [hydrated]);
    const importCanvas = async (file?: File) => {
        if (!file) return;
        try {
            const zip = await readZip(file);
            const projectFile = zip.get("projects.json");
            if (!projectFile) throw new Error("missing projects.json");
            const data = JSON.parse(await projectFile.text()) as CanvasExportFile;
            await Promise.all(
                data.projects.flatMap((project) =>
                    project.files.map(async (item) => {
                        const blob = zip.get(item.path);
                        if (!blob) return;
                        const typedBlob = blob.type ? blob : blob.slice(0, blob.size, item.mimeType);
                        await (item.storageKey.startsWith("image:") ? setImageBlob(item.storageKey, typedBlob) : setMediaBlob(item.storageKey, typedBlob));
                    }),
                ),
            );
            data.projects.forEach((item) => importProject(item.project));
            message.success(`已导入 ${data.projects.length} 个画布`);
        } catch {
            message.error("导入失败，请选择有效的画布压缩包");
        } finally {
            if (inputRef.current) inputRef.current.value = "";
        }
    };

    const searchParams = useSearchParams();
    const embedded = searchParams.get("embedded") === "1";
    const libraryView = searchParams.get("view") === "library";
    if (embedded && !libraryView) {
        return <CanvasPreviewHomeForEmbedded createAndEnter={createAndEnter} />;
    }
    return <>
        <CanvasPreviewLibrary projects={projects} hydrated={hydrated} inputRef={inputRef} importCanvas={importCanvas} createAndEnter={createAndEnter} embedded={embedded} />
        <CanvasDeleteProjectsDialog />
        <CanvasTrashDialog />
    </>;
}

function CanvasPreviewHomeForEmbedded({ createAndEnter }: { createAndEnter: () => void }) {
    return <CanvasPreviewHome embedded composer={<div className="canvas-ui-embedded-note">点击下方“创建空白画布”进入编辑器。画布内原有提示词、节点、连线和生成逻辑继续保留。</div>} composerOpen={false} onOpenComposer={createAndEnter} onCloseComposer={() => undefined} onCreateBlank={createAndEnter} />;
}
