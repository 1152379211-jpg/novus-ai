export const CANVAS_GRID_SIZE = 28;

// Snap the whole selection by its top-left anchor, preserving relative positions.
// Threshold-based: only magnetize to the grid when the anchor is within `threshold`
// canvas px of a grid line, otherwise move freely (avoids the jumpy 48px-stepping feel).
export function snapCanvasDragDelta(positions: readonly { x: number; y: number }[], dx: number, dy: number, enabled: boolean, threshold = 12) {
    if (!enabled || !positions.length) return { x: dx, y: dy };
    const left = Math.min(...positions.map((position) => position.x));
    const top = Math.min(...positions.map((position) => position.y));
    const targetLeft = Math.round((left + dx) / CANVAS_GRID_SIZE) * CANVAS_GRID_SIZE;
    const targetTop = Math.round((top + dy) / CANVAS_GRID_SIZE) * CANVAS_GRID_SIZE;
    return {
        x: Math.abs(targetLeft - (left + dx)) <= threshold ? targetLeft - left : dx,
        y: Math.abs(targetTop - (top + dy)) <= threshold ? targetTop - top : dy,
    };
}
