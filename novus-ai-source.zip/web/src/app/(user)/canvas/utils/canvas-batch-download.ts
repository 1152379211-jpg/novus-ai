"use client";

/**
 * 024（boss 2026-10-04）：统一批量下载策略
 *   1. 5 个以内（含 5）：正常一个一个下载（逐个触发，带小间隔避免浏览器拦截连续下载）
 *   2. 5 个以上：直接下载压缩包（zip）
 * 全站所有「批量下载」入口（多选工具栏 / 组工具栏 / 生成历史等）共用这一套口径。
 */

import { saveAs } from "file-saver";
import { zip } from "fflate";
import { message as antdMessage } from "antd";

/** 触发打包成 zip 的阈值：> 该数量走压缩包，否则逐个下载 */
export const BATCH_DOWNLOAD_ZIP_THRESHOLD = 5;

/**
 * zip 压缩级别（fflate 参数）：
 *   level: 0 = 只打包不压缩（媒体文件用这个，几乎零 CPU、秒出，压缩率本来就接近 0）
 *   level: 1~9 = deflate 压缩，1 最快压缩比最低、9 最慢压缩比最高
 * boss 若要「压缩包可以调整」，改这一个常量即可（当前默认 0）。
 */
const ZIP_DEFLATE_LEVEL = 0;

export type BatchDownloadItem = {
    /** 节点 / 条目 id，仅用于排序与去重 */
    id: string;
    /** 落盘文件名（zip 内的文件名） */
    label: string;
    /** 可下载地址（blob / data / http / intl-canvas 协议都行） */
    url: string;
};

function safeFileName(name: string): string {
    return String(name || "asset").replace(/[\\/:*?"<>|]+/g, "_").slice(0, 120);
}

// 029：单个文件拉取超时——视频/大图卡住时不能无限等（此前「点了没反应」多是这里静默挂死）
const FETCH_TIMEOUT_MS = 45_000;

async function fetchToArrayBuffer(url: string): Promise<Uint8Array> {
    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
    try {
        const response = await fetch(url, { signal: controller.signal });
        if (!response.ok) throw new Error(`下载失败: ${response.status}`);
        return new Uint8Array(await response.arrayBuffer());
    } finally {
        window.clearTimeout(timer);
    }
}

function zipBlob(entries: { name: string; data: Uint8Array }[]): Promise<Blob> {
    return new Promise((resolve, reject) => {
        zip(entries, { level: ZIP_DEFLATE_LEVEL }, (error, data) => {
            if (error) { reject(error); return; }
            resolve(new Blob([data], { type: "application/zip" }));
        });
    });
}

// 064：嵌入宿主（Novus AI 外壳）时优先走主进程打包——零浏览器内存，3GB 视频也不卡；
// 协议地址（intl-canvas://）在浏览器下载机制里本来就无效，主进程直接读盘才是正路。
function embeddedInHost(): boolean {
    return typeof window !== "undefined" && window.parent !== window;
}

async function hostBatchDownload(items: BatchDownloadItem[], prefix: string): Promise<boolean> {
    if (!embeddedInHost() || !items.length) return false;
    const requestId = `batch-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    return new Promise<boolean>((resolve) => {
        let hide = antdMessage.loading(`宿主打包中（0/${items.length}）…`, 0);
        let settled = false;
        const finish = (result: boolean) => {
            if (settled) return;
            settled = true;
            window.clearTimeout(timer);
            window.removeEventListener("message", onMessage);
            hide();
            resolve(result);
        };
        const onMessage = (event: MessageEvent) => {
            const data = (event.data || {}) as { source?: string; type?: string; payload?: Record<string, unknown> };
            if (data?.source !== "kinglevel-host") return;
            const payload = (data.payload || {}) as Record<string, unknown>;
            if (data.type === "batch-download-progress" && payload.requestId === requestId) {
                hide();
                hide = antdMessage.loading(`宿主打包中（${Number(payload.done ?? 0)}/${Number(payload.total ?? items.length)}）…`, 0);
            } else if (data.type === "batch-download-result" && payload.requestId === requestId) {
                if (payload.ok) {
                    const count = Number(payload.count ?? items.length);
                    const skipped = Number(payload.skipped ?? 0);
                    antdMessage.success(`已保存压缩包（${count} 个文件${skipped ? `，跳过 ${skipped} 个` : ""}）`);
                    finish(true);
                } else if (payload.cancelled) {
                    finish(true); // 用户在保存对话框点了取消，不算失败
                } else {
                    antdMessage.error(`宿主打包失败：${String(payload.message || "未知错误")}`);
                    finish(false);
                }
            }
        };
        const timer = window.setTimeout(() => {
            if (settled) return;
            antdMessage.warning("宿主打包超时，改用浏览器方式下载");
            finish(false);
        }, 15 * 60_000);
        window.addEventListener("message", onMessage);
        const defaultName = `${prefix}-${new Date().toISOString().slice(0, 10)}`;
        window.parent.postMessage(
            { source: "kinglevel-canvas", type: "batch-download-request", payload: { requestId, defaultName, items: items.map((item) => ({ url: item.url, name: item.label })) } },
            "*",
        );
    });
}

/**
 * 批量下载入口：按数量自动选择「逐个下载」或「打包 zip」
 * @param items 待下载条目
 * @param prefix zip 文件名前缀（可选）
 */
export async function downloadBatchItems(items: BatchDownloadItem[], prefix = "canvas"): Promise<void> {
    const list = (items || []).filter((item) => Boolean(item?.url)).filter((item, index, self) => self.findIndex((exist) => exist.id === item.id) === index);
    if (!list.length) return;

    // 064：嵌入宿主时一切批量下载（不论几个）都走主进程打包——浏览器 saveAs 对 intl-canvas:// 协议无效，
    // 且浏览器内存打包大数据必卡死。失败/超时才回退下面的浏览器老路径。
    if (await hostBatchDownload(list, prefix)) return;

    const total = list.length;
    if (total <= BATCH_DOWNLOAD_ZIP_THRESHOLD) {
        // 逐个下载：每个间隔 180ms，避免浏览器判定连续下载弹窗拦截
        list.forEach((item, index) => {
            window.setTimeout(() => {
                try { saveAs(item.url, safeFileName(item.label)); } catch { /* 静默：单个失败不影响其余 */ }
            }, index * 180);
        });
        return;
    }

    // 打包 zip：029 重写——进度可见、单个失败自动回退逐个下载，绝不再静默无反应
    let hide = antdMessage.loading(`正在打包 ${total} 个文件（0/${total}）…`, 0);
    const entries: { name: string; data: Uint8Array }[] = [];
    const failedItems: BatchDownloadItem[] = [];
    const usedNames = new Set<string>();
    let done = 0;
    for (const item of list) {
        try {
            let name = safeFileName(item.label);
            let serial = 2;
            while (usedNames.has(name)) {
                name = safeFileName(item.label).replace(/(\.[^.]*)?$/, (ext) => `-${serial}${ext || ""}`);
                serial += 1;
            }
            usedNames.add(name);
            entries.push({ name, data: await fetchToArrayBuffer(item.url) });
        } catch {
            failedItems.push(item);
        }
        done += 1;
        hide();
        hide = antdMessage.loading(`正在打包 ${total} 个文件（${done}/${total}）…`, 0);
    }
    hide();
    if (entries.length) {
        try {
            const blob = await zipBlob(entries);
            saveAs(blob, `${prefix}-${total}-files-${new Date().toISOString().replace(/[:.]/g, "-")}.zip`);
            antdMessage.success(`已打包下载 ${entries.length} 个文件`);
        } catch (error) {
            // zip 打包本身失败（内存不足等）：全部回退逐个下载
            antdMessage.error("压缩包打包失败，已改为逐个下载");
            failedItems.push(...list.filter((item) => !failedItems.includes(item)));
        }
    }
    // 拉取失败 / 打包失败的文件：回退为逐个下载，保证用户一定能拿到文件
    if (failedItems.length) {
        antdMessage.warning(`${failedItems.length} 个文件未能入包，已改为单独下载`);
        failedItems.forEach((item, index) => {
            window.setTimeout(() => {
                try { saveAs(item.url, safeFileName(item.label)); } catch { /* 静默 */ }
            }, index * 250);
        });
    }
}
