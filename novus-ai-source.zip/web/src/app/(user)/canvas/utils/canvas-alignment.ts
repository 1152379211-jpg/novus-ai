// Alignment guides: while dragging nodes, snap to other nodes' edges/centers and
// report the guide line positions (world coordinates) for rendering.

export interface AlignBox {
    id: string;
    x: number;
    y: number;
    width: number;
    height: number;
}

export interface AlignmentSnapResult {
    dx: number;
    dy: number;
    vLines: number[];
    hLines: number[];
}

interface EdgeCandidates {
    vertical: number[];
    horizontal: number[];
}

function edgesOf(box: AlignBox): EdgeCandidates {
    return {
        vertical: [box.x, box.x + box.width / 2, box.x + box.width],
        horizontal: [box.y, box.y + box.height / 2, box.y + box.height],
    };
}

// Compute the best alignment per axis against other nodes, and snap the delta to it.
export function computeAlignmentSnap(
    draggedBoxes: readonly AlignBox[],
    dx: number,
    dy: number,
    otherNodes: readonly AlignBox[],
    threshold: number,
): AlignmentSnapResult {
    const vLines: number[] = [];
    const hLines: number[] = [];
    if (!draggedBoxes.length || !otherNodes.length || threshold <= 0) return { dx, dy, vLines, hLines };

    const left = Math.min(...draggedBoxes.map((box) => box.x)) + dx;
    const right = Math.max(...draggedBoxes.map((box) => box.x + box.width)) + dx;
    const centerX = (left + right) / 2;
    const top = Math.min(...draggedBoxes.map((box) => box.y)) + dy;
    const bottom = Math.max(...draggedBoxes.map((box) => box.y + box.height)) + dy;
    const centerY = (top + bottom) / 2;

    let bestV: { diff: number; line: number } | null = null;
    let bestH: { diff: number; line: number } | null = null;

    for (const other of otherNodes) {
        const edges = edgesOf(other);
        for (const draggedX of [left, centerX, right]) {
            for (const otherX of edges.vertical) {
                const diff = otherX - draggedX;
                if (Math.abs(diff) <= threshold && (!bestV || Math.abs(diff) < Math.abs(bestV.diff))) {
                    bestV = { diff, line: otherX };
                }
            }
        }
        for (const draggedY of [top, centerY, bottom]) {
            for (const otherY of edges.horizontal) {
                const diff = otherY - draggedY;
                if (Math.abs(diff) <= threshold && (!bestH || Math.abs(diff) < Math.abs(bestH.diff))) {
                    bestH = { diff, line: otherY };
                }
            }
        }
    }

    if (bestV) {
        dx += bestV.diff;
        vLines.push(bestV.line);
    }
    if (bestH) {
        dy += bestH.diff;
        hLines.push(bestH.line);
    }
    return { dx, dy, vLines, hLines };
}
