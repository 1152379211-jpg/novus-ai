"use client";

export function fitNodeSize(width: number, height: number, maxWidth = 640, maxHeight = 640) {
    const w = Math.max(1, width);
    const h = Math.max(1, height);
    const scale = Math.min(1, maxWidth / w, maxHeight / h);
    return { width: w * scale, height: h * scale };
}

/** 媒体节点统一长边：同比例的节点尺寸恒定（16:9=420×236，9:16=236×420，1:1=420×420） */
export const MEDIA_NODE_LONG_SIDE = 420;

/**
 * 把任意原始尺寸归一化成统一的媒体节点尺寸：长边固定为 MEDIA_NODE_LONG_SIDE，短边按比例缩放。
 * 无论素材本身多大（1080×1920 还是 720×1280），9:16 一律 236×420，16:9 一律 420×236。
 */
export function normalizeNodeSize(width: number, height: number, longSide = MEDIA_NODE_LONG_SIDE) {
    const w = Math.max(1, width);
    const h = Math.max(1, height);
    const scale = longSide / Math.max(w, h);
    return { width: Math.round(w * scale), height: Math.round(h * scale) };
}

export function nodeSizeFromRatio(size: string, baseWidth: number, baseHeight: number) {
    const match = size?.match(/^(\d+)(?:x|:)(\d+)/);
    if (!match) return null;
    const width = Number(match[1]);
    const height = Number(match[2]);
    const ratio = width / Math.max(1, height);
    if (ratio < 0.25 || ratio > 4) return null;
    // 同样走统一归一化：按比例参数建出的节点与导入素材的节点尺寸一致
    return normalizeNodeSize(width, height);
}
