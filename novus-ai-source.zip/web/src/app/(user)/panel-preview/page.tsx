"use client";

/** 临时预览路由：真实挂载 CanvasNodePromptPanel，用于截图核对 UI（核对完删除） */
import { useState } from "react";
import { CanvasNodeType, type CanvasNodeData } from "../canvas/types";
import { CanvasNodePromptPanel } from "../canvas/components/canvas-node-prompt-panel";

const FAKE_NODE: CanvasNodeData = {
    id: "preview-video-node",
    type: CanvasNodeType.Video,
    title: "视频节点 1",
    position: { x: 0, y: 0 },
    width: 420,
    height: 236,
    metadata: { status: "idle", size: "16:9", vquality: "720", seconds: "5", generationMode: "text" },
};

export default function PanelPreviewPage() {
    const [prompt, setPrompt] = useState("");
    return (
        <main className="flex min-h-screen items-center justify-center" style={{ background: "#141414" }}>
            <div style={{ width: 660, padding: 24 }}>
                <div
                    className="flex items-center justify-center rounded-xl"
                    style={{ height: 236, background: "#262626", border: "0.5px solid rgba(255,255,255,.14)", marginBottom: 20 }}
                >
                    <span style={{ color: "#666" }}>（上方模拟视频节点）</span>
                </div>
                <CanvasNodePromptPanel
                    node={FAKE_NODE}
                    isRunning={false}
                    onPromptChange={(_id: string, value: string) => setPrompt(value)}
                    onConfigChange={() => undefined}
                    onGenerate={() => undefined}
                    mentionReferences={[]}
                    connectedNodes={[]}
                    videoFrameOptions={[]}
                    videoResourceOptions={[]}
                    onDisconnectReference={() => undefined}
                    onReorderReference={() => undefined}
                    onStartReferenceSelection={() => undefined}
                    onImageSettingsOpenChange={() => undefined}
                />
                <p style={{ color: "#555", fontSize: 12, marginTop: 12 }}>prompt: {prompt || "（空）"}</p>
            </div>
        </main>
    );
}
